// Filament picker: brand -> type -> colour (named, common/special, or a colour wheel), plus the look
// (solid, matte, silk, metal, translucent, clear, glow, sparkle, galaxy, marble, wood) and gradient / multicolour.
import { swatchCss } from './swatch.js';
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const COMMON = [
  ['White', '#FFFFFF'], ['Black', '#000000'], ['Grey', '#8E9089'], ['Silver', '#A6A9AA'], ['Red', '#C12E1F'], ['Orange', '#FF6A13'],
  ['Yellow', '#F4EE2A'], ['Lime', '#BECF00'], ['Green', '#00AE42'], ['Dark green', '#164B35'], ['Cyan', '#0086D6'], ['Blue', '#0A2989'],
  ['Purple', '#5E43B7'], ['Pink', '#F55A74'], ['Hot pink', '#FF80FF'], ['Brown', '#9D432C'], ['Beige', '#F7E6DE'], ['Navy', '#042F56'], ['Teal', '#00807F'],
];
const SPECIAL = [  // [name, colours, look, gradient/multi]
  ['Clear', ['#F0F0F040'], 'clear'], ['Translucent red', ['#C12E1F99'], 'translucent'], ['Translucent blue', ['#0086D699'], 'translucent'],
  ['Glow green', ['#A1FFAC'], 'glow'], ['Glow blue', ['#7AC0E9'], 'glow'], ['Glow orange', ['#FF9D5B'], 'glow'],
  ['Gold metal', ['#E4BD68'], 'metal'], ['Silver metal', ['#A6A9AA'], 'metal'], ['Copper metal', ['#B87333'], 'metal'],
  ['Silk gold', ['#F4A925'], 'silk'], ['Galaxy black', ['#1A1A2E'], 'galaxy'], ['Wood', ['#B8865B'], 'wood'], ['Marble white', ['#E8E8E8'], 'marble'],
  ['Rainbow', ['#FF0000', '#FFFF00', '#00FF00', '#0000FF'], 'silk', 'gradient'], ['Sunset', ['#FF6A13', '#F55A74'], 'solid', 'gradient'],
  ['Red / blue', ['#C12E1F', '#0A2989'], 'silk', 'multi'], ['Black / white', ['#000000', '#FFFFFF'], 'solid', 'multi'],
];
const LOOKS = [['solid', 'Solid'], ['matte', 'Matte'], ['silk', 'Silk'], ['metal', 'Metal'], ['translucent', 'Translucent'], ['clear', 'Clear'],
  ['glow', 'Glow in the dark'], ['sparkle', 'Sparkle'], ['galaxy', 'Galaxy'], ['marble', 'Marble'], ['wood', 'Wood']];
const lookOf = name => { const n = String(name || '').toLowerCase(); for (const [k] of LOOKS) if (k !== 'solid' && n.includes(k === 'glow' ? 'glow' : k)) return k; if (n.includes('transparent')) return 'clear'; return 'solid'; };
let data = null, st = null, resolveFn = null;

export async function pickFilament(api, opts = {}) {
  if (!data) data = await api.filament_catalog();
  const cols = (opts.colors && opts.colors.length ? opts.colors : [opts.color || '#FFFFFF']).map(c => String(c).toUpperCase());
  st = { brand: null, item: null, colors: cols, stop: 0, ctype: opts.ctype || (cols.length > 1 ? 'gradient' : 'single'), effect: opts.effect || 'solid', q: '', named: null };
  $('pkTitle').textContent = opts.title || 'Pick a filament';
  $('pkUse').textContent = opts.useText || 'Use this filament';
  if (opts.preset) {
    for (const b of data.catalog) { const it = b.items.find(i => i.preset === opts.preset || i.name === String(opts.preset).split(' @')[0]); if (it) { st.brand = b.brand; st.item = it; break; } }
  }
  if (!st.item && opts.id) {     // e.g. what an AMS slot says it holds (a filament id like GFSNL04)
    for (const b of data.catalog) { if (b.brand === 'Your filaments') continue; const it = b.items.find(i => i.id === opts.id); if (it) { st.brand = b.brand; st.item = it; break; } }
  }
  if (!st.brand) st.brand = (data.catalog.find(b => b.brand === 'Bambu Lab') || data.catalog[0] || {}).brand;
  $('pkSearch').value = ''; render(); drawWheel();
  $('picker').classList.remove('hidden'); setTimeout(() => $('pkSearch').focus(), 50);
  return new Promise(r => resolveFn = r);
}
function close(v) { $('picker').classList.add('hidden'); if (resolveFn) { const r = resolveFn; resolveFn = null; r(v); } }
function matches(it, b) { const q = st.q.trim().toLowerCase(); if (!q) return true; const hay = (b + ' ' + it.name + ' ' + it.type + ' ' + lookOf(it.name)).toLowerCase(); return q.split(/\s+/).every(w => hay.includes(w)); }
const cur = () => st.colors[Math.min(st.stop, st.colors.length - 1)];
function setCur(hex, keepAlpha = true) {
  const old = cur(); let h = hex.toUpperCase();
  if (keepAlpha && h.length === 7 && old.length === 9) h += old.slice(7);
  st.colors[Math.min(st.stop, st.colors.length - 1)] = h; st.named = null;
}
const look = () => ({ colors: st.ctype === 'single' ? [st.colors[0]] : st.colors, ctype: st.ctype, effect: st.effect, color: st.colors[0] });

function render() {
  const cat = data.catalog;
  const brands = cat.filter(b => b.items.some(it => matches(it, b.brand)));
  if (st.q && !brands.find(b => b.brand === st.brand) && brands.length) st.brand = brands[0].brand;
  $('pkBrands').innerHTML = brands.map(b => `<div class="${b.brand === st.brand ? 'on' : ''}" data-b="${esc(b.brand)}">${esc(b.brand)} <span class="t">${b.items.filter(it => matches(it, b.brand)).length}</span></div>`).join('') || '<div class="t">Nothing matches.</div>';
  $('pkBrands').querySelectorAll('[data-b]').forEach(el => el.onclick = () => { st.brand = el.dataset.b; render(); });
  const b = cat.find(x => x.brand === st.brand) || { items: [] };
  const items = b.items.filter(it => matches(it, b.brand));
  $('pkTypes').innerHTML = items.map((it, i) => `<div class="${st.item && st.item.preset === it.preset ? 'on' : ''}" data-i="${i}">${esc(it.name)}${lookOf(it.name) !== 'solid' ? ` <span class="t">· ${esc(LOOKS.find(l => l[0] === lookOf(it.name))[1])}</span>` : ''}<br><span class="t">${esc(it.type)} · ${it.tmin}-${it.tmax} °C</span></div>`).join('') || '<div class="t">Pick a brand.</div>';
  const on = $('pkTypes').querySelector('.on'); if (on && !st.scrolled) { on.scrollIntoView({ block: 'center' }); st.scrolled = true; }
  $('pkTypes').querySelectorAll('[data-i]').forEach(el => el.onclick = () => {
    st.item = items[+el.dataset.i]; st.effect = lookOf(st.item.name);
    const named = data.colors[st.item.id] || [];
    if (named.length) pickNamed(named[0]); else render();
  });
  // official named colours (Bambu), including their gradient / multicolour / see-through ones
  const named = st.item ? (data.colors[st.item.id] || []) : [];
  $('pkNamed').innerHTML = named.length ? named.map((n, i) => `<span class="sw ${st.named === n ? 'on' : ''}" title="${esc(n.name)}${n.ctype !== 'single' ? ' (' + n.ctype + ')' : ''}" data-n="${i}" style="${swatchCss({ colors: n.colors && n.colors.length ? n.colors : [n.color], ctype: n.ctype, effect: lookOf(st.item.name) })}"></span>`).join('')
    : `<span class="dim small">${st.item ? 'No official colour list for this one: use the colours below or the wheel.' : 'Pick a type to see its official colours.'}</span>`;
  $('pkNamed').querySelectorAll('[data-n]').forEach(el => el.onclick = () => pickNamed(named[+el.dataset.n]));
  $('pkCommon').innerHTML = COMMON.map(([n, c]) => `<span class="sw" title="${n}" data-c="${c}" style="${swatchCss({ colors: [c], effect: 'solid' })}"></span>`).join('') +
    SPECIAL.map(([n, cs, eff, ct], i) => `<span class="sw" title="${n}" data-s="${i}" style="${swatchCss({ colors: cs, ctype: ct || 'single', effect: eff })}"></span>`).join('');
  $('pkCommon').querySelectorAll('[data-c]').forEach(el => el.onclick = () => { setCur(el.dataset.c, false); render(); drawWheel(); });
  $('pkCommon').querySelectorAll('[data-s]').forEach(el => el.onclick = () => { const [, cs, eff, ct] = SPECIAL[+el.dataset.s]; st.colors = cs.slice(); st.effect = eff; st.ctype = ct || (cs.length > 1 ? 'gradient' : 'single'); st.stop = 0; st.named = null; render(); drawWheel(); });
  $('pkLook').innerHTML = LOOKS.map(([k, n]) => `<button class="${st.effect === k ? 'on' : ''}" data-l="${k}">${n}</button>`).join('');
  $('pkLook').querySelectorAll('[data-l]').forEach(el => el.onclick = () => { st.effect = el.dataset.l; if (st.effect === 'clear' || st.effect === 'translucent') { if (+$('pkAlpha').value === 0) { st.colors = st.colors.map(c => c.slice(0, 7) + (st.effect === 'clear' ? '40' : '99')); } } render(); drawWheel(); });
  $('pkMode').value = st.ctype;
  $('pkStops').innerHTML = st.ctype === 'single' ? '' : st.colors.map((c, i) => `<span class="sw ${i === st.stop ? 'on' : ''}" data-k="${i}" title="Colour ${i + 1}: click, then pick it below" style="${swatchCss({ colors: [c], effect: st.effect })}"></span>`).join('') +
    (st.colors.length < 4 ? '<button id="pkAddStop" title="Add a colour">+</button>' : '') + (st.colors.length > 2 ? '<button id="pkDelStop" title="Remove the selected colour">−</button>' : '') +
    `<span class="dim small">${st.ctype === 'gradient' ? 'fades from one colour to the next' : 'changes colour in stripes'}</span>`;
  $('pkStops').querySelectorAll('[data-k]').forEach(el => el.onclick = () => { st.stop = +el.dataset.k; render(); drawWheel(); });
  if ($('pkAddStop')) $('pkAddStop').onclick = () => { st.colors.push(st.colors[st.colors.length - 1]); st.stop = st.colors.length - 1; render(); drawWheel(); };
  if ($('pkDelStop')) $('pkDelStop').onclick = () => { st.colors.splice(st.stop, 1); st.stop = Math.max(0, st.stop - 1); render(); drawWheel(); };
  $('pkHex').value = cur().slice(0, 7);
  $('pkBig').style.cssText = swatchCss(look());
  const nm = st.named ? st.named.name : (COMMON.find(c => c[1] === cur().slice(0, 7)) || [])[0] || cur().slice(0, 7);
  const lk = LOOKS.find(l => l[0] === st.effect)[1];
  $('pkChosen').innerHTML = st.item ? `<span class="sw" style="${swatchCss(look())};width:18px;height:18px;vertical-align:middle;display:inline-block"></span> ${esc(st.brand)} · <b>${esc(st.item.name)}</b> · ${esc(nm)}${st.ctype !== 'single' ? ' · ' + st.ctype : ''}${st.effect !== 'solid' ? ' · ' + lk : ''}` : '<span class="dim">Pick a brand and a type.</span>';
  $('pkUse').disabled = !st.item;
}
function pickNamed(n) {
  st.named = n;
  const cs = (n.colors && n.colors.length ? n.colors : [n.color]).map(c => c.toUpperCase());
  st.colors = cs; st.stop = 0; st.ctype = cs.length > 1 ? (n.ctype === 'multi' ? 'multi' : 'gradient') : 'single';
  if (cs[0].length === 9 && !cs[0].endsWith('FF') && st.effect === 'solid') st.effect = 'translucent';
  render(); drawWheel();
}
$('pkMode').onchange = () => { st.ctype = $('pkMode').value; if (st.ctype !== 'single' && st.colors.length < 2) st.colors.push(st.colors[0] === '#FFFFFF' ? '#0086D6' : '#FFFFFF'); if (st.ctype === 'single') { st.colors = [st.colors[0]]; st.stop = 0; } render(); drawWheel(); };

// ---------------------------------------------------------------- the colour wheel (hue around, saturation outwards)
function hsv2rgb(h, s, v) { const f = n => { const k = (n + h / 60) % 6; return v - v * s * Math.max(0, Math.min(k, 4 - k, 1)); }; return [f(5), f(3), f(1)].map(x => Math.round(x * 255)); }
function rgb2hsv(r, g, b) { r /= 255; g /= 255; b /= 255; const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn; let h = 0;
  if (d) h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h = (h * 60 + 360) % 360; return [h, mx ? d / mx : 0, mx]; }
const hex2rgb = h => { const n = parseInt(h.slice(1, 7), 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
const rgb2hex = (r, g, b) => '#' + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('').toUpperCase();
function drawWheel() {
  const cv = $('pkWheel'), ctx = cv.getContext('2d'), W = cv.width, R = W / 2;
  const [h, s, v] = rgb2hsv(...hex2rgb(cur()));
  if (document.activeElement !== $('pkVal')) $('pkVal').value = Math.round(v * 100);
  const a = cur().length === 9 ? parseInt(cur().slice(7, 9), 16) : 255;
  if (document.activeElement !== $('pkAlpha')) $('pkAlpha').value = Math.round((1 - a / 255) * 100);
  const img = ctx.createImageData(W, W), vv = +$('pkVal').value / 100;
  for (let y = 0; y < W; y++) for (let x = 0; x < W; x++) {
    const dx = x - R, dy = y - R, d = Math.hypot(dx, dy), i = (y * W + x) * 4;
    if (d > R) { img.data[i + 3] = 0; continue; }
    const hue = (Math.atan2(dx, -dy) * 180 / Math.PI + 360) % 360;      // red at the top, like your picture
    const [r, g, b] = hsv2rgb(hue, Math.min(1, d / R), vv);
    img.data[i] = r; img.data[i + 1] = g; img.data[i + 2] = b; img.data[i + 3] = d > R - 1 ? Math.round((R - d) * 255) : 255;
  }
  ctx.putImageData(img, 0, 0);
  const ang = h * Math.PI / 180, px = R + Math.sin(ang) * s * R, py = R - Math.cos(ang) * s * R;
  ctx.beginPath(); ctx.arc(px, py, 7, 0, Math.PI * 2); ctx.lineWidth = 3; ctx.strokeStyle = '#fff'; ctx.stroke(); ctx.lineWidth = 1; ctx.strokeStyle = '#000'; ctx.stroke();
}
let wheelDrag = false;
function fromWheel(e) {
  const cv = $('pkWheel'), r = cv.getBoundingClientRect(), k = cv.width / r.width, R = cv.width / 2;
  const dx = (e.clientX - r.left) * k - R, dy = (e.clientY - r.top) * k - R;
  const hue = (Math.atan2(dx, -dy) * 180 / Math.PI + 360) % 360, sat = Math.min(1, Math.hypot(dx, dy) / R);
  setCur(rgb2hex(...hsv2rgb(hue, sat, +$('pkVal').value / 100))); render(); drawWheel();
}
$('pkWheel').addEventListener('pointerdown', e => { wheelDrag = true; $('pkWheel').setPointerCapture(e.pointerId); fromWheel(e); });
$('pkWheel').addEventListener('pointermove', e => { if (wheelDrag) fromWheel(e); });
$('pkWheel').addEventListener('pointerup', () => wheelDrag = false);
$('pkVal').oninput = () => { const [h, s] = rgb2hsv(...hex2rgb(cur())); setCur(rgb2hex(...hsv2rgb(h, s, +$('pkVal').value / 100))); render(); drawWheel(); };
$('pkAlpha').oninput = () => { const a = Math.round(255 * (1 - +$('pkAlpha').value / 100)); setCur(cur().slice(0, 7) + a.toString(16).padStart(2, '0').toUpperCase(), false);
  if (a < 255 && st.effect === 'solid') st.effect = 'translucent'; if (a === 255 && (st.effect === 'translucent' || st.effect === 'clear')) st.effect = 'solid'; render(); };
$('pkSearch').oninput = () => { st.q = $('pkSearch').value; render(); };
$('pkHex').onchange = () => { const v = $('pkHex').value.trim(); if (/^#?[0-9a-f]{6}$/i.test(v)) { setCur('#' + v.replace('#', '')); render(); drawWheel(); } };
$('pkClose').onclick = () => close(null); $('pkCancel').onclick = () => close(null);
$('pkUse').onclick = () => { if (!st.item) return; const L = look();
  close({ preset: st.item.preset, name: st.item.name, type: st.item.type, id: st.item.id, color: L.colors[0].slice(0, 7), colors: L.colors, ctype: L.ctype, effect: L.effect,
          tmin: st.item.tmin, tmax: st.item.tmax, brand: st.brand }); };
window.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('picker').classList.contains('hidden')) close(null); });
