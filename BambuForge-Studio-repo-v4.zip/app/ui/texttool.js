// BambuForge Studio: the text tool (v3).
// - Every text is an object: hover it anywhere to get a hand, drag it to move it (it follows the surface).
// - Changes go onto the model by themselves. While you edit a text, the part is shown WITHOUT that text and the live
//   version is drawn on top, so there's never a ghost of the old one.
// - Letter placement and the real geometry come from the back end; the window only draws, so it stays smooth.
const $ = id => document.getElementById(id);
const X = () => window.studio && window.studio.ctx;
const DEF = { size: 10, spacing: 0, rot: 0, th: 1.2, emb: 0.4, arc: 90, waveH: 2, waveL: 20 };
const MINLEFT = 2.0;
const UNITS = { mm: [1, 200, 0.1, 1, 1], in: [0.04, 7.87, 0.01, 1 / 25.4, 2], pt: [3, 567, 1, 2.835, 0] };   // min,max,step (that unit), mm->unit, decimals
const COMMON = ['#111111', '#FFFFFF', '#C12E1F', '#F4EE2A', '#FF6A13', '#00AE42', '#0086D6', '#0A2989', '#5E43B7', '#F077E8', '#9D432C', '#8E9089', '#E4BD68'];
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const stat = (m, bad) => { const c = X(); if (c) c.status(m, bad); };

let fontsInfo = null, fontTab = 'mine';
let part = -1, items = [], cur = -1;          // the part whose texts we're showing, its texts, the one being edited
let preview = null, ctxMesh = null, ctxFor = null, gen = 0, applying = 0, applyT = null, prevT = null;
let drag = false, thick = {};
const frameCache = new Map();                  // item JSON -> letter outlines + placement (from the back end)
const it = () => items[cur];

// ------------------------------------------------------------------ helpers
function meshOf(i) { const c = X(); return c && c.meshes().find(m => m.userData.id === i); }
function itemKey(t) { return JSON.stringify([t.text, t.font, +t.size, !!t.bold, !!t.italic, !!t.under, +t.spacing, +t.rot, t.path, +t.arc, +t.waveH, +t.waveL, t.style, t.point, t.normal]); }
function wire(t) {   // what the back end needs for one text
  return { text: t.text, font: t.font, bold: !!t.bold, italic: !!t.italic, under: !!t.under, size: +t.size, spacing: +t.spacing, rot: +t.rot,
    style: t.style, th: +t.th, emb: +t.emb, path: t.path, arc: +t.arc, waveH: +t.waveH, waveL: +t.waveL, slot: t.slot, point: t.point, normal: t.normal, allow: !!t.allow };
}
async function placement(t, pid = part) {
  const k = pid + '|' + itemKey(t);
  if (frameCache.has(k)) return frameCache.get(k);
  const L = await X().api().text_preview(pid, wire(t));
  if (L && !L.error) { frameCache.set(k, L); if (frameCache.size > 60) frameCache.delete(frameCache.keys().next().value); }
  return L;
}
function frameOf(T, n, rot) {   // same as the back end: x along the text, y up the letters, z out of the surface
  n = n.clone().normalize();
  const up = Math.abs(n.z) < 0.9 ? new T.Vector3(0, 0, 1) : new T.Vector3(0, 1, 0);
  const x = new T.Vector3().crossVectors(up, n).normalize(), y = new T.Vector3().crossVectors(n, x), a = rot * Math.PI / 180;
  return { x: x.clone().multiplyScalar(Math.cos(a)).addScaledVector(y, Math.sin(a)), y: x.clone().multiplyScalar(-Math.sin(a)).addScaledVector(y, Math.cos(a)), n };
}
function anchorMatrix(T, t) { const F = frameOf(T, new T.Vector3().fromArray(t.normal), t.rot); return new T.Matrix4().makeBasis(F.x, F.y, F.n).setPosition(new T.Vector3().fromArray(t.point)); }
function shapesOf(contours) {
  const T = X().THREE, sp = new T.ShapePath();
  let big = 0, sign = 1;
  contours.forEach(c => { let a = 0; for (let i = 0; i < c.length; i++) { const p = c[i], q = c[(i + 1) % c.length]; a += p[0] * q[1] - q[0] * p[1]; } if (Math.abs(a) > big) { big = Math.abs(a); sign = Math.sign(a); } });
  contours.forEach(c => { sp.moveTo(c[0][0], c[0][1]); for (let i = 1; i < c.length; i++) sp.lineTo(c[i][0], c[i][1]); });
  return sp.toShapes(sign > 0);
}
// the letters of one text as meshes in plate coords (used for the live view and as invisible "handles" for grabbing)
function lettersOf(T, t, L, mat) {
  const g = new T.Group();
  const z = { raise: [0, t.th], flat: [-t.emb, t.th - t.emb], cut: [-0.15, 0.12], through: [-0.15, 0.12] }[t.style] || [0, t.th];
  const pieces = L.glyphs.map(gl => gl.contours); if (L.underline) pieces.push([L.underline]);
  pieces.forEach((contours, i) => {
    const f = L.frames[i]; if (!f) return;
    const shapes = shapesOf(contours); if (!shapes.length) return;
    const geo = new T.ExtrudeGeometry(shapes, { depth: Math.max(0.05, z[1] - z[0]), bevelEnabled: false, curveSegments: 2 }); geo.translate(0, 0, z[0]);
    const n = new T.Vector3().fromArray(f[2]).normalize(), tx = new T.Vector3().fromArray(f[1]); tx.addScaledVector(n, -tx.dot(n)).normalize();
    geo.applyMatrix4(new T.Matrix4().makeBasis(tx, new T.Vector3().crossVectors(n, tx), n).setPosition(new T.Vector3().fromArray(f[0])));
    g.add(new T.Mesh(geo, mat));
  });
  return g;
}

// invisible grab areas covering each letter's whole box (so the gaps between letters and inside an O can be grabbed too)
function hitBoxesOf(T, t, L) {
  const g = new T.Group(), mat = new T.MeshBasicMaterial({ visible: false, side: T.DoubleSide });
  const xs = L.glyphs.map(gl => gl.x);
  L.glyphs.forEach((gl, i) => {
    const f = L.frames[i]; if (!f) return;
    const gapL = i > 0 ? (xs[i] - xs[i - 1]) : gl.w + 2, gapR = i < xs.length - 1 ? (xs[i + 1] - xs[i]) : gl.w + 2;
    const w = Math.max(gl.w, (gapL + gapR) / 2) + 0.5, h = Math.max(2, +t.size) * 1.35;
    const geo = new T.PlaneGeometry(w, h); geo.translate(0, 0, Math.max(0.2, t.style === 'raise' || t.style === 'flat' ? +t.th : 0.2));
    const n = new T.Vector3().fromArray(f[2]).normalize(), tx = new T.Vector3().fromArray(f[1]); tx.addScaledVector(n, -tx.dot(n)).normalize();
    geo.applyMatrix4(new T.Matrix4().makeBasis(tx, new T.Vector3().crossVectors(n, tx), n).setPosition(new T.Vector3().fromArray(f[0])));
    g.add(new T.Mesh(geo, mat));
  });
  return g;
}

// ------------------------------------------------------------------ handles: every saved text can be grabbed, whether or not the panel is open
let handles = new Map();     // part id -> Group of invisible letter meshes (userData.part, userData.item)
let handleSig = '', handleBusy = false;
async function refreshHandles() {
  const c = X(); if (!c || !c.state() || handleBusy) return;
  handleBusy = true;
  try { await refreshHandles2(c); } catch (e) { console.warn('text handles', e); handleSig = ''; } finally { handleBusy = false; }
}
async function refreshHandles2(c) {
  const T = c.THREE;
  const all = await c.api().all_texts(); if (!Array.isArray(all)) return;
  const sig = JSON.stringify(all) + '|' + c.meshes().map(m => m.uuid).join(',');
  if (sig === handleSig) return; handleSig = sig;
  handles.forEach(g => g.parent && g.parent.remove(g)); handles = new Map();
  const byPart = {}; all.forEach(a => (byPart[a.part] = byPart[a.part] || []).push(a));
  for (const pid of Object.keys(byPart)) {
    const m = meshOf(+pid); if (!m) continue;
    const list = await c.api().part_texts(+pid);
    const g = new T.Group(); g.userData.textHandles = true;
    for (let k = 0; k < list.length; k++) {
      const t = { ...DEF, ...list[k] };
      const L = await placement(t, +pid);
      if (!L || L.error) continue;
      const lg = hitBoxesOf(T, t, L); lg.children.forEach(ch => { ch.userData.part = +pid; ch.userData.item = k; });
      g.add(lg);
    }
    m.add(g); handles.set(+pid, g);
  }
}
function handleHit(e) {
  const c = X(); if (!c) return null; const T = c.THREE, el = c.renderer.domElement;
  const r = el.getBoundingClientRect(), ray = new T.Raycaster();
  ray.setFromCamera(new T.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1), c.camera);
  const objs = []; if (preview) objs.push(...preview.children.flatMap(g => g.children));
  handles.forEach(g => g.traverse(o => { if (o.isMesh && o.userData.item !== undefined && !(o.userData.part === part && o.userData.item === cur && preview)) objs.push(o); }));
  const h = ray.intersectObjects(objs, false)[0];
  if (!h) return null;
  if (h.object.userData.part === undefined) return { part, item: cur, live: true };
  return { part: h.object.userData.part, item: h.object.userData.item };
}

// ------------------------------------------------------------------ opening / choosing
async function open(sel) {
  const c = X(); if (!c || !c.state()) return;
  if (!fontsInfo) { fontsInfo = await c.api().fonts_list(); }
  const p = sel && sel.part !== undefined ? sel.part : c.selected();
  if (p !== part) { await endEdit(); part = p; items = []; cur = -1; }
  if (part < 0) { items = []; cur = -1; renderAll(); return; }
  const got = await c.api().part_texts(part);
  const dirty = items.filter(x => x.dirty);
  items = (got || []).map(x => ({ ...DEF, unit: 'mm', allow: false, ...x, saved: true, dirty: false }));
  if (dirty.length && dirty.length === items.length) items = dirty;          // keep unsaved edits if nothing else changed
  cur = sel && sel.item !== undefined ? sel.item : (items.length ? Math.min(Math.max(cur, 0), items.length - 1) : -1);
  renderAll();
}
function defaultFont() {
  const f = (fontsInfo && fontsInfo.families) || [];
  for (const want of ['Arial Black', 'Arial', 'Segoe UI', 'DejaVu Sans', 'Liberation Sans']) if (f.includes(want)) return want;
  return f[0] || 'Arial';
}
function anchorGuess() {   // where the camera looks at the part, else the middle of its top
  const c = X(), m = meshOf(part); if (!m) return null; const T = c.THREE;
  const ray = new T.Raycaster(); ray.setFromCamera(new T.Vector2(0, 0), c.camera);
  let h = ray.intersectObject(m, false)[0];
  if (!h) { const b = new T.Box3().setFromObject(m), ctr = b.getCenter(new T.Vector3()); ray.set(new T.Vector3(ctr.x, ctr.y, b.max.z + 50), new T.Vector3(0, 0, -1)); h = ray.intersectObject(m, false)[0]; }
  if (!h) return null;
  return { point: m.worldToLocal(h.point.clone()).toArray().map(v => +v.toFixed(3)), normal: h.face.normal.toArray().map(v => +v.toFixed(5)) };
}
function addNew() {
  const c = X(); if (part < 0) { stat('Click a part first, then + Add text.', true); return; }
  const a = anchorGuess(); if (!a) { stat("Couldn't find a spot on that part. Turn the view so the part is in the middle.", true); return; }
  const slots = c.state().filaments.slots, used = slots.find(s => s.used) || slots[0], other = slots.find(s => s.slot !== (used && used.slot)) || used;
  items.push({ ...DEF, text: 'TEXT', font: defaultFont(), bold: false, italic: false, under: false, style: 'raise', path: 'straight', unit: 'mm', slot: other ? other.slot : 1, allow: false, ...a, saved: false, dirty: true });
  cur = items.length - 1; renderAll(); changed(250);
  setTimeout(() => { $('ttText').focus(); $('ttText').select(); }, 30);
}
function removeItem(i) {
  const t = items[i]; if (!t) return;
  items.splice(i, 1); cur = Math.min(cur, items.length - 1); clearPreview();
  renderAll(); if (t.saved) applyNow(`Removed text "${t.text}"`);
}

// ------------------------------------------------------------------ panel
function toU(mm) { const u = UNITS[it().unit]; return +(mm * u[3]).toFixed(u[4]); }
function fromU(v) { return v / UNITS[it().unit][3]; }
const SL = [['ttSize', 'size', true], ['ttSp', 'spacing'], ['ttRot', 'rot'], ['ttTh', 'th'], ['ttEmb', 'emb'], ['ttArc', 'arc'], ['ttWH', 'waveH'], ['ttWL', 'waveL']];
function showVals() {
  const t = it(); if (!t) return;
  const u = UNITS[t.unit]; $('ttSize').min = u[0]; $('ttSize').max = u[1]; $('ttSize').step = u[2];
  SL.forEach(([id, key, conv]) => {
    const v = conv ? toU(t[key]) : t[key]; $(id).value = v;
    if (document.activeElement !== $(id + 'N')) $(id + 'N').value = (key === 'rot' || key === 'arc') ? Math.round(v) : (conv ? v : (+v).toFixed(1));
  });
}
function renderChips() {
  const c = X();
  if (part < 0) {   // no part selected: list every text on every part
    c && c.api().all_texts().then(all => {
      if (part >= 0) return;
      $('ttChips').innerHTML = (all || []).map(a => `<div class="ttchip" data-p="${a.part}" data-k="${a.index}" title="${esc(a.part_name)}"><span>${esc(a.text || '(empty)')}</span><span class="dim small" style="margin-left:4px">${esc(a.part_name)}</span></div>`).join('');
      $('ttChips').querySelectorAll('[data-p]').forEach(ch => ch.onclick = () => { c.select(+ch.dataset.p, false); open({ part: +ch.dataset.p, item: +ch.dataset.k }); });
      $('ttNone').innerHTML = (all && all.length ? 'Click a text above, or a part, to edit.' : 'Click a part, then <b>+ Add text</b>.') + ' You can grab any text on the model and drag it.';
    });
    return;
  }
  $('ttChips').innerHTML = items.map((t, i) => `<div class="ttchip ${i === cur ? 'on' : ''}" data-i="${i}" title="${esc(t.text)}"><span>${esc(t.text || '(empty)')}</span><b data-x="${i}" title="Delete this text">✕</b></div>`).join('') +
    `<div class="ttchip" id="ttAddNew" style="color:var(--green2)">+ Add text</div>`;
  $('ttChips').querySelectorAll('[data-i]').forEach(ch => ch.onclick = e => {
    if (e.target.dataset.x !== undefined) { removeItem(+e.target.dataset.x); return; }
    if (cur !== +ch.dataset.i) { endEditView(); cur = +ch.dataset.i; renderAll(); }
  });
  $('ttAddNew').onclick = addNew;
}
function renderAll() {
  renderChips();
  const t = it();
  $('ttNone').classList.toggle('hidden', !!t); $('ttEd').classList.toggle('hidden', !t);
  if (!t) { clearPreview(); return; }
  $('ttText').value = t.text; $('ttFontName').textContent = t.font; $('ttFontName').style.fontFamily = `'${t.font}'`; $('ttUnit').value = t.unit;
  $('ttB').classList.toggle('on', !!t.bold); $('ttI').classList.toggle('on', !!t.italic); $('ttU').classList.toggle('on', !!t.under);
  document.querySelectorAll('#ttStyle span').forEach(s => s.classList.toggle('on', s.dataset.v === t.style));
  document.querySelectorAll('#ttPath span').forEach(s => s.classList.toggle('on', s.dataset.v === t.path));
  $('ttThL').textContent = t.style === 'cut' ? 'Depth' : 'Thickness';
  $('ttThRow').classList.toggle('hidden', t.style === 'through');
  $('ttEmbRow').classList.toggle('hidden', t.style !== 'flat');
  $('ttArcRow').classList.toggle('hidden', t.path !== 'arc');
  ['ttWHRow', 'ttWLRow'].forEach(r => $(r).classList.toggle('hidden', t.path !== 'wave'));
  const slot = X().state().filaments.slots.find(s => s.slot === t.slot);
  $('ttColSw').style.background = slot ? slot.color : '#888'; $('ttColName').textContent = slot ? `${slot.slot} · ${slot.name}` : `Colour ${t.slot}`;
  $('ttColRow').classList.toggle('hidden', t.style === 'cut' || t.style === 'through');
  showVals(); checkDepth();
  if (t.dirty || !t.saved) rebuildSoon(0); else clearPreview();
}

// any change to the current text: draw it now, put it on the model as soon as you pause
function changed(ms = 450) {
  const t = it(); if (!t) return;
  t.dirty = true; startEditView(); rebuildSoon(60); applySoon(ms);
}
function bind() {
  SL.forEach(([id, key, conv]) => {
    const r = $(id), n = $(id + 'N');
    r.oninput = () => { if (!it()) return; it()[key] = conv ? fromU(+r.value) : +r.value; n.value = r.value; changed(500); };
    n.onchange = () => { if (!it()) return; let v = parseFloat(n.value); if (!isFinite(v)) { showVals(); return; } v = Math.min(+r.max, Math.max(+r.min, v)); it()[key] = conv ? fromU(v) : v; showVals(); changed(150); };
    n.onkeydown = e => { if (e.key === 'Enter') n.blur(); };
  });
  document.querySelectorAll('#tt .trs').forEach(b => b.onclick = () => { if (!it()) return; it()[b.dataset.r] = DEF[b.dataset.r]; showVals(); changed(150); });
  $('ttText').oninput = () => { if (!it()) return; it().text = $('ttText').value; renderChips(); changed(450); };
  $('ttUnit').onchange = () => { if (!it()) return; it().unit = $('ttUnit').value; showVals(); };
  [['ttB', 'bold'], ['ttI', 'italic'], ['ttU', 'under']].forEach(([id, k]) => $(id).onclick = () => { if (!it()) return; it()[k] = !it()[k]; $(id).classList.toggle('on', it()[k]); changed(150); });
  document.querySelectorAll('#ttStyle span').forEach(s => s.onclick = () => { if (!it() || it().style === s.dataset.v) return; it().style = s.dataset.v; renderAll(); changed(150); });
  document.querySelectorAll('#ttPath span').forEach(s => s.onclick = () => { if (!it() || it().path === s.dataset.v) return; it().path = s.dataset.v; renderAll(); changed(150); });
  $('ttAllow').onchange = () => { if (!it()) return; it().allow = $('ttAllow').checked; checkDepth(); changed(100); };
  $('ttDelete').onclick = () => { if (cur >= 0) removeItem(cur); };
  // fonts
  $('ttFontBtn').onclick = e => { e.stopPropagation(); $('ttColPop').classList.add('hidden'); $('ttFontPop').classList.toggle('hidden'); $('ttFontQ').value = ''; fontList(); $('ttFontQ').focus(); };
  $('ttFontQ').oninput = fontList;
  document.querySelectorAll('#ttFontPop .tttabs span').forEach(t => t.onclick = () => { fontTab = t.dataset.t; document.querySelectorAll('#ttFontPop .tttabs span').forEach(x => x.classList.toggle('on', x === t)); fontList(); });
  $('ttFontAdd').onclick = async () => { const d = await X().api().font_add_dialog(); if (!d) return; if (d.error) { stat(d.error, true); return; } fontsInfo = d; if (d.added) { it().font = d.added; renderAll(); changed(100); stat(`Added the font "${d.added}".`); } fontList(); };
  // colour
  $('ttColBtn').onclick = e => { e.stopPropagation(); $('ttFontPop').classList.add('hidden'); $('ttColPop').classList.toggle('hidden'); tiles(); };
  document.querySelectorAll('.ttpop').forEach(p => p.addEventListener('click', e => e.stopPropagation()));
  document.addEventListener('click', () => document.querySelectorAll('.ttpop').forEach(p => p.classList.add('hidden')));
  wheel();
  $('ttHex').onchange = () => { const v = $('ttHex').value.trim(); if (/^#?[0-9a-f]{6}$/i.test(v)) useColour('#' + v.replace('#', '').toUpperCase()); };
}
function fontList() {
  const q = $('ttFontQ').value.toLowerCase(), box = $('ttFontList');
  if (fontTab === 'mine') {
    const fams = ((fontsInfo && fontsInfo.families) || []).filter(f => f.toLowerCase().includes(q)).slice(0, 400);
    box.innerHTML = fams.map(f => `<div class="ttfi ${it() && f === it().font ? 'on' : ''}" data-f="${esc(f)}"><span style="font-family:'${esc(f)}'">${esc(f)}</span></div>`).join('') || '<div class="dim small" style="padding:6px">No font matches.</div>';
    box.querySelectorAll('[data-f]').forEach(d => d.onclick = () => { it().font = d.dataset.f; $('ttFontPop').classList.add('hidden'); renderAll(); changed(100); });
  } else {
    const fr = ((fontsInfo && fontsInfo.free) || []).filter(f => f.name.toLowerCase().includes(q));
    box.innerHTML = fr.map(f => `<div class="ttfi" data-g="${esc(f.name)}"><span>${esc(f.name)}</span><button ${f.installed ? 'disabled' : ''}>${f.installed ? 'Installed' : 'Get'}</button></div>`).join('') +
      '<div class="dim small" style="padding:6px">Free fonts from Google Fonts (free to use and print).</div>';
    box.querySelectorAll('[data-g]').forEach(d => {
      d.onclick = () => { const f = fr.find(x => x.name === d.dataset.g); if (f && f.installed) { it().font = f.name; $('ttFontPop').classList.add('hidden'); renderAll(); changed(100); } };
      const b = d.querySelector('button'); b.onclick = async e => {
        e.stopPropagation(); if (b.disabled) return; b.textContent = '…'; b.disabled = true;
        const r = await X().api().font_download(d.dataset.g); if (r.error) { stat(r.error, true); b.textContent = 'Get'; b.disabled = false; return; }
        fontsInfo = r; it().font = d.dataset.g; renderAll(); changed(100); fontList(); stat(`Downloaded ${d.dataset.g} and added it to your fonts.`);
      };
    });
  }
}
function tiles() {
  const slots = X().state().filaments.slots, t = it();
  $('ttTilesF').innerHTML = slots.map(s => `<div class="tttile ${s.slot === t.slot ? 'on' : ''}" title="${s.slot} · ${esc(s.name)}" style="background:${s.color}" data-s="${s.slot}"></div>`).join('');
  $('ttTilesC').innerHTML = COMMON.map(c => `<div class="tttile" title="${c}" style="background:${c}" data-c="${c}"></div>`).join('');
  $('ttTilesF').querySelectorAll('[data-s]').forEach(d => d.onclick = () => { t.slot = +d.dataset.s; renderAll(); tiles(); changed(100); });
  $('ttTilesC').querySelectorAll('[data-c]').forEach(d => d.onclick = () => useColour(d.dataset.c));
  const s = slots.find(x => x.slot === t.slot); if (s && document.activeElement !== $('ttHex')) $('ttHex').value = s.color;
}
async function useColour(hex) {
  const c = X(), slots = c.state().filaments.slots, same = slots.find(s => s.color.toUpperCase() === hex.toUpperCase());
  if (same) { it().slot = same.slot; renderAll(); tiles(); changed(100); return; }
  const n = slots.length + 1; if (n > 16) { stat('16 colours is the most a project can have.', true); return; }
  const base = slots[0], d = await c.api().set_slot(n, base.preset, hex, base.type, null, 'single', null);
  if (d.error) { stat(d.error, true); return; }
  c.state().filaments = d.filaments; c.pushUndo(`Add colour ${n}`);
  it().slot = n; renderAll(); tiles(); changed(100); stat(`Added colour ${n} (${hex}) for the text.`);
}
function wheel() {
  const cv = $('ttWheel'), x = cv.getContext('2d'), W = cv.width, R = W / 2, img = x.createImageData(W, W);
  for (let y = 0; y < W; y++) for (let i = 0; i < W; i++) {
    const dx = i - R, dy = y - R, d = Math.hypot(dx, dy), o = (y * W + i) * 4; if (d > R) continue;
    const h = (Math.atan2(dx, -dy) * 180 / Math.PI + 360) % 360, s = d / R, f = n => { const k = (n + h / 60) % 6; return 1 - s * Math.max(0, Math.min(k, 4 - k, 1)); };
    img.data[o] = f(5) * 255; img.data[o + 1] = f(3) * 255; img.data[o + 2] = f(1) * 255; img.data[o + 3] = 255;
  }
  x.putImageData(img, 0, 0);
  cv.onclick = e => { const r = cv.getBoundingClientRect(), p = x.getImageData(Math.min(W - 1, (e.clientX - r.left) * W / r.width), Math.min(W - 1, (e.clientY - r.top) * W / r.height), 1, 1).data; if (p[3]) useColour('#' + [p[0], p[1], p[2]].map(v => v.toString(16).padStart(2, '0')).join('').toUpperCase()); };
}

// ------------------------------------------------------------------ the live view of the text being edited
function clearPreview() { if (preview && preview.parent) preview.parent.remove(preview); preview = null; }
function rebuildSoon(ms) { clearTimeout(prevT); prevT = setTimeout(rebuild, ms); }
async function rebuild() {
  const c = X(), t = it(); if (!c || part < 0 || !t) { clearPreview(); return; }
  if (!t.dirty && t.saved) { clearPreview(); return; }
  const key = itemKey(t), L = await placement(t, part);
  if (!L || L.error || !it() || itemKey(it()) !== key) return;           // something changed meanwhile: the newer one draws
  const T = c.THREE, m = meshOf(part); if (!m) return;
  const slot = c.state().filaments.slots.find(s => s.slot === t.slot), hole = t.style === 'cut' || t.style === 'through';
  const mat = new T.MeshStandardMaterial({ color: hole ? 0x3a1c40 : (slot ? slot.color : '#ffffff'), roughness: 0.55, emissive: 0x0b2a16, polygonOffset: true, polygonOffsetFactor: -2 });
  const g = new T.Group(); g.userData.textPreview = true; g.matrixAutoUpdate = false;
  g.add(lettersOf(T, t, L, mat)); g.add(hitBoxesOf(T, t, L));
  g.userData.base = anchorMatrix(T, t);
  clearPreview(); m.add(g); preview = g;
  thick[cur] = t.style === 'cut' && L.thick != null ? L.thick : Infinity;
  checkDepth();
}
function checkDepth() {
  const t = it(); if (!t) return;
  const tmin = thick[cur], isCut = t.style === 'cut' && isFinite(tmin);
  if (isCut) { const cap = Math.max(0.2, Math.floor(tmin * 10) / 10); $('ttTh').max = cap; if (t.th > cap) { t.th = cap; showVals(); } $('ttMax').textContent = `deepest possible here: ${cap.toFixed(1)} mm (the part is ${tmin.toFixed(1)} mm thick)`; }
  else { $('ttTh').max = 200; $('ttMax').textContent = ''; }
  $('ttMax').classList.toggle('hidden', !isCut);
  const left = isCut ? tmin - t.th : Infinity, thin = left < MINLEFT;
  $('ttWarn').classList.toggle('hidden', !thin);
  if (thin) {
    $('ttWarnT').innerHTML = `⚠ Only <b>${Math.max(0, left).toFixed(1)} mm</b> left under the letters (keep ${MINLEFT} mm). ` +
      (tmin > MINLEFT + 0.2 ? `Safe depth: <b>${(tmin - MINLEFT).toFixed(1)} mm</b> or less.` : `The part is only ${tmin.toFixed(1)} mm here: try <b>Raised</b> or <b>Cut out</b>.`) +
      (t.allow ? '' : ' Not added until fixed or allowed.');
    $('ttAllow').checked = !!t.allow;
  }
}
const blockedItem = x => x.style === 'cut' && isFinite(thick[items.indexOf(x)]) && thick[items.indexOf(x)] - x.th < MINLEFT && !x.allow;

// while a saved text is being edited, show the part without it (no ghost); the live version is drawn on top
async function startEditView() {
  const c = X(), t = it(); if (!c || !t || !t.saved || part < 0) return;
  const want = part + ':' + cur; if (ctxFor === want) return; ctxFor = want;
  const others = items.filter((x, i) => i !== cur && x.saved && !blockedItem(x)).map(wire);
  const d = await c.api().text_context(part, others);
  if (ctxFor !== want || !d || d.error || !d.file) return;
  const m = meshOf(part); if (!m) return;
  const tmp = await c.loadMesh(d, m.userData.plateOffset || [0, 0]);
  if (ctxFor !== want) return;
  endEditView(true);
  tmp.userData.textContext = true; tmp.userData.id = -100 - part;
  m.parent.add(tmp);
  m.userData.hiddenForText = true; setHidden(m, true); ctxMesh = tmp;
}
function setHidden(m, on) {   // hide the part's surface but keep its children (the live text, the grab handles)
  const mats = Array.isArray(m.material) ? m.material : [m.material];
  mats.forEach(mt => { if (on) { mt.userData._vis = mt.visible; mt.visible = false; } else if (mt.userData._vis !== undefined) { mt.visible = mt.userData._vis; delete mt.userData._vis; } });
}
function endEditView(keepFlag) {
  if (ctxMesh && ctxMesh.parent) ctxMesh.parent.remove(ctxMesh);
  ctxMesh = null;
  const m = meshOf(part); if (m && m.userData.hiddenForText) { setHidden(m, false); m.userData.hiddenForText = false; }
  if (!keepFlag) ctxFor = null;
}

// ------------------------------------------------------------------ putting it on the model (in the background, newest wins)
function applySoon(ms) { clearTimeout(applyT); applyT = setTimeout(() => applyNow(), ms); }
async function applyNow(label) {
  const c = X(); if (!c || part < 0 || drag) return;
  clearTimeout(applyT);
  const send = items.filter(x => !blockedItem(x) && (x.text || '').trim()).map(wire);
  const my = ++gen, keep = part, keepCur = cur, snapshot = items.map(itemKey); applying++; working(true);
  let d;
  try { d = await c.api().text_set(keep, send, my); } catch (e) { d = { error: String(e && e.message || e) }; } finally { applying--; }
  if (my !== gen || !d || d.stale) { if (!applying) working(false); return; }          // a newer change is on its way
  working(false);
  if (d.error) { stat(d.error, true); return; }
  const changedSince = items.map(itemKey).some((k, i) => k !== snapshot[i]) || items.length !== snapshot.length;
  // show the real result (only this part is re-sent; the view and selection stay put)
  endEditView(); clearPreview();
  await c.show(d, { keep: true, quiet: true }); c.select(keep, false);
  part = keep; cur = Math.min(keepCur, items.length - 1);
  c.pushUndo(label || (send.length ? 'Text on the part' : 'Removed the text'));
  if (!changedSince) items.forEach(x => { if (!blockedItem(x) && (x.text || '').trim()) { x.saved = true; x.dirty = false; } });
  renderChips(); handleSig = ''; refreshHandles();
  if (changedSince || items.some(x => x.dirty)) { startEditView(); rebuild(); applySoon(300); }
}
function working(on) { const n = $('ttBusy'); if (n) n.classList.toggle('hidden', !on); }

// ------------------------------------------------------------------ dragging (the live text, or any text on the model)
let proxy = null, proxyKey = null;
async function ensureProxy() {   // a light, tiled copy of the part for quick picking while dragging
  const c = X(), m = meshOf(part); if (!m) return null; const T = c.THREE;
  const key = part + ':' + m.uuid;
  if (proxy && proxyKey === key) return proxy;
  const r = await c.api().part_proxy(part); if (!r || r.error) return null;
  const V = r.v, F = r.f, nt = F.length / 3, N = 8;
  let x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
  for (let i = 0; i < V.length; i += 3) { x0 = Math.min(x0, V[i]); x1 = Math.max(x1, V[i]); y0 = Math.min(y0, V[i + 1]); y1 = Math.max(y1, V[i + 1]); }
  const bins = Array.from({ length: N * N }, () => []);
  for (let k = 0; k < nt; k++) {
    const a = F[3 * k] * 3, b = F[3 * k + 1] * 3, cc = F[3 * k + 2] * 3;
    const cx = (V[a] + V[b] + V[cc]) / 3, cy = (V[a + 1] + V[b + 1] + V[cc + 1]) / 3;
    const ix = Math.min(N - 1, Math.max(0, Math.floor((cx - x0) / (x1 - x0 + 1e-9) * N))), iy = Math.min(N - 1, Math.max(0, Math.floor((cy - y0) / (y1 - y0 + 1e-9) * N)));
    bins[iy * N + ix].push(F[3 * k], F[3 * k + 1], F[3 * k + 2]);
  }
  const pos = new T.BufferAttribute(new Float32Array(V), 3), mat = new T.MeshBasicMaterial({ side: T.DoubleSide });
  proxy = new T.Group(); proxy.matrixAutoUpdate = false;
  bins.forEach(ix => { if (!ix.length) return; const g = new T.BufferGeometry(); g.setAttribute('position', pos); g.setIndex(ix); g.computeBoundingSphere(); g.computeBoundingBox(); const me = new T.Mesh(g, mat); me.matrixAutoUpdate = false; proxy.add(me); });
  proxyKey = key; return proxy;
}
function hookDrag() {
  const c = X(), T = c.THREE, el = c.renderer.domElement, ray = new T.Raycaster(), ndc = new T.Vector2();
  let pending = null, queued = false;
  const pick = e => { const r = el.getBoundingClientRect(); ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1); ray.setFromCamera(ndc, c.camera); };
  const usable = () => c.state() && c.mode() === 'plates' && c.step() === 1 && !c.vt().measure && !c.paintTool() && !c.tools().dragging;
  el.addEventListener('pointerdown', async e => {
    if (e.button !== 0 || !usable()) return;
    const h = handleHit(e); if (!h) return;
    e.stopPropagation(); c.controls.enabled = false; drag = true; el.style.cursor = 'grabbing';
    if (h.part !== part || h.item !== cur) {           // grabbed a text that isn't the one being edited: open it
      if (c.selected() !== h.part) c.select(h.part, false);
      c.card('textCard'); await open({ part: h.part, item: h.item });
    } else if (!$('textCard').classList.contains('open')) c.card('textCard');   // show its settings while you move it
    const t = it(); if (!t) { drag = false; c.controls.enabled = true; return; }
    t.dirty = true; startEditView(); await rebuild(); await ensureProxy();
  }, true);
  window.addEventListener('pointermove', e => {
    if (!drag) { if (e.target === el && usable()) { const h = handleHit(e); if (h) el.style.cursor = 'grab'; } return; }
    pending = e; if (queued) return; queued = true;
    requestAnimationFrame(() => {
      queued = false; const ev = pending; pending = null; if (!ev || !drag || !preview || !proxy) return;
      pick(ev); const m = meshOf(part); if (!m) return;
      proxy.children.forEach(ch => ch.matrixWorld.copy(m.matrixWorld));
      const h = ray.intersectObjects(proxy.children, false)[0]; if (!h) return;
      const inv = new T.Matrix4().copy(m.matrixWorld).invert(), nrm = h.face.normal.clone();
      if (nrm.dot(ray.ray.direction.clone().transformDirection(inv)) > 0) nrm.negate();
      const t = it(); t.point = m.worldToLocal(h.point.clone()).toArray().map(v => +v.toFixed(3)); t.normal = nrm.toArray().map(v => +v.toFixed(5));
      preview.matrix.copy(anchorMatrix(T, t)).multiply(new T.Matrix4().copy(preview.userData.base).invert()); preview.matrixWorldNeedsUpdate = true;
    });
  });
  window.addEventListener('pointerup', () => {
    if (!drag) return; drag = false; c.controls.enabled = true; el.style.cursor = '';
    renderChips(); rebuild(); applySoon(120);
  });
}

// ------------------------------------------------------------------ start
async function endEdit() { if (applyT && items.some(x => x.dirty)) { clearTimeout(applyT); await applyNow(); } endEditView(); clearPreview(); }
(function boot() {
  if (!X() || !$('tt')) { setTimeout(boot, 200); return; }
  bind(); hookDrag();
  window.texttool = { open, addNew, items: () => items, applyNow, overText: e => !!handleHit(e), busyDrag: () => drag,
    _dbg: () => ({ handles: handles.size, letters: [...handles.values()].map(g => { let n = 0; g.traverse(o => { if (o.isMesh) n++; }); return n; }), attached: [...handles.values()].map(g => !!g.parent), busy: handleBusy }) };
  // keep in step with the rest of the app: selection, the open section, rebuilt meshes
  let lastSel = null;
  setInterval(() => {
    const c = X(); if (!c || !c.state()) return;
    refreshHandles();
    const sec = $('textCard'), openSec = sec && sec.classList.contains('open') && c.step() === 1;
    const sel = c.selected();
    if (openSec && sel !== lastSel && !drag && !applying) { lastSel = sel; open(); }
    if (!openSec) lastSel = null;
    if (!openSec && preview && !items.some(x => x.dirty)) clearPreview();
  }, 300);
})();
