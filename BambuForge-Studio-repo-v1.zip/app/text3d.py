"""Put text on a model: raised (embossed) or cut in (engraved), lying on the surface you clicked."""
import math
import numpy as np
import manifold3d as mf
import split


def text_solid(shapes, depth, sink):
    """shapes: [{'outer': [[x,y]...], 'holes': [[[x,y]...]...]}] in mm, centred on 0,0. Extruded from -sink to +depth."""
    secs = []
    for s in shapes:
        cont = [np.asarray(s['outer'], np.float64)] + [np.asarray(h, np.float64) for h in s.get('holes', []) if len(h) >= 3]
        cont = [c for c in cont if len(c) >= 3]
        if not cont: continue
        cs = mf.CrossSection(cont, mf.FillRule.EvenOdd)
        if not cs.is_empty(): secs.append(cs)
    if not secs: raise ValueError('There is no text to add.')
    cs = secs[0]
    for x in secs[1:]: cs = cs + x
    h = depth + sink
    if h <= 0: raise ValueError('Text depth must be more than 0.')
    return mf.Manifold.extrude(cs, h).translate((0, 0, -sink))


def frame(point, normal, angle_deg):
    """4x4 that puts the text's (x right, y up, z out) onto the surface at point, facing out along normal."""
    n = np.asarray(normal, float); n /= np.linalg.norm(n) or 1
    up = np.array([0, 0, 1.0]) if abs(n[2]) < 0.9 else np.array([0, 1.0, 0])
    x = np.cross(up, n); x /= np.linalg.norm(x) or 1
    y = np.cross(n, x)
    a = math.radians(angle_deg)
    xr, yr = x * math.cos(a) + y * math.sin(a), -x * math.sin(a) + y * math.cos(a)
    M = np.eye(4); M[:3, 0], M[:3, 1], M[:3, 2], M[:3, 3] = xr, yr, n, point
    return M


def add_text(part, shapes, point, normal, depth=1.0, mode='raise', slot=None, angle=0.0):
    """Returns (trimesh, filament per triangle). The text gets filament `slot` (raised text) or keeps the part's colours (cut in)."""
    depth = max(0.2, float(depth))
    M = frame(point, normal, angle)[:3, :].astype(np.float64)
    solid = split.to_mf(part.mesh, part.exts() if part.face_ext is not None else None)
    if mode == 'raise':
        # the letters stand `depth` above the surface; below it they only fill into the part (up to 3 mm), so on a
        # curved surface no corner floats, and on a thin wall nothing pokes out of the other side
        above = text_solid(shapes, depth, 0.0).transform(M)
        below = text_solid(shapes, 0.0, 3.0).transform(M) ^ solid
        T = above + below
        slot = int(slot or part.ext)
        # the text's own faces carry its filament slot through the union
        g = T.to_mesh()
        T = mf.Manifold(mf.Mesh(vert_properties=np.array(g.vert_properties[:, :3], np.float32, copy=True, order="C"), tri_verts=np.array(g.tri_verts, np.uint32, copy=True, order="C"),
                                face_id=np.full(len(g.tri_verts), split.FID + slot, np.uint32)))
        out = solid + T
    else:
        T = text_solid(shapes, 0.6, depth).transform(M)
        out = solid - T
    if out.is_empty(): raise ValueError('The text missed the model. Click right on its surface.')
    return split.to_tm_ext(out, part.ext)


# ------------------------------------------------------------------ text that wraps around curved surfaces
def _closest_on_tris(p, a, b, c):
    """Closest point on each triangle (a, b, c are n x 3) to point p (Ericson's method, vectorised)."""
    ab, ac, ap = b - a, c - a, p - a
    d1, d2 = (ab * ap).sum(1), (ac * ap).sum(1)
    bp = p - b; d3, d4 = (ab * bp).sum(1), (ac * bp).sum(1)
    cp = p - c; d5, d6 = (ab * cp).sum(1), (ac * cp).sum(1)
    vc = d1 * d4 - d3 * d2; vb = d5 * d2 - d1 * d6; va = d3 * d6 - d5 * d4
    den = va + vb + vc; den[den == 0] = 1e-12
    v = vb / den; w = vc / den
    res = a + ab * v[:, None] + ac * w[:, None]
    m = (d1 <= 0) & (d2 <= 0); res[m] = a[m]
    m = (d3 >= 0) & (d4 <= d3); res[m] = b[m]
    m = (d6 >= 0) & (d5 <= d6); res[m] = c[m]
    m = (vc <= 0) & (d1 >= 0) & (d3 <= 0); t = d1 / np.where(d1 - d3 == 0, 1e-12, d1 - d3); res[m] = (a + ab * t[:, None])[m]
    m = (vb <= 0) & (d2 >= 0) & (d6 <= 0); t = d2 / np.where(d2 - d6 == 0, 1e-12, d2 - d6); res[m] = (a + ac * t[:, None])[m]
    m = (va <= 0) & ((d4 - d3) >= 0) & ((d5 - d6) >= 0)
    t = (d4 - d3) / np.where((d4 - d3) + (d5 - d6) == 0, 1e-12, (d4 - d3) + (d5 - d6)); res[m] = (b + (c - b) * t[:, None])[m]
    return res


class Surface:
    """Find the nearest point on a mesh, and a smooth surface direction there."""
    def __init__(self, mesh):
        self.tri = np.asarray(mesh.triangles, np.float64)
        self.cen = self.tri.mean(1); self.nrm = np.asarray(mesh.face_normals, np.float64); self.area = np.asarray(mesh.area_faces, np.float64)

    def project(self, q, smooth=2.0):
        d = ((self.cen - q) ** 2).sum(1)
        k = np.argpartition(d, min(96, len(d) - 1))[:96]
        pts = _closest_on_tris(q, self.tri[k, 0], self.tri[k, 1], self.tri[k, 2])
        j = int(np.argmin(((pts - q) ** 2).sum(1)))
        p = pts[j]
        near = ((self.cen - p) ** 2).sum(1) < smooth * smooth
        w = self.area[near][:, None] * self.nrm[near]
        n = w.sum(0) if near.any() else self.nrm[k[j]]
        if np.dot(n, self.nrm[k[j]]) < 0: n = self.nrm[k[j]]
        return p, n / (np.linalg.norm(n) or 1)


def walk(surface, point, normal, angle_deg, length, step=0.5):
    """Walk along the surface from `point` in the text's direction, both ways; returns arc -> (position, tangent, normal)."""
    M = frame(point, normal, angle_deg)
    t0, n0 = M[:3, 0], M[:3, 2]
    p0, n0s = surface.project(np.asarray(point, float))
    out = {0.0: (p0, t0 - n0s * np.dot(t0, n0s), n0s)}
    for sign in (1, -1):
        p, t, n = p0.copy(), t0.copy(), n0s.copy()
        s = 0.0
        while s < length:
            q = p + sign * t * step
            p2, n2 = surface.project(q)
            mv = p2 - p
            if np.linalg.norm(mv) < 1e-6: break
            t = sign * mv; t -= n2 * np.dot(t, n2); t /= (np.linalg.norm(t) or 1)
            p, n = p2, n2; s += step
            out[sign * s] = (p.copy(), t.copy(), n.copy())
    return out


def add_text_wrapped(part, glyphs, point, normal, depth=1.0, mode='raise', slot=None, angle=0.0):
    """Like add_text, but every letter is laid on the surface where it falls, so the words follow the shape."""
    depth = max(0.2, float(depth))
    surf = Surface(part.mesh)
    span = max([abs(g['x']) for g in glyphs] + [1.0]) + 2.0
    path = walk(surf, point, normal, angle, span)
    keys = np.array(sorted(path))
    solid = split.to_mf(part.mesh, part.exts() if part.face_ext is not None else None)
    parts = []
    for g in glyphs:
        s = keys[int(np.argmin(np.abs(keys - g['x'])))]
        p, t, n = path[s]
        y = np.cross(n, t)
        M = np.eye(4); M[:3, 0], M[:3, 1], M[:3, 2], M[:3, 3] = t, y, n, p
        M = M[:3, :].astype(np.float64)
        if mode == 'raise':
            parts.append(text_solid(g['shapes'], depth, 0.0).transform(M))
            parts.append(text_solid(g['shapes'], 0.0, 3.0).transform(M) ^ solid)
        else:
            parts.append(text_solid(g['shapes'], 0.6, depth).transform(M))
    T = mf.Manifold.batch_boolean(parts, mf.OpType.Add)
    if mode == 'raise':
        slot = int(slot or part.ext)
        gm = T.to_mesh()
        T = mf.Manifold(mf.Mesh(vert_properties=np.array(gm.vert_properties[:, :3], np.float32, copy=True, order='C'),
                                tri_verts=np.array(gm.tri_verts, np.uint32, copy=True, order='C'),
                                face_id=np.full(len(gm.tri_verts), split.FID + slot, np.uint32)))
        out = solid + T
    else:
        out = solid - T
    if out.is_empty(): raise ValueError('The text missed the model. Click right on its surface.')
    return split.to_tm_ext(out, part.ext)
