// report any page error to the log, so 'it won't open' can be diagnosed
window.addEventListener('error', e => { try { window.pywebview.api.js_error(`${e.message} @ ${e.filename}:${e.lineno}`); } catch (_) {} });
window.addEventListener('unhandledrejection', e => { try { window.pywebview.api.js_error('Unhandled: ' + (e.reason && (e.reason.stack || e.reason.message) || e.reason)); } catch (_) {} });
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/OrbitControls.js';
import { openEditor, editorOpen as editorActive, editorUndo, editorRedo } from './editor.js';
import { pickFilament } from './picker.js';
import { swatchCss } from './swatch.js';
import { FontLoader } from 'three/addons/FontLoader.js';
import { openHelp, firstRun } from './help.js';
import { makeTools, sectionPlane, applySection, heatOverlay } from './gizmo.js';

const $ = id => document.getElementById(id);
const api = () => window.pywebview.api;
let state = null, meshes = [], selected = -1, volumes = [], beds = [], mode = 'plates';

// ---------- scene (Z is up, like the printer)
THREE.Object3D.DEFAULT_UP.set(0, 0, 1);
const host = $('viewport');
let renderer;
try { renderer = new THREE.WebGLRenderer({ antialias: true }); }
catch (e) {
  document.getElementById('dropHint').textContent = '3D graphics (WebGL) are not available on this PC: ' + e.message;
  throw e;
}
renderer.setPixelRatio(window.devicePixelRatio);
host.appendChild(renderer.domElement);
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x1e1e22);
const camera = new THREE.PerspectiveCamera(40, 1, 1, 50000);
camera.up.set(0, 0, 1);
camera.position.set(400, -600, 450);
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
// even light from every side: the underside of a part shows its true colour, not a dark shadow
scene.add(new THREE.HemisphereLight(0xffffff, 0xb4b4bc, 1.35));
const sun = new THREE.DirectionalLight(0xffffff, 0.75); sun.position.set(300, -500, 800); scene.add(sun);
const fill = new THREE.DirectionalLight(0xffffff, 0.45); fill.position.set(-400, 300, 200); scene.add(fill);
const under = new THREE.DirectionalLight(0xffffff, 0.45); under.position.set(100, 200, -600); scene.add(under);
renderer.localClippingEnabled = true;
const world = new THREE.Group(); scene.add(world);

function resize() { const r = host.getBoundingClientRect(); renderer.setSize(r.width, r.height); camera.aspect = r.width / Math.max(1, r.height); camera.updateProjectionMatrix(); }
new ResizeObserver(resize).observe(host); resize();
(function loop() { requestAnimationFrame(loop); controls.update(); renderer.render(scene, camera); })();

function bed(plate, size, maxH, name) {
  const g = new THREE.Group();
  const [w, d] = size, [ox, oy] = plate.offset;
  const plane = new THREE.Mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshStandardMaterial({ color: 0x3a3a40, roughness: 0.95 }));
  plane.position.set(ox + w / 2, oy + d / 2, -0.05); g.add(plane);
  const lines = [];
  for (let x = 0; x <= w + 0.1; x += 16) lines.push(ox + x, oy, 0, ox + x, oy + d, 0);
  for (let y = 0; y <= d + 0.1; y += 16) lines.push(ox, oy + y, 0, ox + w, oy + y, 0);
  const lg = new THREE.BufferGeometry(); lg.setAttribute('position', new THREE.Float32BufferAttribute(lines, 3));
  g.add(new THREE.LineSegments(lg, new THREE.LineBasicMaterial({ color: 0x4a4a51 })));
  const edge = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(w, d, 0.01)), new THREE.LineBasicMaterial({ color: 0x00ae42 }));
  edge.position.set(ox + w / 2, oy + d / 2, 0); g.add(edge);
  const vol = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(w, d, maxH)), new THREE.LineBasicMaterial({ color: 0x00ae42, transparent: true, opacity: 0.35 }));
  vol.position.set(ox + w / 2, oy + d / 2, maxH / 2); g.add(vol); volumes.push(vol);
  vol.visible = $('volTog').checked;
  const label = makeLabel(name); label.position.set(ox, oy - 22, 0); g.add(label);
  return g;
}

function makeLabel(text) {
  const c = document.createElement('canvas'); c.width = 512; c.height = 64;
  const x = c.getContext('2d'); x.fillStyle = '#B2B3B5'; x.font = '600 34px Segoe UI, sans-serif'; x.fillText(text, 4, 44);
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true }));
  s.scale.set(256, 32, 1); s.center.set(0, 0.5); return s;
}

async function loadMesh(part, plateOffset) {
  const buf = await (await fetch(part.file + '?v=' + Date.now())).arrayBuffer();
  const head = new Uint32Array(buf, 0, 2), nv = head[0], nt = head[1];
  const pos = new Float32Array(buf, 8, nv * 3), idx = new Uint32Array(buf, 8 + nv * 12, nt * 3);
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setIndex(new THREE.BufferAttribute(idx, 1));
  g.computeVertexNormals();
  const slotOf = s => (state && state.filaments && state.filaments.slots.find(x => x.slot === s)) || { color: part.color, colors: [part.color], effect: 'solid', ctype: 'single' };
  const groups = part.groups && part.groups.length ? part.groups : [{ ext: part.ext || 1, start: 0, count: idx.length }];
  // multicolour / gradient filaments: colour every vertex by its height through the part
  if (groups.some(gr => (slotOf(gr.ext).colors || []).length > 1)) {
    let z0 = Infinity, z1 = -Infinity; for (let i = 2; i < pos.length; i += 3) { z0 = Math.min(z0, pos[i]); z1 = Math.max(z1, pos[i]); }
    const col = new Float32Array(nv * 3).fill(1);
    groups.forEach(gr => {
      const f = slotOf(gr.ext), cs = (f.colors || [f.color]).map(c => new THREE.Color(String(c).slice(0, 7)));
      for (let k = gr.start; k < gr.start + gr.count; k++) {
        const v = idx[k], t = (pos[v * 3 + 2] - z0) / Math.max(1e-6, z1 - z0);
        let c;
        if (cs.length === 1) c = cs[0];
        else if (f.ctype === 'multi') c = cs[Math.min(cs.length - 1, Math.floor(t * cs.length * 3) % cs.length)];
        else { const x = t * (cs.length - 1), a = Math.floor(Math.min(x, cs.length - 1.0001)); c = cs[a].clone().lerp(cs[a + 1], x - a); }
        col[v * 3] = c.r; col[v * 3 + 1] = c.g; col[v * 3 + 2] = c.b;
      }
    });
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  }
  const mk = s => {
    const f = slotOf(s), multi = (f.colors || []).length > 1, eff = f.effect || 'solid';
    const a = String((f.colors || [f.color])[0]).length === 9 ? parseInt(String(f.colors[0]).slice(7, 9), 16) / 255 : 1;
    const p = { color: multi ? 0xffffff : String(f.color).slice(0, 7), vertexColors: multi, roughness: 0.7, metalness: 0.0, emissive: part.fits ? 0x000000 : 0x5a0000 };
    if (eff === 'matte') p.roughness = 0.95;
    if (eff === 'silk') { p.roughness = 0.25; p.metalness = 0.35; }
    if (eff === 'metal') { p.roughness = 0.3; p.metalness = 0.85; }
    if (eff === 'sparkle' || eff === 'galaxy') { p.roughness = 0.4; p.metalness = 0.3; }
    if (eff === 'translucent' || a < 1) { p.transparent = true; p.opacity = Math.min(0.75, a); p.depthWrite = false; }
    if (eff === 'clear') { p.transparent = true; p.opacity = 0.35; p.depthWrite = false; p.roughness = 0.1; }
    const mt = new THREE.MeshStandardMaterial(p);
    if (eff === 'glow') { mt.userData.glow = String(f.color).slice(0, 7); if (part.fits) mt.emissive.set(mt.userData.glow).multiplyScalar(0.35); }
    return mt;
  };
  let mat;
  if (groups.length > 1) { mat = groups.map(gr => mk(gr.ext)); groups.forEach((gr, i) => g.addGroup(gr.start, gr.count, i)); }
  else mat = mk(groups[0].ext);
  const m = new THREE.Mesh(g, mat);
  m.userData.slots = part.groups ? part.groups.map(gr => gr.ext) : [part.ext || 1];
  m.position.set(plateOffset[0], plateOffset[1], 0);
  m.userData.id = part.id; m.userData.plateOffset = plateOffset; m.userData.asm = part.asm;
  return m;
}

async function show(desc) {
  state = desc;
  world.clear(); meshes = []; volumes = []; selected = -1;
  beds = [];
  const off = {}; desc.plates.forEach(p => { off[p.id] = p.offset; const b = bed(p, desc.bed, desc.max_h, p.name); beds.push(b); world.add(b); });
  busy('Building the 3D view…');
  meshes = await Promise.all(desc.parts.map(p => loadMesh(p, off[p.plate] || [0, 0])));
  meshes.forEach(m => world.add(m));
  busy(null);
  $('dropHint').classList.add('hidden');
  $('vAsm').disabled = !desc.assembled;
  const mo = $('measure'); mo.options[0].disabled = !desc.assembled;
  if (!desc.assembled && mo.value === 'asm') mo.value = 'tallest';
  if (desc.assembled && !mo.dataset.touched) mo.value = 'asm';
  setMode(mode === 'asm' && desc.assembled ? 'asm' : 'plates', true);
  renderList(); renderSize(); renderFit(); select(-1); view('fit'); renderTotals(desc); renderPrinterLine(desc); renderSlots(); renderFloat(); renderPos(); fillTextSlots();
  const tris = desc.parts.reduce((a, p) => a + p.tris, 0), shown = desc.parts.reduce((a, p) => a + p.shown_tris, 0);
  status(`${desc.title}  ·  ${desc.parts.length} parts on ${desc.plates.length} plate${desc.plates.length > 1 ? 's' : ''}  ·  ${tris.toLocaleString()} triangles` +
         (shown < tris ? ` (${shown.toLocaleString()} shown)` : '') + (desc.took ? `  ·  opened in ${desc.took}s` : ''));
}

function renderList() {
  const L = $('partList'); L.innerHTML = '';
  $('partCount').textContent = `(${state.parts.length})`;
  state.plates.forEach(pl => {
    const ps = state.parts.filter(p => p.plate === pl.id); if (!ps.length) return;
    const h = document.createElement('div'); h.className = 'plateHdr'; h.textContent = pl.name; L.appendChild(h);
    ps.forEach(p => {
      const d = document.createElement('div'); d.className = 'item'; d.dataset.id = p.id;
      const ss = (state.filaments ? state.filaments.slots.filter(s => (p.slots || [p.ext]).includes(s.slot)) : []);
      const swc = ss.length > 1 ? swatchCss({ colors: ss.map(s => s.color), ctype: 'multi', effect: 'solid' }) : ss.length ? swatchCss(ss[0]) : `background:${p.color}`;
      d.innerHTML = `<div class="t"><span class="sw" style="${swc}" title="${ss.map(s => s.slot + ' · ' + esc(s.name)).join(', ')}"></span><span>${esc(p.name)}</span></div>
        <div class="m">${p.size.join(' × ')} mm · ${p.fits ? '<span class="ok">fits</span>' : '<span class="bad">too big: ' + esc(p.why) + '</span>'}</div>`;
      d.onclick = () => select(p.id, true); L.appendChild(d);
    });
  });
}

function setMode(m, silent) {
  mode = m;
  $('vPlates').classList.toggle('on', m === 'plates'); $('vAsm').classList.toggle('on', m === 'asm');
  beds.forEach(b => b.visible = m === 'plates');
  let minz = Infinity;
  meshes.forEach(ms => {
    if (m === 'asm' && ms.userData.asm) {
      ms.matrixAutoUpdate = false; ms.matrix.fromArray(ms.userData.asm); ms.matrixWorldNeedsUpdate = true;
    } else { ms.matrixAutoUpdate = true; ms.position.set(ms.userData.plateOffset[0], ms.userData.plateOffset[1], 0); ms.rotation.set(0, 0, 0); ms.scale.set(1, 1, 1); ms.updateMatrix(); }
  });
  world.updateMatrixWorld(true);
  if (m === 'asm') { const b = new THREE.Box3(); meshes.forEach(ms => b.expandByObject(ms)); world.position.set(-(b.min.x + b.max.x) / 2, -(b.min.y + b.max.y) / 2, -b.min.z); }
  else world.position.set(0, 0, 0);
  world.updateMatrixWorld(true);
  if (!silent) view('fit');
}
$('vPlates').onclick = () => setMode('plates'); $('vAsm').onclick = () => { if (state && state.assembled) setMode('asm'); };

function measured() {
  const m = $('measure').value;
  if (m === 'asm' && state.assembled) return { mm: state.assembled.length, what: state.assembled.upright ? 'Whole model, tip to tip' : 'Whole model, longest side' };
  if (m === 'sel') { const p = state.parts[selected]; if (p) return { mm: p.size[2], what: p.name + ' (height)' }; return null; }
  return { mm: state.tallest, what: state.tallest_name + ' (tallest part)' };
}
function renderSize() {
  const m = measured();
  $('curLbl').textContent = m ? m.what : 'Select a part first';
  $('curH').textContent = m ? mmStr(m.mm) : '—';
  $('curScale').textContent = (state.scale * 100).toFixed(1) + '%';
  $('newLbl').textContent = m ? 'New size for: ' + m.what.toLowerCase() : 'New size';
  $('preview').textContent = '';
}
$('measure').onchange = () => { $('measure').dataset.touched = '1'; if (state) { renderSize(); sizePreview(); } };

function renderFit() {
  const bad = state.parts.filter(p => !p.fits);
  $('fitInfo').innerHTML = bad.length === 0
    ? `<span class="ok">All ${state.parts.length} parts fit the P1S</span> (256 × 256 mm, ${state.max_h} mm tall).`
    : `<span class="bad">${bad.length} part${bad.length > 1 ? 's are' : ' is'} too big</span> for the P1S and will need splitting (step 2).<br>` +
      bad.map(p => `· ${esc(p.name)}: ${esc(p.why)}`).join('<br>');
}

function select(id, focus) {
  selected = id;
  document.querySelectorAll('.item').forEach(e => e.classList.toggle('sel', +e.dataset.id === id));
  meshes.forEach(m => {
    const p = state.parts[m.userData.id];
    (Array.isArray(m.material) ? m.material : [m.material]).forEach(mt => { mt.emissive.setHex(m.userData.id === id ? 0x0a3a1e : (p.fits ? 0x000000 : 0x5a0000)); if (mt.userData.glow && m.userData.id !== id && p.fits) mt.emissive.set(mt.userData.glow).multiplyScalar(0.35); });
  });
  const p = state && state.parts[id];
  $('selInfo').innerHTML = p ? `<b>${esc(p.name)}</b><br><span class="dim">Plate ${p.plate} · ${p.size.join(' × ')} mm<br>${p.tris.toLocaleString()} triangles` +
      (p.volume_cm3 != null ? ` · ${p.volume_cm3} cm³` : '') + `<br>${p.fits ? '<span class="ok">Fits the P1S</span>' : '<span class="bad">Too big: ' + esc(p.why) + '</span>'}</span>` : 'Nothing selected';
  if (focus && p) frame([meshes.find(m => m.userData.id === id)]);
  if (state && $('measure').value === 'sel') renderSize();
  const p4 = document.querySelector('.page[data-page="4"]'); if (p4 && !p4.classList.contains('hidden')) renderOrient();
  renderPos();
}

function frame(objs) {
  const box = new THREE.Box3(); objs.forEach(o => box.expandByObject(o));
  if (box.isEmpty()) return;
  const c = box.getCenter(new THREE.Vector3()), r = box.getSize(new THREE.Vector3()).length() / 2;
  const dir = camera.position.clone().sub(controls.target).normalize();
  controls.target.copy(c); camera.position.copy(c).add(dir.multiplyScalar(r / Math.sin(THREE.MathUtils.degToRad(camera.fov / 2)) * 1.05));
  camera.near = Math.max(0.5, r / 100); camera.far = r * 100; camera.updateProjectionMatrix();
}

function view(kind) {
  const objs = meshes.length ? world.children : [];
  const t = controls.target.clone();
  if (kind === 'top') camera.position.set(t.x, t.y - 0.01, t.z + 1000);
  else if (kind === 'front') camera.position.set(t.x, t.y - 1000, t.z);
  else if (kind === 'iso') camera.position.set(t.x + 600, t.y - 800, t.z + 600);
  frame(objs.length ? objs : [world]);
}
document.querySelectorAll('[data-view]').forEach(b => b.onclick = () => view(b.dataset.view));
$('volTog').onchange = e => volumes.forEach(v => v.visible = e.target.checked);

// click to select
const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(); let downAt = null;
renderer.domElement.addEventListener('pointerdown', e => downAt = [e.clientX, e.clientY]);
renderer.domElement.addEventListener('pointerup', e => {
  if (!downAt || Math.hypot(e.clientX - downAt[0], e.clientY - downAt[1]) > 4 || !meshes.length) return;
  const r = renderer.domElement.getBoundingClientRect();
  ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
  ray.setFromCamera(ndc, camera);
  const hit = ray.intersectObjects(meshes, false)[0];
  if (vt.measure) { tools3d.measureClick(hit); return; }
  if (hit && paintTool && curStep === 1) {
    if (paintTool === 'flat') doLayFlat(hit); else if (paintTool === 'text') doText(hit); else doPaint(hit);
    return;
  }
  select(hit ? hit.object.userData.id : -1, false);
});

// ---------- size
function parseHeight() {
  const raw = $('targetH').value.trim(), unit = $('unit').value;
  if (!raw) return null;
  const ft = raw.match(/^\s*(\d+(?:\.\d+)?)\s*(?:'|ft|feet)\s*(?:(\d+(?:\.\d+)?)\s*(?:"|in|inches)?)?\s*$/i);
  if (ft || unit === 'ftin') {
    const m = ft || raw.match(/^\s*(\d+(?:\.\d+)?)\s*[ ,]\s*(\d+(?:\.\d+)?)\s*$/);
    if (!m) return NaN;
    return (parseFloat(m[1]) * 12 + (m[2] ? parseFloat(m[2]) : 0)) * 25.4;
  }
  const v = parseFloat(raw.replace(/[^0-9.]/g, ''));
  if (!isFinite(v)) return NaN;
  return unit === 'cm' ? v * 10 : unit === 'in' ? v * 25.4 : v;
}
function sizePreview() {
  $('sizeErr').textContent = '';
  if (!state) return;
  const mm = parseHeight(), pct = parseFloat($('pct').value);
  let f = null;
  const cur = measured();
  if (mm != null) {
    if (!isFinite(mm) || mm <= 0) { $('sizeErr').textContent = 'Enter a size like 1651, 165.1 cm, 65 in or 5\'5".'; return; }
    if (!cur) { $('sizeErr').textContent = 'Select a part first, or measure the whole model.'; return; }
    f = mm / cur.mm; $('pct').value = '';
  }
  else if (isFinite(pct) && pct > 0) f = pct / 100;
  if (!f) { renderSize(); return; }
  const c2 = cur || { mm: state.tallest, what: state.tallest_name };
  $('preview').textContent = `${c2.what}: ${mmStr(c2.mm)} → ${mmStr(c2.mm * f)}  (${(f * 100).toFixed(1)}%)`;
  return f;
}
$('targetH').oninput = sizePreview; $('unit').onchange = sizePreview;
$('pct').oninput = () => { $('targetH').value = ''; sizePreview(); };
$('applyBtn').onclick = async () => {
  if (!state) { $('sizeErr').textContent = 'Open a file first.'; return; }
  const f = sizePreview();
  if (!f) { if (!$('sizeErr').textContent) $('sizeErr').textContent = 'Enter a new height or a percentage first.'; return; }
  if (f < 0.01 || f > 100) { $('sizeErr').textContent = 'That size is out of range.'; return; }
  busy('Resizing every part…');
  const d = await api().scale(f); busy(null);
  if (d.error) { $('sizeErr').textContent = d.error; return; }
  $('targetH').value = ''; $('pct').value = ''; await show(d); undoMgr.pushServer('Resize');
};
$('resetBtn').onclick = async () => { if (!state) return; busy('Reloading the original…'); const d = await api().reset(); busy(null); if (d && !d.error) await show(d); };

// ---------- files
async function openPath(path) {
  busy('Opening ' + path.split(/[\\/]/).pop() + '…');
  const d = await api().load(path);
  busy(null);
  if (d.error) { status(d.error, true); return; }
  undoMgr.reset(); cuts = []; splitIdx = -1; S = null;
  await show(d);
}
$('openBtn').onclick = async () => { const p = await api().open_dialog(); if (p) openPath(p); };
$('exp3mf').onclick = () => doExport('3mf'); $('expStl').onclick = () => doExport('stl');
async function doExport(kind) {
  if (!state) { status('Open a file first.', true); return; }
  busy('Saving…'); const r = await api().export_dialog(kind); busy(null);
  if (r && r.error) status(r.error, true); else if (r && r.saved) status('Saved ' + r.saved);
}
$('copyLog').onclick = async e => {
  e.preventDefault(); const t = await api().copy_log();
  try { await navigator.clipboard.writeText(t); status('Log copied. Paste it into your chat with Claude.'); }
  catch { status('Couldn\'t copy automatically; the log is at %LOCALAPPDATA%\\BambuForgeStudio\\studio.log', true); }
};

// ---------- helpers
function busy(t) { $('busy').classList.toggle('hidden', !t); if (t) $('busyText').textContent = t; }
function status(t, bad) { const s = $('status'); s.textContent = t; s.style.color = bad ? 'var(--err)' : ''; }
function esc(s) { return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
function mmStr(mm) { const inch = mm / 25.4, ft = Math.floor(inch / 12), i = inch - ft * 12; return `${mm.toFixed(1)} mm (${ft}' ${i.toFixed(1)}")`; }

window.studio = { openPath, select, view, setMode, _set: (h, u) => { $('targetH').value = h; $('unit').value = u; sizePreview(); }, _apply: () => $('applyBtn').click() };
async function ready() {
  status('Ready. Open or drop a .3mf, .stl or .obj file.');
  try { const gl = renderer.getContext(); const dbg = gl.getExtension('WEBGL_debug_renderer_info'); api().ready('WebGL ' + (dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : 'ok') + ', ' + navigator.userAgent); } catch (e) { api().ready('WebGL check failed: ' + e.message); }
  const f = await api().startup_file();
  if (f) openPath(f);
}
if (window.pywebview && window.pywebview.api && window.pywebview.api.startup_file) ready();
else window.addEventListener('pywebviewready', ready);

// =====================================================================  steps
let jointInfo = null, cuts = [], splitIdx = -1, planes = [];
const EXTRA_H = { twist: 10, thread: 12, dovetail: 5 };   // spigot / tongue added on top of the piece below
document.querySelectorAll('#steps .step').forEach(b => b.onclick = () => goStep(+b.dataset.step));
let curStep = 1;
// Five steps on screen; behind them the old pages: step 1 shows pages 1 and 4 (model and plates), step 2 shows 2 and 3 (split and hollow).
const STEP_PAGES = { 1: [1, 4], 2: [2, 3], 5: [5], 6: [6], 7: [7], 8: [8] };
function goStep(n) {
  if (n === 4) n = 1; if (n === 3) n = 2;          // old step numbers still used in a few places
  curStep = n; buildVtools();
  document.querySelectorAll('#steps .step').forEach(b => b.classList.toggle('on', +b.dataset.step === n));
  document.querySelectorAll('.page').forEach(p => p.classList.toggle('hidden', !STEP_PAGES[n].includes(+p.dataset.page)));
  if (n === 2) { enterSplit(); enterHollow(); }
  if (n === 1) { renderPlateInfo(); renderOrient(); }
  document.querySelector('main').classList.toggle('wide', n === 5);
  if (n === 5) enterSettings(); if (n === 6) renderSend();
  $('pview').classList.toggle('hidden', n !== 7); if (n === 7) enterPrinters(); else stopPoll();
  $('mview').classList.toggle('hidden', n !== 8); if (n === 8) enterModels();
  setTimeout(() => { resize(); placeGrips(); }, 50);
  if (n !== 2) clearPlanes();
  accRender();
}

// ---------- progress for long jobs
async function longJob(text, fn) {
  busy(text);
  let alive = true;
  (async () => { while (alive) { await sleep(500); try { const p = await api().progress(); if (alive && p) busy(p.text + (p.frac != null ? `  ${Math.round(p.frac * 100)}%` : '')); } catch (_) {} } })();
  try { return await fn(); } finally { alive = false; busy(null); }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

// ---------- step 2: split and joints
async function enterSplit() {
  if (!jointInfo) {
    jointInfo = await api().joint_types();
    $('jointAll').innerHTML = Object.entries(jointInfo.joints).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join('');
    $('magnet').innerHTML = jointInfo.magnets.map(m => `<option value="${m}" ${m === '8x3' ? 'selected' : ''}>${m} mm</option>`).join('');
  }
  if (!state) { $('splitPart').innerHTML = ''; $('splitWhy').textContent = 'Open a file first.'; return; }
  const opts = state.parts.map(p => ({ p, bad: !p.fits })).sort((a, b) => (b.bad - a.bad) || (b.p.size[2] - a.p.size[2]));
  $('splitPart').innerHTML = opts.map(o => `<option value="${o.p.id}">${o.bad ? '⚠ ' : ''}${esc(o.p.name)} · ${o.p.size[2]} mm tall</option>`).join('');
  if (splitIdx >= 0 && state.parts[splitIdx]) $('splitPart').value = splitIdx; else splitIdx = +$('splitPart').value;
  const nbad = state.parts.filter(p => !p.fits).length;
  $('splitWhy').innerHTML = nbad ? `<span class="bad">${nbad} part${nbad > 1 ? 's are' : ' is'} too big for the P1S.</span> Pick one and press Suggest cuts.` : '<span class="ok">Everything already fits.</span> You can still split a part if you want.';
  renderCuts();
}
$('splitPart').onchange = () => { splitIdx = +$('splitPart').value; cuts = []; renderCuts(); select(splitIdx, true); };
$('planBtn').onclick = async () => {
  if (!state) return;
  splitIdx = +$('splitPart').value;
  const r = await longJob('Measuring the part…', () => api().plan_cuts(splitIdx, $('jointAll').value));
  if (r.error) { status(r.error, true); return; }
  if (!r.cuts.length) { status('This part already fits the P1S; add a cut by hand if you still want to split it.'); }
  const k = $('jointAll').value;
  undoMgr.pushCuts('Suggest cuts');
  cuts = r.cuts.map(z => ({ z, kind: k }));
  partH = r.height;
  renderCuts(); select(splitIdx, true);
};
let partH = 0;
$('addCut').onclick = () => {
  if (!state || splitIdx < 0) return;
  const p = state.parts[splitIdx]; partH = p.size[2];
  const zs = [0, ...cuts.map(c => c.z), partH];
  let gap = 0, at = partH / 2;
  for (let i = 0; i < zs.length - 1; i++) if (zs[i + 1] - zs[i] > gap) { gap = zs[i + 1] - zs[i]; at = (zs[i] + zs[i + 1]) / 2; }
  undoMgr.pushCuts('Add a cut'); cuts.push({ z: Math.round(at * 10) / 10, kind: $('jointAll').value }); cuts.sort((a, b) => a.z - b.z); renderCuts();
};
$('jointAll').onchange = () => { if (cuts.length) undoMgr.pushCuts('Joint type for every cut'); cuts.forEach(c => c.kind = $('jointAll').value); renderCuts(); };

function pieceHeights() {
  const p = state && state.parts[splitIdx]; if (!p) return [];
  const cs = [...cuts].sort((a, b) => a.z - b.z);
  const zs = [0, ...cs.map(c => c.z), p.size[2]];
  return zs.slice(1).map((z, i) => z - zs[i] + (i < cs.length ? (EXTRA_H[cs[i].kind] || 0) : 0));
}
function renderCuts() {
  const L = $('cutList');
  if (!state || splitIdx < 0 || !cuts.length) { L.innerHTML = 'Pick a part and press Suggest cuts (or Add cut). Drag a green plane in the 3D view to move it.'; $('cutCount').textContent = ''; clearPlanes(); return; }
  cuts.sort((a, b) => a.z - b.z);
  const hs = pieceHeights();
  $('cutCount').textContent = `(${cuts.length} cut${cuts.length > 1 ? 's' : ''} → ${cuts.length + 1} pieces)`;
  L.innerHTML = cuts.map((c, i) => {
    const bad = hs[i] > state.max_h || hs[i + 1] > state.max_h;
    return `<div class="cut ${bad ? 'bad' : ''}" data-i="${i}"><span class="n">Cut ${i + 1}</span>
      <span><input class="cz" value="${c.z.toFixed(1)}"> mm</span><button class="x" title="Remove this cut">✕</button>
      <select class="ck">${Object.entries(jointInfo.joints).map(([k, v]) => `<option value="${k}" ${k === c.kind ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select>
      <span class="dim" style="grid-column:1/4">piece below ${hs[i].toFixed(0)} mm · above ${hs[i + 1].toFixed(0)} mm${bad ? ' · <span class="bad">too tall</span>' : ''}</span>
      ${c.specs ? `<span style="grid-column:1/4" class="${c.red ? 'bad' : 'ok'}">${c.red ? '⚠ hand-placed joints have a problem' : '✓ ' + describeSpecs(c.specs)}</span>` : ''}
      <button class="ed" title="Place, size and check the joints yourself, in 2D or 3D">Edit joints…</button></div>`;
  }).join('') + `<div class="dim">Pieces: ${hs.map(h => h.toFixed(0)).join(' · ')} mm (max ${state.max_h})</div>`;
  L.querySelectorAll('.cut').forEach(el => {
    const i = +el.dataset.i;
    el.querySelector('.cz').onchange = e => { undoMgr.pushCuts('Move cut ' + (i + 1)); const v = parseFloat(e.target.value); if (isFinite(v) && v > 5 && v < state.parts[splitIdx].size[2] - 5) { cuts[i].z = v; if (cuts[i].specs) { cuts[i].specs = null; status('Cut moved: its hand-placed joints were reset. Open Edit joints again to place them.'); } } renderCuts(); };
    el.querySelector('.ck').onchange = e => { undoMgr.pushCuts('Joint type for cut ' + (i + 1)); cuts[i].kind = e.target.value; cuts[i].specs = null; cuts[i].red = false; renderCuts(); };
    el.querySelector('.ed').onclick = () => openEditor({ api: api(), idx: splitIdx, cuts: cuts.map(q => q.z), cutIndex: i, cut: cuts[i],
      busyJob: longJob, status,
      onDone: (specs, type, red) => { const c = cuts.find(q => q === cuts[i]); if (!c) return; undoMgr.pushCuts('Edit joints at cut ' + (i + 1));
        if (specs) { c.specs = specs; c.red = red; c.kind = type === 'dowel' ? 'dowels' : (type === 'magnet' ? 'magnets' : type); }
        else { c.specs = null; c.red = false; c.kind = type; }
        renderCuts(); } });
    el.querySelector('.x').onclick = () => { undoMgr.pushCuts('Remove cut ' + (i + 1)); cuts.splice(i, 1); renderCuts(); };
  });
  drawPlanes();
}

function clearPlanes() { planes.forEach(p => p.parent && p.parent.remove(p)); planes = []; }
function drawPlanes() {
  clearPlanes();
  const m = meshes.find(x => x.userData.id === splitIdx); if (!m) return;
  m.geometry.computeBoundingBox();
  const b = m.geometry.boundingBox, w = b.max.x - b.min.x + 40, d = b.max.y - b.min.y + 40;
  const hs = pieceHeights();
  cuts.forEach((c, i) => {
    const bad = hs[i] > state.max_h || hs[i + 1] > state.max_h;
    const pl = new THREE.Mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshBasicMaterial({ color: bad ? 0xe85a5a : 0x00ae42, transparent: true, opacity: 0.35, side: THREE.DoubleSide, depthWrite: false }));
    pl.position.set((b.min.x + b.max.x) / 2, (b.min.y + b.max.y) / 2, b.min.z + c.z);
    const edge = new THREE.LineSegments(new THREE.EdgesGeometry(pl.geometry), new THREE.LineBasicMaterial({ color: bad ? 0xe85a5a : 0x1cc25a }));
    pl.add(edge);
    pl.userData.cut = i; pl.renderOrder = 2;
    m.add(pl); planes.push(pl);
  });
}

// drag a cut plane up and down
let drag = null;
renderer.domElement.addEventListener('pointerdown', e => {
  if (!planes.length) return;
  const r = renderer.domElement.getBoundingClientRect();
  ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
  ray.setFromCamera(ndc, camera);
  const hit = ray.intersectObjects(planes, false)[0];
  if (!hit) return;
  const pl = hit.object, i = pl.userData.cut;
  // screen direction and pixels per mm of the part's own up axis
  const a = pl.getWorldPosition(new THREE.Vector3()), up = pl.parent.localToWorld(pl.position.clone().add(new THREE.Vector3(0, 0, 10)));
  const sa = a.clone().project(camera), su = up.clone().project(camera);
  const dir = new THREE.Vector2((su.x - sa.x) * r.width / 2, -(su.y - sa.y) * r.height / 2);
  const ppm = dir.length() / 10; if (ppm < 1e-6) return;
  undoMgr.pushCuts('Drag cut ' + (i + 1));
  drag = { i, x: e.clientX, y: e.clientY, z0: cuts[i].z, dir: dir.normalize(), ppm };
  controls.enabled = false; e.stopPropagation();
}, true);
window.addEventListener('pointermove', e => {
  if (!drag) return;
  const moved = (e.clientX - drag.x) * drag.dir.x + (e.clientY - drag.y) * drag.dir.y;
  const H = state.parts[splitIdx].size[2];
  cuts[drag.i].z = Math.round(Math.min(H - 5, Math.max(5, drag.z0 + moved / drag.ppm)) * 2) / 2;
  const pl = planes[drag.i]; if (pl) { pl.geometry.computeBoundingBox(); }
  renderCutsQuick();
});
window.addEventListener('pointerup', () => { if (drag) { const c = cuts[drag.i]; if (c && c.specs && Math.abs(c.z - drag.z0) > 0.01) { c.specs = null; status('Cut moved: its hand-placed joints were reset. Open Edit joints again to place them.'); } drag = null; controls.enabled = true; renderCuts(); } });
let quickT = 0;
function renderCutsQuick() { const t = performance.now(); if (t - quickT > 60) { quickT = t; renderCuts(); } }

$('makeBtn').onclick = async () => {
  if (!state || splitIdx < 0 || !cuts.length) { status('Add or suggest cuts first.', true); return; }
  const redCut = cuts.findIndex(c => c.specs && c.red);
  if (redCut >= 0) { status(`Cut ${redCut + 1} has a joint that doesn't fit (shown red). Open Edit joints to fix it first.`, true); return; }
  const kindsOut = cuts.map(c => c.specs ? c.specs : (c.kind === 'dowel' ? 'dowels' : c.kind === 'magnet' ? 'magnets' : c.kind));
  const d = await longJob('Cutting…', () => api().apply_split(splitIdx, cuts.map(c => c.z), kindsOut, parseFloat($('clr').value) || 0.2, $('magnet').value));
  if (d.error) { status(d.error, true); return; }
  const notes = d.notes || [], before = new Set(state.parts.map(p => p.name));
  undoMgr.pushServer('Make pieces'); cuts = []; splitIdx = -1;
  let cur = d; await show(cur);
  $('splitNotes').innerHTML = notes.map((n, i) => `<div class="note"><b>Cut ${i + 1}</b> at ${n.z} mm: ${esc(n.note)}</div>`).join('');
  // hollow the new pieces in the same go (their 30 mm ends stay solid for the joints)
  if ($('hWithSplit').checked) {
    const fresh = state.parts.filter(p => p.role === 'piece' && !before.has(p.name));
    for (const [i, p] of fresh.entries()) {
      const r = await longJob(`Hollowing piece ${i + 1} of ${fresh.length}…`, () => api().hollow_part(p.id, $('hWall').value, Math.max(30, parseFloat($('hEnds').value) || 30), $('hChan').value));
      if (r.error) { status(`${p.name}: ${r.error}`, true); break; }
      cur = r; undoMgr.pushServer(`Hollow ${p.name}`);
    }
    await show(cur);
  }
  enterSplit();
  const msg = `Split into pieces with ${notes.length} joint${notes.length > 1 ? 's' : ''}${$('hWithSplit').checked ? ', hollowed' : ''}. ${state.parts.filter(p => !p.fits).length ? 'Some parts still need splitting.' : 'Everything fits now.'}`;
  if ($('autoArr').checked && state.parts.every(p => p.fits || p.lift > 0.05)) {
    const a = await longJob('Laying the pieces out on plates…', () => api().orient_all());
    if (!a.error) { undoMgr.pushServer('Auto-orient + arrange'); await show(a); goStep(1); setMode('plates'); accOpen($('platesCard')); renderPlateInfo(); status(msg + ` Laid out on ${state.plates.length} plate${state.plates.length > 1 ? 's' : ''}.`); return; }
  }
  status(msg);
};
async function doUndo() { const d = await longJob('Undoing…', () => api().undo()); if (d.error) { status(d.error, true); return; } cuts = []; await show(d); if (!$('splitNotes').closest('.hidden')) enterSplit(); renderPlateInfo(); }
$('undoBtn').onclick = () => undoMgr.doUndo();

window.studio.goStep = goStep;
window.studio.plan = () => $('planBtn').click();
window.studio.make = () => $('makeBtn').click();
window.studio.arrange = () => $('arrangeBtn').click();
window.studio.setSplit = i => { $('splitPart').value = i; $('splitPart').onchange(); };

// =====================================================================  step 5: settings and print time (BambuForge built in)
let S = null;   // {printer, base, name, rows:[{key, orig, value, manual, use, why}], ev:[...], folders}
async function enterSettings(force) {
  if (S && state && S.gen === state.gen && !force) { renderSettings(); return; }
  const r = await longJob(state ? 'Measuring every part and picking the best settings…' : 'Reading your Bambu printers and filaments…', () => api().settings_init(null));
  if (r.error) { $('sRows').innerHTML = `<div class="bad" style="padding:8px">${esc(r.error)}</div>`; return; }
  S = { gen: state ? state.gen : -1, printer: r.printer, base: r.base, name: r.name, folders: r.folders, eta: null, exe: r.exe,
        filament: r.filament, plate: r.plate, temps: r.temps,
        rows: r.rows.map(x => ({ key: x.key, orig: x.value, value: x.value, manual: false, use: true, why: x.why })), summary: r.summary, notes: r.plate_notes };
  $('sPrinter').innerHTML = r.printers.map(p => `<option ${p === r.printer ? 'selected' : ''}>${esc(p)}</option>`).join('');
  $('sPlate').innerHTML = r.plates.map(p => `<option ${p === r.plate ? 'selected' : ''}>${esc(p)}</option>`).join('');
  renderFilChips();
  fillBases(r.bases, r.base); $('sName').value = r.name; S.nameManual = false;
  $('sFolder').innerHTML = r.folders.map(f => `<option value="${esc(f.id)}">${esc(f.label)}</option>`).join('');
  $('setSummary').textContent = '· ' + r.summary.join(' · ');
  renderPlateNote();
  if (state) { await evalSettings(); syncFinish(); } else { $('sRows').innerHTML = '<div class="dim" style="padding:8px">Open a file to get settings picked for it. Printer, plate and filament choices are remembered.</div>'; $('sCount').textContent = ''; }
}
function niceFil(n) { return String(n || '').replace(/ @BBL .*$/, '').replace(/ @base$/, ''); }
function fillFilaments() { renderFilChips(); }
async function renderPlateNote() {
  if (!state) { $('sPlateNote').innerHTML = ''; return; }
  const r = await api().slot_temps(); const plate = $('sPlate').value || S.plate;
  const bad = r.slots.filter(s => !s.plates[plate]);
  const ok = r.slots.filter(s => s.plates[plate]);
  const bed = ok.length ? Math.max(...ok.map(s => s.plates[plate])) : null;
  if (bad.length) {
    const good = Object.keys(r.slots[0].plates).filter(p => r.slots.every(s => s.plates[p]));
    $('sPlateNote').innerHTML = `<span class="bad">⚠ ${bad.map(s => esc(s.name)).join(', ')} doesn't print on the ${esc(plate)} (Bambu's own profile says so). ${good.length ? 'Plates that suit all your filaments: ' + good.map(esc).join(', ') + '.' : 'No single plate suits all of these filaments.'}</span>`;
  } else $('sPlateNote').innerHTML = `<span class="ok">${esc(plate)}: bed ${bed} °C · ` + r.slots.map(s => `<span class="sw" style="background:${s.color};width:11px;height:11px;vertical-align:middle"></span> ${esc(s.name)} ${s.nozzle} °C`).join(' · ') + '</span>';
}
function renderFilChips() {
  if (!state || !state.filaments) { $('sFilChips').innerHTML = '<span class="dim small">Open a file first.</span>'; return; }
  $('sFilChips').innerHTML = state.filaments.slots.filter(s => s.used).map(s => `<span class="fchip" data-s="${s.slot}" title="Click to change"><span class="sw" style="${swatchCss(s)};width:14px;height:14px"></span>${s.slot} · ${esc(s.name)}</span>`).join('');
  $('sFilChips').querySelectorAll('.fchip').forEach(el => el.onclick = () => editSlot(+el.dataset.s));
}
async function chooseSetting(what) {
  const pr = what === 'printer' ? $('sPrinter').value : null, fl = null, pl = what === 'plate' ? $('sPlate').value : null;
  const r = await longJob(what === 'printer' ? 'Switching printer…' : 'Updating…', () => api().settings_choose(pr, fl, pl));
  if (r.error) { status(r.error, true); $('sPrinter').value = S.printer; return; }
  if (pr) {
    S.printer = pr;
    const all = [...r.filaments.mine, ...r.filaments.bambu, ...r.filaments.generic];
    if (!all.includes(S.filament)) { S.filament = all.find(n => n.startsWith('Bambu PLA Basic')) || all[0]; await api().settings_choose(null, S.filament, null); }
    if (r.describe) { await show(r.describe); undoMgr.pushServer('Printer: ' + niceFil(pr)); }
    status(`Printer set to ${pr}. Bed ${state ? state.bed.join(' × ') : ''} mm, ${state ? state.max_h : ''} mm tall.`);
    await enterSettings(true); return;
  }
  if (fl) S.filament = fl;
  if (pl) S.plate = pl;
  const t = await api().settings_choose(null, null, null); S.temps = t.temps;
  renderPlateNote(); if (S.eta) { S.eta.stale = true; renderEta(); }
}
function fillBases(list, pick) { $('sBase').innerHTML = list.map(b => `<option ${b === pick ? 'selected' : ''}>${esc(b)}</option>`).join(''); }
async function evalSettings() {
  const r = await api().settings_eval(S.base, S.rows);
  S.ev = r.rows;
  S.ev.forEach((e, i) => { if (!S.rows[i].manual) S.rows[i].value = e.value; });
  if (!S.nameManual) { const lh = S.ev.find(e => e.key === 'layer_height'); if (lh && lh.norm) $('sName').value = S.name.replace(/^0?\.\d+mm/, '.' + (+lh.norm).toFixed(2).slice(2) + 'mm'); }
  renderSettings();
  if (S.eta) { S.eta.stale = true; renderEta(); }
}
function renderSettings() {
  const R = $('sRows');
  R.innerHTML = S.ev.map((e, i) => {
    const row = S.rows[i];
    const st = e.error ? `<span class="st err">⚠ ${esc(e.error)}</span>` : e.same ? '<span class="st same">= same as base</span>' : '<span class="st ch">✓ will change</span>';
    return `<div class="srow ${row.use ? '' : 'off'}" data-i="${i}" title="${esc(e.tooltip)}${e.allowed.length ? '\n\nAllowed: ' + esc(e.allowed.join(', ')) : ''}">
      <span class="cb ${row.use ? 'on' : ''}"></span>
      <span class="nm">${esc(e.label)} <span class="h">${esc(e.category ? e.category + ' · ' : '')}${esc(e.key)}</span><br><span class="bv">Bambu base: ${esc(e.base)}</span></span>
      <input value="${esc(row.value)}">${st}
      <span class="why">${e.auto ? '↻ ' + esc(e.auto) + ' · ' : ''}${esc(row.why || '')}</span></div>`;
  }).join('');
  R.querySelectorAll('.srow').forEach(el => {
    const i = +el.dataset.i;
    el.querySelector('.cb').onclick = () => { S.rows[i].use = !S.rows[i].use; renderSettings(); if (S.eta) { S.eta.stale = true; renderEta(); } };
    el.querySelector('input').onchange = e => { S.rows[i].value = e.target.value; S.rows[i].orig = e.target.value; S.rows[i].manual = true; evalSettings(); };
  });
  const used = S.rows.filter(r => r.use).length, ch = S.ev.filter((e, i) => S.rows[i].use && !e.error && !e.same).length;
  $('sCount').textContent = `${used} of ${S.rows.length} ticked · ${ch} will change`;
  const bad = S.ev.filter((e, i) => S.rows[i].use && e.error).length;
  $('sNote').innerHTML = bad ? `<span class="bad">${bad} ticked setting${bad > 1 ? 's have' : ' has'} a problem. Fix the value or untick it.</span>` : '';
}
$('sPrinter').onchange = () => chooseSetting('printer');
$('sPlate').onchange = () => chooseSetting('plate');

$('sBase').onchange = () => { S.base = $('sBase').value; evalSettings(); };
$('sName').oninput = () => { S.nameManual = true; S.name = $('sName').value; };
$('sAll').onclick = e => { e.preventDefault(); S.rows.forEach((r, i) => r.use = !S.ev[i].error); renderSettings(); };
$('sNone').onclick = e => { e.preventDefault(); S.rows.forEach(r => r.use = false); renderSettings(); };

$('etaBtn').onclick = async () => {
  if (!S) return;
  const r = await longJob('Starting Bambu Studio…', () => api().estimate(S.base, S.rows, $('sName').value.trim()));
  try { const pi = await api().plates_info(); if (pi && !pi.error) applyLite(pi); } catch (_) {}
  if (r.error) { status(r.error, true); $('etaTable').innerHTML = `<span class="bad">${esc(r.error)}</span>`; return; }
  S.eta = r; S.eta.stale = false; renderEta(); refreshTotals();
  status(`Print time from Bambu Studio: ${fmtHm(r.total)} total, ${(r.grams / 1000).toFixed(2)} kg of filament.`);
};
function fmtHm(s) { const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60); return h ? `${h} h ${String(m).padStart(2, '0')} m` : `${m} m`; }
function renderEta() {
  const e = S.eta; if (!e) return;
  const name = id => (state.plates.find(p => p.id === id) || {}).name || 'Plate ' + id;
  $('etaTable').innerHTML = `<table class="eta"><tr><th>Plate</th><th>What's on it</th><th>Time</th><th>Filament</th></tr>` +
    e.nice.map(x => `<tr><td>${esc(name(x.plate))}</td><td class="dim">${esc((S.notes || {})[x.plate] || '')}</td><td>${x.time}</td><td>${x.grams} g</td></tr>`).join('') +
    `</table><div style="margin-top:6px;${e.stale ? 'color:var(--warn)' : 'color:var(--green2)'}">${e.stale ? 'Settings changed; press Update print time. Was: ' : 'Total: '}${fmtHm(e.total)} · ${(e.grams / 1000).toFixed(2)} kg</div>`;
}
$('saveSet').onclick = async () => {
  if (!S) return;
  const r = await longJob('Writing the project…', () => api().save_with_settings(S.base, S.rows, $('sName').value.trim()));
  if (r && r.error) status(r.error, true); else if (r && r.saved) status('Saved ' + r.saved + '. Open it in Bambu Studio and it is ready to slice with these settings.');
};

// =====================================================================  step 6: send
function renderSend() {
  if (!state) { $('sendSummary').textContent = 'Open a file first.'; return; }
  if (!S || S.gen !== state.gen) { $('sendSummary').innerHTML = 'Go to step 3 (Settings) first so the settings are picked. <a href="#" id="go5">Go to step 3</a>'; const g = $('go5'); if (g) g.onclick = e => { e.preventDefault(); goStep(5); }; return; }
  const ch = S.ev.filter((e, i) => S.rows[i].use && !e.error && !e.same).length;
  $('sendSummary').innerHTML = `Preset <b>${esc($('sName').value)}</b> based on <b>${esc(S.base)}</b> for ${esc(S.printer)} · ${ch} setting${ch === 1 ? '' : 's'} changed.` +
    (S.eta ? `<br>Print time ${fmtHm(S.eta.total)} · ${(S.eta.grams / 1000).toFixed(2)} kg${S.eta.stale ? ' (before your last changes)' : ''}` : '');
}
$('sendBtn').onclick = async () => {
  if (!S) { goStep(5); return; }
  const name = $('sName').value.trim(), folder = $('sFolder').value, open = $('openAfter').checked;
  let r = await longJob('Sending…', () => api().send(S.base, S.rows, name, folder, open));
  if (r.need_close) {
    if (!confirm('Bambu Studio is open. It has to close so it can pick up the new preset.\n\nClose Bambu Studio now? (It will ask you to save your project if needed.)')) { status('Cancelled. Nothing was changed.'); return; }
    let c = await longJob('Waiting for Bambu Studio to close…', () => api().close_bambu(false));
    if (!c.closed) {
      if (!confirm('Bambu Studio is still open (maybe a "save project?" box is waiting).\n\nForce it to close? Unsaved work in Bambu Studio will be lost.')) { status('Cancelled. Nothing was changed.'); return; }
      c = await longJob('Closing Bambu Studio…', () => api().close_bambu(true));
      if (!c.closed) { status("Bambu Studio wouldn't close, so nothing was changed.", true); return; }
    }
    await sleep(800);
    r = await longJob('Sending…', () => api().send(S.base, S.rows, name, folder, open));
  }
  if (r.error) { status(r.error, true); $('sendInfo').innerHTML = `<span class="bad">${esc(r.error)}</span>`; return; }
  const msg = `${r.updated ? 'Updated' : 'Created'} '${esc(name)}' (${r.changed} setting${r.changed === 1 ? '' : 's'} changed from ${esc(S.base)}).${r.backup ? ' Old version backed up.' : ''}` +
    (r.opened ? ' Bambu Studio is opening with your project.' : '');
  $('sendInfo').innerHTML = `<span class="ok">${msg}</span>`; status(msg.replace(/<[^>]+>/g, ''));
  if (r.synced_folder && r.opened) watchSync(r.info, name);
};
async function watchSync(info, name) {
  for (let i = 0; i < 90; i++) {
    await sleep(2000);
    const s = await api().sync_status(info);
    if (s.synced) { $('sendInfo').innerHTML += `<br><span class="ok">✓ '${esc(name)}' is synced to your Bambu account (cloud id ${esc(s.id)}).</span>`; return; }
    if (i % 5 === 0) $('sendInfo').dataset.wait = i;
  }
  $('sendInfo').innerHTML += '<br><span style="color:var(--warn)">Not synced yet. Make sure you are signed in to Bambu Studio; it syncs next time it starts.</span>';
}
window.studio.goStep = goStep;
window.studio.eta = () => $('etaBtn').click();
window.studio.setBase = b => { $('sBase').value = b; $('sBase').onchange(); };

// =====================================================================  step 3: hollow
function enterHollow() {
  if (!state) { $('hPart').innerHTML = ''; return; }
  $('hPart').innerHTML = state.parts.filter(p => p.role !== 'joint').map(p => `<option value="${p.id}">${esc(p.name)} · ${p.size.join(' × ')} mm</option>`).join('');
  if (selected >= 0 && state.parts[selected] && state.parts[selected].role !== 'joint') $('hPart').value = selected;
  hPick();
}
function hPick() { const p = state && state.parts[+$('hPart').value]; if (p) { $('hEnds').value = p.role === 'piece' ? 30 : 3; select(p.id, true); } }
$('hPart').onchange = hPick;
$('hBtn').onclick = async () => {
  if (!state) return;
  const d = await longJob('Hollowing…', () => api().hollow_part(+$('hPart').value, $('hWall').value, $('hEnds').value, $('hChan').value));
  if (d.error) { status(d.error, true); $('hNote').innerHTML = `<span class="bad">${esc(d.error)}</span>`; return; }
  await show(d); undoMgr.pushServer('Hollow'); $('hNote').innerHTML = `<span class="ok">${esc(d.note)}</span>`; status('Hollowed: ' + d.note); enterHollow();
};
$('hUndo').onclick = async () => { await undoMgr.doUndo(); enterHollow(); $('hNote').textContent = ''; };

// =====================================================================  step 4: plates, orientation, moving parts
async function plateJob(text, fn, label) {
  const d = await longJob(text, fn);
  if (d.error) { status(d.error, true); return; }
  if (label) undoMgr.pushServer(label);
  await show(d); setMode('plates'); renderPlateInfo(); renderOrient();
  if (d.note) status(d.note.split('\n').length > 1 ? `Turned ${d.note.split('\n').length} parts and arranged ${state.plates.length} plate${state.plates.length > 1 ? 's' : ''}.` : d.note);
}
$('orientAll').onclick = () => state && plateJob('Finding the best way to print each part…', () => api().orient_all(), 'Auto-orient + arrange');
$('arrangeBtn').onclick = () => state && plateJob('Arranging plates…', () => api().arrange(), 'Arrange plates');
$('undoBtn2').onclick = () => undoMgr.doUndo();
function renderPlateInfo() {
  if (!state) { $('plateInfo').textContent = ''; return; }
  $('plateInfo').innerHTML = state.plates.map(pl => {
    const ps = state.parts.filter(p => p.plate === pl.id);
    return ps.length ? `<div class="note"><b>${esc(pl.name)}</b>: ${ps.length} part${ps.length > 1 ? 's' : ''}, tallest ${Math.max(...ps.map(p => p.size[2])).toFixed(0)} mm</div>` : '';
  }).join('');
}
async function renderOrient() {
  const p = state && state.parts[selected];
  $('oPlate').innerHTML = state ? state.plates.map(pl => `<option value="${pl.id}">${esc(pl.name)}</option>`).join('') + '<option value="new">A new plate</option>' : '';
  if (!p) { $('oSel').textContent = 'Click a part in the 3D view or the list. Drag it to move it on its plate.'; $('oOpts').innerHTML = ''; return; }
  $('oPlate').value = p.plate;
  $('oSel').innerHTML = `<b>${esc(p.name)}</b> · ${p.size.join(' × ')} mm · drag it in the 3D view to move it`;
  const opts = await api().orient_options(p.id);
  const ok = opts.filter(o => o.fits); const best = (ok.length ? ok : opts).reduce((a, b) => (a.support_cm2 - 0.3 * a.bed_cm2) <= (b.support_cm2 - 0.3 * b.bed_cm2) ? a : b);
  $('oOpts').innerHTML = opts.map(o => `<div class="opt ${o === best ? 'best' : ''} ${o.fits ? '' : 'nofit'}" data-n="${esc(o.name)}"><span>${esc(o.name)}${o === best ? ' <span class="ok">(best)</span>' : ''}</span><span class="s">${o.height} mm tall</span>
     <span class="s">support ${o.support_cm2} cm² · on bed ${o.bed_cm2} cm²${o.fits ? '' : ' · too big'}</span></div>`).join('');
  $('oOpts').querySelectorAll('.opt').forEach(el => el.onclick = () => plateJob('Turning it…', () => api().orient_part(p.id, el.dataset.n), 'Turn ' + p.name));
}
$('oPlate').onchange = () => { const p = state && state.parts[selected]; if (!p) return; const v = $('oPlate').value; plateJob('Moving…', () => api().move_part(p.id, 0, 0, v === 'new' ? 'new' : +v), 'Move ' + p.name + ' to another plate'); };

// keep the step-4 panel in sync when a part is clicked
const _select = select;
window.studio.orientAll = () => $('orientAll').click();
window.studio.hollow = (i, w, e, c) => { $('hPart').value = i; $('hWall').value = w; $('hEnds').value = e; $('hChan').value = c; $('hBtn').click(); };

function describeSpecs(sp) {
  if (!sp.length) return 'glue face only';
  const n = {}; sp.forEach(s => { const k = s.kind === 'magnet' ? `magnet pair ${s.md}×${s.mt}` : ({ dpeg: 'D-peg', dowel: 'dowel', twist: 'twist-lock', thread: 'screw thread' }[s.kind]); n[k] = (n[k] || 0) + 1; });
  return 'hand-placed: ' + Object.entries(n).map(([k, v]) => `${v} × ${k}`).join(', ');
}
window.studio.editCut = i => document.querySelectorAll('#cutList .cut .ed')[i].click();

// =====================================================================  Parts panel: printer and filament per plate
function renderPrinterLine(d) {
  if (!d || !d.printer) { $('printerLine').textContent = ''; return; }
  $('printerLine').textContent = `${d.printer.replace(' 0.4 nozzle', '')} · ${d.bed.join(' × ')} × ${d.max_h} mm` + (d.filament ? ` · ${niceFil(d.filament)}` : '');
}
function priceOf(s) { return (UI && UI.prices && (UI.prices[s.preset || s.name] || UI.prices[s.name])) || 0; }
function costOf(d) {
  if (!d || !d.filaments) return null;
  const used = d.filaments.slots.filter(s => s.used); if (!used.length || !used.every(s => priceOf(s) > 0)) return null;
  return used.reduce((a, s) => a + s.grams / 1000 * priceOf(s), 0);
}
function renderTotals(d) {
  if (!d || !d.filament_per_plate || !d.filament_per_plate.length) { $('filTotals').innerHTML = ''; return; }
  const name = id => (state.plates.find(p => p.id === id) || {}).name || 'Plate ' + id;
  $('filTotals').innerHTML = '<div class="panelTitle" style="font-size:13px">Filament</div>' +
    d.filament_per_plate.map(f => `<div class="row"><span>${esc(name(f.plate))}</span><span>${f.grams} g${f.time ? ' · ' + f.time : ''}</span></div>`).join('') +
    `<div class="row tot"><span>Overall total</span><span>${(d.filament_total / 1000).toFixed(2)} kg</span></div>` +
    (costOf(d) != null ? `<div class="row"><span>Cost</span><b>$${costOf(d).toFixed(2)}</b></div>` + d.filament_per_plate.map(f => `<div class="row dim small"><span>&nbsp;&nbsp;${esc(name(f.plate))}</span><span>$${(costOf(d) * f.grams / Math.max(1, d.filament_total)).toFixed(2)}</span></div>`).join('')
      : '<div class="dim small adv" style="margin-top:3px">Add roll prices in Colours (Advanced) to see the cost.</div>') +
    (d.filaments && d.filaments.slots.filter(s => s.used).length > 1 ? '<div class="panelTitle" style="font-size:13px;margin-top:8px">By colour</div>' +
      d.filaments.slots.filter(s => s.used).map(s => `<div class="row"><span><span class="sw" style="${swatchCss(s)};width:11px;height:11px;vertical-align:middle;display:inline-block"></span> ${s.slot} · ${esc(s.name)}</span><span>${Math.round(s.grams)} g</span></div>`).join('') : '') +
    `<div class="plateTag">${d.filament_exact ? 'Exact, from Bambu Studio' : 'Estimate · exact after Update print time (step 3)'}</div>`;
}
async function refreshTotals() { if (!state) return; const t = await api().totals(); renderTotals(t); }

// =====================================================================  undo / redo for everything
const undoMgr = {
  undo: [], redo: [],
  pushServer(label) { this.undo.push({ kind: 'server', label }); this.redo = []; this.render(); },
  pushCuts(label) { this.undo.push({ kind: 'cuts', label, snap: snapCuts() }); this.redo = []; this.render(); },
  async doUndo() {
    if (editorActive()) { editorUndo(); return; }
    const e = this.undo.pop(); if (!e) return;
    if (e.kind === 'server') { const d = await longJob('Undoing ' + e.label + '…', () => api().undo()); if (d.error) { status(d.error, true); return; } if (d.gen != null) await show(d); this.redo.push(e); if (e.label.startsWith('Printer')) enterSettings(true); }
    else { const now = snapCuts(); restoreCuts(e.snap); this.redo.push({ ...e, snap: now }); }
    status('Undid: ' + e.label); this.render(); afterUndo();
  },
  async doRedo() {
    if (editorActive()) { editorRedo(); return; }
    const e = this.redo.pop(); if (!e) return;
    if (e.kind === 'server') { const d = await longJob('Redoing ' + e.label + '…', () => api().redo()); if (d.error) { status(d.error, true); return; } if (d.gen != null) await show(d); this.undo.push(e); if (e.label.startsWith('Printer')) enterSettings(true); }
    else { const now = snapCuts(); restoreCuts(e.snap); this.undo.push({ ...e, snap: now }); }
    status('Redid: ' + e.label); this.render(); afterUndo();
  },
  async jump(n) { for (let i = 0; i < n; i++) await this.doUndo(); },
  reset() { this.undo = []; this.redo = []; this.render(); },
  render() {
    $('undoBtn0').disabled = !this.undo.length; $('redoBtn0').disabled = !this.redo.length;
    $('undoBtn0').title = this.undo.length ? `Undo: ${this.undo[this.undo.length - 1].label} (Ctrl+Z)` : 'Nothing to undo';
    $('redoBtn0').title = this.redo.length ? `Redo: ${this.redo[this.redo.length - 1].label} (Ctrl+Shift+Z)` : 'Nothing to redo';
    $('histSel').innerHTML = `<option value="0">History (${this.undo.length})</option>` + this.undo.slice().reverse().map((u, i) => `<option value="${i + 1}">↶ ${i + 1}: ${esc(u.label)}</option>`).join('');
  }
};
function snapCuts() { return JSON.stringify({ cuts, splitIdx }); }
function restoreCuts(s) { const o = JSON.parse(s); cuts = o.cuts; splitIdx = o.splitIdx; renderCuts(); }
function afterUndo() { const p2 = document.querySelector('.page[data-page="2"]'); if (p2 && !p2.classList.contains('hidden')) renderCuts(); const p4 = document.querySelector('.page[data-page="4"]'); if (p4 && !p4.classList.contains('hidden')) { renderPlateInfo(); renderOrient(); } }
$('undoBtn0').onclick = () => undoMgr.doUndo(); $('redoBtn0').onclick = () => undoMgr.doRedo();
$('histSel').onchange = e => { const n = +e.target.value; e.target.value = '0'; if (n) undoMgr.jump(n); };
window.addEventListener('keydown', e => {
  if (!(e.ctrlKey || e.metaKey)) return;
  const k = e.key.toLowerCase(), t = document.activeElement && document.activeElement.tagName;
  if (t === 'INPUT' || t === 'TEXTAREA') return;            // typing: let the box undo its own text
  if (k === 'z' && !e.shiftKey) { e.preventDefault(); undoMgr.doUndo(); }
  else if ((k === 'z' && e.shiftKey) || k === 'y') { e.preventDefault(); undoMgr.doRedo(); }
});
undoMgr.render();

// =====================================================================  step 7: printers on your network
let PR = { list: [], cur: null, timer: null, last: null, tray: 0, fan: {}, dragFan: false };
async function enterPrinters() {
  const r = await api().printers_saved();
  if (!r.mqtt) { $('pConn').innerHTML = '<span class="bad">Part of the program is missing. Unzip the download again into a new folder.</span>'; return; }
  PR.list = r.printers;
  if (!PR.cur && PR.list.length) PR.cur = PR.list[0].serial;
  renderPrinterSel();
  $('pPlate').innerHTML = state ? state.plates.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('') : '<option value="">Open a file first</option>';
  if (!PR.list.length) { $('pConn').innerHTML = '<span class="dim">No printers yet. Press <b>Find printers</b>, or <b>Add by IP…</b>.</span>'; $('pAdd').classList.remove('hidden'); setCtl(false); return; }
  startPoll();
}
function renderPrinterSel() {
  $('pSel').innerHTML = PR.list.map(p => `<option value="${esc(p.serial)}" ${p.serial === PR.cur ? 'selected' : ''}>${p.connected ? '●' : '○'} ${esc(p.name)} · ${esc(p.model || '')}</option>`).join('');
}
$('pSel').onchange = () => { PR.cur = $('pSel').value; PR.last = null; startPoll(); };
function setCtl(on) { $('pCtl').style.opacity = on ? 1 : 0.4; $('pCtl').style.pointerEvents = on ? 'auto' : 'none'; }
function startPoll() { stopPoll(); poll(); PR.timer = setInterval(poll, 2000); }
function stopPoll() { if (PR.timer) clearInterval(PR.timer); PR.timer = null; }
async function poll() {
  if (!PR.cur) return;
  let s; try { s = await api().printer_status(PR.cur); } catch (e) { return; }
  if (s.error && !s.serial) { $('pConn').innerHTML = `<span class="bad">${esc(s.error)}</span>`; setCtl(false); return; }
  PR.last = s; renderPrinter(s);
}
const fmtMin = m => m == null ? '–' : `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, '0')} m`;
function renderPrinter(s) {
  const ok = s.online && !s.error;
  $('pConn').innerHTML = ok ? `<span class="ok">● Online · LAN · ${esc(s.ip)}</span> <span class="dim">· ${esc(s.state_text)}</span>`
    : s.error ? `<span class="bad">● ${esc(s.error)}</span><div class="dim small" style="margin-top:4px">If it was working before: on the printer, check <b>Settings → WLAN → LAN Only Mode</b> and <b>Developer Mode</b> are still on.</div>`
    : '<span class="warn">○ Waiting for the printer to report in…</span>';
  setCtl(ok);
  const msgs = (s.hms_info || []).map(h => `<div class="hmsbox">⚠ ${esc(h.code)} · ${esc(h.text)} · <a href="${h.link}" target="_blank">How to fix (Bambu wiki)</a></div>`);
  if (s.error_info) msgs.unshift(`<div class="hmsbox err">⚠ ${esc(s.error_info.code)} · ${esc(s.error_info.text)} · <a href="${s.error_info.link}" target="_blank">How to fix (Bambu wiki)</a></div>`);
  const bad = (s.cmd_results || []).filter(c => !/^(success|ok)$/i.test(c.result) && Date.now() / 1000 - c.t < 60);
  if (bad.length) msgs.unshift(`<div class="hmsbox err">The printer refused "${esc(bad[bad.length - 1].command)}": ${esc(bad[bad.length - 1].reason || bad[bad.length - 1].result)}. Is <b>Developer Mode</b> on?</div>`);
  $('pHms').innerHTML = msgs.join('');
  const busy = ['RUNNING', 'PREPARE', 'PAUSE'].includes(s.state);
  $('pJob').textContent = busy || s.state === 'FINISH' || s.state === 'FAILED' ? (s.job || 'Print') : 'Nothing printing';
  $('pState').textContent = s.state_text;
  const stages = [];
  if (s.state === 'PREPARE' || s.state === 'RUNNING' || s.state === 'PAUSE') stages.push(`<div class="now">▶ ${esc(s.stage_text)}${s.stage === 2 && s.bed_target ? ` to ${Math.round(s.bed_target)} °C` : ''}${s.stage === 7 && s.nozzle_target ? ` to ${Math.round(s.nozzle_target)} °C` : ''}</div>`);
  if (s.state === 'FINISH') stages.push('<div class="now">✓ Finished</div>'); if (s.state === 'FAILED') stages.push('<div style="color:var(--err)">■ Stopped or failed</div>');
  $('pStages').innerHTML = stages.join('');
  const pct = s.percent == null ? 0 : s.percent; $('pBar').style.width = (busy || s.state === 'FINISH' ? pct : 0) + '%';
  $('pPct').textContent = busy || s.state === 'FINISH' ? pct + '%' : '–';
  $('pLayer').textContent = s.layers ? `${s.layer} / ${s.layers}` : '–';
  $('pLeft').textContent = busy ? fmtMin(s.remaining_min) : '–';
  $('pFin').textContent = busy && s.remaining_min != null ? new Date(Date.now() + s.remaining_min * 60000).toLocaleString([], { weekday: 'short', hour: 'numeric', minute: '2-digit' }) : '–';
  $('pG').textContent = s.grams_total ? `${s.grams_used ?? 0} / ${s.grams_total} g` : '–';
  $('pPause').textContent = s.state === 'PAUSE' ? 'Resume' : 'Pause';
  $('pPause').disabled = !busy; $('pStop').disabled = !busy; $('pHome').disabled = busy || !ok; $('pCal').disabled = busy || !ok; $('pSend').disabled = busy || !ok || !state;
  const t = v => v == null ? '–' : Math.round(v);
  $('tN').textContent = t(s.nozzle); $('tB').textContent = t(s.bed);
  if (document.activeElement !== $('sN')) $('sN').value = t(s.nozzle_target); if (document.activeElement !== $('sB')) $('sB').value = t(s.bed_target);
  const fanPct = v => v == null ? 0 : Math.round(+v / 15 * 100 / 10) * 10;   // printers report fan speed 0-15
  [['fP', 'part_fan'], ['fA', 'aux_fan']].forEach(([id, key]) => {
    const rep = fanPct(s[key]), pend = PR.fan[id];
    if (pend && Math.abs(rep - pend.v) <= 10) delete PR.fan[id];                       // the printer has caught up
    if (pend && Date.now() > pend.until) delete PR.fan[id];                              // gave up waiting: show the truth
    if (PR.fan[id]) { $(id).value = PR.fan[id].v; $(id + 'o').textContent = PR.fan[id].v + '% (setting…)'; }
    else if (!PR.dragFan) { $(id).value = rep; $(id + 'o').textContent = rep + '%'; }
  });
  const lightOn = s.light !== 'off'; $('pLight').textContent = lightOn ? 'On' : 'Off'; $('pLight').className = lightOn ? 'primary' : '';
  const now = s.tray_now == null ? null : +s.tray_now;
  $('pNozzle').textContent = 'Nozzle: ' + (now == null || now === 255 ? 'empty (no filament loaded)' : now === 254 ? 'external spool' : `filament from AMS slot ${now + 1}`);
  $('pAms').title = 'Click a slot to set its brand, type and colour';
  $('pAms').innerHTML = (s.ams || []).map(a => `<div class="slot ${a.index === PR.tray ? 'on' : ''} ${a.empty ? 'empty' : ''}" data-i="${a.index}" style="${swatchCss((PR.looks || {})[(PR.cur || '') + ':' + a.index] || { colors: [a.color] })};color:${lum(a.color) > 0.6 ? '#222' : '#fff'}" title="${esc(a.name || a.type || 'empty')}"><b>A${a.index + 1}</b><br>${esc(a.empty ? 'empty' : (a.name && a.name !== a.type ? a.name : a.type))}${!a.empty && a.name && a.name !== a.type ? `<br><span style="opacity:.75">${esc(a.type)}</span>` : ''}</div>`).join('') || '<span class="dim small">No AMS reported.</span>';
  $('pAms').querySelectorAll('.slot').forEach(el => el.onclick = () => amsEdit(+el.dataset.i));
  $('pLoad').textContent = `Load slot ${PR.tray + 1}`;
  const used = state && state.filaments ? state.filaments.slots.filter(x => x.used) : [];
  const trayVal = $('pTray').value;
  $('pTray').innerHTML = (used.length > 1 ? `<option value="-2">Match my model's colours (colour 1 → slot 1…)</option>` : '') +
    (s.ams || []).filter(a => !a.empty).map(a => `<option value="${a.index}">AMS slot ${a.index + 1} · ${esc(a.type)}</option>`).join('') + '<option value="-1">External spool</option>';
  if ([...$('pTray').options].some(o => o.value === trayVal)) $('pTray').value = trayVal; else if (used.length > 1) $('pTray').value = '-2'; else $('pTray').value = String(PR.tray);
  renderSlotMap(s);
  $('pFw').textContent = s.firmware ? `Firmware ${s.firmware}` + (s.update_available ? ' · update available: install it from Bambu Handy or Bambu Studio' : ' · up to date') : '';
  $('pHist').innerHTML = (s.history || []).map(h => `${esc(h.at)} · ${esc(h.printer)} · ${esc(h.job)} · ${esc(h.result)}`).join('<br>') || 'None yet.';
}
async function amsEdit(i) {
  PR.tray = i; renderPrinter(PR.last);
  const a = (PR.last.ams || []).find(x => x.index === i) || {};
  const r = await pickFilament(api(), { title: `What's in AMS slot ${i + 1}?`, color: a.color, useText: `Set AMS slot ${i + 1}` });
  if (!r) return;
  await pcmd('ams_set', { tray: i, id: r.id, type: r.type, color: r.color, tmin: r.tmin, tmax: r.tmax }, null, `AMS slot ${i + 1} set to ${r.brand} ${r.name}.`);
  PR.looks = PR.looks || {}; PR.looks[(PR.cur || '') + ':' + i] = { colors: r.colors, ctype: r.ctype, effect: r.effect };
}
function lum(hex) { const n = parseInt(hex.slice(1), 16); return (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255; }
async function pcmd(cmd, a, b, okText) { const r = await api().printer_cmd(PR.cur, cmd, a ?? null, b ?? null); if (r.error) status(r.error, true); else if (okText) status(okText); setTimeout(poll, 800); }
$('pPause').onclick = () => pcmd(PR.last && PR.last.state === 'PAUSE' ? 'resume' : 'pause', null, null, PR.last && PR.last.state === 'PAUSE' ? 'Resuming…' : 'Pausing…');
$('pStop').onclick = () => { if (confirm('Stop this print? It cannot be resumed.')) pcmd('stop', null, null, 'Stopping the print.'); };
$('pHome').onclick = () => pcmd('home', null, null, 'Homing the printer.');
$('pCal').onclick = () => $('pCalBox').classList.toggle('hidden');
$('calGo').onclick = () => { $('pCalBox').classList.add('hidden'); pcmd('calibrate', { bed: $('calBed').checked, vibration: $('calVib').checked, motor: $('calMot').checked }, null, 'Calibration started on the printer.'); };
$('setN').onclick = () => pcmd('nozzle', $('sN').value, null, `Nozzle set to ${$('sN').value} °C.`);
$('setB').onclick = () => pcmd('bed', $('sB').value, null, `Bed set to ${$('sB').value} °C.`);
function fanSet(id, which) {
  const v = +$(id).value; PR.fan[id] = { v, until: Date.now() + 20000 }; PR.dragFan = false;
  $(id + 'o').textContent = v + '% (setting…)'; pcmd('fan', which, v, `${which === 'part' ? 'Part' : 'Aux'} fan set to ${v}%.`);
}
['fP', 'fA'].forEach(id => {
  $(id).addEventListener('pointerdown', () => PR.dragFan = true);
  $(id).oninput = () => { PR.dragFan = true; $(id + 'o').textContent = $(id).value + '%'; };
  $(id).onchange = () => fanSet(id, id === 'fP' ? 'part' : 'aux');
});
$('pLight').onclick = () => pcmd('light', !(PR.last && PR.last.light !== 'off'));
$('pLoad').onclick = () => pcmd('load', PR.tray, null, `Loading AMS slot ${PR.tray + 1}…`);
$('pUnload').onclick = () => pcmd('unload', null, null, 'Unloading the filament…');
$('pTray').onchange = () => { PR.tray = +$('pTray').value; };
$('pSend').onclick = async () => {
  if (!state) { status('Open a file first.', true); return; }
  if (!S || S.gen !== state.gen) { await enterSettings(true); }
  const plate = +$('pPlate').value, level = $('pLevel').checked;
  if (!slotMapOk()) return;
  const r = await longJob('Getting the plate ready…', () => api().printer_send(PR.cur, plate, level, 0, S.base, S.rows, $('sName').value.trim(), PR.map));
  if (r.error) { status(r.error, true); return; }
  status(`Sent ${r.job.name} to the printer. It will heat up${level ? ', level the bed' : ''} and start.`);
  poll();
};
// finding and adding printers
$('pFind').onclick = async () => {
  const r = await longJob('Looking for Bambu printers on your network…', () => api().printers_discover());
  const f = r.found || [];
  $('pFound').innerHTML = f.length ? '<div class="dim" style="margin:8px 0 4px">Found on your network:</div>' + f.map(p => `<div class="inline" style="justify-content:space-between;margin:3px 0"><span>${esc(p.name)} · ${esc(p.model)} · ${esc(p.ip)}${p.connect === 'cloud' ? ' <span class="warn">(cloud mode: turn on LAN Only + Developer Mode)</span>' : ''}</span>${p.saved ? '<span class="ok">added</span>' : `<button data-s="${esc(p.serial)}" data-ip="${esc(p.ip)}" data-n="${esc(p.name)}" data-m="${esc(p.model)}">Add</button>`}</div>`).join('')
    : '<div class="dim" style="margin-top:8px">No printers answered. Make sure they are switched on and on the same network as this PC, or use <b>Add by IP…</b>.</div>';
  $('pFound').querySelectorAll('button[data-s]').forEach(b => b.onclick = () => { $('aSerial').value = b.dataset.s; $('aIp').value = b.dataset.ip; $('aName').value = b.dataset.n; $('aModel').value = [...$('aModel').options].some(o => o.value === b.dataset.m) ? b.dataset.m : 'P1S'; $('pAdd').classList.remove('hidden'); $('aCode').focus(); });
};
$('pAddBtn').onclick = () => $('pAdd').classList.toggle('hidden');
$('aCancel').onclick = () => $('pAdd').classList.add('hidden');
$('aGo').onclick = async () => {
  $('aErr').textContent = '';
  const r = await longJob('Connecting to the printer…', () => api().printer_add($('aSerial').value, $('aIp').value, $('aCode').value, $('aName').value, $('aModel').value));
  if (r.error) { $('aErr').textContent = r.error; return; }
  $('pAdd').classList.add('hidden'); $('aCode').value = ''; PR.cur = $('aSerial').value.trim(); status('Printer added.'); enterPrinters();
};
$('pRemove').onclick = async () => { if (!PR.cur || !confirm('Remove this printer from BambuForge Studio? (Nothing changes on the printer.)')) return; await api().printer_remove(PR.cur); PR.cur = null; enterPrinters(); };
window.studio.printers = { send: () => $('pSend').click(), poll };

// =====================================================================  finish options (ironing, smooth seams, precise walls)
const FINISH = {
  fIron: [['ironing_type', 'top', 'smooths the very top surfaces with a second, gentle pass of the hot nozzle (adds time)']],
  fScarf: [['seam_slope_type', 'external', 'blends the start and end of each outer wall so the seam line almost disappears']],
  fPrecise: [['precise_outer_wall', '1', 'keeps outer walls exactly where they belong for sharper, more accurate edges']],
};
Object.keys(FINISH).forEach(id => $(id).onchange = async () => {
  if (!S) return;
  const on = $(id).checked;
  FINISH[id].forEach(([key, val, why]) => {
    const i = S.rows.findIndex(r => r.key === key);
    if (on && i < 0) S.rows.push({ key, orig: val, value: val, manual: true, use: true, why: '✨ ' + why });
    if (!on && i >= 0) S.rows.splice(i, 1);
  });
  await evalSettings();
});
function syncFinish() { if (!S) return; Object.keys(FINISH).forEach(id => $(id).checked = FINISH[id].every(([k]) => S.rows.some(r => r.key === k && r.use))); }

// =====================================================================  colours: filament slots and painting
let paintTool = null, paintSlot = 1;
function renderSlots() {
  const L = $('slotList');
  if (!state || !state.filaments) { L.innerHTML = '<div class="dim small">Open a file to see its colours.</div>'; $('colNote').textContent = ''; return; }
  const F = state.filaments;
  if (!F.slots.find(s => s.slot === paintSlot)) paintSlot = (F.slots.find(s => s.used) || F.slots[0] || { slot: 1 }).slot;
  $('colNote').textContent = `· ${F.slots.filter(s => s.used).length} in use` + (F.exact ? ' · exact' : ' · estimate');
  L.innerHTML = F.slots.map(s => `<div class="slot1 ${s.slot === paintSlot ? 'on' : ''} ${s.used ? '' : 'unused'}" data-s="${s.slot}" title="Click to paint with this colour; click the swatch to change it">
      <span class="sw" data-edit="${s.slot}" style="${swatchCss(s)}" title="Change filament or colour"></span><span class="n">${s.slot}</span>
      <span>${esc(s.name)} <span class="dim">${esc(s.type || '')}</span></span><span class="g">${s.used ? (s.grams >= 1000 ? (s.grams / 1000).toFixed(2) + ' kg' : Math.round(s.grams) + ' g') : 'not used'}</span>
      ${s.used ? `<span class="price adv" title="What a 1 kg roll of this costs you">$<input data-price="${esc(s.preset || s.name)}" value="${priceOf(s) || ''}" placeholder="per kg"></span>` : ''}</div>`).join('');
  L.querySelectorAll('[data-price]').forEach(inp => { inp.onclick = e => e.stopPropagation(); inp.onchange = () => { const v = parseFloat(inp.value);
    UI.prices = UI.prices || {}; if (isFinite(v) && v > 0) UI.prices[inp.dataset.price] = v; else delete UI.prices[inp.dataset.price]; api().set_ui_pref('prices', UI.prices); renderTotals(state); }; });
  L.querySelectorAll('.slot1').forEach(el => el.onclick = e => { if (e.target.dataset.edit) { editSlot(+e.target.dataset.edit); return; } paintSlot = +el.dataset.s; renderSlots(); paintHint(); });
  paintHint();
}
async function editSlot(slot) {
  const cur = state.filaments.slots.find(s => s.slot === slot) || {};
  const r = await pickFilament(api(), { title: `Filament for colour ${slot}`, preset: cur.preset, color: cur.color, colors: cur.colors, ctype: cur.ctype, effect: cur.effect });
  if (!r) return;
  const d = await api().set_slot(slot, r.preset, r.color, r.type, r.colors, r.ctype, r.effect);
  if (d.error) { status(d.error, true); return; }
  state.filaments = d.filaments; undoMgr.pushServer(`Colour ${slot}: ${r.name}`);
  await refreshLooks(); renderSlots(); renderTotals(state); renderFilChips(); if (S) renderPlateNote();
  status(`Colour ${slot} is now ${r.brand} ${r.name}.`);
}
async function refreshLooks() {
  const cam = camera.position.clone(), tgt = controls.target.clone();
  const keep = state.filaments;
  const d = await api().totals(); state.filaments = d.filaments || keep;
  await show(state); camera.position.copy(cam); controls.target.copy(tgt); controls.update();
}
function recolor() {
  meshes.forEach(m => {
    const mats = Array.isArray(m.material) ? m.material : [m.material];
    mats.forEach((mt, i) => { const s = (m.userData.slots || [])[i]; const f = state.filaments.slots.find(x => x.slot === s); if (f) mt.color.set(f.color); });
  });
}
$('addSlot').onclick = async () => {
  if (!state) return;
  const n = state.filaments.slots.length + 1;
  if (n > 16) { status('16 colours is the most a project can have.', true); return; }
  const r = await pickFilament(api(), { title: `Filament for colour ${n}` });
  if (!r) return;
  const d = await api().set_slot(n, r.preset, r.color, r.type, r.colors, r.ctype, r.effect);
  if (d.error) { status(d.error, true); return; }
  state.filaments = d.filaments; paintSlot = n; undoMgr.pushServer(`Add colour ${n}`); renderSlots();
};
document.querySelectorAll('.page [data-tool]').forEach(b => b.onclick = () => {
  paintTool = paintTool === b.dataset.tool ? null : b.dataset.tool;
  document.querySelectorAll('.page [data-tool]').forEach(x => x.classList.toggle('on', x.dataset.tool === paintTool));
  if (typeof markVtools === 'function') markVtools();
  renderer.domElement.style.cursor = paintTool ? 'crosshair' : '';
  paintHint(); textHint();
});
$('paintAng').oninput = () => $('paintAngO').textContent = $('paintAng').value + '°';
function paintHint() {
  const s = state && state.filaments && state.filaments.slots.find(x => x.slot === paintSlot);
  $('angRow').style.display = paintTool === 'edges' ? '' : 'none';
  if (paintTool === 'flat' || paintTool === 'text') { $('paintHint').innerHTML = 'Pick a tool, then click the model. Click the tool again to stop painting.'; return; }
  $('paintHint').innerHTML = !paintTool ? 'Pick a tool, then click the model. Click the tool again to stop painting.'
    : `Click the model to paint it <span class="sw" style="background:${s ? s.color : '#888'};width:12px;height:12px;vertical-align:middle"></span> colour ${paintSlot}. ` +
      ({ part: 'The whole part you click changes colour.', same: 'The connected area you click that is all one colour changes.', edges: 'The area you click changes, stopping at edges sharper than the slider.' })[paintTool];
}
async function doPaint(hit) {
  const m = hit.object, p = m.worldToLocal(hit.point.clone());
  const d = await longJob('Painting…', () => api().paint(m.userData.id, [p.x, p.y, p.z], paintTool, paintSlot, +$('paintAng').value));
  if (d.error) { status(d.error, true); return; }
  const cam = camera.position.clone(), tgt = controls.target.clone();
  await show(d); camera.position.copy(cam); controls.target.copy(tgt); controls.update();
  undoMgr.pushServer(({ part: 'Colour whole part', same: 'Fill same colour', edges: 'Fill up to edges' })[paintTool]);
  status('Painted. Ctrl+Z undoes it.');
}

firstRun();
window.studio.help = openHelp;

// =====================================================================  step 1: turn, lay flat, drop, lift (Shift-drag), text
function renderFloat() {
  const f = state ? state.parts.filter(p => p.lift > 0.05) : [];
  $('floatWarn').classList.toggle('hidden', !f.length);
  $('floatWarn').textContent = f.length ? `⚠ ${f.map(p => p.name).join(', ')} ${f.length > 1 ? 'are' : 'is'} lifted off the plate and can't be printed. Select it and press Drop to plate.` : '';
}
function renderPos() {
  const p = state && state.parts[selected];
  $('posFor').innerHTML = p ? `<b>${esc(p.name)}</b> · ${p.size.join(' × ')} mm${p.lift > 0.05 ? ` · <span class="warn">lifted ${p.lift} mm</span>` : ''}` : 'Click a part first (in the 3D view or the Parts list).';
  document.querySelectorAll('#posCard [data-rot], #rotGo').forEach(b => b.disabled = !p);
}
async function posJob(text, fn, label) {
  const cam = camera.position.clone(), tgt = controls.target.clone(), keep = selected;
  const d = await longJob(text, fn);
  if (d.error) { status(d.error, true); return; }
  await show(d); camera.position.copy(cam); controls.target.copy(tgt); controls.update();
  if (keep >= 0 && state.parts[keep]) select(keep, false);
  undoMgr.pushServer(label); status(label + '. Ctrl+Z undoes it.');
}
document.querySelectorAll('#posCard [data-rot]').forEach(b => b.onclick = () => {
  if (selected < 0) return; const [ax, dg] = b.dataset.rot.split(',');
  posJob('Turning…', () => api().rotate_part(selected, ax, +dg), `Turned ${state.parts[selected].name} ${dg}° around ${ax.toUpperCase()}`);
});
$('dropBtn').onclick = () => {
  if (!state) return;
  const id = selected >= 0 ? selected : null;
  posJob('Dropping to the plate…', () => api().drop_part(id), id == null ? 'Dropped everything to the plate' : `Dropped ${state.parts[id].name} to the plate`);
};
async function doLayFlat(hit) {
  const m = hit.object, p = m.worldToLocal(hit.point.clone());
  await posJob('Laying it flat…', () => api().lay_flat(m.userData.id, [p.x, p.y, p.z]), `Laid ${state.parts[m.userData.id].name} flat`);
}
// ---- text
const fonts = {}, fontLoader = new FontLoader();
function loadFont(name) { return fonts[name] || (fonts[name] = new Promise((ok, bad) => fontLoader.load(`vendor/fonts/${name}.typeface.json`, ok, undefined, bad))); }
function fillTextSlots() {
  if (!state || !state.filaments) return;
  const cur = $('txtSlot').value;
  $('txtSlot').innerHTML = state.filaments.slots.map(s => `<option value="${s.slot}">${s.slot} · ${esc(s.name)}</option>`).join('');
  const sel = state.parts[selected];
  $('txtSlot').value = cur && state.filaments.slots.some(s => String(s.slot) === cur) ? cur : String(sel ? sel.ext : (state.filaments.slots[0] || { slot: 1 }).slot);
}
function textHint() {
  $('txtHint').textContent = paintTool === 'text' ? 'Now click the spot on the model where the middle of the text should go.' : '';
  $('txtSlot').disabled = $('txtMode').value === 'cut';
}
$('txtMode').onchange = textHint;
async function textShapes() {
  const txt = $('txtVal').value.trim(); if (!txt) throw new Error('Type some text first.');
  const size = parseFloat($('txtSize').value); if (!(size >= 2 && size <= 200)) throw new Error('Letter height should be between 2 and 200 mm.');
  const font = await loadFont($('txtFont').value);
  const shapes = font.generateShapes(txt, 100);
  const raw = shapes.map(s => { const e = s.extractPoints(6); return { outer: e.shape.map(p => [p.x, p.y]), holes: e.holes.map(h => h.map(p => [p.x, p.y])) }; });
  const pts = raw.flatMap(s => s.outer); if (!pts.length) throw new Error("That font doesn't have those letters.");
  const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]);
  const cx = (Math.min(...xs) + Math.max(...xs)) / 2, cy = (Math.min(...ys) + Math.max(...ys)) / 2, k = size / Math.max(1e-6, Math.max(...ys) - Math.min(...ys));
  const f = ([x, y]) => [+((x - cx) * k).toFixed(3), +((y - cy) * k).toFixed(3)];
  return raw.map(s => ({ outer: s.outer.map(f), holes: s.holes.map(h => h.map(f)) }));
}
async function textGlyphs() {
  // one outline set per letter, each centred on its own middle, with where it sits along the line (mm)
  const txt = $('txtVal').value.trim(); if (!txt) throw new Error('Type some text first.');
  const size = parseFloat($('txtSize').value); const font = await loadFont($('txtFont').value);
  const all = font.generateShapes(txt, 100).flatMap(s => s.extractPoints(6).shape); const ys = all.map(p => p.y);
  const k = size / Math.max(1e-6, Math.max(...ys) - Math.min(...ys)), cy = (Math.max(...ys) + Math.min(...ys)) / 2;
  const scale = 100 / font.data.resolution; let pen = 0; const out = [];
  for (const ch of txt) {
    const gl = font.data.glyphs[ch] || font.data.glyphs['?']; const adv = (gl ? gl.ha : 50) * scale;
    if (ch.trim()) {
      const sh = font.generateShapes(ch, 100).map(s => { const e = s.extractPoints(6); return { outer: e.shape.map(p => [p.x, p.y]), holes: e.holes.map(h => h.map(p => [p.x, p.y])) }; });
      const xs = sh.flatMap(s => s.outer.map(p => p[0])); const gx = xs.length ? (Math.min(...xs) + Math.max(...xs)) / 2 : adv / 2;
      out.push({ x: (pen + gx), shapes: sh.map(s => ({ outer: s.outer.map(([x, y]) => [+((x - gx) * k).toFixed(3), +((y - cy) * k).toFixed(3)]), holes: s.holes.map(h => h.map(([x, y]) => [+((x - gx) * k).toFixed(3), +((y - cy) * k).toFixed(3)])) })) });
    }
    pen += adv;
  }
  const mid = pen / 2; out.forEach(g => g.x = +((g.x - mid) * k).toFixed(3));
  return out;
}
async function doText(hit) {
  let shapes, glyphs = null; try { shapes = await textShapes(); if ($('txtWrap').checked) glyphs = await textGlyphs(); } catch (e) { status(e.message, true); return; }
  const m = hit.object, p = m.worldToLocal(hit.point.clone()), n = hit.face.normal.clone().normalize();
  const depth = parseFloat($('txtDepth').value) || 1, mode2 = $('txtMode').value;
  await posJob(mode2 === 'raise' ? 'Adding raised text…' : 'Cutting the text in…',
    () => api().add_text(m.userData.id, shapes, [p.x, p.y, p.z], [n.x, n.y, n.z], depth, mode2, +$('txtSlot').value, parseFloat($('txtAng').value) || 0, glyphs, !!glyphs),
    `Text "${$('txtVal').value.trim()}" on ${state.parts[m.userData.id].name}`);
}
window.studio.textShapes = textShapes;
window.studio.textGlyphs = textGlyphs;

// the colours picked in step 1, lined up under the AMS slots they will use
function renderModelSlots(s) {
  // under each AMS slot: which of your colours will print from it (from the slot picker above)
  if (!state || !state.filaments) { $('pModel').innerHTML = ''; $('pMatch').disabled = true; return; }
  const n = Math.max(4, (s.ams || []).length), used = usedSlots();
  $('pModel').innerHTML = '<div class="dim small" style="margin:6px 0 2px">Prints from each slot:</div><div class="pmodel">' + Array.from({ length: n }, (_, i) => {
    const fs = used.filter(f => PR.map && PR.map[f.slot] === i), a = (s.ams || []).find(x => x.index === i);
    if (!fs.length) return '<div><span class="sw" style="background:transparent;border:1px dashed var(--border)"></span>not used</div>';
    return fs.map(f => { const off = a && !a.empty && cdist(a.color, f.color) >= 60;
      return `<div title="${esc(f.name)}"><span class="sw" style="${swatchCss(f)}"></span>colour ${f.slot}${off ? '<br><span class="miss">different colour loaded</span>' : ''}</div>`; }).join('');
  }).join('') + '</div>';
  $('pMatch').disabled = !used.length;
}
$('pMatch').onclick = async () => {
  if (!confirm("Tell the printer that each AMS slot you picked holds the filament and colour you chose for your model?\n\nOnly do this if you've actually loaded those rolls in those slots.")) return;
  const r = await longJob('Updating the AMS…', () => api().printer_match_project(PR.cur, PR.map));
  if (r.error) { status(r.error, true); return; }
  status(`AMS slot${r.slots.length > 1 ? 's' : ''} ${r.slots.join(', ')} now match your model.` + (r.skipped.length ? ` Colours ${r.skipped.join(', ')} don't have an AMS slot.` : ''));
  setTimeout(poll, 1000);
};
window.studio.show = show;

// =====================================================================  redesign: tool bar, gizmos, menus, shortcuts, panels, look
const vt = { measure: false, section: false, heat: false, move: false, rotate: false };
let outline = null;
const tools3d = makeTools({
  scene, camera, controls, dom: renderer.domElement, tagEl: $('gtag'),
  selected: () => (curStep === 1 && mode === 'plates' && selected >= 0) ? meshes.find(m => m.userData.id === selected) || null : null,
  onRotate: async (axis, deg) => { const id = selected; await posJob('Turning…', () => api().rotate_part(id, axis, Math.round(deg * 100) / 100), `Turned ${state.parts[id].name} ${deg.toFixed(0)}° around ${axis.toUpperCase()}`); },
  onMove: async (dx, dy, dz) => { const id = selected; await posJob('Moving…', () => api().move_part(id, dx, dy, null, dz), dz > 0.05 ? `Lifted ${state.parts[id].name}` : `Moved ${state.parts[id].name}`); },
  onMeasure: t => status('📏 ' + t),
});
renderer.domElement.addEventListener('pointerdown', e => { if (tools3d.down(e)) { controls.enabled = false; e.stopPropagation(); downAt = null; } }, true);
window.addEventListener('pointermove', e => { if (tools3d.dragging || e.target === renderer.domElement) tools3d.move(e); });   // keep following the mouse even off the 3D view
window.addEventListener('pointerup', async () => { if (await tools3d.up()) controls.enabled = true; });

const VT = {
  1: [['size', '⤢ Size', 'S'], ['colours', '🖌 Colours', 'C'], ['text', 'T Text', 'T'], ['sep'], ['move', '✥ Move', 'M'], ['rotate', '⟳ Rotate', 'R'], ['flat', '▭ Lay flat', 'F'], ['drop', '⤓ Drop', 'D'], ['heat', '🔥 Support map', 'H']],
  2: [['cuts', '✂ Cuts', 'U'], ['joints', '◎ Joints', 'J'], ['hollow', '▢ Hollow', 'W']],
};
const VIEWTOOLS = [['measure', '📏 Measure', 'K'], ['section', '✂ Section', 'X']];
function buildVtools() {
  const own = VT[curStep] || [];
  $('vtools').innerHTML = own.map(([k, l, s]) => k === 'sep' ? '<span class="sep"></span>' : `<button data-vt="${k}" title="${l.slice(2)} (${s})">${l}<kbd>${s}</kbd></button>`).join('') +
    (own.length ? '<span class="sep"></span>' : '') + VIEWTOOLS.map(([k, l, s]) => `<button data-vt="${k}" title="${l.slice(2)} (${s})">${l}<kbd>${s}</kbd></button>`).join('');
  $('vtools').querySelectorAll('[data-vt]').forEach(b => b.onclick = () => useTool(b.dataset.vt));
  vt.move = vt.rotate = false; tools3d.setMode(null);
  if (paintTool && curStep !== 1) { paintTool = null; document.querySelectorAll('[data-tool]').forEach(x => x.classList.remove('on')); }
  if (curStep !== 1 && vt.heat) toggleHeat(false);
  markVtools();
}
function markVtools() {
  document.querySelectorAll('#vtools [data-vt]').forEach(b => b.classList.toggle('on', (['move','rotate','heat','measure','section'].includes(b.dataset.vt) && !!vt[b.dataset.vt]) || (b.dataset.vt === 'flat' && paintTool === 'flat') || (b.dataset.vt === 'text' && paintTool === 'text')));
}
function card(id) { const el = $(id); if (!el) return; accOpen(el); el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 900); }
function useTool(k) {
  if (k === 'size') { card('sizeCard'); return; }
  if (k === 'colours') { card('colCard'); return; }
  if (k === 'cuts') { card('cutsCard'); return; }
  if (k === 'joints') { card('jointsCard'); return; }
  if (k === 'hollow') { card('hollowCard'); return; }
  if (k === 'text') { card('textCard'); const b = document.querySelector('#textCard [data-tool="text"]'); if (b && paintTool !== 'text') b.click(); else if (b) b.click(); markVtools(); return; }
  if (k === 'drop') { $('dropBtn').click(); return; }
  if (k === 'flat') { const b = document.querySelector('[data-tool="flat"]'); if (b) b.click(); markVtools(); return; }
  if (k === 'move' || k === 'rotate') {
    const on = !vt[k]; vt.move = vt.rotate = false; vt[k] = on;
    if (k === 'rotate' && on && !$('freeRot').checked) { $('freeRot').checked = true; }
    if (on && mode !== 'plates') setMode('plates');
    tools3d.setMode(on ? k : null); card('posCard');
    if (on && selected < 0) status('Click a part to ' + (k === 'move' ? 'move' : 'turn') + ' it.');
    markVtools(); return;
  }
  if (k === 'heat') { toggleHeat(!vt.heat); return; }
  if (k === 'measure') { vt.measure = !vt.measure; tools3d.setMeasure(vt.measure); status(vt.measure ? '📏 Click two points on the model to measure between them.' : ''); markVtools(); return; }
  if (k === 'section') { vt.section = !vt.section; $('secBox').classList.toggle('hidden', !vt.section); applySection(meshes, vt.section); updateSection(); markVtools(); }
}
$('freeRot').onchange = () => { if (vt.rotate) tools3d.setMode($('freeRot').checked ? 'rotate' : null); };
function updateSection() {
  const top = state ? Math.max(...state.parts.map(p => p.size[2] + (p.min ? p.min[2] : 0)), 10) : 100;
  sectionPlane.constant = vt.section ? top * (+$('secSlider').value / 100) + 0.01 : 1e9;
}
$('secSlider').oninput = updateSection;
function toggleHeat(on) {
  vt.heat = on; world.children.filter(o => o.userData.heat).forEach(o => world.remove(o));
  if (on) { let area = 0; meshes.forEach(m => { const ov = heatOverlay(m); area += ov.userData.area; world.add(ov); }); status(`🔥 Red = needs support: about ${(area / 100).toFixed(0)} cm² in view. Turn parts to shrink the red.`); }
  markVtools();
}
// keep the tools in step with every redraw
const _show = show;
show = async function (d) {
  const r = await _show(d);
  if (vt.section) applySection(meshes, true), updateSection();
  if (vt.heat) toggleHeat(true);
  tools3d.place(); drawOutline(); renderPlateTabs(); renderPosFields(); renderReadyBtn(); return r;
};
function drawOutline() {
  if (outline) { scene.remove(outline); outline = null; }
  const m = meshes.find(x => x.userData.id === selected); if (!m) return;
  outline = new THREE.BoxHelper(m, 0x1CC25A); outline.material.transparent = true; outline.material.opacity = 0.55; scene.add(outline);
}
const _select2 = select;
select = function (id, focus) { _select2(id, focus); drawOutline(); tools3d.place(); renderPosFields(); };
// ---------- position and turn boxes (Advanced)
function renderPosFields() {
  const p = state && state.parts[selected];
  ['posX', 'posY', 'posZ', 'absX', 'absY', 'absZ'].forEach(id => $(id).disabled = !p);
  if (!p) { ['posX', 'posY', 'posZ', 'absX', 'absY', 'absZ'].forEach(id => $(id).value = ''); return; }
  const cx = (p.min[0] + p.min[0] + p.size[0]) / 2, cy = (p.min[1] + p.min[1] + p.size[1]) / 2;
  [['posX', cx], ['posY', cy], ['posZ', p.min[2]]].forEach(([id, v]) => { if (document.activeElement !== $(id)) $(id).value = (+v).toFixed(1); });
  (p.rot || [0, 0, 0]).forEach((v, i) => { const id = ['absX', 'absY', 'absZ'][i]; if (document.activeElement !== $(id)) $(id).value = (+v).toFixed(1); });
  $('posFor').innerHTML = `<b>${esc(p.name)}</b> · ${p.size.join(' × ')} mm` + (p.lift > 0.05 ? ` · <span class="warn">lifted ${p.lift} mm</span>` : '') + (p.overhang >= 1 ? ` · needs support: ${p.overhang} cm²` : ' · no big overhangs');
}
['posX', 'posY', 'posZ'].forEach(id => $(id).onchange = () => { if (selected < 0) return; const id0 = selected;
  posJob('Moving…', () => api().move_to(id0, $('posX').value, $('posY').value, $('posZ').value), `Moved ${state.parts[id0].name}`); });
$('relGo').onclick = () => { if (selected < 0) return; const v = ['relX', 'relY', 'relZ'].map(i => parseFloat($(i).value) || 0); if (!v.some(x => x)) return; const id0 = selected;
  posJob('Turning…', () => api().rotate_euler(id0, v[0], v[1], v[2], false), `Turned ${state.parts[id0].name}`).then(() => ['relX', 'relY', 'relZ'].forEach(i => $(i).value = 0)); };
$('absGo').onclick = () => { if (selected < 0) return; const v = ['absX', 'absY', 'absZ'].map(i => parseFloat($(i).value) || 0); const id0 = selected;
  posJob('Turning…', () => api().rotate_euler(id0, v[0], v[1], v[2], true), `Set turn of ${state.parts[id0].name}`); };
// ---------- copies and line-up
$('copyGo').onclick = () => { if (selected < 0) { status('Click a part first.', true); return; } const n = Math.max(1, Math.min(50, parseInt($('copyN').value) || 1)); const id0 = selected;
  posJob('Making copies…', () => api().duplicate(id0, n), `${n} cop${n === 1 ? 'y' : 'ies'} of ${state.parts[id0].name}`); };
document.querySelectorAll('[data-align]').forEach(b => b.onclick = () => { const pl = selected >= 0 ? state.parts[selected].plate : (state.plates[0] || {}).id;
  if (pl == null) return; posJob('Lining up…', () => api().align_parts(b.dataset.align, pl), b.textContent); });
// ---------- right-click menu
function ctxShow(x, y, id) {
  select(id, false); const p = state.parts[id];
  const items = [['Turn 90° (spin)', () => posJob('Turning…', () => api().rotate_part(id, 'z', 90), `Turned ${p.name} 90°`), 'R'],
    ['Lay flat on a face…', () => { goStep(1); useTool('flat'); }, 'F'], ['Drop to plate', () => posJob('Dropping…', () => api().drop_part(id), `Dropped ${p.name}`), 'D'],
    ['Move to the plate centre', () => posJob('Moving…', () => api().move_to(id, state.bed[0] / 2, state.bed[1] / 2, null), `Centred ${p.name}`), ''],
    ['sep'], ['Colours…', () => { goStep(1); useTool('colours'); }, 'C'], ['Add text here…', () => { goStep(1); useTool('text'); }, 'T'],
    ['sep'], ['Duplicate', () => posJob('Copying…', () => api().duplicate(id, 1), `Copy of ${p.name}`), 'Ctrl+D'], ['Delete', () => delPart(id), 'Del']];
  const m = $('ctx'); m.innerHTML = items.map((it, i) => it[0] === 'sep' ? '<div class="sepl"></div>' : `<div class="mi" data-i="${i}"><span>${it[0]}</span><kbd>${it[2] || ''}</kbd></div>`).join('');
  m.querySelectorAll('[data-i]').forEach(d => d.onclick = () => { m.classList.add('hidden'); items[+d.dataset.i][1](); });
  m.style.left = Math.min(x, innerWidth - 250) + 'px'; m.style.top = Math.min(y, innerHeight - 330) + 'px'; m.classList.remove('hidden');
}
function delPart(id) { if (!confirm(`Delete ${state.parts[id].name}? (Ctrl+Z brings it back.)`)) return; posJob('Deleting…', () => api().delete_part(id), `Deleted ${state.parts[id].name}`); }
renderer.domElement.addEventListener('contextmenu', e => {
  e.preventDefault(); if (!meshes.length) return; const r = renderer.domElement.getBoundingClientRect();
  ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1); ray.setFromCamera(ndc, camera);
  const hit = ray.intersectObjects(meshes, false)[0]; if (hit) ctxShow(e.clientX, e.clientY, hit.object.userData.id);
});
$('partList').addEventListener('contextmenu', e => { const it = e.target.closest('[data-id]'); if (!it) return; e.preventDefault(); ctxShow(e.clientX, e.clientY, +it.dataset.id); });
document.addEventListener('pointerdown', e => { ['ctx', 'openMenu', 'gearMenu'].forEach(id => { if (!$(id).contains(e.target) && e.target.id !== 'openMore' && e.target.id !== 'gearBtn') $(id).classList.add('hidden'); }); }, true);
// ---------- one-letter shortcuts
window.addEventListener('keydown', e => {
  const t = document.activeElement && document.activeElement.tagName;
  if (t === 'INPUT' || t === 'TEXTAREA' || t === 'SELECT' || editorActive() || !$('helpModal').classList.contains('hidden') || !$('picker').classList.contains('hidden')) return;
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'd') { e.preventDefault(); if (selected >= 0) posJob('Copying…', () => api().duplicate(selected, 1), `Copy of ${state.parts[selected].name}`); return; }
  if (e.ctrlKey || e.metaKey || e.altKey) return;
  if (e.key === 'Delete' && selected >= 0) { delPart(selected); return; }
  if (e.key === 'Escape') { $('ctx').classList.add('hidden'); if (vt.measure) useTool('measure'); if (vt.move || vt.rotate) { vt.move = vt.rotate = false; tools3d.setMode(null); markVtools(); } return; }
  const k = e.key.toUpperCase();
  const hit = [...(VT[curStep] || []), ...VIEWTOOLS].find(x => x[0] !== 'sep' && x[2] === k);
  if (hit) { e.preventDefault(); useTool(hit[0]); }
});
// ---------- simple / advanced, theme, text size, tray, panels
let UI = {};
async function loadUi() {
  UI = await api().ui_prefs();
  document.body.classList.toggle('simple', UI.mode === 'simple');
  document.querySelectorAll('#modeSw span').forEach(s => s.classList.toggle('on', s.dataset.m === (UI.mode || 'advanced')));
  document.body.classList.toggle('light', UI.theme === 'light'); $('uiTheme').textContent = UI.theme === 'light' ? '☾ Dark theme' : '☀ Light theme';
  scene.background = new THREE.Color(UI.theme === 'light' ? 0xE6E6E2 : 0x1e1e22);
  $('uiSize').value = UI.textsize || 100; document.body.style.zoom = (UI.textsize || 100) / 100;
  $('uiTray').checked = UI.keep_tray !== false;
  if (UI.panels) { const P = Array.isArray(UI.panels) ? { l: UI.panels[0], r: UI.panels[1] } : UI.panels, g = $('mainGrid');
    if (P.l) g.style.setProperty('--lw', P.l + 'px'); if (P.r) g.style.setProperty('--rw', P.r + 'px'); if (P.r5) g.style.setProperty('--rw5', P.r5 + 'px'); resize(); setTimeout(placeGrips, 50); }
  renderSlots();
}
document.querySelectorAll('#modeSw span').forEach(s => s.onclick = () => { UI.mode = s.dataset.m; api().set_ui_pref('mode', UI.mode); loadUiQuick(); });
function loadUiQuick() { document.body.classList.toggle('simple', UI.mode === 'simple'); document.querySelectorAll('#modeSw span').forEach(s => s.classList.toggle('on', s.dataset.m === UI.mode)); }
$('gearBtn').onclick = e => { const r = e.target.getBoundingClientRect(), m = $('gearMenu'); m.style.left = (r.right - 300) + 'px'; m.style.top = r.bottom + 4 + 'px'; m.classList.toggle('hidden'); };
$('uiTheme').onclick = () => { UI.theme = UI.theme === 'light' ? 'dark' : 'light'; api().set_ui_pref('theme', UI.theme); loadUi(); };
$('uiSize').onchange = () => { UI.textsize = +$('uiSize').value; api().set_ui_pref('textsize', UI.textsize); document.body.style.zoom = UI.textsize / 100; setTimeout(resize, 50); };
$('uiTray').onchange = () => api().set_ui_pref('keep_tray', $('uiTray').checked);
// column grips: they sit on the edges of the side columns, on every step
function placeGrips() {
  const g = $('mainGrid'); if (!g) return; const cs = getComputedStyle(g).gridTemplateColumns.split(' ').map(parseFloat);
  $('gripL').style.left = cs[0] + 'px'; $('gripR').style.left = (cs[0] + cs[1]) + 'px';
}
function colVar(side) { return side === 'l' ? '--lw' : ($('mainGrid').classList.contains('wide') ? '--rw5' : '--rw'); }
['gripL', 'gripR'].forEach(id => {
  const sp = $(id), side = id === 'gripL' ? 'l' : 'r';
  sp.addEventListener('pointerdown', e => {
    const g = $('mainGrid'), cs = getComputedStyle(g).gridTemplateColumns.split(' ').map(parseFloat);
    const w0 = side === 'l' ? cs[0] : cs[2], x0 = e.clientX; sp.classList.add('drag'); sp.setPointerCapture(e.pointerId); e.preventDefault();
    const mv = ev => { const d = ev.clientX - x0, max = Math.max(320, innerWidth * 0.5);
      const w = Math.round(side === 'l' ? Math.max(180, Math.min(max, w0 + d)) : Math.max(260, Math.min(max, w0 - d)));
      g.style.setProperty(colVar(side), w + 'px'); resize(); placeGrips(); };
    const up = () => { sp.classList.remove('drag'); sp.removeEventListener('pointermove', mv); sp.removeEventListener('pointerup', up);
      const c2 = getComputedStyle(g).gridTemplateColumns.split(' ').map(parseFloat);
      UI.panels = UI.panels || {}; if (Array.isArray(UI.panels)) UI.panels = { l: UI.panels[0], r: UI.panels[1] };
      UI.panels[side === 'l' ? 'l' : ($('mainGrid').classList.contains('wide') ? 'r5' : 'r')] = Math.round(side === 'l' ? c2[0] : c2[2]);
      api().set_ui_pref('panels', UI.panels); };
    sp.addEventListener('pointermove', mv); sp.addEventListener('pointerup', up);
  });
  sp.addEventListener('dblclick', () => { const g = $('mainGrid'); g.style.removeProperty(colVar(side)); resize(); placeGrips();
    UI.panels = UI.panels && !Array.isArray(UI.panels) ? UI.panels : {}; delete UI.panels[side === 'l' ? 'l' : ($('mainGrid').classList.contains('wide') ? 'r5' : 'r')]; api().set_ui_pref('panels', UI.panels); });
});
new ResizeObserver(placeGrips).observe($('mainGrid'));

// ---------- plate tabs
function renderPlateTabs() {
  if (!state || state.plates.length < 2 || mode !== 'plates') { $('plateTabs').innerHTML = ''; return; }
  $('plateTabs').innerHTML = state.plates.map(pl => { const ps = state.parts.filter(p => p.plate === pl.id);
    const cols = ps.map(p => p.color).slice(0, 4); return `<div data-p="${pl.id}" title="${esc(pl.name)}: ${ps.length} part${ps.length === 1 ? '' : 's'}"><i style="background:linear-gradient(90deg,${(cols.length > 1 ? cols : [cols[0] || '#888', cols[0] || '#888']).join(',')})"></i>${esc(pl.name.replace(/^Plate /, 'Plate '))}</div>`; }).join('');
  $('plateTabs').querySelectorAll('[data-p]').forEach(d => d.onclick = () => { $('plateTabs').querySelectorAll('[data-p]').forEach(x => x.classList.toggle('on', x === d));
    frame(meshes.filter(m => state.parts[m.userData.id] && state.parts[m.userData.id].plate === +d.dataset.p)); });
}
// ---------- open menu: recent files, add a model
$('openMore').onclick = async e => {
  const r = e.target.getBoundingClientRect(), m = $('openMenu'), rec = await api().recent_files();
  m.innerHTML = '<div class="dim small" style="padding:4px 10px">Recent</div>' + (rec.length ? rec.map((f, i) => `<div class="mi ${f.exists ? '' : 'off'}" data-r="${i}"><span>${esc(f.name)}</span><span class="dim small">${esc(f.when)}</span></div>`).join('') : '<div class="mi off">Nothing yet</div>') +
    '<div class="sepl"></div><div class="mi" id="omOpen">Open another file…</div><div class="mi ' + (state ? '' : 'off') + '" id="omAdd">+ Add a model to this project…</div>';
  m.querySelectorAll('[data-r]').forEach(d => d.onclick = () => { m.classList.add('hidden'); if (rec[+d.dataset.r].exists) window.studio.openPath(rec[+d.dataset.r].path); else status("That file has been moved or deleted.", true); });
  $('omOpen').onclick = () => { m.classList.add('hidden'); $('openBtn').click(); };
  $('omAdd').onclick = async () => { m.classList.add('hidden'); if (!state) return; const d = await longJob('Adding the model…', () => api().add_model_dialog());
    if (!d) return; if (d.error) { status(d.error, true); return; } await show(d); undoMgr.pushServer('Add a model'); status('Added. New parts went where there was room (a new plate if needed).'); };
  m.style.left = (r.right - 320) + 'px'; m.style.top = r.bottom + 4 + 'px'; m.classList.toggle('hidden');
};
// ---------- crash recovery
(async function checkRecovery() {
  for (let i = 0; i < 40 && !(window.pywebview && window.pywebview.api && window.pywebview.api.recovery_info); i++) await sleep(250);
  const r = await api().recovery_info(); if (!r) return;
  $('recText').textContent = `BambuForge Studio closed unexpectedly. Bring back your work from ${r.when} (${r.title}, ${r.parts} part${r.parts === 1 ? '' : 's'}, ${r.changes} change${r.changes === 1 ? '' : 's'})?`;
  $('recBanner').classList.remove('hidden');
  $('recYes').onclick = async () => { $('recBanner').classList.add('hidden'); const d = await longJob('Bringing your work back…', () => api().recover(true)); if (d && !d.error) { undoMgr.reset(); await show(d); status('Your work is back.'); } };
  $('recNo').onclick = () => { $('recBanner').classList.add('hidden'); api().recover(false); };
})();
// ---------- ready-to-print check
let lastReady = null;
function renderReadyBtn() { const b = $('readyBtn'); if (!state) { b.className = 'ready'; b.textContent = '✓ Ready to print?'; return; } }
async function runReady() {
  if (!state) { status('Open a file first.', true); return; }
  const sup = !!(S && S.rows.some(r => r.key === 'enable_support' && r.use && String(r.value) === '1'));
  const r = await api().check_ready(sup, PR && PR.cur ? PR.cur : null, PR && PR.map ? PR.map : null);
  const items = r.items.slice();
  const red = (typeof cuts !== 'undefined' ? cuts : []).filter(c => c.specs && c.red);
  items.splice(2, 0, { ok: !red.length, title: 'All hand-placed joints fit', detail: red.length ? `${red.length} cut${red.length > 1 ? 's have' : ' has'} a red joint` : '', fix: red.length ? 'joints' : null, fix_text: 'Fix in step 2' });
  lastReady = items;
  $('readyList').innerHTML = items.map((it, i) => `<div class="rk"><span class="i ${it.ok ? 'ok' : 'wa'}">${it.ok ? '✓' : '⚠'}</span><span>${esc(it.title)}${it.detail ? `<br><span class="dim small">${esc(it.detail)}</span>` : ''}</span>${!it.ok && it.fix ? `<button data-fix="${i}">${esc(it.fix_text)}</button>` : '<span></span>'}</div>`).join('');
  $('readyList').querySelectorAll('[data-fix]').forEach(b => b.onclick = () => fixReady(lastReady[+b.dataset.fix].fix));
  const bad = items.filter(x => !x.ok).length;
  $('readySum').innerHTML = bad ? `<span class="warn">${bad} thing${bad > 1 ? 's' : ''} to check</span>` : '<span class="ok">Everything looks good.</span>';
  $('readyFor').textContent = (state.title || '') + (PR && PR.cur ? ' · checked against your printer' : '');
  const btn = $('readyBtn'); btn.className = 'ready ' + (bad ? 'warn' : 'ok'); btn.textContent = bad ? `⚠ ${bad} to check` : '✓ Ready to print';
}
async function fixReady(f) {
  if (f === 'drop') { await posJob('Dropping…', () => api().drop_part(null), 'Dropped everything to the plate'); }
  else if (f === 'arrange') { await plateJob('Arranging plates…', () => api().arrange(), 'Arrange plates'); }
  else if (f === 'split') { $('readyModal').classList.add('hidden'); goStep(2); return; }
  else if (f === 'joints') { $('readyModal').classList.add('hidden'); goStep(2); return; }
  else if (f === 'support') {
    if (!S || S.gen !== state.gen) await enterSettings(true);
    const i = S.rows.findIndex(r => r.key === 'enable_support');
    if (i >= 0) { S.rows[i].value = '1'; S.rows[i].orig = '1'; S.rows[i].use = true; S.rows[i].manual = true; }
    else S.rows.push({ key: 'enable_support', orig: '1', value: '1', manual: true, use: true, why: 'turned on from the ready-to-print check: these overhangs need holding up' });
    if (!S.rows.some(r => r.key === 'support_type')) S.rows.push({ key: 'support_type', orig: 'tree(auto)', value: 'tree(auto)', manual: true, use: true, why: 'tree supports snap off cleanly and use less filament' });
    await evalSettings(); status('Supports are on (step 3, Settings).');
  }
  else if (f.startsWith('plate:')) { const pl = f.slice(6); await api().settings_choose(null, null, pl); if (S) { S.plate = pl; $('sPlate').value = pl; renderPlateNote(); } status(`Plate set to ${pl}. Make sure that plate is on the printer.`); }
  else if (f === 'ams') { if (!confirm("Tell the printer each AMS slot holds what your model needs? Only if you've loaded those rolls.")) return; const r = await api().printer_match_project(PR.cur, PR.map); if (r.error) status(r.error, true); await sleep(1500); }
  runReady();
}
$('readyBtn').onclick = async () => { $('readyModal').classList.remove('hidden'); $('readyList').innerHTML = '<div class="dim" style="padding:10px">Checking…</div>'; await runReady(); };
$('readyClose').onclick = () => $('readyModal').classList.add('hidden');
$('readyRecheck').onclick = runReady;
$('readyGo').onclick = () => { $('readyModal').classList.add('hidden'); goStep(5); };
// ---------- start-up
(async () => { for (let i = 0; i < 40 && !(window.pywebview && window.pywebview.api && window.pywebview.api.ui_prefs); i++) await sleep(250); try { await loadUi(); } catch (_) {} goStep(curStep || 1); })();

window.studio._dbg = { camera, renderer, THREE, meshesRef: () => meshes, sel: () => selected, tools: tools3d };

// =====================================================================  fold-away sections and folding columns
const ACC_STEPS = [1, 2];
const accOpenIds = { 1: new Set(['sizeCard']), 2: new Set(['splitCard']) };
function accInit() {
  document.querySelectorAll('aside.right .page > .card').forEach(c => {
    if (c.querySelector(':scope > .secb')) return;
    const t = c.querySelector(':scope > .panelTitle');
    const body = document.createElement('div'); body.className = 'secb';
    [...c.childNodes].forEach(n => { if (n !== t) body.appendChild(n); });
    c.appendChild(body);
    if (!t) { const nt = document.createElement('div'); nt.className = 'panelTitle'; nt.textContent = c.id; c.insertBefore(nt, body); }
    const tt = c.querySelector(':scope > .panelTitle');
    const sum = document.createElement('span'); sum.className = 'sum'; tt.appendChild(sum);
    tt.addEventListener('click', e => { if (e.target.closest('button') || c.classList.contains('fixed')) return; accToggle(c); });
  });
}
function accCards() { return [...document.querySelectorAll('aside.right .page:not(.hidden) > .card')]; }
function accToggle(c) {
  const set = accOpenIds[curStep]; if (!set) return;
  if ($('accMulti').checked) { set.has(c.id) ? set.delete(c.id) : set.add(c.id); }
  else { const was = set.has(c.id); set.clear(); if (!was) set.add(c.id); }
  accRender();
}
function accOpen(c) {
  if (!ACC_STEPS.includes(curStep)) { c.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); return; }
  const set = accOpenIds[curStep]; if (!$('accMulti').checked) set.clear(); set.add(c.id); accRender();
}
function accRender() {
  const on = ACC_STEPS.includes(curStep);
  document.querySelector('aside.right').classList.toggle('acc', on);
  if (!on) return;
  accInit();
  const set = accOpenIds[curStep];
  accCards().forEach(c => { c.classList.toggle('open', c.classList.contains('fixed') || set.has(c.id)); const s = c.querySelector('.sum'); if (s) s.textContent = accSummary(c.id); });
}
$('accMulti').onchange = () => { if (!$('accMulti').checked) { const set = accOpenIds[curStep]; if (set && set.size > 1) { const keep = [...set].pop(); set.clear(); set.add(keep); } } accRender(); };
// what a folded section shows, so you can see everything at a glance
function accSummary(id) {
  const p = state && state.parts[selected];
  try {
    switch (id) {
      case 'sizeCard': return state ? (state.assembled ? `${(state.assembled.length || 0).toFixed(1)} mm` : '') : '';
      case 'colCard': return '';
      case 'textCard': return $('txtVal').value ? `"${$('txtVal').value.slice(0, 14)}"` : '';
      case 'fitCard': return state ? (state.parts.every(x => x.fits) ? 'all fit' : `${state.parts.filter(x => !x.fits).length} too big`) : '';
      case 'posCard': return p ? `${p.name.slice(0, 16)} · turned ${(p.rot || [0, 0, 0]).map(v => Math.round(v)).join('/')}` : 'click a part';
      case 'copyCard': return '';
      case 'platesCard': return state ? `${state.parts.length} parts · ${state.plates.length} plate${state.plates.length > 1 ? 's' : ''}` : '';
      case 'orientCard': return p ? `${p.overhang || 0} cm² support` : '';
      case 'splitCard': return state && state.parts[+$('splitPart').value] ? state.parts[+$('splitPart').value].name.slice(0, 18) : '';
      case 'cutsCard': return cuts.length ? `${cuts.length} cut${cuts.length > 1 ? 's' : ''}` : 'none yet';
      case 'jointsCard': return $('jointAll').selectedOptions[0] ? $('jointAll').selectedOptions[0].text.replace(/ \+.*| \(.*/, '') : '';
      case 'hollowCard': return $('hWithSplit').checked ? `${$('hWall').value} mm walls with the cut` : 'off';
      case 'makeCard': return '';
      case 'towerCard1': { const t = (state && state.plates.find(p => p.tower) || {}).tower; return !t ? '' : t.problem ? '⚠ needs moving' : t.manual ? 'placed by you' : 'automatic'; }
    }
  } catch (_) {}
  return '';
}
// keep the summaries fresh
const _show3 = show; show = async function (d) { const r = await _show3(d); accRender(); return r; };
const _select3 = select; select = function (id, f) { _select3(id, f); accRender(); };
// fold the side columns away, and bring them back
function applyFolds() {
  const g = $('mainGrid');
  g.classList.toggle('foldL', !!UI.foldL); g.classList.toggle('foldR', !!UI.foldR);
  $('railL').classList.toggle('hidden', !UI.foldL); $('railR').classList.toggle('hidden', !UI.foldR);
  setTimeout(() => { resize(); placeGrips(); }, 30);
}
$('foldL').onclick = () => { UI.foldL = true; api().set_ui_pref('foldL', true); applyFolds(); };
$('foldR').onclick = () => { UI.foldR = true; api().set_ui_pref('foldR', true); applyFolds(); };
$('railL').onclick = () => { UI.foldL = false; api().set_ui_pref('foldL', false); applyFolds(); };
$('railR').onclick = () => { UI.foldR = false; api().set_ui_pref('foldR', false); applyFolds(); };
const _loadUi2 = loadUi; loadUi = async function () { await _loadUi2(); applyFolds(); };
accRender();
window.studio.useTool = useTool; window.studio.cur = () => curStep;

// show "Opening…" the moment a file is dropped (reading the file can take a few seconds before the app answers)
// Drag and drop: handled right here, so it's instant. WebView2 hands Python the real file paths.
document.addEventListener('dragover', e => { if (e.dataTransfer && [...(e.dataTransfer.types || [])].includes('Files')) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; } });
document.addEventListener('drop', async e => {
  const files = e.dataTransfer && e.dataTransfer.files; if (!files || !files.length) return;
  e.preventDefault(); e.stopPropagation();
  const f = files[0], ok = /\.(3mf|stl|obj)$/i.test(f.name);
  if (!ok) { status(`${f.name} isn't a model file. Drop a .3mf, .stl or .obj.`, true); return; }
  busy('Opening ' + f.name + '…');
  try {
    if (window.chrome && chrome.webview && chrome.webview.postMessageWithAdditionalObjects) chrome.webview.postMessageWithAdditionalObjects('FilesDropped', files);
    const path = await api().dropped([f.name]);
    busy(null);
    if (path) window.studio.openPath(path); else status("Couldn't read where that file is. Use Open file… instead.", true);
  } catch (err) { busy(null); status("Couldn't open the dropped file. Use Open file… instead.", true); }
}, true);

// =====================================================================  AMS slot picker: which slot each colour prints from, with a live preview
PR.map = PR.map || {}; PR.mapKey = null; PR.view = 'slots';
const hex3 = h => [1, 3, 5].map(i => parseInt(String(h).slice(i, i + 2), 16) || 0);
const cdist = (a, b) => { const x = hex3(a), y = hex3(b); return Math.hypot(x[0] - y[0], x[1] - y[1], x[2] - y[2]); };
const typeOf = t => String(t || '').toUpperCase().split(/[\s-]/)[0];
function usedSlots() { return state && state.filaments ? state.filaments.slots.filter(s => s.used) : []; }
function autoMap(ams) {
  const m = {}, taken = new Set(), full = (ams || []).filter(a => !a.empty);
  usedSlots().forEach(s => {
    let best = -1, bd = 1e9;
    for (const pass of [true, false]) {          // first try a free slot of the same type, then any free slot
      full.forEach(a => { if (taken.has(a.index)) return; if (pass && typeOf(a.type) !== typeOf(s.type)) return; const d = cdist(a.color, s.color); if (d < bd) { bd = d; best = a.index; } });
      if (best >= 0) break;
    }
    if (best < 0 && full.length) best = full.reduce((b, a) => cdist(a.color, s.color) < cdist(b.color, s.color) ? a : b).index;
    m[s.slot] = best; if (best >= 0) taken.add(best);
  });
  return m;
}
function renderSlotMap(s) {
  const used = usedSlots(), ams = (s && s.ams) || [];
  if (!state || !used.length) { $('pMaps').innerHTML = '<span class="dim small">Open a model first.</span>'; return; }
  const key = state.gen + '|' + PR.cur + '|' + ams.map(a => a.index + a.color + a.type).join(',');
  if (PR.mapKey !== key) { const keep = PR.map; PR.map = autoMap(ams); if (PR.mapKey && PR.mapKey.split('|')[0] == state.gen) Object.keys(keep).forEach(k => { if (PR.mapUser && PR.mapUser[k]) PR.map[k] = keep[k]; }); PR.mapKey = key; buildPrev(); }
  $('pMaps').innerHTML = used.map(sl => {
    const t = PR.map[sl.slot], a = ams.find(x => x.index === t);
    const col = t === -1 ? '#D8D8D8' : a ? a.color : '#888';
    const wcol = a && cdist(a.color, sl.color) >= 60, wtype = a && typeOf(a.type) !== typeOf(sl.type);
    return `<div class="pmap ${PR.popFor === sl.slot ? 'on' : ''}" data-s="${sl.slot}" title="Colour ${sl.slot}: ${esc(sl.name)}">
      <div class="top" style="${swatchCss(sl)};color:${lum(String(sl.color).slice(0, 7)) > .6 ? '#222' : '#fff'}">${esc(sl.type || 'PLA')} · colour ${sl.slot}</div>
      <div class="bot"><span class="sw2" style="background:${t === -1 ? 'repeating-conic-gradient(#bbb 0% 25%,#eee 0% 50%) 50%/8px 8px' : col}"></span>${t === -1 ? 'Ext' : t >= 0 ? 'A' + (t + 1) : '?'} ▾</div>
      ${wtype ? '<div class="w">different type</div>' : wcol ? '<div class="w">different colour</div>' : ''}</div>`;
  }).join('');
  $('pMaps').querySelectorAll('[data-s]').forEach(el => {
    el.onclick = e => { e.stopPropagation(); slotPop(el, +el.dataset.s, ams); };
    el.onmouseenter = () => prevHighlight(+el.dataset.s); el.onmouseleave = () => prevHighlight(null);
  });
  const vals = Object.values(PR.map).filter(v => v >= 0), dup = vals.some((v, i) => vals.indexOf(v) !== i);
  $('pMapNote').innerHTML = dup ? '<span class="warn">Two colours print from the same slot, so they will come out the same colour.</span>' : '';
  prevColour(); if (s) renderModelSlots(s);
}
function slotPop(el, slot, ams) {
  const p = $('slotPop'), r = el.getBoundingClientRect(), sl = usedSlots().find(x => x.slot === slot); PR.popFor = slot;
  p.innerHTML = `<div class="dim small">Colour ${slot} (${esc(sl ? sl.name : '')}) prints from:</div><div class="trays">${ams.map(a => `<div class="tray ${PR.map[slot] === a.index ? 'on' : ''}" data-i="${a.index}" style="background:${a.color};color:${lum(a.color) > .6 ? '#222' : '#fff'}">${PR.map[slot] === a.index ? '<span class="tk">✓</span>' : ''}<b>A${a.index + 1}</b><br>${esc(a.empty ? 'empty' : a.type)}</div>`).join('') || '<span class="dim small">No AMS reported.</span>'}</div>
    <div class="tray ${PR.map[slot] === -1 ? 'on' : ''}" data-i="-1" style="background:repeating-conic-gradient(#bbb 0% 25%,#eee 0% 50%) 50%/10px 10px;color:#222;width:64px">${PR.map[slot] === -1 ? '<span class="tk">✓</span>' : ''}<b>Ext</b><br>spool</div>`;
  p.style.left = Math.min(r.left, innerWidth - 340) + 'px'; p.style.top = (r.bottom + 6) + 'px'; p.classList.remove('hidden');
  p.querySelectorAll('[data-i]').forEach(t => {
    t.onclick = e => { e.stopPropagation(); PR.map[slot] = +t.dataset.i; PR.mapUser = PR.mapUser || {}; PR.mapUser[slot] = true; p.classList.add('hidden'); PR.popFor = null; renderSlotMap(PR.last); };
    t.onmouseenter = () => prevColour(slot, +t.dataset.i); t.onmouseleave = () => prevColour();
  });
  renderSlotMap(PR.last);
}
document.addEventListener('pointerdown', e => { if (!$('slotPop').contains(e.target) && !e.target.closest('.pmap')) { $('slotPop').classList.add('hidden'); if (PR.popFor != null) { PR.popFor = null; if (PR.last) renderSlotMap(PR.last); } } }, true);
function slotMapOk() {
  const used = usedSlots(); const miss = used.filter(s => PR.map[s.slot] == null || PR.map[s.slot] < -1 || (PR.map[s.slot] === undefined));
  if (miss.length) { status('Pick an AMS slot for every colour first.', true); return false; }
  return true;
}
$('pAuto').onclick = () => { PR.mapUser = {}; PR.mapKey = null; if (PR.last) renderSlotMap(PR.last); };
document.querySelectorAll('.pseg span').forEach(s => s.onclick = () => { PR.view = s.dataset.v; document.querySelectorAll('.pseg span').forEach(x => x.classList.toggle('on', x === s)); prevColour(); });
// ---- the small preview: your real parts on the chosen plate, coloured by slot
let PV = null;
function buildPrev() {
  if (!PV) {
    const r = new THREE.WebGLRenderer({ antialias: true }); r.setPixelRatio(devicePixelRatio); r.setSize(260, 210); $('pPrev').prepend(r.domElement);
    const sc = new THREE.Scene(); sc.background = new THREE.Color(0x232327);
    const cam = new THREE.PerspectiveCamera(32, 260 / 210, 1, 50000); cam.up.set(0, 0, 1);
    sc.add(new THREE.HemisphereLight(0xffffff, 0xb4b4bc, 1.3)); const k = new THREE.DirectionalLight(0xffffff, 0.5); k.position.set(200, -300, 400); sc.add(k);
    PV = { r, sc, cam, grp: new THREE.Group(), mats: {}, t: 0 }; sc.add(PV.grp);
    (function loop() { requestAnimationFrame(loop); if ($('pview').classList.contains('hidden')) return; PV.t += 0.006; PV.grp.rotation.z = Math.sin(PV.t) * 0.22; PV.r.render(PV.sc, PV.cam); })();
  }
  PV.grp.clear(); PV.mats = {};
  if (!state) return;
  const plate = +$('pPlate').value || (state.plates[0] || {}).id;
  const mk = slot => PV.mats[slot] || (PV.mats[slot] = new THREE.MeshStandardMaterial({ color: 0x999999, roughness: 0.6 }));
  const box = new THREE.Box3();
  meshes.forEach(m => {
    const p = state.parts[m.userData.id]; if (!p || p.plate !== plate) return;
    const slots = m.userData.slots || [p.ext || 1];
    const mat = slots.length > 1 ? slots.map(mk) : mk(slots[0]);
    const c = new THREE.Mesh(m.geometry, mat); m.updateMatrixWorld(true); c.applyMatrix4(m.matrixWorld); PV.grp.add(c); box.expandByObject(c);
  });
  if (box.isEmpty()) return;
  const ctr = box.getCenter(new THREE.Vector3()), size = box.getSize(new THREE.Vector3()).length();
  PV.grp.children.forEach(c => c.position.sub(ctr)); PV.grp.position.set(0, 0, 0); PV.grp.userData.shift = ctr.clone();
  PV.cam.position.set(size * 0.8, -size * 0.95, size * 0.8); PV.cam.lookAt(0, 0, 0); PV.cam.near = size / 100; PV.cam.far = size * 20; PV.cam.updateProjectionMatrix();
  prevColour();
}
function prevColour(trySlot, tryTray) {
  if (!PV) return; const ams = (PR.last && PR.last.ams) || [];
  usedSlots().forEach(sl => {
    const mat = PV.mats[sl.slot]; if (!mat) return;
    let t = PR.map[sl.slot]; if (trySlot === sl.slot) t = tryTray;
    const a = ams.find(x => x.index === t);
    mat.color.set(PR.view === 'model' ? String(sl.color).slice(0, 7) : t === -1 ? '#D8D8D8' : a ? a.color : '#888888');
  });
}
const _prevColour2 = prevColour;
prevColour = function (a, b) { _prevColour2(a, b); if (PV && PV.towerG) { const c = towerColour(); PV.towerG.children.forEach(m => m.material && m.material.color && m.material.type !== 'LineBasicMaterial' && m.material.color.set(c)); } };
function prevHighlight(slot) { if (!PV) return; Object.entries(PV.mats).forEach(([k, m]) => m.emissive.setHex(slot != null && +k === slot ? 0x1a4a2a : 0)); }
$('pPlate').addEventListener('change', buildPrev);
window.studio.slotMap = () => PR.map;

// =====================================================================  prime tower ghost, and plates that can't print
// the prime tower, drawn the way Bambu Studio shows it: a solid rounded block in the first colour, on a thin brim
function roundedSquare(x0, y0, s, r) {
  const sh = new THREE.Shape(); r = Math.min(r, s / 2);
  sh.moveTo(x0 + r, y0); sh.lineTo(x0 + s - r, y0); sh.quadraticCurveTo(x0 + s, y0, x0 + s, y0 + r);
  sh.lineTo(x0 + s, y0 + s - r); sh.quadraticCurveTo(x0 + s, y0 + s, x0 + s - r, y0 + s);
  sh.lineTo(x0 + r, y0 + s); sh.quadraticCurveTo(x0, y0 + s, x0, y0 + s - r); sh.lineTo(x0, y0 + r); sh.quadraticCurveTo(x0, y0, x0 + r, y0);
  return sh;
}
function towerColour() {
  const s = state && state.filaments ? state.filaments.slots.filter(x => x.used) : [];
  if (PR && PR.view !== 'model' && PR.map && s.length && PR.last && PR.last.ams) { const a = PR.last.ams.find(t => t.index === PR.map[s[0].slot]); if (a) return a.color; }
  return s.length ? String(s[0].color).slice(0, 7) : '#FFFFFF';
}
function towerMesh(t) {
  const g = new THREE.Group(), col = towerColour();
  const body = new THREE.Mesh(new THREE.ExtrudeGeometry(roundedSquare(t.x, t.y, t.w, t.w * 0.18), { depth: t.h, bevelEnabled: false, curveSegments: 6 }),
    new THREE.MeshStandardMaterial({ color: col, roughness: 0.7 }));
  g.add(body);
  const e = new THREE.LineSegments(new THREE.EdgesGeometry(body.geometry, 30), new THREE.LineBasicMaterial({ color: 0x8a8a90, transparent: true, opacity: 0.6 })); g.add(e);
  const b = t.brim || 3;
  const brim = new THREE.Mesh(new THREE.ExtrudeGeometry(roundedSquare(t.x - b, t.y - b, t.w + 2 * b, (t.w + 2 * b) * 0.2), { depth: 0.3, bevelEnabled: false, curveSegments: 6 }),
    new THREE.MeshStandardMaterial({ color: col, roughness: 0.8, transparent: true, opacity: 0.75 }));
  g.add(brim);
  g.userData.tower = true; return g;
}
function drawTowers() {
  world.children.filter(o => o.userData.tower).forEach(o => world.remove(o));
  if (!state || mode !== 'plates') return;
  state.plates.forEach(pl => { if (!pl.tower) return; const g = towerMesh(pl.tower); g.position.set(pl.offset[0], pl.offset[1], 0); world.add(g); });
}
function plateProblems() {
  const out = [];
  (state ? state.plates : []).forEach(pl => {
    (pl.outside || []).forEach(n => out.push(`${pl.name}: ${n} sticks out past the plate edge`));
    (pl.overlap || []).forEach(o => out.push(`${pl.name}: ${o[0]} and ${o[1]} overlap`));
    if (pl.tower_room === false) out.push(`${pl.name}: no room for the prime tower`);
    if (pl.tower && pl.tower.problem) out.push(`${pl.name}: prime tower: ${pl.tower.problem}`);
  });
  return out;
}
const _renderFloat2 = renderFloat;
renderFloat = function () {
  _renderFloat2();
  const pp = plateProblems();
  if (pp.length && $('floatWarn').classList.contains('hidden')) {
    $('floatWarn').textContent = '⚠ ' + pp.slice(0, 2).join(' · ') + (pp.length > 2 ? ` (+${pp.length - 2} more)` : '') + '. Arrange plates (step 1) fixes it.';
    $('floatWarn').classList.remove('hidden');
  }
};
const _show4 = show; show = async function (d) { const r = await _show4(d); drawTowers(); renderFloat(); return r; };
const _setMode2 = setMode; setMode = function (m, s) { _setMode2(m, s); drawTowers(); };
// the Printers preview shows the tower too
const _buildPrev2 = buildPrev;
buildPrev = function () {
  _buildPrev2(); if (!PV || !state) return;
  const plate = +$('pPlate').value || (state.plates[0] || {}).id, pl = state.plates.find(x => x.id === plate);
  if (!pl || !PV.grp.children.length) return;
  const shift = PV.grp.userData.shift || new THREE.Vector3();
  PV.towerG = null; if (pl.tower) { const g = towerMesh(pl.tower); g.position.set(pl.offset[0], pl.offset[1], 0).sub(shift); PV.grp.add(g); PV.towerG = g; }
  // the plate itself, so you can see everything sits inside it
  const bw = state.bed[0], bd = state.bed[1];
  const plateG = new THREE.Group();
  const sq = new THREE.Mesh(new THREE.PlaneGeometry(bw, bd), new THREE.MeshBasicMaterial({ color: 0x3a3a40 })); sq.position.set(bw / 2, bd / 2, -0.2); plateG.add(sq);
  const edge = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.PlaneGeometry(bw, bd)), new THREE.LineBasicMaterial({ color: 0x00AE42 })); edge.position.set(bw / 2, bd / 2, 0); plateG.add(edge);
  plateG.position.set(pl.offset[0], pl.offset[1], 0).sub(shift); PV.grp.add(plateG);
  // frame the whole plate
  const box = new THREE.Box3().setFromObject(PV.grp), c = box.getCenter(new THREE.Vector3()), size = box.getSize(new THREE.Vector3()).length();
  PV.grp.children.forEach(ch => ch.position.sub(c));
  PV.cam.position.set(size * 0.62, -size * 0.85, size * 0.85); PV.cam.lookAt(0, 0, 0); PV.cam.near = size / 100; PV.cam.far = size * 20; PV.cam.updateProjectionMatrix();
};
window.studio.state = () => state;

// the colour tiles and preview work before (or without) a printer connection
const _enterPrinters2 = enterPrinters;
enterPrinters = async function () { const r = await _enterPrinters2(); try { PR.mapKey = null; renderSlotMap(PR.last || { ams: [] }); } catch (_) {} return r; };

new ResizeObserver(() => { const v = document.querySelector('section.view'); if (v) v.classList.toggle('narrow', v.clientWidth < 1000); }).observe(document.querySelector('section.view'));

// =====================================================================  prime tower: drag it, type it, its settings, and the real one from the slice
let towerView = 'estimate';
function towerPlates() { return state ? state.plates.filter(p => p.tower) : []; }
let towerPlateSel = null;
function renderTowerCards() {
  const tps = towerPlates();
  document.querySelectorAll('.towerCard').forEach(card => {
    const body = card.querySelector('.tcBody');
    if (!state) { body.innerHTML = '<div class="dim small">Open a model first.</div>'; return; }
    if (!tps.length) {
      const multi = state.filaments && state.filaments.slots.filter(s => s.used).length > 1;
      body.innerHTML = `<div class="dim small">${multi ? (state.plates.some(p => p.tower_room === false) ? "There's no room for one on a plate: use Arrange plates." : 'The prime tower is turned off.') : 'Only needed for prints with more than one colour.'}</div>` + towerSettingsHtml();
      wireTowerSettings(body); return;
    }
    if (!tps.find(p => p.id === towerPlateSel)) towerPlateSel = tps[0].id;
    const pl = tps.find(p => p.id === towerPlateSel), t = pl.tower, sl = pl.sliced;
    body.innerHTML = (tps.length > 1 ? `<div class="inline"><span class="dim small">Plate</span><select class="tcPlate">${tps.map(p => `<option value="${p.id}" ${p.id === pl.id ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}</select></div>` : '') +
      `<div class="dim small">Drag the tower on the plate in the 3D view, or type where it goes (its front-left corner, in mm).</div>
       <div class="tcrow"><span class="dim small">X</span><input class="tcX" value="${t.x.toFixed(1)}"><span class="dim small">Y</span><input class="tcY" value="${t.y.toFixed(1)}"></div>
       <div class="tcstat ${t.problem ? 'bad' : 'ok'}">${t.problem ? '⚠ ' + esc(t.problem) : (t.manual ? 'Placed by you' : 'Placed automatically') + ` · prints over ${t.foot[0].toFixed(0)}–${t.foot[2].toFixed(0)} × ${t.foot[1].toFixed(0)}–${t.foot[3].toFixed(0)} mm`}</div>
       <div class="inline gap"><button class="tcAuto" ${t.manual ? '' : 'disabled'}>Put it back automatically</button></div>
       <div class="seg2" title="${sl ? '' : 'Press Update print time in step 3 to see the real tower'}"><span data-tv="estimate" class="${towerView === 'estimate' || !sl ? 'on' : ''}">Estimate</span><span data-tv="sliced" class="${sl ? (towerView === 'sliced' ? 'on' : '') : 'off'}">As sliced</span></div>
       <div class="dim small" style="margin-top:4px">${sl ? `As sliced: the real tower from Bambu's G-code, ${(sl.bbox[2] - sl.bbox[0]).toFixed(1)} × ${(sl.bbox[3] - sl.bbox[1]).toFixed(1)} mm over ${sl.layers} layers.` : 'As sliced appears after Update print time (step 3), drawn from the real G-code.'}</div>` + towerSettingsHtml();
    const sel = body.querySelector('.tcPlate'); if (sel) sel.onchange = () => { towerPlateSel = +sel.value; renderTowerCards(); };
    const go = () => { const x = parseFloat(body.querySelector('.tcX').value), y = parseFloat(body.querySelector('.tcY').value); if (isFinite(x) && isFinite(y)) towerJob(() => api().set_tower(pl.id, x, y), 'Moved the prime tower'); };
    body.querySelector('.tcX').onchange = go; body.querySelector('.tcY').onchange = go;
    body.querySelector('.tcAuto').onclick = () => towerJob(() => api().set_tower(pl.id, null, null), 'Prime tower back to automatic');
    body.querySelectorAll('[data-tv]').forEach(s => s.onclick = () => { if (s.classList.contains('off')) { status('Press Update print time (step 3) first, then As sliced shows the real tower.', true); return; } towerView = s.dataset.tv; renderTowerCards(); drawTowers(); });
    wireTowerSettings(body);
  });
}
function towerSettingsHtml() {
  const c = (state && state.tower_cfg) || {};
  return `<div class="grid2 adv" style="margin-top:8px"><label class="dim small">Width</label><select class="tcW"><option value="35">35 mm (Bambu)</option><option value="30">30 mm</option><option value="40">40 mm</option><option value="50">50 mm</option></select>
    <label class="dim small">Brim</label><select class="tcB"><option value="3">3 mm (Bambu)</option><option value="0">none</option><option value="5">5 mm</option><option value="-1">automatic</option></select></div>
    <label class="chk2 adv" style="margin-top:6px"><input type="checkbox" class="tcRib" ${c.rib === false ? '' : 'checked'}> Rib walls (stronger, Bambu's default)</label>
    <label class="chk2 adv" style="margin-top:4px"><input type="checkbox" class="tcOn" ${c.enabled === false ? '' : 'checked'}> Use a prime tower</label>`;
}
function wireTowerSettings(body) {
  const c = (state && state.tower_cfg) || {};
  const w = body.querySelector('.tcW'), b = body.querySelector('.tcB'); if (!w) return;
  w.value = String(c.width ?? 35); b.value = String(c.brim ?? 3);
  w.onchange = () => towerJob(() => api().set_tower_cfg('width', +w.value), 'Prime tower width');
  b.onchange = () => towerJob(() => api().set_tower_cfg('brim', +b.value), 'Prime tower brim');
  body.querySelector('.tcRib').onchange = e => towerJob(() => api().set_tower_cfg('rib', e.target.checked), 'Prime tower rib walls');
  body.querySelector('.tcOn').onchange = e => { if (!e.target.checked && !confirm('Print without a prime tower? Colour changes may smear and the first lines of each colour can come out weak.')) { e.target.checked = true; return; } towerJob(() => api().set_tower_cfg('enabled', e.target.checked), e.target.checked ? 'Prime tower on' : 'Prime tower off'); };
}
async function towerJob(fn, label) {
  const d = await fn(); if (!d || d.error) { status((d && d.error) || 'That didn\'t work.', true); return; }
  applyLite(d); undoMgr.pushServer(label); status(label + '. Ctrl+Z undoes it.');
}
// update plates/towers without rebuilding the 3D parts
function applyLite(d) { state.plates = d.plates; state.tower_cfg = d.tower_cfg; drawTowers(); renderTowerCards(); renderFloat(); renderPlateTabs(); if (PV) buildPrev(); }
// draw: the estimate block, or the real lines from the slice
const _towerMesh0 = towerMesh;
function towerFor(pl) {
  const t = pl.tower;
  if (towerView === 'sliced' && pl.sliced) {
    const pts = []; pl.sliced.segs.forEach(s => { pts.push(new THREE.Vector3(s[0], s[1], s[4]), new THREE.Vector3(s[2], s[3], s[4])); });
    const g = new THREE.Group();
    g.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color: new THREE.Color(towerColour()) })));
    g.userData.tower = true; g.userData.plate = pl.id; return g;
  }
  const g = _towerMesh0(t);
  if (t.problem) g.traverse(o => { if (o.isMesh) o.material.color.set('#F0A030'); });
  g.userData.plate = pl.id; return g;
}
drawTowers = function () {
  world.children.filter(o => o.userData.tower).forEach(o => world.remove(o));
  if (!state || mode !== 'plates') return;
  state.plates.forEach(pl => { if (!pl.tower) return; const g = towerFor(pl); g.position.set(pl.offset[0], pl.offset[1], 0); world.add(g); });
};
// the Printers preview uses the same drawing
const _buildPrev3 = buildPrev;
buildPrev = function () {
  _buildPrev3(); if (!PV || !PV.towerG || !state) return;
  const plate = +$('pPlate').value || (state.plates[0] || {}).id, pl = state.plates.find(x => x.id === plate); if (!pl || !pl.tower) return;
  const pos = PV.towerG.position.clone(); PV.grp.remove(PV.towerG);
  const g = towerFor(pl); g.position.copy(pos); PV.grp.add(g); PV.towerG = g;
};
// drag the tower on the plate
let tdrag = null;
renderer.domElement.addEventListener('pointerdown', e => {
  if (e.button !== 0 || mode !== 'plates' || !state || vt.measure || tools3d.dragging) return;
  const r = renderer.domElement.getBoundingClientRect();
  ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1); ray.setFromCamera(ndc, camera);
  const tw = world.children.filter(o => o.userData.tower);
  const hit = ray.intersectObjects(tw, true)[0]; if (!hit) return;
  let g = hit.object; while (g && !g.userData.tower) g = g.parent; if (!g) return;
  const pl = state.plates.find(p => p.id === g.userData.plate); if (!pl) return;
  const p = new THREE.Vector3(); if (!ray.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0, 0, 1), 0), p)) return;
  tdrag = { g, pl, p0: p, x0: pl.tower.x, y0: pl.tower.y, gx0: g.position.x, gy0: g.position.y };
  controls.enabled = false; e.stopPropagation(); downAt = null;
}, true);
window.addEventListener('pointermove', e => {
  if (!tdrag) return;
  const r = renderer.domElement.getBoundingClientRect();
  ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1); ray.setFromCamera(ndc, camera);
  const p = new THREE.Vector3(); if (!ray.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0, 0, 1), 0), p)) return;
  const dx = p.x - tdrag.p0.x, dy = p.y - tdrag.p0.y, t = tdrag.pl.tower;
  tdrag.g.position.set(tdrag.gx0 + dx, tdrag.gy0 + dy, 0); tdrag.x = tdrag.x0 + dx; tdrag.y = tdrag.y0 + dy;
  // live check, like the server's: past the edge, or touching a part
  const pad = t.pad, f = [tdrag.x - pad, tdrag.y - pad, tdrag.x + t.w + pad, tdrag.y + t.d + pad], bw = state.bed[0], bd = state.bed[1];
  const out = f[0] < 0 || f[1] < 0 || f[2] > bw || f[3] > bd;
  const hitPart = state.parts.filter(q => q.plate === tdrag.pl.id).some(q => !(f[2] + 2 <= q.min[0] || q.min[0] + q.size[0] + 2 <= f[0] || f[3] + 2 <= q.min[1] || q.min[1] + q.size[1] + 2 <= f[1]));
  tdrag.g.traverse(o => { if (o.isMesh || o.isLineSegments) o.material.color.set(out || hitPart ? '#F0A030' : towerColour()); });
  const v = new THREE.Vector3(tdrag.g.position.x + t.x + t.w / 2, tdrag.g.position.y + t.y + t.d / 2, t.h + 6).project(camera), tag = $('gtag');
  tag.style.left = (v.x + 1) / 2 * r.width + 'px'; tag.style.top = (1 - v.y) / 2 * r.height + 'px';
  tag.textContent = out ? 'Off the plate' : hitPart ? 'Touching a part' : `X ${tdrag.x.toFixed(0)} · Y ${tdrag.y.toFixed(0)}`; tag.classList.remove('hidden');
});
window.addEventListener('pointerup', async () => {
  if (!tdrag) return; const d = tdrag; tdrag = null; controls.enabled = true; $('gtag').classList.add('hidden');
  if (d.x == null || Math.hypot(d.x - d.x0, d.y - d.y0) < 0.5) { drawTowers(); return; }
  await towerJob(() => api().set_tower(d.pl.id, d.x, d.y), 'Moved the prime tower');
});
const _show5 = show; show = async function (dd) { const r = await _show5(dd); state.tower_cfg = dd.tower_cfg; renderTowerCards(); return r; };
window.studio.renderTowerCards = renderTowerCards;

// =====================================================================  Models: sites, search everywhere, library
let MI = null;
const mEsc = s => esc(s || '');
async function enterModels() { MI = await api().models_info(); renderModels(); }
function renderModels() {
  if (!MI) return;
  $('mSites').innerHTML = MI.sites.map((s, i) => `<div class="msite"><span class="ico" style="background:${s.color}">${mEsc(s.name[0])}</span>
    <div class="nm"><b>${mEsc(s.name)}${s.builtin ? '' : ' <span class="dim small" style="display:inline">· yours</span>'}</b><span>${mEsc(s.home.replace(/^https?:\/\//, ''))}</span></div>
    <div class="acts"><button class="primary" data-open="${i}">Open</button><button data-more="${i}" title="More">⋯</button></div></div>`).join('');
  $('mSites').querySelectorAll('[data-open]').forEach(b => b.onclick = () => api().open_site(MI.sites[+b.dataset.open].name));
  $('mSites').querySelectorAll('[data-more]').forEach(b => b.onclick = e => siteMenu(MI.sites[+b.dataset.more], e));
  $('mRestore').classList.toggle('hidden', MI.sites.filter(s => s.builtin).length >= 7);
  $('libCount').textContent = MI.library.length ? `· ${MI.library.length}` : '';
  $('libList').innerHTML = MI.library.map((f, i) => `<div class="lib1"><div><b>${mEsc(f.file)}</b><span class="dim small">${mEsc(f.source)} · ${f.when} · ${(f.size / 1048576).toFixed(1)} MB</span></div>
    <div class="acts"><button class="primary" data-lo="${i}">Open</button><button data-ld="${i}" title="Delete">✕</button></div></div>`).join('') || '<div class="dim small" style="margin-top:8px">Nothing yet. Open a site, download a model, and it appears here.</div>';
  $('libList').querySelectorAll('[data-lo]').forEach(b => b.onclick = () => { const f = MI.library[+b.dataset.lo]; goStep(1); window.studio.openPath(f.path); });
  $('libList').querySelectorAll('[data-ld]').forEach(b => b.onclick = async () => { const f = MI.library[+b.dataset.ld]; if (!confirm(`Delete ${f.file} from your library?`)) return; MI = await api().library_remove(f.file); renderModels(); });
}
function siteMenu(s, e) {
  const items = [['Search this site for…', async () => { const q = prompt(`Search ${s.name} for:`); if (q) api().open_site(s.name, q); }],
    ['Move up', async () => { MI = await api().site_move(s.name, -1); renderModels(); }], ['Move down', async () => { MI = await api().site_move(s.name, 1); renderModels(); }]];
  if (!s.builtin) {
    items.unshift(['Rename or change address', () => openSiteModal(s)]);
    items.push([s.search ? 'Search address learned ✓ (learn again)' : 'Teach it how to search', () => teachSearch(s)]);
    items.push(['Remove', async () => { if (!confirm(`Remove ${s.name}? Models you downloaded from it stay in your library.`)) return; MI = await api().site_remove(s.name); renderModels(); }]);
  } else items.push(['Hide from the list', async () => { MI = await api().site_remove(s.name); renderModels(); status(`${s.name} hidden. "Show hidden built-in sites" brings it back.`); }]);
  const m = $('ctx'); m.innerHTML = items.map((it, i) => `<div class="mi" data-i="${i}"><span>${it[0]}</span></div>`).join('');
  m.querySelectorAll('[data-i]').forEach(d => d.onclick = () => { m.classList.add('hidden'); items[+d.dataset.i][1](); });
  m.style.left = Math.min(e.clientX, innerWidth - 260) + 'px'; m.style.top = Math.min(e.clientY, innerHeight - 220) + 'px'; m.classList.remove('hidden');
}
async function teachSearch(s) {
  const q = 'benchy';
  await api().open_site(s.name);
  if (!confirm(`In the ${s.name} window, search for:\n\n    ${q}\n\nThen come back here and press OK. BambuForge will remember how ${s.name} searches.`)) return;
  const r = await api().site_learn(s.name, q); if (r.error) { status(r.error, true); return; } MI = r; renderModels(); status(`Got it: ${s.name} is now included in Search everywhere.`);
}
let siteEditing = null;
function openSiteModal(s) {
  siteEditing = s || null; $('smTitle').textContent = s ? 'Edit site' : 'Add a model site'; $('smOk').textContent = s ? 'Save' : 'Add';
  $('smUrl').value = s ? s.home : ''; $('smName').value = s ? s.name : ''; $('smName').dataset.typed = s ? '1' : ''; $('smErr').textContent = '';
  $('siteModal').classList.remove('hidden'); setTimeout(() => $('smUrl').focus(), 30);
}
$('mAdd').onclick = () => openSiteModal();
$('mRestore').onclick = async () => { MI = await api().site_restore(); renderModels(); };
$('smCancel').onclick = () => $('siteModal').classList.add('hidden');
$('smUrl').oninput = () => { if ($('smName').dataset.typed) return; const h = $('smUrl').value.replace(/^https?:\/\//i, '').replace(/^www\./i, '').split(/[./]/)[0]; $('smName').value = h ? h[0].toUpperCase() + h.slice(1) : ''; };
$('smName').oninput = () => $('smName').dataset.typed = '1';
$('smOk').onclick = async () => {
  const r = siteEditing ? await api().site_edit(siteEditing.name, $('smName').value, $('smUrl').value) : await api().site_add($('smUrl').value, $('smName').value);
  if (r.error) { $('smErr').textContent = r.error; return; }
  MI = r; $('siteModal').classList.add('hidden'); renderModels();
  if (!siteEditing) status(`Added ${$('smName').value || 'the site'}. Downloads from it go to your library. Use ⋯ → "Teach it how to search" to include it in Search everywhere.`);
};
['smUrl', 'smName'].forEach(id => $(id).onkeydown = e => { if (e.key === 'Enter') $('smOk').click(); if (e.key === 'Escape') $('smCancel').click(); });
// search everywhere: every site's own results, one click each (opens in the browser window)
function searchEverywhere() {
  const q = $('mQ').value.trim(); if (!q || !MI) return;
  const can = MI.sites.filter(s => s.builtin || s.search), cant = MI.sites.filter(s => !s.builtin && !s.search);
  $('mResults').classList.remove('hidden');
  $('mResults').innerHTML = `<div class="panelTitle">Results for “${mEsc(q)}” <span class="dim small">· click a site to see its results in the browser window</span></div>
    <div class="mres">${can.map((s, i) => `<div class="r" data-r="${MI.sites.indexOf(s)}"><span class="ico" style="width:26px;height:26px;border-radius:6px;display:flex;align-items:center;justify-content:center;font-weight:700;color:#fff;background:${s.color}">${mEsc(s.name[0])}</span><div style="flex:1"><b>${mEsc(s.name)}</b><div class="dim small">see “${mEsc(q)}” ↗</div></div></div>`).join('')}</div>` +
    (cant.length ? `<div class="dim small" style="margin-top:8px">Not searched yet: ${cant.map(s => mEsc(s.name)).join(', ')}. Use ⋯ → "Teach it how to search" once.</div>` : '');
  $('mResults').querySelectorAll('[data-r]').forEach(d => d.onclick = () => api().open_site(MI.sites[+d.dataset.r].name, q));
}
$('mGo').onclick = searchEverywhere; $('mQ').onkeydown = e => { if (e.key === 'Enter') searchEverywhere(); };
$('libAdd').onclick = async () => { MI = await api().library_add_dialog(); renderModels(); };
$('libShow').onclick = () => api().library_show();
// a download finished in the browser window
window.studio.modelDownloaded = async (names, path) => {
  if (MI) { MI = await api().models_info(); renderModels(); }
  const t = $('toastBar') || (() => { const d = document.createElement('div'); d.id = 'toastBar'; d.className = 'banner'; d.style.top = 'auto'; d.style.bottom = '34px'; d.style.background = '#1f3a2a'; d.style.color = '#8EE0AE'; document.body.appendChild(d); return d; })();
  t.innerHTML = `<span>✓ Saved to your library: <b>${names.map(mEsc).join(', ')}</b></span><span style="flex:1"></span><button class="primary" id="tbOpen">Open in BambuForge</button><button id="tbX">✕</button>`;
  t.classList.remove('hidden');
  $('tbOpen').onclick = () => { t.classList.add('hidden'); goStep(1); window.studio.openPath(path); };
  $('tbX').onclick = () => t.classList.add('hidden');
};
// without a desktop Bambu Studio there is nothing for "Send" to open: hide that step and number the rest 1-4
(async () => {
  for (let i = 0; i < 40 && !(window.pywebview && window.pywebview.api && window.pywebview.api.app_info); i++) await sleep(250);
  try {
    const ai = await api().app_info(); window.studio.appInfo = ai;
    if (!ai.desktop) { const b = document.querySelector('#steps [data-step="6"]'); if (b) b.classList.add('hidden'); const p = document.querySelector('#steps [data-step="7"]'); if (p) p.textContent = '4 Printers'; }
  } catch (_) {}
})();
