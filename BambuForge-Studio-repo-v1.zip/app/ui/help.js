// The built-in guide: plain-English, step-by-step help for every part of BambuForge Studio, plus a short tour.
const $ = id => document.getElementById(id);
const G = [
['sec', 'Getting started'],
['welcome', 'Welcome: what this program does', `
<h2>Welcome to BambuForge Studio</h2>
<p>BambuForge Studio takes a 3D model and gets it ready for your Bambu Lab printer. You don't need to know anything about 3D printing settings: it picks them for you and explains why.</p>
<p>It works in <b>5 steps</b>, shown as buttons along the top of the window. You go from left to right:</p>
<ol>
<li><b>1 Model and plates</b>: open your model, make it bigger or smaller, choose its colours, add text, then move and turn each piece and lay everything out on the printer's plates.</li>
<li><b>2 Split and hollow</b>: if it's too big for your printer, cut it into pieces that fit, with pegs or magnets to join them, and (optionally) make the pieces hollow. The pieces are then laid out on plates for you.</li>
<li><b>3 Settings</b>: pick your printer, plate and filament; see how long it will take and how much plastic it uses.</li>
<li><b>4 Send</b>: send everything to Bambu Studio.</li>
<li><b>5 Printers</b>: (optional) send prints straight to your printer and watch them.</li>
</ol>
<p>The options for each step are in <b>sections</b> on the right. Click a section's name to open it; the others fold up so nothing needs scrolling. Folded sections still show the key facts. Tick <b>keep several open</b> at the top of that column to have more than one open.</p>
<p>Drag the thin edges of the side columns to make them wider or narrower, or press <b>«</b> / <b>»</b> to fold a column away and give the 3D view the whole screen (the little tab on the side brings it back).</p>
<div class="tip">You don't have to use every step. A small model that already fits can go straight from step 1 to step 3.</div>
<p>Press <b>Show me around</b> at the top of this window for a quick tour of the screen.</p>`],
['screen', 'The screen at a glance', `
<h2>The screen at a glance</h2>
<ul>
<li><b>Top bar</b>: the 5 steps, the <b>↶ ↷</b> undo and redo arrows, <b>History</b>, <b>? Help</b> (this guide) and <b>Open file…</b>.</li>
<li><b>Left: Parts</b>: every part in your model, which plate it's on, its size, and whether it <span style="color:#5DCAA5">fits</span> or is <span style="color:#F09595">too big</span>. Underneath: how much filament each plate needs, and the total.</li>
<li><b>Middle: the 3D view</b>: your model. <b>Left-drag</b> spins it, <b>right-drag</b> moves it, the <b>mouse wheel</b> zooms. Click a part to select it.</li>
<li><b>Buttons above the 3D view</b>: <b>On plates</b> shows the parts laid out for printing; <b>Assembled</b> shows the finished object. <b>Fit</b>, <b>3D</b>, <b>Top</b>, <b>Front</b> change the camera.</li>
<li><b>Right</b>: the controls for whichever step you're on.</li>
<li><b>Bottom bar</b>: messages about what just happened, and <b>Copy log</b> (for getting help).</li>
</ul>`],
['open', 'Opening a model', `
<h2>Opening a model</h2>
<ol>
<li>Click <b>Open file…</b> (top right), or just <b>drag the file</b> from a folder onto the window.</li>
<li>Pick a <b>.3mf</b> (a Bambu Studio project, or any 3MF), an <b>.stl</b> or an <b>.obj</b> file.</li>
<li>Wait a moment while it loads. Big models can take 10 to 20 seconds.</li>
</ol>
<div class="tip">Files from <b>MakerWorld</b> or <b>Printables</b> are usually .3mf or .stl. Both work.</div>
<p>When it opens you'll see your model in the middle, its parts on the left, and its colours in the <b>Colours</b> box on the right.</p>`],
['sec', 'The steps'],
['size', '1 · Making it bigger or smaller', `
<h2>Step 1 · Making it bigger or smaller</h2>
<ol>
<li>In <b>Size</b> on the right, choose what to measure: the <b>whole model</b>, the <b>tallest part</b>, or the part you <b>selected</b>.</li>
<li>Type the size you want in the box. You can type it any way you like: <kbd>1651</kbd> (mm), <kbd>165 cm</kbd>, <kbd>65 in</kbd> or <kbd>5'5"</kbd>. Or type a percentage in <b>or scale by</b>.</li>
<li>Press <b>Apply size</b>.</li>
</ol>
<p>Parts that are now too big for your printer turn red. That's fine: step 2 cuts them into pieces.</p>
<div class="tip">Made a mistake? Press <kbd>Ctrl</kbd>+<kbd>Z</kbd> to undo, or <b>Reset</b> to go back to the original size.</div>`],
['position', '1 · Moving and turning parts', `
<h2>Step 1 · Moving and turning parts</h2>
<p>In <b>1 Model and plates</b>, click the part you want (in the 3D view or the Parts list). It gets a green box around it.</p>
<h3>Move it</h3>
<ol><li>Press <b>✥ Move</b> on the bar over the 3D view (or the <kbd>M</kbd> key).</li>
<li>Drag the part to slide it around the plate, or drag one of the arrows to move it in just one direction (red and green slide it, blue lifts it).</li>
<li>A label shows how far you moved. Let go and it stays there.</li></ol>
<h3>Turn it</h3>
<ol><li>Press <b>⟳ Rotate</b> (or <kbd>R</kbd>). Thin red, green and blue rings appear around the part. They brighten when your mouse is over one.</li>
<li>Drag a ring. A protractor with tick marks appears and a label shows the angle, like <b>Z: +30°</b>. It clicks every 5°; hold <kbd>Ctrl</kbd> for smooth.</li>
<li>Let go. The part stays sitting on the plate.</li></ol>
<p>The <b>Quick turns</b> buttons turn it 90° in one click. In <b>Advanced</b> mode you can also type exact numbers: <b>Relative</b> turns it <i>by</i> that much; <b>Absolute</b> turns it <i>to</i> exactly that.</p>
<h3>Lay it flat, lift it, drop it</h3>
<ul><li><b>Lay flat on a face</b> (<kbd>F</kbd>): click a flat side and that side goes face-down on the plate.</li>
<li>Hold <kbd>Shift</kbd> and drag a part (with Move on) to lift it. A lifted part <b>can't be printed</b>; an orange warning tells you.</li>
<li><b>Drop</b> (<kbd>D</kbd>) puts it back on the plate. With nothing selected it drops everything.</li></ul>
<div class="tip">Right-click any part for quick actions: turn 90°, lay flat, drop, centre it, colours, text, copy, delete.</div>`],
['tools', 'Measure, section view, support map', `
<h2>Measure, section view and support map</h2>
<ul><li><b>📏 Measure</b> (<kbd>K</kbd>): click two points on the model. A yellow line shows the distance in mm.</li>
<li><b>✂ Section</b> (<kbd>X</kbd>): a slider slices the model open from the top so you can see inside: hollow walls, peg holes, wire channels.</li>
<li><b>🔥 Support map</b> (<kbd>H</kbd>, in step 1): faces that will need support turn red. Turn the part until the red mostly goes away; less support means less cleanup.</li></ul>`],
['shortcuts', 'Keyboard shortcuts, Simple and Advanced', `
<h2>Keyboard shortcuts</h2>
<p>Click the 3D view first, then press:</p>
<ul><li>Step 1: <kbd>S</kbd> size, <kbd>C</kbd> colours, <kbd>T</kbd> text, <kbd>M</kbd> move, <kbd>R</kbd> rotate, <kbd>F</kbd> lay flat, <kbd>D</kbd> drop, <kbd>H</kbd> support map</li>
<li>Anywhere: <kbd>K</kbd> measure, <kbd>X</kbd> section, <kbd>Ctrl</kbd>+<kbd>D</kbd> copy, <kbd>Del</kbd> delete, <kbd>Esc</kbd> stop the current tool, <kbd>Ctrl</kbd>+<kbd>Z</kbd> undo, <kbd>F1</kbd> this guide</li></ul>
<h3>Simple and Advanced</h3>
<p>The switch at the top. <b>Simple</b> hides the number boxes (exact positions, angles, scale %, font and depth) so the screen stays clean. <b>Advanced</b> shows everything. Your choice is remembered.</p>
<h3>Look</h3>
<p>The <b>⚙</b> button: bigger or smaller text, light or dark theme, and whether closing the window keeps it running in the tray. Drag the thin bars at the edges of the side panels to make them wider or narrower.</p>`],
['ready', 'Ready to print? check', `
<h2>The "Ready to print?" check</h2>
<p>Press <b>Ready to print?</b> at the top before you send anything. It checks:</p>
<ul><li>every part sits on the plate,</li><li>everything fits your printer,</li><li>hand-placed joints are all green,</li>
<li>overhangs have support,</li><li>your filaments stick to the chosen plate,</li><li>your printer's AMS has the right colours (if a printer is connected).</li></ul>
<p>Each ⚠ has a button that fixes it for you. The button at the top turns green (<b>✓ Ready to print</b>) when everything is OK.</p>`],
['copies', 'Copies, line-up and adding models', `
<h2>Copies, line-up and adding models</h2>
<ul><li><b>Copies</b> (step 1, Copies and line-up): click a part, type how many, press <b>Make</b>. They go wherever there's room (on a new plate if needed). <kbd>Ctrl</kbd>+<kbd>D</kbd> makes one copy.</li>
<li><b>Align left</b>, <b>Centre</b>, <b>Space evenly</b> line up the parts on the selected part's plate.</li>
<li><b>Add a model</b>: the little ▾ next to <b>Open file…</b> → <b>Add a model to this project…</b>. Its colours are added to your colour list.</li>
<li><b>Plate tabs</b> at the bottom of the 3D view jump to each plate.</li>
<li><b>Recent files</b> are in the same ▾ menu.</li></ul>`],
['text', '1 · Putting text on your model', `
<h2>Step 1 · Putting text on your model</h2>
<ol><li>In <b>Add text</b>, type your words.</li>
<li>Pick a <b>Font</b> and the <b>Letter height</b> (8 mm is easy to read).</li>
<li><b>Style</b>: <b>Raised</b> letters stick out of the surface; <b>Cut in</b> letters are carved into it.</li>
<li><b>Depth</b>: how far they stick out or go in (1 mm is good; keep cut-in text thinner than the wall).</li>
<li><b>Turn</b>: turns the words on the surface (90 makes them run the other way).</li>
<li><b>Wrap around the surface</b>: each letter follows the shape, like a label on a cup. Untick it for text on one flat plane.</li>
<li><b>Colour</b> (raised text only): which colour the letters print in. Pick a different one from the model to make them stand out.</li>
<li>Press <b>Place text</b>, then <b>click the spot on the model</b> where the middle of the text should go.</li></ol>
<div class="tip">The text lies flat against the surface you click, even on sides or slopes. Raised text sinks slightly into curved surfaces so no corner floats. Don't like it? <kbd>Ctrl</kbd>+<kbd>Z</kbd>.</div>`],
['colours', '1 · Colours and painting', `
<h2>Step 1 · Colours and painting</h2>
<p>The <b>Colours</b> box lists every colour (filament) your model uses. Each one has a number (1, 2, 3…), which is also the slot it will use in your AMS.</p>
<h3>See how much of each colour you need</h3>
<p>Each row shows how many grams of that colour the model needs. It's an estimate until you press <b>Update print time</b> in step 3; then it's Bambu's exact number.</p>
<h3>Change a colour or filament</h3>
<ol>
<li>Click the <b>coloured square</b> on a row.</li>
<li>A window opens. Pick the <b>brand</b> (Bambu Lab, SUNLU, eSUN, Polymaker, Generic…), then the <b>type</b> (PLA Basic, PLA+ 2.0, PETG, Silk, Wood, Glow…), then the <b>colour</b>.</li>
<li>Press <b>Use this filament</b>. The model changes colour straight away.</li>
</ol>
<div class="tip">Type in the search box at the top of that window, like <kbd>sunlu pla</kbd> or <kbd>glow</kbd>, to find a filament fast.</div>
<h3>Paint parts of the model</h3>
<ol>
<li>Click the <b>row</b> of the colour you want to paint with (it gets a green border).</li>
<li>Pick a tool:
<ul><li><b>Whole part</b>: the whole part you click becomes that colour.</li>
<li><b>Same colour</b>: the connected area you click that's all one colour changes (like a paint bucket).</li>
<li><b>Up to edges</b>: fills the area you click and stops at sharp edges. The <b>Edge sharpness</b> slider sets how sharp an edge has to be to stop it. Lower numbers stop at gentler edges.</li></ul></li>
<li>Click on the model. Click the tool again to stop painting.</li>
</ol>
<h3>Special colours and looks</h3>
<ul><li><b>Look</b>: Solid, Matte, Silk, Metal, Translucent, Clear, Glow in the dark, Sparkle, Galaxy, Marble or Wood. The 3D view shows it (see-through, shiny, glowing…).</li>
<li><b>Colours</b>: <b>One colour</b>, <b>Gradient</b> (one colour fades into the next, like rainbow silk) or <b>Multicolour</b> (changes in stripes). Click a little square under it, then pick that colour. <b>+</b> adds a colour (up to 4).</li>
<li><b>The colour wheel</b>: click or drag on it to pick any colour. <b>Brightness</b> makes it darker or lighter; <b>See-through</b> makes it transparent.</li>
<li>Bambu's own filaments show their official colours first, including their gradient and see-through ones. The second row has ready-made specials: clear, translucent, glow, metal, silk, galaxy, wood, marble and rainbow.</li></ul>
<p>Need another colour? Press <b>+ Add a colour</b>.</p>
<div class="tip">Painting is undoable: <kbd>Ctrl</kbd>+<kbd>Z</kbd>.</div>`],
['split', '2 · Splitting big models', `
<h2>Step 2 · Splitting big models into pieces</h2>
<p>Your printer can only print things up to a certain size. If a part is too big (red in the Parts list), split it:</p>
<ol>
<li>Click <b>2 Split and hollow</b> at the top.</li>
<li>Choose the part in <b>Part to split</b>. Too-big parts are at the top with a ⚠.</li>
<li>Choose a <b>joint</b> for the pieces (see below), then press <b>Suggest cuts</b>. Green flat sheets appear on the model where it will be cut. It picks the thickest, strongest places.</li>
<li>Want a cut somewhere else? <b>Drag the green sheet</b> up or down, or type a height. A sheet turns <span style="color:#F09595">red</span> if a piece would be too tall.</li>
<li>Press <b>Make pieces</b>. With <b>Then lay the pieces out on plates</b> ticked, it turns each piece the best way up and packs the plates for you, then takes you back to step 1 to check them.</li>
</ol>
<h3>Which joint should I pick?</h3>
<ul>
<li><b>Keyed D-peg + glue</b>: strongest; only fits one way, so pieces can't be glued crooked. Best for most things.</li>
<li><b>Twin dowels + glue</b>: two thin pins; good for flatter pieces.</li>
<li><b>Dovetail</b>, <b>Twist-lock</b>, <b>Screw thread</b>: come apart again without glue.</li>
<li><b>Magnets</b>: come apart easily. You choose the magnet size you've bought.</li>
<li><b>Hollow-core sleeve</b>: for tube-shaped parts; keeps a hole through the middle for wires.</li>
<li><b>Glue face only</b>: no peg at all.</li>
</ul>`],
['joints', '2 · Placing joints yourself', `
<h2>Step 2 · Placing joints yourself (the joint editor)</h2>
<ol>
<li>After <b>Suggest cuts</b>, every cut has an <b>Edit joints…</b> button. Click it.</li>
<li>You'll see the two pieces with the joints shown as see-through shapes:
<ul><li><span style="color:#5DCAA5">Green</span>: fits well.</li>
<li><span style="color:#FAC775">Orange</span>: fits, but the wall around it is thin.</li>
<li><span style="color:#F09595">Red</span>: won't work (it breaks through the outside, is too deep, or overlaps another joint). The bar at the top says why.</li></ul></li>
<li><b>Drag</b> a joint to move it. Use <b>Diameter</b> and <b>Depth</b> to resize it, or for magnets pick the <b>magnet size</b> you have.</li>
<li><b>Add one</b> adds another joint; <b>Remove</b> deletes the selected one. Click the numbered buttons to pick which joint you're changing.</li>
<li>The two sliders separate the pieces so you can see inside: <b>Pull pieces apart</b> and <b>Exploded view</b>.</li>
<li>Press <b>Done</b>.</li>
</ol>
<div class="warn"><b>Make pieces</b> won't work while any joint is red. Fix it first.</div>`],
['hollow', '2 · Hollowing', `
<h2>Step 2 · Hollowing (optional)</h2>
<p>Big solid parts use lots of plastic. Hollowing keeps a strong outer wall and leaves the inside empty.</p>
<p>The easy way: in the <b>Hollow</b> section, tick <b>Hollow the pieces when I press Make pieces</b>. Every new piece is hollowed straight after the cut, keeping its ends solid so the joints stay strong.</p>
<ol><li>Pick the part. Set the <b>Wall</b> thickness (3 mm is good).</li>
<li><b>Wire channel</b>: type a size (like 8 mm) to make a hole straight through, for LED wires. 0 means no hole.</li>
<li>Press <b>Hollow it</b>.</li></ol>`],
['plates', '1 · Laying out the plates', `
<h2>Step 1 · Laying out the plates</h2>
<ol><li>Press <b>Auto-orient + arrange</b>. Every piece is turned the way it prints best (least support plastic, most of it touching the bed) and packed onto as few plates as possible.</li>
<li>Want to change something? Click a part: you'll see every way it could sit, with how much support it needs. Click one to use it.</li>
<li>Drag parts around the plate with the mouse, or use <b>Move to</b> to put a part on another plate.</li></ol>`],
['settings', '3 · Settings, plate, filament, print time', `
<h2>Step 3 · Settings and print time</h2>
<ol>
<li><b>Printer</b>: pick your printer (and nozzle size, usually 0.4). Everything adjusts to it.</li>
<li><b>Plate</b>: pick the build plate you actually have on the printer (it's printed on the plate). If one of your filaments doesn't stick to that plate, you'll get a warning.</li>
<li><b>Filaments</b>: the colours your model uses. Click one to change it.</li>
<li><b>Based on</b> and <b>Preset name</b>: leave these alone unless you know you want something different.</li>
<li>The list underneath shows every setting it's changing, with the reason in plain English. Untick any you don't want.</li>
<li>Press <b>Update print time</b>. Bambu Studio works out the real time and grams for every plate (a few minutes for big jobs).</li>
</ol>
<h3>Finish options</h3>
<ul><li><b>Iron the tops</b>: makes flat top surfaces smooth and shiny. Adds time.</li>
<li><b>Smooth seams</b>: hides the little line where each layer starts.</li>
<li><b>Precise outer walls</b>: sharper, more accurate edges.</li></ul>
<div class="tip">Tall, thin parts automatically print slower near the top (<b>Slow down by height</b>) so they don't wobble or get knocked over.</div>`],
['send', '4 · Sending to Bambu Studio', `
<h2>Step 4 · Sending to Bambu Studio</h2>
<ol><li>Pick your Bambu account in <b>Save to</b>.</li>
<li>Leave <b>Open my project in Bambu Studio when done</b> ticked.</li>
<li>Press <b>Send to Bambu Studio</b>. If Bambu Studio is open, it asks to close it first (save your work there if it asks).</li>
<li>Bambu Studio opens with your project, already set up. Press <b>Slice plate</b> and <b>Print plate</b> there as usual.</li></ol>
<p>You'll see <b>✓ synced</b> once your settings have reached your Bambu account.</p>`],
['printers', '5 · Printing straight to your printer', `
<h2>Step 5 · Printing straight to your printer</h2>
<h3>One-time setup (on the printer itself)</h3>
<ol><li>On the printer's touchscreen, open <b>Settings</b> (the gear), then <b>WLAN</b>.</li>
<li>Turn on <b>LAN Only Mode</b>.</li>
<li>Scroll down and turn on <b>Developer Mode</b>.</li>
<li>Write down the <b>Access Code</b> shown on that screen (8 characters).</li></ol>
<div class="warn">While Developer Mode is on, the Bambu Handy phone app and cloud printing don't work for that printer. Turn it off again on the same screen whenever you like.</div>
<h3>Adding the printer in BambuForge Studio</h3>
<ol><li>Click <b>5 Printers</b>, then <b>Find printers</b>. Windows may ask to allow network access: click <b>Allow</b>.</li>
<li>Click <b>Add</b> next to your printer, type the access code, and press <b>Connect</b>. (If it isn't found, use <b>Add by IP…</b>; the IP address and serial number are on the printer's screen under Settings.)</li></ol>
<h3>Printing</h3>
<ol><li>Pick the <b>plate</b> and which <b>AMS slot</b> to use, then press <b>Send to printer</b>.</li>
<li>You'll see each stage: heating the bed, levelling, heating the nozzle, then printing, with % done, time left, when it will finish, and filament used.</li>
<li><b>Pause</b>, <b>Stop</b>, <b>Home</b> and <b>Calibrate…</b> are under that.</li></ol>
<h3>The AMS</h3>
<p>Click a slot to tell the printer what's in it: brand, type and colour. <b>Load</b> and <b>Unload</b> feed filament in and out.</p>
<h3>Which slot each colour prints from</h3>
<p>Next to <b>Send to printer</b> there's a tile for each colour in your model. The top half is the colour you picked; the bottom half is the AMS slot it will print from (<b>A1</b>–<b>A4</b>, or <b>Ext</b> for the external spool).</p>
<ul><li>Studio matches them for you: the closest colour of the same type, each slot used once where possible.</li>
<li>Click a tile to choose a different slot. Move your mouse over a slot to try it on the little preview first.</li>
<li>The preview turns slowly and shows your parts on the chosen plate: <b>As it will print</b> uses the AMS colours, <b>Your colours</b> shows what you picked.</li>
<li><b>different colour</b> or <b>different type</b> means that slot doesn't hold what you picked. <b>Match automatically</b> undoes your changes.</li></ul>
<p>The preview shows the whole plate (green edge) with your parts and, for multi-colour prints, the <b>prime tower</b> (the grey see-through box). The tower is where the printer cleans the nozzle after each colour change; Studio puts it in a free spot on the plate, clear of your parts.</p>
<p>Under the AMS slots, <b>Prints from each slot</b> lists which colours use each one. If you've loaded the right rolls but the printer doesn't know, press <b>Set AMS to match my model</b>.</p>`],
['sec', 'Everyday'],
['undo', 'Undo, redo and history', `
<h2>Undo, redo and history</h2>
<ul><li><kbd>Ctrl</kbd>+<kbd>Z</kbd> undoes the last thing. <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>Z</kbd> (or <kbd>Ctrl</kbd>+<kbd>Y</kbd>) puts it back.</li>
<li>The <b>↶ ↷</b> arrows at the top do the same.</li>
<li><b>History</b> lists everything you've done; pick an entry to jump back that far.</li>
<li>Inside the joint editor, undo and redo change the joints.</li></ul>`],
['save', 'Saving and sharing', `
<h2>Saving and sharing</h2>
<ul><li><b>Save as 3MF…</b> (step 1) saves your model with its parts and colours.</li>
<li><b>Save project with these settings…</b> (step 3) saves a Bambu Studio project with all the settings, ready to print.</li>
<li>To give the program to a friend, send them the same zip you installed from. They need Bambu Studio installed and opened once.</li></ul>`],
['sec', 'Problems and fixes'],
['p-runanyway', '"Windows protected your PC"', `
<h2>"Windows protected your PC" when you start it</h2>
<p>Windows shows this for programs that aren't digitally signed. BambuForge Studio isn't signed (that costs money every month), so it will appear.</p>
<ol><li>Click <b>More info</b> (small text under the message).</li><li>Click <b>Run anyway</b>.</li></ol>
<p>You only need to do this once for each new version.</p>
<div class="tip"><b>To skip it completely:</b> before unzipping a new version, right-click the downloaded zip → <b>Properties</b> → tick <b>Unblock</b> at the bottom → <b>OK</b>. Then unzip.</div>`],
['p-recover', 'It closed unexpectedly / getting work back', `
<h2>It closed unexpectedly</h2>
<p>Your work is saved in the background every minute. Next time you start BambuForge Studio, an orange bar asks <b>Bring it back</b>? Click it and you're back where you were (up to a minute before it closed).</p>`],
['p-tray', 'Where did it go? (the tray icon)', `
<h2>Where did the window go?</h2>
<p>Closing the window keeps BambuForge Studio running in the <b>tray</b> (bottom right of the screen, next to the clock; click the little ^ if you don't see it). That way it can tell you when a print finishes or a printer has a problem.</p>
<ul><li><b>Double-click</b> the icon to open the window again.</li><li><b>Right-click</b> it for Open, Copy logs, Open the log folder, and <b>Quit</b>.</li>
<li>Don't want that? ⚙ → untick "Keep running in the tray".</li></ul>`],
['p-start', "It won't open / nothing happens", `
<h2>It won't open, or nothing happens</h2>
<ol><li>Wait 30 seconds: the first start after installing is slow.</li>
<li>If a message says it stopped, click <b>Yes</b> to copy the logs, then paste them to whoever is helping you.</li>
<li>Unzip the download again into a new folder and start <b>BambuForge Studio.exe</b> from there. It checks for Microsoft's WebView2 and offers to install it.</li>
<li>Restart the PC and try again.</li>
<li>Still stuck? Start menu → <b>BambuForge Studio - copy logs</b>, and send them.</li></ol>`],
['p-file', "My file won't open, or can't be cut", `
<h2>My file won't open, or can't be cut</h2>
<ul><li><b>"isn't a closed solid"</b>: the model has holes in its surface. Open it in Bambu Studio, right-click it → <b>Fix model</b>, save, and open it here again.</li>
<li><b>Only some colours show up</b>: make sure you opened the <b>.3mf</b> project, not an .stl. An STL file has no colours in it.</li>
<li>Very big files (millions of triangles) can take a minute. Watch the message at the bottom.</li></ul>`],
['p-red', 'Parts are red or "too big"', `
<h2>Parts are red or "too big"</h2>
<ul><li>Red means it won't fit on your printer. Go to <b>2 Split and hollow</b> and press <b>Suggest cuts</b>.</li>
<li>Check the <b>printer</b> in step 3 is the one you own. A smaller printer (like the A1 mini) makes more things too big.</li>
<li>If it's only a little too big, try <b>Arrange plates → Auto-orient + arrange</b> in step 1: laying it a different way may make it fit.</li></ul>`],
['p-time', "Print time doesn't work", `
<h2>"Update print time" doesn't work</h2>
<ul><li>It needs <b>Bambu Studio</b> installed. Install it from bambulab.com, open it once, then try again.</li>
<li>If a part is red (too big), fix that first.</li>
<li>Big projects take several minutes. Leave it running.</li></ul>`],
['p-preset', "My settings don't show in Bambu Studio", `
<h2>My settings don't show in Bambu Studio</h2>
<ol><li>In step 4, make sure <b>Save to</b> is your account (it says "signed in").</li>
<li>Bambu Studio only reads new settings when it starts, so let BambuForge close and reopen it.</li>
<li>In Bambu Studio, open the process (print settings) list; it's under <b>User presets</b>.</li></ol>`],
['p-printer', "My printer isn't found or won't connect", `
<h2>My printer isn't found, or won't connect</h2>
<ul><li>The printer and this PC must be on the <b>same Wi-Fi/network</b>.</li>
<li>On the printer: <b>Settings → WLAN</b>: <b>LAN Only Mode</b> and <b>Developer Mode</b> must both be on.</li>
<li><b>"Wrong access code"</b>: retype the 8 characters exactly as on the printer's screen. It can change when you switch LAN mode on, so check it again.</li>
<li>Windows Firewall: if you clicked "Cancel" when Windows asked, search Start for <b>Allow an app through Windows Firewall</b> and tick BambuForge Studio (Python) for Private networks.</li>
<li>Not found by <b>Find printers</b>? Use <b>Add by IP…</b> with the IP shown on the printer (Settings → WLAN).</li></ul>`],
['p-refused', 'The printer refuses commands or a print', `
<h2>The printer refuses commands, or a print won't start</h2>
<ul><li>Turn <b>Developer Mode</b> on (printer: Settings → WLAN), then restart the printer.</li>
<li>Make sure the printer type in step 3 matches the printer you're sending to.</li>
<li>Clear the bed and close the door; check filament is loaded.</li>
<li>Press <b>Copy log</b> and send it for help: every command and the printer's answer is in there.</li></ul>`],
['p-fan', 'Fan sliders jump back', `
<h2>The fan sliders jump back</h2>
<p>When you move a fan slider it says <b>(setting…)</b> until the printer reports the new speed. If the printer doesn't change it within 20 seconds, the slider shows what the printer is really doing. Some printers ignore fan changes while they're idle or heating; try again once printing has started.</p>`],
['p-float', "It says a part is lifted off the plate", `
<h2>"Lifted off the plate and can't be printed"</h2>
<p>You (or a Shift-drag) lifted a part into the air. Printers can't print in mid-air. Click the part and press <b>Drop to plate</b> in step 1 (or press it with nothing selected to drop everything).</p>`],
['tower', 'The prime tower', `
<h2>The prime tower</h2>
<p>Prints with more than one colour need a <b>prime tower</b>: a small block printed next to your model where the nozzle gets cleaned after each colour change, so the new colour comes out clean.</p>
<h3>Moving it</h3>
<ul><li>Studio places it automatically in a free spot, kept well inside the plate and clear of your parts.</li>
<li>To move it yourself, <b>drag it</b> on the plate in the 3D view (in step 1 or step 3), or type <b>X</b> and <b>Y</b> in the <b>Prime tower</b> section. While you drag it turns orange if it would print off the plate or touch a part.</li>
<li><b>Put it back automatically</b> undoes your placement. <b>Arrange plates</b> also puts it back.</li></ul>
<h3>Estimate and As sliced</h3>
<ul><li><b>Estimate</b> shows a solid block the size Bambu's tower really prints (with its rib walls and brim).</li>
<li>After <b>Update print time</b> (step 3), <b>As sliced</b> draws the tower from the real G-code Bambu made, layer by layer, so you see exactly what will print and exactly where.</li></ul>
<h3>Settings (Advanced)</h3>
<p>Width, brim, rib walls (stronger; Bambu's default) and turning the tower off. Without a tower, colour changes can smear.</p>`],
['models', 'Models: finding and downloading models', `
<h2>Models: finding and downloading models</h2>
<p>Click <b>🌐 Models</b> at the top left.</p>
<ul><li><b>Search everywhere</b>: type what you want (e.g. <i>dragon</i>) and press Enter. Click any site to see its results for that search.</li>
<li><b>Model sites</b>: MakerWorld, Printables, Thingiverse, Cults, MyMiniFactory, Thangs and Free3D are built in. <b>Open</b> shows the real website in the BambuForge browser window. Sign in there once and it's remembered.</li>
<li><b>Downloads</b> of .3mf, .stl, .obj, .step or .zip files in that window go straight into <b>My library</b> (no Save box). Zips are unpacked for you. A green bar offers <b>Open in BambuForge</b>.</li>
<li><b>My library</b> (right column) keeps everything you downloaded, even offline: <b>Open</b>, delete, <b>Add files…</b> of your own, or <b>Show the folder</b> (Documents\\BambuForge\\Library).</li>
<li><b>+ Add a site</b> adds any other model website. Its <b>⋯</b> menu can rename it, move it, remove it, or <b>Teach it how to search</b> (you search for "benchy" on it once, so Search everywhere can include it).</li>
<li>Built-in sites can be hidden with <b>⋯ → Hide</b> and brought back with <b>Show hidden built-in sites</b>.</li></ul>`],
['engine', 'The built-in slicer', `
<h2>The built-in slicer</h2>
<p>BambuForge slices with Bambu Lab's own slicing engine, built right in (the <b>engine</b> folder). You don't need Bambu Studio installed. Print times, the prime tower and the files sent to your printer are exactly what Bambu Studio would make, because it's the same engine.</p>
<p>If Bambu Studio <i>is</i> installed, the extra <b>Send</b> step (open the project in Bambu Studio) appears too. Without it, that step is hidden.</p>`],
['p-outside', '"Outside the printable area" / parts overlap', `
<h2>"G-code outside the printable area", or parts overlapping</h2>
<p>A plate can't print if a part sticks out past its edge, two parts overlap, or there's no room for the <b>prime tower</b> (multi-colour prints need one).</p>
<ul><li>Studio checks this all the time. An orange note appears at the top of the 3D view, and <b>Ready to print?</b> lists it.</li>
<li>The fix: <b>Arrange plates</b> in step 1 (or the <b>Arrange plates</b> button in the Ready check). It packs the parts and leaves room for the tower.</li>
<li>You'll see the tower as a grey see-through box on each multi-colour plate, and in the preview on the Printers step.</li>
<li><b>Send to printer</b> won't send a plate with one of these problems; it tells you which.</li></ul>`],
['p-error', 'An error code is showing', `
<h2>An error code is showing</h2>
<p>Error codes (like <kbd>0300-1A00-0002-0001</kbd>) come from the printer. The message explains it in plain words; click <b>How to fix (Bambu wiki)</b> for Bambu's step-by-step fix with pictures.</p>`],
['p-log', 'Getting help (Copy log)', `
<h2>Getting help</h2>
<ol><li>Click <b>Copy log</b> (bottom right).</li>
<li>Paste it (<kbd>Ctrl</kbd>+<kbd>V</kbd>) into your message to whoever is helping you, with a sentence about what you were doing.</li></ol>
<p>The log lists what the program did, step by step. It doesn't contain your access codes or passwords.</p>`],
['sec', 'Words explained'],
['words', 'Glossary', `
<h2>Words explained</h2>
<ul>
<li><b>Plate</b>: the flat bed parts are printed on. Also one "load" of parts printed at once.</li>
<li><b>Filament</b>: the plastic string the printer melts. <b>PLA</b> is the easy everyday one; <b>PETG</b> is tougher; <b>ABS/ASA</b> need an enclosed printer.</li>
<li><b>AMS</b>: Bambu's box that holds 4 rolls of filament and switches colours automatically.</li>
<li><b>Slot</b>: one of the places in the AMS (1-4), and the matching colour number in your model.</li>
<li><b>Preset</b>: a saved set of print settings.</li>
<li><b>Layer height</b>: how thick each layer is. Thinner looks smoother but takes longer.</li>
<li><b>Walls</b>: the solid outer skin of a part. More walls = stronger.</li>
<li><b>Infill</b>: the honeycomb-like pattern inside. 15% means 15% plastic, 85% air.</li>
<li><b>Supports</b>: temporary plastic holding up overhangs; you snap it off after printing.</li>
<li><b>Brim</b>: a thin flat ring around the bottom that stops tall parts tipping or corners lifting.</li>
<li><b>Ironing</b>: running the hot nozzle over flat tops again to make them smooth.</li>
<li><b>Seam</b>: the small line where each layer starts and ends.</li>
<li><b>Developer Mode</b>: a printer setting that lets programs like this one control it on your home network.</li>
</ul>`],
];
const TOUR = [
  ['#steps', 'These are the <b>5 steps</b>. Go from left to right. You can skip steps you don\'t need.'],
  ['#openBtn', 'Start here: <b>Open file…</b> opens a model. You can also drag a file onto the window.'],
  ['.left', 'Your <b>parts</b> appear here: green "fits" means it fits your printer, red means it\'s too big. Filament needed per plate is at the bottom.'],
  ['.view', 'This is your model in <b>3D</b>. Left-drag to spin, right-drag to move, wheel to zoom. Click a part to select it.'],
  ['#colCard', '<b>Colours</b>: every colour your model uses, how much of each, and tools to paint the model. Click a colour square to change the filament.'],
  ['.undo', '<b>Undo</b> (Ctrl+Z), <b>redo</b> (Ctrl+Shift+Z) and <b>History</b>: nothing you do is permanent.'],
  ['#helpBtn', 'Stuck? <b>? Help</b> (or the F1 key) opens this guide anytime. The small <b>?</b> buttons jump to the right page.'],
  ['#copyLog', 'If something goes wrong, <b>Copy log</b> copies the details to paste to whoever is helping you.'],
];
let cur = 'welcome';
function toc(q) {
  const ql = (q || '').toLowerCase().trim();
  $('hToc').innerHTML = G.map(([id, title, body]) => {
    if (id === 'sec') return ql ? '' : `<div class="sec">${title}</div>`;
    if (ql && !(title + ' ' + body.replace(/<[^>]+>/g, ' ')).toLowerCase().includes(ql)) return '';
    return `<div data-id="${id}" class="${id === cur ? 'on' : ''}">${title}</div>`;
  }).join('') || '<div class="dim">Nothing found. Try other words.</div>';
  $('hToc').querySelectorAll('[data-id]').forEach(el => el.onclick = () => showPage(el.dataset.id));
}
function showPage(id) {
  const p = G.find(g => g[0] === id) || G[1]; cur = p[0];
  $('hBody').innerHTML = p[2]; $('hBody').scrollTop = 0; toc($('hSearch').value);
}
export function openHelp(id) { $('helpModal').classList.remove('hidden'); showPage(id || cur); }
function closeHelp() { $('helpModal').classList.add('hidden'); }
$('helpBtn').onclick = () => openHelp();
$('hClose').onclick = closeHelp;
$('hSearch').oninput = () => toc($('hSearch').value);
$('hTour').onclick = () => { closeHelp(); startTour(); };
document.querySelectorAll('button.qhelp[data-help]').forEach(b => b.onclick = e => { e.stopPropagation(); openHelp(b.dataset.help); });
window.addEventListener('keydown', e => {
  if (e.key === 'F1') { e.preventDefault(); openHelp(); }
  if (e.key === 'Escape' && !$('helpModal').classList.contains('hidden')) closeHelp();
});
// ---- the tour
let ti = 0;
export function startTour() { ti = 0; $('tour').classList.remove('hidden'); $('tourRing').classList.remove('hidden'); tourShow(); }
function tourEnd() { $('tour').classList.add('hidden'); $('tourRing').classList.add('hidden'); try { localStorage.setItem('bfs_tour_done', '1'); } catch (_) {} }
function tourShow() {
  const [sel, text] = TOUR[ti]; const el = document.querySelector(sel);
  const r = el ? el.getBoundingClientRect() : { left: innerWidth / 2 - 100, top: innerHeight / 2 - 40, width: 200, height: 80 };
  Object.assign($('tourRing').style, { left: r.left - 6 + 'px', top: r.top - 6 + 'px', width: r.width + 12 + 'px', height: r.height + 12 + 'px' });
  $('tourText').innerHTML = text; $('tourStep').textContent = `${ti + 1} of ${TOUR.length}`;
  $('tourNext').textContent = ti === TOUR.length - 1 ? 'Finish' : 'Next';
  const box = document.querySelector('.tourbox'), bw = 340, bh = 150;
  let x = r.left + r.width + 16, y = r.top;
  if (x + bw > innerWidth) x = Math.max(10, r.left - bw - 16);
  if (x < 10 || r.width > innerWidth * 0.5) { x = Math.min(innerWidth - bw - 10, Math.max(10, r.left + 20)); y = r.top + r.height + 14; }
  if (y + bh > innerHeight) y = Math.max(10, r.top - bh - 14);
  Object.assign(box.style, { left: x + 'px', top: y + 'px' });
}
$('tourNext').onclick = () => { if (++ti >= TOUR.length) tourEnd(); else tourShow(); };
$('tourSkip').onclick = tourEnd;
window.addEventListener('resize', () => { if (!$('tour').classList.contains('hidden')) tourShow(); });
export function firstRun() { let done = false; try { done = localStorage.getItem('bfs_tour_done') === '1'; } catch (_) {} if (!done) setTimeout(startTour, 800); }
toc('');
