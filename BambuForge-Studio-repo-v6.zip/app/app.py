"""BambuForge Studio - Phase 1: open, view in 3D, check the P1S fit, scale, export."""
import json, subprocess, os, sys, threading, time, traceback, shutil, platform
import numpy as np
import re, zipfile

DATA = os.path.join(os.environ.get('LOCALAPPDATA') or os.path.expanduser('~/.local/share'), 'BambuForgeStudio')
os.makedirs(DATA, exist_ok=True)
if sys.platform == 'win32':
    # pythonw has no console: send anything printed to a file instead of a pipe that may close
    _console = open(os.path.join(DATA, 'console.log'), 'w', encoding='utf-8', buffering=1)
    sys.stdout = sys.stderr = _console

import webview

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import engine, split, build, copy, subprocess, math, trimesh
import bambu, hollow, printers, text3d, models, fonts

APP_NAME = "BambuForge Studio"
VERSION = "2.0.0"
CACHE = os.path.join(HERE, 'ui', 'cache')     # served to the viewer
LOG = os.path.join(DATA, 'studio.log')


def log(level, msg):
    try:
        os.makedirs(DATA, exist_ok=True)
        with open(LOG, 'a', encoding='utf-8') as f:
            f.write(time.strftime('%Y-%m-%d %H:%M:%S') + f' {level:<5} ' + str(msg).replace('\n', '\n                          ') + '\n')
    except Exception:
        pass


PREFS = os.path.join(DATA, 'studio_settings.json')
AUTOSAVE = os.path.join(DATA, 'autosave.pkl')
LOCK = os.path.join(DATA, 'session.lock')
IPC = os.path.join(DATA, 'ipc')


def trimesh_volume(m):
    try:
        import trimesh
        return trimesh.Trimesh(m.vertices, m.faces).volume
    except Exception:
        return 0.0


def load_prefs():
    try:
        with open(PREFS, encoding='utf-8') as f: return json.load(f)
    except Exception:
        return {}


def save_prefs(p):
    try:
        with open(PREFS, 'w', encoding='utf-8') as f: json.dump(p, f, indent=2)
    except Exception:
        log('WARN', 'Could not save settings: ' + traceback.format_exc(limit=1))


def startup_report():
    """Everything useful for fixing 'it won't open', written to studio.log on every start."""
    lines = [f"Python {sys.version.split()[0]} ({platform.architecture()[0]}) on {platform.platform()}", f"Program folder: {HERE}"]
    for mod in ('numpy', 'trimesh', 'manifold3d', 'webview'):
        try:
            m = __import__(mod); lines.append(f"{mod} {getattr(m, '__version__', '?')}")
        except Exception as e:
            lines.append(f"{mod} FAILED: {e}")
    if sys.platform == 'win32':
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full') as k:
                lines.append(f".NET Framework release {winreg.QueryValueEx(k, 'Release')[0]} (needs 394802+)")
        except Exception as e:
            lines.append(f".NET Framework: not found ({e})")
        wv = '{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'
        found = []
        for hive, name, path in ((winreg.HKEY_LOCAL_MACHINE, 'HKLM', rf'SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{wv}'),
                                 (winreg.HKEY_LOCAL_MACHINE, 'HKLM', rf'SOFTWARE\Microsoft\EdgeUpdate\Clients\{wv}'),
                                 (winreg.HKEY_CURRENT_USER, 'HKCU', rf'SOFTWARE\Microsoft\EdgeUpdate\Clients\{wv}')):
            try:
                with winreg.OpenKey(hive, path) as k:
                    found.append(f"{name}: {winreg.QueryValueEx(k, 'pv')[0]}")
            except Exception:
                pass
        lines.append("WebView2 runtime: " + (", ".join(found) if found else "NOT FOUND"))
        try:
            import clr
            clr.AddReference('System.Windows.Forms')
            lines.append(".NET bridge (pythonnet): OK")
        except Exception as e:
            lines.append(f".NET bridge (pythonnet) FAILED: {e}")
    log('INFO', "\n".join(lines))


class Api:
    def __init__(self):
        self._project = None
        self._window = None
        self._gen = 0
        self._undo = []
        self._redo = []
        self._progress = None
        self._saved = None
        self._prefs = load_prefs()
        self._printer = None         # Bambu machine preset name, e.g. "Bambu Lab P1S 0.4 nozzle"
        self._filament = self._prefs.get('filament')
        self._plate = self._prefs.get('plate')
        self._exact = {}             # plate -> exact grams/seconds from Bambu, for the current parts

    # ---------- app preferences (look, simple/advanced, tray, filament prices)
    def ui_prefs(self):
        d = {'mode': 'advanced', 'theme': 'dark', 'textsize': 100, 'keep_tray': True, 'close_action': 'ask', 'prices': {}, 'panels': None}
        d.update(self._prefs.get('ui', {}))
        return d

    def _to_tray(self):
        self._window.hide()
        if not getattr(self, '_told_tray', False):
            self._told_tray = True
            notify('Still running', 'BambuForge Studio is in the tray (bottom right). Right-click the icon to open it or quit.')

    def close_choice(self, action, remember=False):
        """From the "close or keep running?" box."""
        if remember: self.set_ui_pref('close_action', 'tray' if action == 'tray' else 'quit')
        log('STEP', f"Window close: {'keep running in the tray' if action == 'tray' else 'close'}" + (' (remembered)' if remember else ''))
        if action == 'tray': self._to_tray(); return {'ok': True}
        self._quitting = True
        threading.Timer(0.1, lambda: self._window.destroy()).start()
        return {'ok': True}

    def set_ui_pref(self, key, value):
        ui = self._prefs.setdefault('ui', {}); ui[key] = value; save_prefs(self._prefs)
        return {'ok': True}

    # ---------- recent files
    def _add_recent(self, path):
        r = [p for p in self._prefs.get('recent', []) if os.path.normcase(p) != os.path.normcase(path)]
        self._prefs['recent'] = ([path] + r)[:10]; save_prefs(self._prefs)

    def recent_files(self):
        out = []
        for p in self._prefs.get('recent', []):
            try: out.append({'path': p, 'name': os.path.basename(p), 'when': time.strftime('%b %d %I:%M %p', time.localtime(os.path.getmtime(p))), 'exists': True})
            except OSError: out.append({'path': p, 'name': os.path.basename(p), 'when': 'file moved or deleted', 'exists': False})
        return out

    # ---------- auto-save and recovery
    def _autosave_loop(self):
        import pickle
        while True:
            time.sleep(60)
            try:
                if self._project is not None and getattr(self, '_dirty', False):
                    tmp = AUTOSAVE + '.tmp'
                    with open(tmp, 'wb') as f:
                        pickle.dump({'project': self._project, 'printer': self._printer, 'filament': self._filament, 'plate': self._plate,
                                     'when': time.time(), 'title': self._project.get('title'), 'parts': len(self._project['parts']),
                                     'changes': len(self._undo)}, f, protocol=pickle.HIGHEST_PROTOCOL)
                    os.replace(tmp, AUTOSAVE)
                    self._dirty = False
            except Exception:
                log('WARN', 'Auto-save failed: ' + traceback.format_exc(limit=1))

    def recovery_info(self):
        """If the last session didn't close normally and left work behind, describe it."""
        info = getattr(self, '_recovery', None)
        if not info: return None
        return {'title': info['title'], 'parts': info['parts'], 'changes': info['changes'], 'when': time.strftime('%I:%M %p, %b %d', time.localtime(info['when']))}

    def recover(self, yes):
        info = getattr(self, '_recovery', None); self._recovery = None
        if not yes or not info:
            try: os.remove(AUTOSAVE)
            except OSError: pass
            return {'ok': True}
        self._project = info['project']
        if info.get('printer'): self._set_printer(info['printer'])
        self._filament, self._plate = info.get('filament'), info.get('plate')
        self._undo, self._redo, self._exact = [], [], {}
        log('STEP', f"Recovered {info['title']} from auto-save")
        return self._describe(rebuild=True)

    def _mark(self, data):
        if not data: return data
        self._dirty = True
        return data

    # ---------- files
    def open_dialog(self):
        r = self._window.create_file_dialog(webview.FileDialog.OPEN, allow_multiple=False,
                                           file_types=('3D models (*.3mf;*.stl;*.obj)', 'All files (*.*)'))
        return r[0] if r else None

    def load(self, path):
        t = time.time()
        log('STEP', f'Open {path}')
        try:
            self._ensure_printer()
            t1 = time.time()
            self._project = engine.load(path)
            log('INFO', f'Read the file in {time.time() - t1:.1f}s (printer profiles {t1 - t:.1f}s)')
            self._undo = []; self._redo = []; self._saved = None; self._exact = {}
        except Exception as e:
            log('ERROR', traceback.format_exc())
            return {'error': f"Couldn't open that file: {e}"}
        log('INFO', f"Loaded {len(self._project['parts'])} parts in {time.time() - t:.1f}s")
        self._add_recent(path); self._dirty = True
        t2 = time.time(); d = self._describe(rebuild=True, took=time.time() - t)
        log('INFO', f'Prepared the 3D view in {time.time() - t2:.1f}s')
        return d

    def _filament_per_plate(self, plates):
        """Filament per plate: a quick estimate now, Bambu's exact figure once the print time has been worked out."""
        P = self._project
        dens = 1.24
        try:
            if self._filament: dens = self._prof().plate_temps(self._filament)['density']
        except Exception: pass
        grams = {}
        for p in P['parts']:
            m = p.mesh
            vol = float(abs(m.volume)) if m.is_volume else float(abs(trimesh_volume(m)))
            shell = min(vol, float(m.area) * 1.3)                              # about 3 walls / solid skins
            g = (shell + max(0.0, vol - shell) * 0.15) * dens / 1000 * 1.04   # 15% infill, plus brim and supports
            grams[p.plate] = grams.get(p.plate, 0.0) + g
        out = []
        for pl in plates:
            pid = pl['id'] if isinstance(pl, dict) else pl
            ex = self._exact.get(pid)
            out.append({'plate': pid, 'grams': round(ex['grams'] if ex else grams.get(pid, 0.0)), 'exact': bool(ex), 'time': ex['time'] if ex else None})
        return out

    def _slot_usage(self):
        """Grams of each filament slot: Bambu's exact numbers after Update print time, otherwise an estimate
        (the inside of a part goes to its own filament, the outside is shared by the painted colours by area)."""
        P = self._project
        if self._exact and all(e.get('by_slot') is not None for e in self._exact.values()):
            tot = {}
            for e in self._exact.values():
                for k, v in e['by_slot'].items(): tot[int(k)] = tot.get(int(k), 0.0) + v
            return {k: round(v, 1) for k, v in tot.items()}, True
        dens = 1.24
        try:
            if self._filament: dens = self._prof().plate_temps(self._filament)['density']
        except Exception: pass
        tot = {}
        for p in P['parts']:
            m = p.mesh
            vol = float(abs(m.volume)) if m.is_volume else float(abs(trimesh_volume(m)))
            shell = min(vol, float(m.area) * 1.3)
            inner = max(0.0, vol - shell) * 0.15
            fe = p.exts(); areas = m.area_faces
            a_tot = float(areas.sum()) or 1.0
            for k in np.unique(fe):
                share = float(areas[fe == k].sum()) / a_tot
                tot[int(k)] = tot.get(int(k), 0.0) + shell * share * dens / 1000 * 1.04
            tot[p.ext] = tot.get(p.ext, 0.0) + inner * dens / 1000 * 1.04
        return {k: round(v, 1) for k, v in tot.items()}, False

    def _slots_info(self):
        P = self._project
        use, exact = self._slot_usage()
        used = sorted({s for p in P['parts'] for s in p.slots_used()})
        out = []
        for i, f in enumerate(P.get('filaments') or [], start=1):
            name = (f.get('preset') or self._filament or 'Generic PLA').split(' @')[0]
            out.append({'slot': i, 'color': f.get('color', '#9AA0A6'), 'preset': f.get('preset'), 'name': name, 'type': f.get('type', 'PLA'),
                        'colors': f.get('colors') or [f.get('color', '#9AA0A6')], 'ctype': f.get('ctype', 'single'),
                        'effect': f.get('effect') or engine.effect_of(f.get('preset')), 'used': i in used, 'grams': use.get(i, 0.0)})
        return {'slots': out, 'exact': exact}

    def totals(self):
        if not self._project: return {'filament_per_plate': [], 'filament_total': 0, 'filament_exact': False}
        fil = self._filament_per_plate(sorted(self._project['plates']))
        return {'filament_per_plate': fil, 'filament_total': round(sum(f['grams'] for f in fil)), 'filament_exact': all(f['exact'] for f in fil) and bool(fil),
                'filaments': self._slots_info()}

    def _part_key(self, p):
        """A fingerprint of everything that changes how a part looks (shape, position, colours)."""
        import zlib
        m = p.mesh
        k = zlib.crc32(np.ascontiguousarray(m.vertices, np.float64).tobytes())
        k = zlib.crc32(np.ascontiguousarray(m.faces, np.int64).tobytes(), k)
        fe = p.face_ext
        if fe is not None: k = zlib.crc32(np.ascontiguousarray(fe).tobytes(), k)
        return (k, int(p.ext or 0), str(p.color))

    def _describe(self, rebuild=False, took=None):
        """What the screen needs. A part's 3D view file is only re-written when the part really changed, so after
        small changes (moving one part, text on one part) only that part is re-sent."""
        P = self._project
        if rebuild: self._gen += 1
        os.makedirs(CACHE, exist_ok=True)
        cache = getattr(self, '_bincache', None)
        if cache is None or getattr(self, '_bincache_for', None) is not P:
            cache = self._bincache = {}; self._bincache_for = P
        parts, used = [], set()
        nplates = max(P['plates'].keys())
        for i, p in enumerate(P['parts']):
            d = p.info(i)
            key = self._part_key(p)
            c = cache.get(id(p))
            if c and c['key'] == key and os.path.exists(os.path.join(CACHE, c['fn'])):
                fn, shown, oh = c['fn'], c['shown'], c['oh']
            else:
                self._binseq = getattr(self, '_binseq', 0) + 1
                fn = f"g{self._gen}_p{i}_{self._binseq}.bin"
                shown = engine.write_display(p, os.path.join(CACHE, fn))
                oh = round(build.overhang_area(p) / 100, 1)
                cache[id(p)] = {'key': key, 'fn': fn, 'shown': shown, 'oh': oh}
            used.add(fn)
            d['shown_tris'] = shown
            M = p.display_to_assembled()
            d['asm'] = None if M is None else [float(x) for x in M.T.flatten()]   # column-major for three.js
            d['file'] = 'cache/' + fn
            d['groups'] = getattr(p, '_groups', None)
            d['rot'] = build.euler_of(p)
            d['overhang'] = oh
            parts.append(d)
        # forget parts that are gone; delete old view files a little later (the screen may still be loading one)
        alive = {id(p) for p in P['parts']}
        for k in [k for k in cache if k not in alive]: cache.pop(k, None)
        now = time.time()
        for f in os.listdir(CACHE):
            if f.endswith('.bin') and f not in used:
                fp = os.path.join(CACHE, f)
                try:
                    if now - os.path.getmtime(fp) > 20: os.remove(fp)
                except OSError: pass
        lo = [min(p['min'][k] for p in parts) for k in range(3)]
        tallest = max(parts, key=lambda d: d['size'][2])
        plates = [{'id': k, 'name': v, 'offset': engine.plate_offset(k, nplates)} for k, v in sorted(P['plates'].items())]
        try:
            chk = build.plate_check(P, self._layer_h())
            for pl in plates:
                pl.update(chk.get(pl['id'], {}))
                st = (getattr(self, '_sliced_tower', None) or {}).get(pl['id'])
                if st: pl['sliced'] = st
        except Exception:
            log('WARN', 'Plate check failed: ' + traceback.format_exc(limit=1))
        asm = engine.assembled_size(P['parts'])
        fil = self._filament_per_plate(plates)
        sp = None
        try:
            if self._printer: sp = self._prof().spec(self._printer)
        except Exception: pass
        return {'gen': self._gen, 'title': P['title'], 'path': P['path'], 'bambu': P['bambu'], 'parts': parts, 'plates': plates, 'assembled': asm, 'tower_cfg': P.get('tower_cfg') or {},
                'printer': self._printer, 'printer_spec': sp, 'filament': self._filament, 'plate_type': self._plate,
                'filaments': self._slots_info(),
                'filament_per_plate': fil, 'filament_total': round(sum(f['grams'] for f in fil)), 'filament_exact': all(f['exact'] for f in fil) and bool(fil),
                'bed': list(engine.BED), 'max_h': engine.MAX_H, 'excl': list(build.EXCL), 'tallest': tallest['size'][2], 'tallest_name': tallest['name'],
                'took': round(took, 1) if took else None, 'scale': round(P['parts'][0].scale, 6)}

    def scale(self, factor):
        if not self._project: return {'error': 'Open a file first.'}
        factor = float(factor)
        if not (0.01 <= factor <= 100): return {'error': 'That size is out of range.'}
        self._push_undo('Resize')
        engine.scale_parts(self._project['parts'], factor)
        for p in self._project['parts']:          # text already added stays, but is now part of the model (it was resized with it)
            p.texts, p.text_base = [], None
        log('STEP', f'Scaled by {factor:.6f} (total {self._project["parts"][0].scale:.6f})')
        return self._describe(rebuild=True)

    def reset(self):
        if not self._project: return None
        return self.load(self._project['path'])

    def export_dialog(self, kind):
        if not self._project: return {'error': 'Open a file first.'}
        base = self._project['title'] + (f" ({self._project['parts'][0].scale * 100:.1f}%)" if abs(self._project['parts'][0].scale - 1) > 1e-9 else '')
        r = self._window.create_file_dialog(webview.FileDialog.SAVE, save_filename=base + ('.stl' if kind == 'stl' else '.3mf'),
                                           file_types=(('STL (*.stl)',) if kind == 'stl' else ('3MF (*.3mf)',)))
        if not r: return None
        path = r if isinstance(r, str) else r[0]
        try:
            engine.export(self._project['parts'], path, max(self._project['plates'].keys()))
            log('STEP', f'Exported {path}')
            return {'saved': path}
        except Exception as e:
            log('ERROR', traceback.format_exc())
            return {'error': f"Couldn't save: {e}"}

    # ---------- step 2: split and joints
    def joint_types(self):
        return {'joints': split.JOINTS, 'magnets': list(split.MAGNETS)}

    def progress(self):
        return getattr(self, '_progress', None)

    def _set_progress(self, text, frac=None):
        self._progress = {'text': text, 'frac': frac}

    def plan_cuts(self, idx, kind='dpeg'):
        if not self._project: return {'error': 'Open a file first.'}
        p = self._project['parts'][int(idx)]
        try:
            self._set_progress('Measuring the part to find the best places to cut…', 0)
            cuts = split.plan_cuts(p.mesh, max_h=engine.MAX_H - 5.0 - split.EXTRA_H.get(kind, 0.0), progress=lambda f: self._set_progress('Measuring the part to find the best places to cut…', f))
            log('STEP', f'Planned cuts for {p.name}: {[round(c, 1) for c in cuts]}')
            return {'cuts': [round(float(c), 1) for c in cuts], 'height': round(float(p.mesh.extents[2]), 1), 'zmin': round(float(p.mesh.bounds[0][2]), 2)}
        except split.NotSolid as e:
            return {'error': str(e)}
        except Exception as e:
            log('ERROR', traceback.format_exc()); return {'error': f'Planning failed: {e}'}
        finally:
            self._progress = None

    def apply_split(self, idx, cuts, kinds, clr, magnet):
        if not self._project: return {'error': 'Open a file first.'}
        idx = int(idx)
        p = self._project['parts'][idx]
        cuts = sorted(float(c) for c in cuts)
        h = p.mesh.extents[2]
        edges = [0.0] + cuts + [h]
        kinds = list(kinds)
        def extra_of(k):
            if isinstance(k, list):
                return max([float(s['dep']) for s in k if s.get('kind') in ('twist', 'thread')] + [0.0])
            return split.EXTRA_H.get(k, 0.0)
        def name_of(k):
            return 'spigot' if isinstance(k, list) else split.JOINTS[k].split(" (")[0].lower()
        for i, (a0, b0) in enumerate(zip(edges, edges[1:])):
            extra = extra_of(kinds[i]) if i < len(cuts) else 0.0
            if b0 - a0 + extra > engine.MAX_H:
                why = f' including the {name_of(kinds[i])} on top ({extra:.0f} mm)' if extra else ''
                return {'error': f'Piece {i + 1} would be {b0 - a0 + extra:.0f} mm tall{why}; the P1S takes {engine.MAX_H:.0f} mm. Move cut {i + 1} down or add a cut.'}
        if any(b - a < 15 for a, b in zip(edges, edges[1:])):
            return {'error': 'Two cuts are too close together (pieces must be at least 15 mm tall).'}
        # hand-placed joints are checked again here; nothing red gets cut
        if any(isinstance(k, list) for k in kinds):
            solid, S = self._part_solid(idx)
            zs = [0.0 + S.z0] + cuts + [S.z1]
            for ci, k in enumerate(kinds):
                if isinstance(k, list) and k:
                    pr = split.check_specs(solid, cuts[ci], k, float(getattr(self, '_wall', 3.0)), zs[ci], zs[ci + 2])
                    reds = [q['text'] for qq in pr for q in qq if q['lvl'] == 'red']
                    if reds: return {'error': f'Cut {ci + 1}: ' + reds[0]}
        self._push_undo('Make pieces')
        try:
            self._set_progress('Cutting the part and making the joints…', 0)
            notes = build.apply_split(self._project, idx, cuts, kinds, float(clr), str(magnet),
                                      progress=lambda f: self._set_progress('Cutting the part and making the joints…', f))
            log('STEP', f'Split {p.name} at {cuts} with ' + str([k if isinstance(k, str) else f'{len(k)} hand-placed' for k in kinds]) + f', clearance {clr}, magnets {magnet}\n' + '\n'.join(f"cut at {n['z']}: {n['kind']} - {n['note']}" for n in notes))
            d = self._describe(rebuild=True); d['notes'] = notes
            return d
        except split.NotSolid as e:
            self._drop_undo(); return {'error': str(e)}
        except Exception as e:
            self._drop_undo(); log('ERROR', traceback.format_exc()); return {'error': f'Splitting failed: {e}'}
        finally:
            self._progress = None

    # ---------- step 2: the joint editor
    def _part_solid(self, idx):
        key = (self._gen, int(idx))
        if getattr(self, '_solid_key', None) != key:
            p = self._project['parts'][int(idx)]
            self._solid = split.to_mf(p.mesh)
            self._sections = split.Sections(self._solid, step=0.75)
            self._solid_key = key
        return self._solid, self._sections

    def cut_editor(self, idx, cuts, i, kind=None, magnet=None):
        """Everything the editor needs for cut i: the two pieces next to the cut, the cut outline, and starting joints."""
        if not self._project: return {'error': 'Open a file first.'}
        try:
            solid, S = self._part_solid(idx)
            cuts = sorted(float(c) for c in cuts); i = int(i); z = cuts[i]
            z0, z1 = S.z0, S.z1
            z_lo = cuts[i - 1] if i > 0 else z0
            z_hi = cuts[i + 1] if i + 1 < len(cuts) else z1
            h_lo, h_hi = min(130.0, z - z_lo), min(130.0, z_hi - z)
            lo = solid.trim_by_plane((0, 0, 1), z - h_lo).trim_by_plane((0, 0, -1), -z)
            hi = solid.trim_by_plane((0, 0, 1), z).trim_by_plane((0, 0, -1), -(z + h_hi))
            self._gen_ed = getattr(self, '_gen_ed', 0) + 1
            files = []
            for name, M in (('lo', lo), ('hi', hi)):
                fn = f'ed{self._gen_ed}_{name}.bin'
                part = engine.Part('x', split.to_tm(M), np.eye(4))
                engine.write_display(part, os.path.join(CACHE, fn), max_tris=400000)
                files.append('cache/' + fn)
            polys = [np.asarray(p).round(3).tolist() for p in S.at(z).to_polygons()]
            specs = split.auto_specs(S, z, kind, 0.2, tuple(magnet) if magnet else (8.0, 3.0)) if kind in split.EDITABLE else None
            return {'z': z, 'z_lo': z_lo, 'z_hi': z_hi, 'h_lo': h_lo, 'h_hi': h_hi, 'files': files, 'outline': polys, 'specs': specs}
        except split.NotSolid as e:
            return {'error': str(e)}
        except Exception as e:
            log('ERROR', traceback.format_exc()); return {'error': f"Couldn't open the joint editor: {e}"}

    def auto_joints(self, idx, z, kind, magnet=None):
        solid, S = self._part_solid(idx)
        return split.auto_specs(S, float(z), kind, 0.2, tuple(magnet) if magnet else (8.0, 3.0)) if kind in split.EDITABLE else []

    def check_joints(self, idx, z, z_lo, z_hi, specs, wall):
        try:
            solid, S = self._part_solid(idx)
            self._wall = float(wall)
            return {'problems': split.check_specs(solid, float(z), specs, float(wall), float(z_lo), float(z_hi))}
        except Exception as e:
            log('ERROR', traceback.format_exc()); return {'error': str(e)}

    # ---------- undo / redo (every change to the model, the plates and the printer)
    def _snapshot(self, label):
        return {'label': label, 'project': copy.deepcopy(self._project), 'printer': self._printer}

    def _push_undo(self, label):
        self._dirty = True; self._sliced_tower = {}
        if self._project is None and label.startswith('Printer') is False: return
        self._undo.append(self._snapshot(label)); self._redo = []
        if len(self._undo) > 60: self._undo.pop(0)          # keep memory in check on big models

    def _drop_undo(self):
        """An action failed: restore what was there and forget that undo step."""
        snap = self._undo.pop(); self._project = snap['project']

    def _restore(self, snap):
        self._project = snap['project']
        if snap['printer'] and snap['printer'] != self._printer: self._set_printer(snap['printer'])
        self._exact = {}

    def undo(self, steps=1):
        if not self._undo: return {'error': 'Nothing to undo.'}
        for _ in range(max(1, int(steps))):
            if not self._undo: break
            snap = self._undo.pop()
            self._redo.append(self._snapshot(snap['label']))
            self._restore(snap)
            log('STEP', f"Undo: {snap['label']}")
        return self._describe(rebuild=True) if self._project else {'ok': True}

    def redo(self):
        if not self._redo: return {'error': 'Nothing to redo.'}
        snap = self._redo.pop()
        self._undo.append(self._snapshot(snap['label']))
        self._restore(snap)
        log('STEP', f"Redo: {snap['label']}")
        return self._describe(rebuild=True) if self._project else {'ok': True}

    def history(self):
        return {'undo': [u['label'] for u in self._undo][::-1], 'redo': [r['label'] for r in self._redo][::-1]}

    def arrange(self):
        if not self._project: return {'error': 'Open a file first.'}
        self._push_undo('Arrange plates')
        build.layout(self._project)
        log('STEP', f"Arranged {len(self._project['parts'])} parts on {len(self._project['plates'])} plates")
        return self._describe(rebuild=True)

    # ---------- steps 5 and 6: hand over to BambuForge / Bambu Studio
    def save_project_dialog(self):
        if not self._project: return {'error': 'Open a file first.'}
        bad = [p.name for p in self._project['parts'] if not p.info(0)['fits']]
        if bad: return {'error': 'These parts are still too big for the P1S: ' + ', '.join(bad) + '. Split them first (step 2).'}
        r = self._window.create_file_dialog(webview.FileDialog.SAVE, save_filename=self._project['title'] + ' (BambuForge Studio).3mf', file_types=('Bambu project (*.3mf)',))
        if not r: return None
        path = r if isinstance(r, str) else r[0]
        if not path.lower().endswith('.3mf'): path += '.3mf'
        try:
            build.write_bambu_project(self._project, path)
            self._saved = path
            log('STEP', f'Saved Bambu project {path}')
            return {'saved': path}
        except Exception as e:
            log('ERROR', traceback.format_exc()); return {'error': f"Couldn't save: {e}"}

    def tools(self):
        """Where BambuForge and Bambu Studio are installed (None if not found)."""
        la = os.environ.get('LOCALAPPDATA', '')
        bf = os.path.join(la, 'BambuForge', 'BambuForge.exe')
        bs = None
        for c in (os.path.join(os.environ.get('ProgramFiles', r'C:\Program Files'), 'Bambu Studio', 'bambu-studio.exe'),):
            if os.path.exists(c): bs = c
        if bs is None and sys.platform == 'win32':
            try:
                import winreg
                for root in (r'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall', r'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'):
                    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, root) as k:
                        for i in range(winreg.QueryInfoKey(k)[0]):
                            try:
                                with winreg.OpenKey(k, winreg.EnumKey(k, i)) as s:
                                    if 'Bambu Studio' in str(winreg.QueryValueEx(s, 'DisplayName')[0]):
                                        loc = winreg.QueryValueEx(s, 'InstallLocation')[0].strip('"')
                                        if os.path.exists(os.path.join(loc, 'bambu-studio.exe')): bs = os.path.join(loc, 'bambu-studio.exe')
                            except OSError:
                                pass
            except OSError:
                pass
        return {'bambuforge': bf if os.path.exists(bf) else None, 'bambu': bs, 'saved': getattr(self, '_saved', None)}

    def open_with(self, which):
        t = self.tools()
        path = t.get('saved')
        if not path or not os.path.exists(path): return {'error': 'Save the Bambu project first (button above).'}
        exe = t.get(which)
        if not exe: return {'error': ('BambuForge' if which == 'bambuforge' else 'Bambu Studio') + " isn't installed on this PC."}
        subprocess.Popen([exe, path], cwd=os.path.dirname(exe))
        log('STEP', f'Opened {path} in {exe}')
        return {'ok': True}

    # ---------- colours: filament slots and painting
    def filament_catalog(self):
        prof = self._prof(); pr = self._ensure_printer()
        return {'catalog': prof.catalog(pr), 'colors': prof.color_codes()}

    def slot_temps(self):
        """Bed/nozzle temperatures of each filament in use, so the plate choice can be checked against all of them."""
        prof = self._prof(); pr = self._ensure_printer()
        out = []
        fl = (self._project or {}).get('filaments') or [{'preset': None, 'color': '#00AE42'}]
        used = sorted({s for p in self._project['parts'] for s in p.slots_used()}) if self._project else [1]
        for i in used:
            f = fl[i - 1] if i - 1 < len(fl) else {'preset': None}
            name = prof.match_filament(f.get('preset'), pr) or self._filament
            if not name: continue
            t = prof.plate_temps(name)
            out.append({'slot': i, 'preset': name, 'name': name.split(' @')[0], 'color': f.get('color'), **t})
        return {'slots': out}

    def set_slot(self, slot, preset=None, color=None, ftype=None, colors=None, ctype=None, effect=None):
        if not self._project: return {'error': 'Open a file first.'}
        slot = int(slot)
        if not (1 <= slot <= 16): return {'error': 'Filament slots go from 1 to 16.'}
        self._push_undo(f'Filament slot {slot}')
        fl = self._project.setdefault('filaments', [])
        while len(fl) < slot: fl.append({'color': '#9AA0A6', 'preset': None, 'type': 'PLA'})
        if preset: fl[slot - 1]['preset'] = preset
        if ftype: fl[slot - 1]['type'] = ftype
        if color: fl[slot - 1]['color'] = str(color)[:7].upper()
        cs = [str(x).upper() for x in (colors or []) if str(x).startswith('#')][:8]
        fl[slot - 1]['colors'] = cs or [fl[slot - 1]['color']]
        fl[slot - 1]['ctype'] = ctype if (ctype in ('gradient', 'multi') and len(cs) > 1) else 'single'
        fl[slot - 1]['effect'] = effect if effect in engine.EFFECTS else engine.effect_of(fl[slot - 1].get('preset'))
        self._exact = {}
        for p in self._project['parts']:
            if p.ext <= len(fl): p.color = fl[p.ext - 1]['color']
        log('STEP', f"Filament slot {slot}: {fl[slot - 1]}")
        return {'filaments': self._slots_info()}

    def _adjacency(self, p):
        key = (self._gen, id(p), len(p.mesh.faces))
        cache = getattr(self, '_adj', {})
        if key not in cache:
            t = trimesh.Trimesh(p.mesh.vertices, p.mesh.faces, process=True)
            adj = t.face_adjacency
            ang = t.face_adjacency_angles if len(adj) else np.zeros(0)
            nbr = [[] for _ in range(len(t.faces))]
            for (a, b), g in zip(adj.tolist(), np.degrees(ang).tolist()):
                nbr[a].append((b, g)); nbr[b].append((a, g))
            cache = {key: (nbr, t.triangles_center)}
            self._adj = cache
        return cache[key]

    def paint(self, idx, point, mode, slot, angle=30.0):
        """Paint part idx with filament `slot`: the whole part, the touching area of the same colour, or the
        area up to the nearest sharp edges (like Bambu's smart fill). point is where you clicked (plate mm)."""
        if not self._project: return {'error': 'Open a file first.'}
        p = self._project['parts'][int(idx)]
        slot = int(slot)
        fl = self._project.get('filaments') or []
        if not (1 <= slot <= max(1, len(fl))): return {'error': 'Pick a filament slot first.'}
        self._push_undo({'part': 'Colour the whole part', 'same': 'Fill same colour', 'edges': 'Fill up to edges'}.get(mode, 'Paint'))
        fe = p.exts().copy()
        if mode == 'part':
            p.ext = slot; fe[:] = slot
        else:
            nbr, centers = self._adjacency(p)
            q = np.asarray(point, float)
            start = int(np.argmin(((centers - q) ** 2).sum(1)))
            keep = fe[start]
            seen = np.zeros(len(fe), bool); seen[start] = True
            stack = [start]
            while stack:
                f = stack.pop()
                for g, a in nbr[f]:
                    if seen[g]: continue
                    if mode == 'same' and fe[g] != keep: continue
                    if mode == 'edges' and a > float(angle): continue
                    seen[g] = True; stack.append(g)
            fe[seen] = slot
            log('STEP', f'Painted {int(seen.sum())} triangles of {p.name} with slot {slot} ({mode})')
        p.set_face_ext(fe)
        if p.ext <= len(fl): p.color = fl[p.ext - 1]['color']
        self._exact = {}
        return self._describe(rebuild=True)

    # ---------- step 1: turning, lifting, laying flat, dropping, text
    def _replace_mesh(self, p, tm, fe):
        p.A = p.A @ np.linalg.inv(p.P) if p.A is not None else None
        p.local = tm; p.P = np.eye(4); p.mesh = tm.copy(); p.set_face_ext(fe)

    def rotate_part(self, idx, axis, deg):
        if not self._project: return {'error': 'Open a file first.'}
        p = self._project['parts'][int(idx)]
        self._push_undo(f'Turn {p.name} {float(deg):g}° ({axis.upper()})')
        build.rotate_part(p, axis, float(deg))
        self._exact = {}
        return self._describe(rebuild=True)

    def rotate_free(self, idx, R3):
        """From the rotation rings: any rotation, about the part's centre."""
        p = self._project['parts'][int(idx)]
        R = np.asarray(R3, float).reshape(3, 3)
        u, _, vt = np.linalg.svd(R); R = u @ vt                  # keep it a clean rotation
        self._push_undo(f'Turn {p.name} (freeform)')
        build.rotate_matrix(p, R)
        self._exact = {}
        return self._describe(rebuild=True)

    def rotate_xyz(self, idx, x, y, z, absolute=False):
        p = self._project['parts'][int(idx)]
        x, y, z = float(x or 0), float(y or 0), float(z or 0)
        self._push_undo(f"Turn {p.name} {'to' if absolute else 'by'} X{x:g} Y{y:g} Z{z:g}")
        if absolute: build.set_absolute(p, x, y, z)
        else: build.rotate_matrix(p, build.euler_R(x, y, z))
        self._exact = {}
        return self._describe(rebuild=True)

    def rotate_euler(self, idx, rx, ry, rz, absolute=False):
        """Turn by X, Y, Z degrees (relative), or to an exact X, Y, Z turn (absolute)."""
        if not self._project: return {'error': 'Open a file first.'}
        p = self._project['parts'][int(idx)]
        self._push_undo(f"{'Set turn of' if absolute else 'Turn'} {p.name}")
        if absolute: build.set_rotation(p, rx, ry, rz)
        else: build.turn_by_matrix(p, build._euler_matrix(rx, ry, rz))
        self._exact = {}
        return self._describe(rebuild=True)

    def move_to(self, idx, x=None, y=None, z=None):
        """Put a part's centre at plate position x, y (mm from the plate's front-left corner) and its bottom at height z."""
        p = self._project['parts'][int(idx)]
        lo, hi = p.mesh.bounds
        dx = (float(x) - (lo[0] + hi[0]) / 2) if x not in (None, '') else 0.0
        dy = (float(y) - (lo[1] + hi[1]) / 2) if y not in (None, '') else 0.0
        dz = (max(0.0, float(z)) - lo[2]) if z not in (None, '') else 0.0
        self._push_undo(f'Move {p.name}')
        build.move_part(p, dx, dy, None, dz)
        return self._describe(rebuild=True)

    def duplicate(self, idx, n=1):
        if not self._project: return {'error': 'Open a file first.'}
        n = max(1, min(50, int(n)))
        src = self._project['parts'][int(idx)]
        self._push_undo(f'{n} cop{"y" if n == 1 else "ies"} of {src.name}')
        made = build.duplicate(self._project, int(idx), n)
        # put the copies where there is room (new plates if needed), leaving everything else where it is
        keep = [q for q in self._project['parts'] if q not in made]
        build.place_new(self._project, made, keep)
        log('STEP', f'Made {n} copies of {src.name}')
        return self._describe(rebuild=True)

    def add_plate(self):
        """A new, empty plate (move parts onto it, or add a model to it)."""
        if not self._project: return {'error': 'Open a file first.'}
        self._push_undo('Add a plate')
        k = max(self._project['plates']) + 1; self._project['plates'][k] = f'Plate {k}'
        log('STEP', f'Added empty plate {k}')
        return self._describe(rebuild=False)

    def remove_plate(self, plate):
        if not self._project: return {'error': 'Open a file first.'}
        plate = int(plate)
        if any(q.plate == plate for q in self._project['parts']): return {'error': 'That plate still has parts on it. Move them off first.'}
        if len(self._project['plates']) <= 1: return {'error': 'A project needs at least one plate.'}
        self._push_undo('Remove a plate')
        # close the gap so plates stay numbered 1, 2, 3...
        keys = sorted(k for k in self._project['plates'] if k != plate)
        remap = {old: i + 1 for i, old in enumerate(keys)}
        self._project['plates'] = {remap[k]: (v if not v.startswith('Plate ') else f'Plate {remap[k]}') for k, v in self._project['plates'].items() if k != plate}
        for q in self._project['parts']: q.plate = remap.get(q.plate, q.plate)
        log('STEP', f'Removed empty plate {plate}')
        return self._describe(rebuild=False)

    def delete_part(self, idx):
        p = self._project['parts'][int(idx)]
        if len(self._project['parts']) == 1: return {'error': "That's the only part. Open another file instead."}
        self._push_undo(f'Delete {p.name}')
        self._project['parts'].pop(int(idx))
        return self._describe(rebuild=True)

    def align_parts(self, how, plate):
        ps = [p for p in self._project['parts'] if p.plate == int(plate)]
        self._push_undo({'left': 'Align left', 'centre': 'Centre', 'space': 'Space evenly'}.get(how, 'Align'))
        try:
            build.align(ps, how)
        except ValueError as e:
            self._drop_undo(); return {'error': str(e)}
        return self._describe(rebuild=True)

    def mask_to_project(self, name, verts, faces):
        """A mask made in the Masks step (mm, already in print position) goes to Model and plates: added to the open
        project, or as a new project if nothing is open. Also kept as an STL in Documents\\BambuForge\\Masks."""
        try:
            V = np.asarray(verts, float).reshape(-1, 3); F = np.asarray(faces, int).reshape(-1, 3)
            tm = trimesh.Trimesh(V, F, process=True)
            trimesh.repair.fix_normals(tm)
            if tm.volume < 0: tm.invert()
            safe = re.sub(r'[^A-Za-z0-9_. -]+', '_', name or 'Mask').strip() or 'Mask'
            try: folder = os.path.join(os.path.dirname(models.library_dir()), 'Masks')
            except Exception: folder = os.path.join(DATA, 'masks')
            os.makedirs(folder, exist_ok=True)
            path = os.path.join(folder, models.unique_name(folder, safe + '.stl'))
            tm.export(path)
            log('STEP', f'Mask "{safe}": {len(F)} triangles, {tm.volume / 1000:.1f} cm³, watertight {tm.is_watertight}, saved to {path}')
            return self.add_model(path) if self._project else self.load(path)
        except Exception as e:
            log('ERROR', traceback.format_exc()); return {'error': f"Couldn't make the mask: {e}"}

    def add_model_dialog(self):
        if not self._project: return {'error': 'Open a file first.'}
        r = self._window.create_file_dialog(webview.FileDialog.OPEN, allow_multiple=False,
                                            file_types=('3D models (*.3mf;*.stl;*.obj)', 'All files (*.*)'))
        if not r: return None
        return self.add_model(r[0] if isinstance(r, (list, tuple)) else r)

    def add_model(self, path):
        try:
            Q = engine.load(path)
        except Exception as e:
            log('ERROR', traceback.format_exc()); return {'error': f"Couldn't open {os.path.basename(path)}: {e}"}
        self._push_undo(f'Add {os.path.basename(path)}')
        P = self._project
        # its colours join this project's colour list
        base = len(P.get('filaments') or [])
        P.setdefault('filaments', []).extend(Q.get('filaments') or [])
        for q in Q['parts']:
            q.ext += base
            if q.face_ext is not None: q.face_ext = (q.face_ext.astype(np.int32) + base).astype(np.uint8)
            q.A = None
        P['parts'].extend(Q['parts'])
        build.place_new(P, Q['parts'], [p for p in P['parts'] if p not in Q['parts']])
        self._add_recent(path)
        log('STEP', f'Added {path} ({len(Q["parts"])} parts)')
        return self._describe(rebuild=True)

    # ---------- text tool: real fonts, several texts per part, each editable later
    def fonts_list(self, rescan=False):
        try:
            if rescan: fonts.index(rescan=True)
            return {'families': fonts.families(), 'free': fonts.free_list()}
        except Exception as e:
            log('ERROR', traceback.format_exc()); return {'error': f"Couldn't read the fonts: {e}", 'families': [], 'free': []}

    def font_download(self, name):
        try:
            self._set_progress(f'Downloading {name}…'); fonts.download(name); log('STEP', f'Downloaded font {name}')
            return self.fonts_list()
        except Exception as e:
            return {'error': f"Couldn't download {name}: {e}"}
        finally: self._progress = None

    def font_add_dialog(self):
        r = self._window.create_file_dialog(webview.FileDialog.OPEN, allow_multiple=False, file_types=('Fonts (*.ttf;*.otf)', 'All files (*.*)'))
        if not r: return None
        try:
            fam = fonts.add_file(r[0] if isinstance(r, (list, tuple)) else r); log('STEP', f'Added font {fam}')
            d = self.fonts_list(); d['added'] = fam; return d
        except Exception as e:
            return {'error': f"That font file couldn't be read: {e}"}

    def text_layout(self, p):
        """Letter outlines (mm) for the live preview."""
        try:
            return fonts.layout(p.get('text', ''), p.get('font', 'Arial'), float(p.get('size', 10)), p.get('bold'), p.get('italic'), p.get('under'), float(p.get('spacing', 0)))
        except Exception as e:
            log('ERROR', traceback.format_exc()); return {'error': str(e)}

    def _text_surface(self, p):
        base = p.text_base[0] if getattr(p, 'text_base', None) else p.local
        key = id(base)
        c = getattr(self, '_tsurf', None)
        if not c or c[0] != key: self._tsurf = (key, text3d.Surface(base), base)
        return self._tsurf[1], self._tsurf[2]

    def _text_base_mf(self, p):
        """The part without any text, converted once and kept while you work on its text."""
        base, bex = p.text_base if getattr(p, 'text_base', None) else (p.local, p.exts())
        c = getattr(self, '_tbmf', None)
        if not c or c[0] != id(base): self._tbmf = (id(base), split.to_mf(base, bex))
        return self._tbmf[1]

    def text_context(self, idx, items):
        """The part with only these texts (the one you're editing left out), for the screen while you edit it, so the old
        version of that text doesn't show as a ghost. Returns the 3D file to show instead of the part."""
        try:
            p = self._project['parts'][int(idx)]
            if not getattr(p, 'text_base', None): return {'file': None}
            base, bex = p.text_base
            Pi = np.linalg.inv(p.P); loc = []
            for it in items or []:
                d = dict(it); d['point'] = (Pi @ np.r_[np.asarray(it['point'], float), 1])[:3].tolist()
                d['normal'] = (p.P[:3, :3].T @ np.asarray(it['normal'], float)).tolist(); loc.append(d)
            if loc:
                surf, _ = self._text_surface(p)
                tm, fe = text3d.apply_texts(base, bex, p.ext, loc, base_mf=self._text_base_mf(p), surf=surf)
            else:
                tm, fe = base, bex
            q = engine.Part(p.name, tm, p.P.copy(), p.plate, p.color, None, p.ext, fe)
            self._binseq = getattr(self, '_binseq', 0) + 1
            fn = f"ctx_{self._binseq}.bin"; engine.write_display(q, os.path.join(CACHE, fn))
            d = p.info(int(idx)); d['file'] = 'cache/' + fn; d['groups'] = getattr(q, '_groups', None)
            return d
        except Exception as e:
            log('ERROR', traceback.format_exc()); return {'error': str(e)}

    def part_proxy(self, idx, max_tris=30000):
        """A lighter copy of the part (plate coords) for quick mouse picking while you drag text."""
        try:
            p = self._project['parts'][int(idx)]
            V = np.asarray(p.mesh.vertices, np.float32); F = np.asarray(p.mesh.faces, np.int32)
            if len(F) > max_tris:
                import fast_simplification
                V, F = fast_simplification.simplify(V, F, target_reduction=1 - max_tris / len(F))
            return {'v': np.round(np.asarray(V, float), 3).flatten().tolist(), 'f': np.asarray(F, int).flatten().tolist()}
        except Exception as e:
            log('ERROR', traceback.format_exc()); return {'error': str(e)}

    def text_preview(self, idx, item):
        """Letter outlines plus where each letter goes on the part (plate coords), and the thickness under the text."""
        try:
            p = self._project['parts'][int(idx)]
            surf, base = self._text_surface(p)
            Pi = np.linalg.inv(p.P); d = dict(item)
            d['point'] = (Pi @ np.r_[np.asarray(item['point'], float), 1])[:3].tolist()
            d['normal'] = (p.P[:3, :3].T @ np.asarray(item['normal'], float)).tolist()
            L = text3d.preview_frames(base, d, surf)
            R = p.P[:3, :3]
            L['frames'] = [[(p.P @ np.r_[f[0], 1])[:3].round(4).tolist(), (R @ np.asarray(f[1])).round(5).tolist(), (R @ np.asarray(f[2])).round(5).tolist()] for f in L['frames']]
            return L
        except Exception as e:
            log('ERROR', traceback.format_exc()); return {'error': str(e)}

    def all_texts(self):
        """Every text on every part (for the text section's list when no part is selected)."""
        if not self._project: return []
        out = []
        for i, p in enumerate(self._project['parts']):
            for k, it in enumerate(getattr(p, 'texts', None) or []):
                out.append({'part': i, 'index': k, 'text': it.get('text', ''), 'part_name': p.name})
        return out

    def part_texts(self, idx):
        p = self._project['parts'][int(idx)]
        out = []
        for it in getattr(p, 'texts', None) or []:
            d = dict(it); d['point'] = (p.P @ np.r_[it['point'], 1])[:3].round(3).tolist(); d['normal'] = (p.P[:3, :3] @ np.asarray(it['normal'])).round(5).tolist()
            out.append(d)
        return out

    def text_set(self, idx, items, gen=None):
        """(Runs while you keep working.) Only the newest request is applied; older ones that are still waiting are skipped."""
        if gen is not None: self._text_want = max(getattr(self, '_text_want', 0), int(gen))
        lock = getattr(self, '_text_lock', None) or threading.Lock(); self._text_lock = lock
        with lock:
            if gen is not None and int(gen) < getattr(self, '_text_want', 0): return {'stale': True}
            return self._text_set(idx, items)

    def _text_set(self, idx, items):
        """Replace all the text on a part (points and normals arrive in plate coords). The part is rebuilt from how it was
        before any text, so every text can be edited or removed later."""
        if not self._project: return {'error': 'Open a file first.'}
        p = self._project['parts'][int(idx)]
        if not hasattr(p, 'text_base') or p.text_base is None:
            p.text_base = (p.local.copy(), p.exts().copy())
        Pi = np.linalg.inv(p.P)
        local_items = []
        for it in items or []:
            d = dict(it); d['point'] = (Pi @ np.r_[np.asarray(it['point'], float), 1])[:3].tolist()
            d['normal'] = (p.P[:3, :3].T @ np.asarray(it['normal'], float)).tolist(); local_items.append(d)
        self._push_undo('Text on ' + p.name)
        try:
            base, bex = p.text_base
            if local_items:
                surf, _ = self._text_surface(p)
                tm, fe = text3d.apply_texts(base, bex, p.ext, local_items, base_mf=self._text_base_mf(p), surf=surf)
            else:
                tm, fe = base.copy(), bex.copy()
            p.local = tm; p.mesh = tm.copy(); p.mesh.apply_transform(p.P); p.set_face_ext(fe)
            p.texts = local_items
            if not local_items: p.text_base = None
            self._exact = {}
            log('STEP', f'Text on {p.name}: ' + ', '.join(f"\"{i.get('text')}\" ({i.get('style')}, {i.get('path')})" for i in local_items) if local_items else f'Removed all text from {p.name}')
            return self._describe(rebuild=True)
        except Exception as e:
            self._drop_undo(); log('ERROR', traceback.format_exc()); return {'error': f"Couldn't add the text: {e}"}
        finally:
            self._progress = None

    def lay_flat(self, idx, point):
        p = self._project['parts'][int(idx)]
        self._push_undo(f'Lay {p.name} flat')
        build.lay_flat(p, point)
        self._exact = {}
        return self._describe(rebuild=True)

    def drop_part(self, idx=None):
        parts = self._project['parts'] if idx is None else [self._project['parts'][int(idx)]]
        self._push_undo('Drop to plate')
        for p in parts: build.drop_to_plate(p)
        return self._describe(rebuild=True)

    def lift_part(self, idx, dz):
        p = self._project['parts'][int(idx)]
        dz = max(-float(p.mesh.bounds[0][2]), float(dz))       # never below the plate
        self._push_undo(f'Lift {p.name}')
        build.move_part(p, 0, 0, None, dz)
        log('STEP', f'Lifted {p.name} to {p.mesh.bounds[0][2]:.1f} mm')
        return self._describe(rebuild=True)

    def add_text(self, idx, shapes, point, normal, depth, mode, slot, angle, glyphs=None, wrap=False):
        if not self._project: return {'error': 'Open a file first.'}
        p = self._project['parts'][int(idx)]
        self._push_undo(f'Text on {p.name}')
        try:
            self._set_progress('Adding the text…')
            if wrap and glyphs:
                tm, fe = text3d.add_text_wrapped(p, glyphs, point, normal, float(depth), mode, int(slot or p.ext), float(angle or 0))
            else:
                tm, fe = text3d.add_text(p, shapes, point, normal, float(depth), mode, int(slot or p.ext), float(angle or 0))
            self._replace_mesh(p, tm, fe)
            self._exact = {}
            log('STEP', f'Text ({mode}, {float(depth):g} mm) on {p.name} at {np.round(point, 1).tolist()}')
            return self._describe(rebuild=True)
        except split.NotSolid as e:
            self._drop_undo(); return {'error': str(e)}
        except Exception as e:
            self._drop_undo(); log('ERROR', traceback.format_exc()); return {'error': f"Couldn't add the text: {e}"}
        finally:
            self._progress = None

    # ---------- prime tower: move it yourself, its settings, and the real one from the slice
    def set_tower(self, plate, x=None, y=None):
        """Put plate's prime tower at x, y (mm, its front-left corner), or back to automatic with x=None."""
        if not self._project: return {'error': 'Open a file first.'}
        tp = self._project.setdefault('tower_pos', {})
        self._push_undo('Move the prime tower' if x is not None else 'Prime tower back to automatic')
        if x is None: tp.pop(int(plate), None)
        else: tp[int(plate)] = (round(float(x), 2), round(float(y), 2))
        log('STEP', f"Prime tower on plate {plate}: {'automatic' if x is None else f'x={float(x):.1f} y={float(y):.1f}'}")
        return self._describe(rebuild=False)

    def dropped(self, names):
        """The full path of a file just dropped on the window (WebView2 tells Python the paths of dropped files)."""
        from webview.dom import _dnd_state
        names = [str(n) for n in (names or [])]
        for _ in range(40):                       # the path arrives a moment after the drop
            for item in list(_dnd_state['paths']):
                if os.path.basename(item[1]) in names or item[0] in names:
                    try: _dnd_state['paths'].remove(item)
                    except ValueError: pass
                    return item[1]
            time.sleep(0.05)
        log('WARN', f'Dropped {names} but no path arrived')
        return None

    def app_info(self):
        env = self._env()
        return {'version': VERSION, 'engine': env.engine_version(), 'has_engine': bool(env.engine), 'desktop': bool(env.desktop_exe)}

    # ---------- Models: model sites in a browser window, downloads into your library
    def models_info(self):
        out = {'sites': [], 'library': [], 'library_dir': ''}
        try: out['sites'] = models.sites(self._prefs)
        except Exception: log('ERROR', 'Model sites: ' + traceback.format_exc())
        try: out['library_dir'] = models.library_dir(); out['library'] = models.library()
        except Exception: log('ERROR', 'Model library: ' + traceback.format_exc()); out['error'] = "Couldn't open the model library folder (Documents\\BambuForge\\Library)."
        log('INFO', f"Models: {len(out['sites'])} sites, {len(out['library'])} in the library")
        return out

    def _browser(self, url, title):
        w = getattr(self, '_bw', None)
        try:
            if w is not None and w in webview.windows:
                w.load_url(url); w.set_title(f'BambuForge · {title}'); w.show(); w.restore(); return
        except Exception:
            pass
        self._bw = webview.create_window(f'BambuForge · {title}', url=url, width=1300, height=900, background_color='#FFFFFF')
        def gone(): self._bw = None
        try: self._bw.events.closed += gone
        except Exception: pass

    def open_site(self, name, search=None):
        site = next((x for x in models.sites(self._prefs) if x['name'] == name), None)
        if not site: return {'error': 'That site is not in your list.'}
        url = models.search_url(site, search) if search else site['home']
        self._browsing = {'site': name, 'search': search}
        log('STEP', f'Models: open {name}' + (f' searching "{search}"' if search else ''))
        self._browser(url, name)
        return {'ok': True, 'url': url}

    def site_add(self, url, name=None):
        u = models.clean_url(url)
        if not u: return {'error': "That doesn't look like a web address. Try something like cults3d.com"}
        st = self._prefs.setdefault('sites', {})
        all_ = models.sites(self._prefs)
        host = lambda x: __import__('urllib.parse').parse.urlparse(x).netloc.lower().replace('www.', '')
        if any(host(x['home']) == host(u) for x in all_): return {'error': 'That site is already in your list.'}
        n = (name or '').strip() or models.guess_name(u)
        mine = st.setdefault('mine', [])
        mine.append({'name': n, 'home': u, 'search': None, 'color': models.COLOURS[len(mine) % len(models.COLOURS)]})
        save_prefs(self._prefs); log('STEP', f'Models: added site {n} ({u})')
        return self.models_info()

    def site_edit(self, name, new_name=None, url=None):
        st = self._prefs.setdefault('sites', {})
        for x in st.get('mine', []):
            if x['name'] == name:
                if url:
                    u = models.clean_url(url)
                    if not u: return {'error': "That doesn't look like a web address."}
                    if u != x['home']: x['home'] = u; x['search'] = None
                if new_name: x['name'] = new_name.strip()
                save_prefs(self._prefs); return self.models_info()
        if new_name and new_name != name: return {'error': "Built-in sites keep their names."}
        return self.models_info()

    def site_remove(self, name):
        st = self._prefs.setdefault('sites', {})
        if any(n == name for n, *_ in models.BUILT_IN):
            st.setdefault('hidden', []).append(name)
        else:
            st['mine'] = [x for x in st.get('mine', []) if x['name'] != name]
        save_prefs(self._prefs); return self.models_info()

    def site_restore(self):
        self._prefs.setdefault('sites', {})['hidden'] = []; save_prefs(self._prefs); return self.models_info()

    def site_move(self, name, delta):
        names = [x['name'] for x in models.sites(self._prefs)]
        if name not in names: return self.models_info()
        i = names.index(name); j = max(0, min(len(names) - 1, i + int(delta)))
        names.insert(j, names.pop(i)); self._prefs.setdefault('sites', {})['order'] = names; save_prefs(self._prefs)
        return self.models_info()

    def site_learn(self, name, q):
        """For a site you added: you searched once in the browser window; remember how its search address looks."""
        w = getattr(self, '_bw', None)
        try: cur = w.get_current_url() if w else None
        except Exception: cur = None
        st = self._prefs.setdefault('sites', {})
        for x in st.get('mine', []):
            if x['name'] == name:
                tpl = models.learn_search(x['home'], cur, q)
                if not tpl: return {'error': f"Couldn't spot \"{q}\" in the browser's address ({cur or 'nothing open'}). Search for exactly that on the site, then try again."}
                x['search'] = tpl; save_prefs(self._prefs); log('STEP', f'Models: learned search for {name}: {tpl}')
                return self.models_info()
        return {'error': 'Only sites you added need this.'}

    def library_remove(self, file):
        models.remove(file); return self.models_info()

    def library_show(self):
        d = models.library_dir()
        try:
            if sys.platform == 'win32': os.startfile(d)
            else: subprocess.Popen(['xdg-open', d])
        except Exception: pass
        return {'ok': True}

    def library_add_dialog(self):
        r = self._window.create_file_dialog(webview.FileDialog.OPEN, allow_multiple=True, file_types=('3D models (*.3mf;*.stl;*.obj;*.step;*.stp)', 'All files (*.*)'))
        for p in (r or []): models.add_to_library(p)
        return self.models_info()

    def _download_done(self, path):
        """A download from the browser window finished: zips are unpacked, then the page is told."""
        b = getattr(self, '_browsing', None) or {}
        page = None
        try: page = self._bw.get_current_url() if getattr(self, '_bw', None) else None
        except Exception: pass
        files = [path]
        if path.lower().endswith('.zip'):
            got = models.model_in_zip(path)
            if got:
                for g in got: models.note_download(g, b.get('site') or 'Download', page)
                files = got
                try: os.remove(path)
                except OSError: pass
        else:
            models.note_download(path, b.get('site') or 'Download', page)
        log('STEP', f'Models: downloaded {[os.path.basename(f) for f in files]} from {b.get("site")}')
        notify('Saved to your library', ', '.join(os.path.basename(f) for f in files))
        try: self._window.evaluate_js(f"window.studio.modelDownloaded({json.dumps([os.path.basename(f) for f in files])}, {json.dumps(files[0])})")
        except Exception: pass

    def plates_info(self):
        return self._describe(rebuild=False) if self._project else {'error': 'Open a file first.'}

    def set_tower_cfg(self, key, value):
        if not self._project: return {'error': 'Open a file first.'}
        if key not in ('width', 'brim', 'rib', 'enabled'): return {'error': 'Unknown tower setting.'}
        self._push_undo('Prime tower settings')
        self._project.setdefault('tower_cfg', {})[key] = value
        log('STEP', f'Prime tower setting {key} = {value}')
        return self._describe(rebuild=False)

    def _read_towers(self, folder, plates):
        self._sliced_tower = {}
        for pl in plates:
            g = os.path.join(folder, f'plate_{int(pl)}.gcode')
            if not os.path.exists(g): continue
            try:
                t = bambu.parse_tower(g)
                if t: self._sliced_tower[int(pl)] = t; log('INFO', f"Plate {pl}: Bambu's real prime tower is {t['bbox'][2] - t['bbox'][0]:.1f} x {t['bbox'][3] - t['bbox'][1]:.1f} mm at x {t['x']:.1f} y {t['y']:.1f}")
            except Exception:
                log('WARN', 'Reading the tower from the G-code failed: ' + traceback.format_exc(limit=1))

    # ---------- ready-to-print check
    def check_ready(self, support_on=False, printer_serial=None, slot_map=None):
        """Everything that commonly wastes a print, each with a ✓ or ⚠ and (where possible) a one-click fix."""
        if not self._project: return {'items': []}
        P = self._project; items = []
        lifted = [p.name for p in P['parts'] if p.mesh.bounds[0][2] > 0.05]
        items.append({'ok': not lifted, 'title': 'Every part sits on the plate',
                      'detail': (', '.join(lifted) + (' is' if len(lifted) == 1 else ' are') + ' lifted off the plate') if lifted else '', 'fix': 'drop' if lifted else None, 'fix_text': 'Drop to plate'})
        big = [p.name for p in P['parts'] if not p.info(0)['fits'] and p.mesh.bounds[0][2] <= 0.05]
        items.append({'ok': not big, 'title': f"Everything fits the {(self._printer or 'printer').replace('Bambu Lab ', '').replace(' 0.4 nozzle', '')}",
                      'detail': (', '.join(big) + ' too big') if big else '', 'fix': 'split' if big else None, 'fix_text': 'Split it (step 2)'})
        probs = self._plate_problems()
        items.append({'ok': not probs, 'title': 'Everything is inside the plates, nothing overlaps, and the prime tower has room',
                      'detail': ' '.join(probs[:3]) + (' …' if len(probs) > 3 else ''), 'fix': 'arrange' if probs else None, 'fix_text': 'Arrange plates'})
        over = sorted(((build.overhang_area(p) / 100, p.name) for p in P['parts']), reverse=True)
        worst = [f'{n}: {a:.0f} cm²' for a, n in over if a >= 3]
        need = bool(worst) and not support_on
        items.append({'ok': not need, 'title': 'Overhangs have support' if worst else 'No big overhangs',
                      'detail': ('Facing down with supports off: ' + ', '.join(worst[:3])) if need else '', 'fix': 'support' if need else None, 'fix_text': 'Turn on supports'})
        try:
            if not self._plate: self.settings_init()
            t = self.slot_temps()['slots']; plate = self._plate
            bad = [x['name'] for x in t if not x['plates'].get(plate)]
            good = [k for k in (t[0]['plates'] if t else {}) if all(x['plates'].get(k) for x in t)]
            items.append({'ok': not bad, 'title': f'Filaments stick to the {plate}', 'detail': (', '.join(bad) + f" doesn't. Suits all: {', '.join(good) or 'none'}") if bad else '',
                          'fix': ('plate:' + good[0]) if bad and good else None, 'fix_text': f'Use {good[0]}' if good else ''})
        except Exception:
            pass
        if printer_serial:
            p = getattr(self, '_live', {}).get(printer_serial)
            if p and p.connected:
                ams = {a['index']: a for a in p.summary().get('ams') or []}
                fl = P.get('filaments') or []
                used = sorted({k for q in P['parts'] for k in q.slots_used()})
                sm = {int(k): int(v) for k, v in dict(slot_map or {}).items()}
                def tray_of(k): return sm.get(k, k - 1)
                def close(a, b):
                    a, b = a.lstrip('#'), b.lstrip('#')
                    return sum((int(a[i:i + 2], 16) - int(b[i:i + 2], 16)) ** 2 for i in (0, 2, 4)) ** 0.5 < 60
                diff = [k for k in used if tray_of(k) >= 0 and (tray_of(k) not in ams or not close(ams[tray_of(k)]['color'][:7], fl[k - 1]['color'][:7]))]
                items.append({'ok': not diff, 'title': f'AMS on {p.name} matches your model', 'detail': ('Colour ' + ', '.join(f'{k} (slot A{tray_of(k) + 1})' for k in diff) + ' differs from what is loaded') if diff else '',
                              'fix': 'ams' if diff else None, 'fix_text': 'Set AMS to match'})
        return {'items': items}

    # ---------- step 3: hollow
    def hollow_part(self, idx, wall, ends, channel):
        if not self._project: return {'error': 'Open a file first.'}
        idx = int(idx); p = self._project['parts'][idx]
        wall, ends, channel = float(wall), float(ends), float(channel or 0)
        if not (1.2 <= wall <= 20): return {'error': 'Wall thickness should be between 1.2 and 20 mm.'}
        self._push_undo('Hollow')
        try:
            self._set_progress('Hollowing…', 0)
            M, note, saved = hollow.hollow(p.mesh, wall, max(wall, ends), max(wall, ends), channel,
                                           progress=lambda f: self._set_progress('Hollowing…', f),
                                           face_ext=p.exts() if p.face_ext is not None else None)
            new, fe = split.to_tm_ext(M, p.ext)
            p.local = new; p.A = p.A @ np.linalg.inv(p.P) if p.A is not None else None
            p.P = np.eye(4); p.mesh = new.copy(); p.set_face_ext(fe)
            p.hollowed = note
            log('STEP', f'Hollowed {p.name}: {note}')
            d = self._describe(rebuild=True); d['note'] = note
            return d
        except split.NotSolid as e:
            self._drop_undo(); return {'error': str(e)}
        except Exception as e:
            self._drop_undo(); log('ERROR', traceback.format_exc()); return {'error': f'Hollowing failed: {e}'}
        finally:
            self._progress = None

    # ---------- step 4: orientation and moving parts
    def orient_options(self, idx):
        p = self._project['parts'][int(idx)]
        return [{'name': o['name'], 'support_cm2': round(o['overhang'] / 100, 1), 'bed_cm2': round(o['bed'] / 100, 1),
                 'height': round(o['height'], 1), 'fits': bool(o['fits'])} for o in build.orient_options(p)]

    def orient_part(self, idx, mode):
        self._push_undo('Turn a part')
        p = self._project['parts'][int(idx)]
        b = build.orient(p, mode)
        log('STEP', f"Turned {p.name}: {b['name']} (support {b['overhang'] / 100:.0f} cm², height {b['height']:.0f} mm)")
        d = self._describe(rebuild=True); d['note'] = f"{p.name}: {b['name'].lower()}"
        return d

    def orient_all(self):
        if not self._project: return {'error': 'Open a file first.'}
        self._push_undo('Auto-orient + arrange')
        names = []
        for p in self._project['parts']:
            if getattr(p, 'role', 'part') == 'joint': continue
            b = build.orient(p, 'auto'); names.append(f"{p.name}: {b['name'].lower()}")
        log('STEP', 'Auto-orient: ' + '; '.join(names))
        build.layout(self._project)
        d = self._describe(rebuild=True); d['note'] = '\n'.join(names)
        return d

    def move_part(self, idx, dx, dy, plate=None, dz=0.0):
        self._push_undo('Move a part')
        p = self._project['parts'][int(idx)]
        if plate == 'new':
            plate = max(self._project['plates']) + 1
            self._project['plates'][plate] = f'Plate {plate}'
            lo, hi = p.mesh.bounds
            dx, dy = engine.BED[0] / 2 - (lo[0] + hi[0]) / 2, engine.BED[1] / 2 - (lo[1] + hi[1]) / 2
        if dz: dz = max(-float(p.mesh.bounds[0][2]), float(dz))     # never below the plate
        on_bed = build.move_part(p, float(dx), float(dy), plate, float(dz or 0.0))
        if plate: self._project['plates'].setdefault(int(plate), f'Plate {plate}')
        log('STEP', f'Moved {p.name} by ({float(dx):.1f}, {float(dy):.1f}) mm' + (f' to plate {plate}' if plate else ''))
        d = self._describe(rebuild=True); d['note'] = '' if on_bed else f'{p.name} is hanging over the edge of the plate'
        return d

    # ---------- steps 5 and 6: settings, print time, preset (BambuForge built in)
    def _env(self, fresh=False):
        if fresh or getattr(self, '_benv', None) is None:
            self._benv = bambu.Env()
        return self._benv

    # ---------- printer, plate and filament (every single-nozzle Bambu printer)
    def _prof(self, fresh=False):
        if fresh or getattr(self, '_profiles', None) is None:
            self._profiles = bambu.Profiles(self._env(fresh))
        return self._profiles

    def _supported(self, name):
        try: return self._prof().spec(name)['extruders'] == 1
        except Exception: return False

    def _ensure_printer(self):
        if self._printer: return self._printer
        prof = self._prof(); env = self._env()
        names = [n for n in prof.printer_names() if self._supported(n)]
        for cand in (self._prefs.get('printer'), env.selected_printer, 'Bambu Lab P1S 0.4 nozzle'):
            if cand in names:
                self._set_printer(cand); return cand
        if names: self._set_printer(names[0])
        return self._printer

    def _set_printer(self, name):
        sp = self._prof().spec(name)
        engine.BED = (sp['w'], sp['d']); engine.MAX_H = sp['h']
        build.EXCL = sp['excl'] or (0.0, 0.0, 0.0, 0.0)
        self._printer = name; self._prefs['printer'] = name; save_prefs(self._prefs)
        log('INFO', f"Printer: {name} · bed {sp['w']:g} × {sp['d']:g} mm, {sp['h']:g} mm tall" + (f", no-print corner {sp['excl']}" if sp['excl'] else ''))

    def printers_list(self):
        prof = self._prof(fresh=True)
        cur = self._ensure_printer()
        out = []
        for n in prof.printer_names():
            sp = prof.spec(n)
            out.append({'name': n, 'model': sp['model'], 'w': sp['w'], 'd': sp['d'], 'h': sp['h'], 'nozzle': sp['nozzle'],
                        'supported': sp['extruders'] == 1})
        return {'printers': out, 'current': cur}

    def set_printer(self, name):
        if not self._supported(name):
            return {'error': 'Dual-nozzle printers (H2D, H2D Pro, H2C, X2D) are not supported yet.'}
        self._push_undo(f'Printer: {name}')
        self._set_printer(name)
        self._exact = {}
        return self._describe(rebuild=True) if self._project else {'printer': name}

    def filament_info(self, filament):
        try: return self._prof().plate_temps(filament)
        except Exception as e: return {'error': str(e)}

    def settings_init(self, printer=None):
        env = self._env(fresh=True)
        if not env.system: return {'error': "Couldn't find Bambu Studio's profiles. Is Bambu Studio installed and opened at least once?"}
        prof = self._prof(fresh=True)
        printer = self._ensure_printer()
        fil = prof.filament_names(printer)
        allf = fil['mine'] + fil['bambu'] + fil['generic']
        filament = self._filament if self._filament in allf else next((f for f in allf if f.startswith('Bambu PLA Basic')), allf[0] if allf else None)
        temps = prof.plate_temps(filament) if filament else {'plates': {}}
        plate = self._plate if self._plate in temps['plates'] and temps['plates'].get(self._plate) else next((k for k, v in temps['plates'].items() if v), 'Textured PEI Plate')
        self._filament, self._plate = filament, plate
        base_info = {'printer': printer, 'printers': [n for n in prof.printer_names() if self._supported(n)], 'bases': env.bases_for(printer),
                     'filaments': fil, 'filament': filament, 'temps': temps, 'plates': [p[0] for p in bambu.PLATES], 'plate': plate,
                     'folders': env.folders, 'exe': env.exe, 'desktop': env.desktop_exe, 'engine': env.engine_version() if env.engine else None, 'profiles': env.preset_version(), 'selected_printer': env.selected_printer}
        if not self._project:
            base_info.update(base=env.closest_base(printer, None, 0.2), name='', rows=[], summary=['Open a file to get settings picked for it.'], plate_notes={})
            return base_info
        r = bambu.recommend(self._project['parts'], env, printer, self._project['title'])
        log('INFO', f"Recommended {r['base']} for {printer} ({filament}, {plate}): " + ', '.join(f"{x['key']}={x['value']}" for x in r['rows']))
        base_info.update(base=r['base'], name=r['name'], rows=r['rows'], summary=r['summary'], plate_notes=r['plates'])
        return base_info

    def settings_choose(self, printer=None, filament=None, plate=None):
        """Remember the chosen printer / filament / plate; returns what the page needs to refresh."""
        out = {}
        if printer and printer != self._printer:
            d = self.set_printer(printer)
            if d.get('error'): return d
            out['describe'] = d if self._project else None
        if filament: self._filament = filament; self._prefs['filament'] = filament
        if plate: self._plate = plate; self._prefs['plate'] = plate
        save_prefs(self._prefs)
        prof = self._prof()
        out['filaments'] = prof.filament_names(self._printer)
        out['temps'] = prof.plate_temps(self._filament) if self._filament else {'plates': {}}
        out['bases'] = self._env().bases_for(self._printer)
        return out

    def settings_bases(self, printer, current):
        env = self._env()
        lst = env.bases_for(printer)
        pick = current if current in lst else env.closest_base(printer, current if current in env.system else None, 0.2)
        return {'bases': lst, 'base': pick}

    def settings_eval(self, base, rows):
        """Check every row against Bambu's own rules and the chosen base preset.
        Layer height and solid-layer counts follow the base's layer height unless you typed them yourself."""
        env = self._env()
        parent = env.resolve(base)
        new_lh = float(bambu.layer_of(base)) if bambu.layer_of(base) < 99 else None
        ref = next((float(r['orig']) for r in rows if r['key'] == 'layer_height' and bambu._num(r.get('orig')) is not None), None)
        out = []
        for r in rows:
            key, val, note = r['key'], str(r.get('value', '')), None
            if not r.get('manual') and ref and new_lh and abs(ref - new_lh) > 1e-6:
                if key == 'layer_height':
                    val = bambu._fmt(new_lh); note = f"follows the base preset (was {r['orig']})"
                elif key in ('top_shell_layers', 'bottom_shell_layers') and str(r['orig']).isdigit():
                    n = int(r['orig']); val = str(max(1, math.ceil(n * ref / new_lh - 1e-6)))
                    if val != r['orig']: note = f"same {n * ref:.2f} mm solid skin at {new_lh:g} mm layers (was {n})"
            elif not r.get('manual'):
                val = str(r.get('orig', val))
            norm, err = bambu.normalize(key, val)
            bv = bambu.base_values(parent, key)
            d = bambu.opt(key) or {}
            same = bool(norm is not None and bv is not None and len(bv) == bambu.vector_len(parent, key) and all(x == norm for x in bv))
            out.append({'key': key, 'value': val, 'norm': norm, 'error': err, 'same': same, 'auto': note,
                        'label': bambu.label(key), 'category': d.get('category', ''), 'base': bambu.friendly(key, bv[0]) if bv else '(Bambu default)',
                        'shown': bambu.friendly(key, norm) if norm is not None else val, 'tooltip': d.get('tooltip', ''),
                        'allowed': d.get('enum_values', [])})
        return {'rows': out}

    def _changes(self, base, rows):
        ev = self.settings_eval(base, rows)['rows']
        bad = [r['key'] for r, u in zip(ev, rows) if u.get('use', True) and r['error']]
        if bad: return None, 'Fix or untick these first: ' + ', '.join(bad)
        return [(r['key'], r['norm']) for r, u in zip(ev, rows) if u.get('use', True)], None

    def estimate(self, base, rows, name):
        if not self._project: return {'error': 'Open a file first.'}
        fl = self._floating()
        if fl: return {'error': fl}
        env = self._env()
        if not env.exe: return {'error': "BambuForge's built-in slicer is missing (the engine folder). Unzip the download again into a new folder."}
        bad = [p.name for p in self._project['parts'] if not p.info(0)['fits']]
        if bad: return {'error': 'Some parts are still too big for the P1S. Split them first (step 2).'}
        ch, err = self._changes(base, rows)
        self._last_rows = list(ch or []); self._last_base = base
        if err: return {'error': err}
        work = os.path.join(DATA, 'estimate'); os.makedirs(work, exist_ok=True)
        proj = os.path.join(work, 'project.3mf')
        try:
            self._set_progress('Writing the project with these settings…')
            bambu.project_with_settings(self._project, proj, env, base, ch, name, log, self._printer, self._filament, self._plate, self._prof())
            res = bambu.slice_times(env.exe, proj, os.path.join(work, 'out'), 3600,
                                    lambda s: self._set_progress(f'Bambu Studio is slicing every plate to measure the print time… {s // 60}m {s % 60:02d}s'), log)
            self._exact = {x['plate']: {'grams': x['grams'], 'time': bambu.hm(x['seconds']), 'by_slot': x.get('by_slot')} for x in res}
            self._read_towers(os.path.join(work, 'out'), [x['plate'] for x in res])
            return {'plates': res, 'total': sum(x['seconds'] for x in res), 'grams': sum(x['grams'] for x in res),
                    'nice': [{'plate': x['plate'], 'time': bambu.hm(x['seconds']), 'grams': round(x['grams'])} for x in res]}
        except Exception as e:
            log('ERROR', traceback.format_exc()); return {'error': f"Couldn't get the print time: {e}"}
        finally:
            self._progress = None

    def _layer_h(self):
        try:
            for k, v in getattr(self, '_last_rows', None) or []:
                if k == 'layer_height': return float(v)
            base = getattr(self, '_last_base', None)
            if base:
                v = self._env().resolve(base).get('layer_height')
                if v is not None: return float(v[0] if isinstance(v, list) else v)
        except Exception: pass
        return 0.2

    def _plate_problems(self, only=None):
        """Plain-English list of what stops a plate printing: past the edge, overlapping, no room for the prime tower."""
        out = []
        for pl, c in build.plate_check(self._project, self._layer_h()).items():
            if only is not None and pl != int(only): continue
            name = self._project['plates'].get(pl, f'Plate {pl}')
            for n in c['outside']: out.append(f'{name}: {n} sticks out past the edge of the plate.')
            for a, b, ar in c['overlap']: out.append(f'{name}: {a} and {b} overlap (about {ar} mm²).')
            if not c['tower_room']: out.append(f"{name}: there's no room for the prime tower that multi-colour prints need.")
            if c.get('tower') and c['tower'].get('problem'): out.append(f"{name}: the prime tower you placed is a problem: {c['tower']['problem']}.")
        return out

    def _floating(self):
        f = [p.name for p in self._project['parts'] if p.mesh.bounds[0][2] > 0.05]
        return (', '.join(f) + (' is' if len(f) == 1 else ' are') + ' lifted off the plate and can\'t be printed. Select it and press Drop to plate (step 1).') if f else None

    def save_with_settings(self, base, rows, name):
        if not self._project: return {'error': 'Open a file first.'}
        fl = self._floating()
        if fl: return {'error': fl}
        ch, err = self._changes(base, rows)
        self._last_rows = list(ch or []); self._last_base = base
        if err: return {'error': err}
        r = self._window.create_file_dialog(webview.FileDialog.SAVE, save_filename=self._project['title'] + ' (BambuForge Studio).3mf', file_types=('Bambu project (*.3mf)',))
        if not r: return None
        path = r if isinstance(r, str) else r[0]
        if not path.lower().endswith('.3mf'): path += '.3mf'
        try:
            bambu.project_with_settings(self._project, path, self._env(), base, ch, name, log, self._printer, self._filament, self._plate, self._prof())
            self._saved = path
            return {'saved': path}
        except Exception as e:
            log('ERROR', traceback.format_exc()); return {'error': f"Couldn't save: {e}"}

    def bambu_running(self):
        return bambu.running()

    def close_bambu(self, force=False):
        bambu.ask_close(bool(force))
        log('STEP', ('Force-closing' if force else 'Asking to close') + ' Bambu Studio')
        for _ in range(240 if not force else 40):
            if not bambu.running(): return {'closed': True}
            time.sleep(0.5)
        return {'closed': False}

    def send(self, base, rows, name, folder_id, open_after):
        if not self._project: return {'error': 'Open a file first.'}
        env = self._env()
        nerr = bambu.validate_name(env, name)
        if nerr: return {'error': nerr}
        ch, err = self._changes(base, rows)
        self._last_rows = list(ch or []); self._last_base = base
        if err: return {'error': err}
        folder = next((f for f in env.folders if f['id'] == folder_id), None)
        if not folder: return {'error': 'Pick the Bambu account to save to.'}
        fl = self._floating()
        if fl: return {'error': fl}
        if bambu.running(): return {'need_close': True}
        log('STEP', f"Send: preset '{name}' based on '{base}' to account folder {folder['id']}")
        try:
            res = bambu.write_preset(env, folder, name, base, ch, os.path.join(DATA, 'backups'), log)
            opened = None
            if open_after and env.desktop_exe:
                proj = os.path.join(DATA, 'projects', self._project['title'] + ' (BambuForge Studio).3mf')
                os.makedirs(os.path.dirname(proj), exist_ok=True)
                if not all(p.info(0)['fits'] for p in self._project['parts']):
                    proj = None
                else:
                    bambu.project_with_settings(self._project, proj, env, base, ch, name, log, self._printer, self._filament, self._plate, self._prof())
                bambu.launch(env.desktop_exe, proj)
                opened = proj or True
                log('STEP', f'Started Bambu Studio {env.desktop_exe}' + (f' with {proj}' if proj else ''))
            return {'ok': True, 'updated': res['updated'], 'changed': res['changed'], 'backup': res['backup'], 'info': res['info'],
                    'opened': opened, 'synced_folder': folder['id'] != 'default'}
        except Exception as e:
            log('ERROR', traceback.format_exc())
            msg = str(e)
            if 'printable area' in msg.lower() or 'outside' in msg.lower():
                return {'error': "Bambu Studio still found part of the print outside the plate, even after moving the prime tower further in. Parts may be too close to the edge or to each other: use Arrange plates in step 1 (it leaves room for the tower), then send again. Copy log shows Bambu's exact message."}
            return {'error': f'Sending failed: {e}'}

    def sync_status(self, info_path):
        ok, sid = bambu.is_synced(info_path)
        return {'synced': ok, 'id': sid}

    # ---------- step 7: printers on your network (LAN Only + Developer Mode)
    def _pfile(self):
        return os.path.join(DATA, 'printers.json')

    def _saved_printers(self):
        try:
            with open(self._pfile(), encoding='utf-8') as f: return json.load(f)
        except Exception:
            return {}

    def _save_printers(self, d):
        with open(self._pfile(), 'w', encoding='utf-8') as f: json.dump(d, f, indent=2)

    def _hms(self):
        if getattr(self, '_hmsdb', None) is None:
            env = self._env()
            dirs = [os.path.join(env.data, 'hms')]
            if env.exe: dirs.append(os.path.join(os.path.dirname(env.exe), 'resources', 'hms'))
            self._hmsdb = printers.HMS(dirs)
        return self._hmsdb

    def _pr(self, serial, connect=True):
        self._live = getattr(self, '_live', {})
        p = self._live.get(serial)
        if p is None:
            sv = self._saved_printers().get(serial)
            if not sv: return None
            p = printers.Printer(serial, sv['ip'], printers.unprotect(sv.get('code', '')), sv.get('name', serial), sv.get('model', ''), log)
            self._live[serial] = p
        if connect and not p.connected:
            p.connect(8)
        return p

    def printers_saved(self):
        sv = self._saved_printers()
        live = getattr(self, '_live', {})
        return {'printers': [{'serial': k, 'name': v.get('name', k), 'model': v.get('model', ''), 'ip': v.get('ip', ''),
                              'connected': bool(live.get(k) and live[k].connected)} for k, v in sv.items()],
                'mqtt': printers.mqtt is not None}

    def printers_discover(self):
        self._set_progress('Looking for Bambu printers on your network…')
        try:
            found = printers.discover(5.0)
        except Exception as e:
            log('WARN', 'Discovery failed: ' + str(e)); found = []
        finally:
            self._progress = None
        sv = self._saved_printers()
        for f in found:
            f['saved'] = f['serial'] in sv
            if f['saved'] and sv[f['serial']].get('ip') != f['ip']:      # printer got a new address: follow it
                sv[f['serial']]['ip'] = f['ip']; self._save_printers(sv)
        log('INFO', f'Discovery found {len(found)} printer(s): ' + ', '.join(f"{f['name']} ({f['model']}, {f['ip']}, {f['connect']})" for f in found))
        return {'found': found}

    def printer_add(self, serial, ip, code, name='', model=''):
        serial, ip, code = str(serial).strip(), str(ip).strip(), str(code).strip()
        if not serial or not ip: return {'error': 'Enter the printer\'s serial number and IP address (both are on its screen, Settings → Device / WLAN).'}
        if len(code) != 8: return {'error': 'The access code is 8 characters, shown on the printer: Settings → WLAN (LAN Only mode).'}
        p = printers.Printer(serial, ip, code, name or serial, model, log)
        self._set_progress(f'Connecting to {name or ip}…')
        ok = p.connect(8)
        self._progress = None
        if not ok:
            return {'error': p.error or 'Could not connect.'}
        sv = self._saved_printers()
        sv[serial] = {'name': name or serial, 'ip': ip, 'model': model, 'code': printers.protect(code)}
        self._save_printers(sv)
        self._live = getattr(self, '_live', {}); self._live[serial] = p
        log('STEP', f'Added printer {name or serial} ({model}) at {ip}')
        return {'ok': True}

    def printer_remove(self, serial):
        sv = self._saved_printers(); sv.pop(serial, None); self._save_printers(sv)
        p = getattr(self, '_live', {}).pop(serial, None)
        if p: p.close()
        return {'ok': True}

    def printer_status(self, serial):
        p = self._pr(serial, connect=True)
        if p is None: return {'error': 'Unknown printer.'}
        st = p.summary()
        if st.get('ams') and not getattr(p, '_ams_logged', False):
            p._ams_logged = True
            log('INFO', f'Printer {p.name} AMS: ' + json.dumps((p.state.get('print') or {}).get('ams'))[:1500])
        st['hms_info'] = [self._hms().describe(c) for c in st['hms']]
        st['error_info'] = self._hms().describe_error(st['print_error']) if st['print_error'] else None
        # history: remember jobs that finished or failed
        key = (st.get('job'), st.get('state'))
        if st.get('job') and st.get('state') in ('FINISH', 'FAILED') and getattr(p, '_last_hist', None) != key:
            p._last_hist = key
            self._history_add({'printer': p.name, 'job': st['job'], 'result': st['state_text'], 'at': time.strftime('%Y-%m-%d %H:%M')})
        st['history'] = self._history()[:8]
        return st

    def _history(self):
        try:
            with open(os.path.join(DATA, 'print_history.json'), encoding='utf-8') as f: return json.load(f)
        except Exception:
            return []

    def _history_add(self, item):
        h = [item] + self._history()
        with open(os.path.join(DATA, 'print_history.json'), 'w', encoding='utf-8') as f: json.dump(h[:200], f, indent=1)

    def printer_cmd(self, serial, cmd, a=None, b=None):
        p = self._pr(serial)
        if p is None or not p.connected: return {'error': (p.error if p else None) or 'Not connected to the printer.'}
        try:
            if cmd == 'pause': p.pause()
            elif cmd == 'resume': p.resume()
            elif cmd == 'stop': p.stop()
            elif cmd == 'home': p.home()
            elif cmd == 'nozzle': p.nozzle_temp(max(0, min(300, int(float(a)))))
            elif cmd == 'bed': p.bed_temp(max(0, min(120, int(float(a)))))
            elif cmd == 'fan': p.fan(a, float(b))
            elif cmd == 'light': p.light(bool(a))
            elif cmd == 'load': p.load(int(a))
            elif cmd == 'unload': p.unload()
            elif cmd == 'calibrate': p.calibrate(bool(a.get('bed')), bool(a.get('vibration')), bool(a.get('motor')))
            elif cmd == 'ams_set': p.ams_set(int(a['tray']), a.get('id') or 'GFL99', a.get('type') or 'PLA', a.get('color') or '#FFFFFF', int(a.get('tmin') or 190), int(a.get('tmax') or 230))
            else: return {'error': 'Unknown command.'}
            log('STEP', f'Printer {p.name}: {cmd} {a if a is not None else ""} {b if b is not None else ""}')
            return {'ok': True}
        except Exception as e:
            log('ERROR', traceback.format_exc()); return {'error': str(e)}

    def printer_match_project(self, serial, slot_map=None):
        """Tell the printer's AMS that slot N holds the filament and colour picked for colour N in step 1."""
        if not self._project: return {'error': 'Open a file first.'}
        p = self._pr(serial)
        if p is None or not p.connected: return {'error': (p.error if p else None) or 'Not connected to the printer.'}
        trays = len(p.summary().get('ams') or []) or 4
        prof = self._prof(); pr = self._ensure_printer(); done = []
        used = sorted({s for q in self._project['parts'] for s in q.slots_used()})
        sm = {int(a): int(b) for a, b in dict(slot_map or {}).items()}
        for k in used:
            tray = sm.get(k, k - 1)
            if tray < 0 or tray >= trays: continue
            f = (self._project.get('filaments') or [])[k - 1]
            name = prof.match_filament(f.get('preset'), pr) or self._filament
            r = prof.filament(name) if name else {}
            g = lambda key, d: (r.get(key, [d]) or [d])[0] if isinstance(r.get(key, [d]), list) else r.get(key, d)
            p.ams_set(tray, r.get('filament_id', 'GFL99') if not isinstance(r.get('filament_id'), list) else r['filament_id'][0],
                      g('filament_type', 'PLA'), f.get('color', '#FFFFFF'), int(float(g('nozzle_temperature_range_low', 190))), int(float(g('nozzle_temperature_range_high', 230))))
            done.append(tray + 1)
        log('STEP', f'Set AMS slots {done} on {p.name} to match the model')
        return {'ok': True, 'slots': done, 'skipped': [k for k in used if not (0 <= sm.get(k, k - 1) < trays)]}

    # ---------- other ways to print: Bambu Connect (no Developer Mode) or Bambu Studio
    def print_ways(self):
        env = self._env()
        return {'connect': bambu_connect_installed(), 'studio': bool(env.desktop_exe), 'method': (self._prefs.get('ui') or {}).get('print_method')}

    def send_other(self, method, plate, base, rows, name):
        """method 'connect': slice the plate with the built-in engine and hand the file to Bambu Connect (you press Print there).
        method 'studio': open the project, with these settings, in Bambu Studio."""
        if not self._project: return {'error': 'Open a file first.'}
        fl = self._floating()
        if fl: return {'error': fl}
        plate = int(plate)
        bad = self._plate_problems(plate)
        if bad: return {'error': ' '.join(bad) + ' Use Arrange plates (step 1) or move the parts, then try again.'}
        env = self._env()
        ch, err = self._changes(base, rows)
        if err: return {'error': err}
        self._last_rows = list(ch or []); self._last_base = base
        safe = re.sub(r'[^A-Za-z0-9_.-]+', '_', f"{self._project['title']}_plate{plate}")[:60]
        try:
            if method == 'studio':
                if not env.desktop_exe: return {'error': 'Bambu Studio is not installed on this PC.', 'need': 'studio'}
                out = os.path.join(DATA, 'projects'); os.makedirs(out, exist_ok=True)
                proj = os.path.join(out, safe + '.3mf')
                self._set_progress('Writing the project with these settings…')
                bambu.project_with_settings(self._project, proj, env, base, ch, name, log, self._printer, self._filament, self._plate, self._prof())
                bambu.launch(env.desktop_exe, proj); log('STEP', f'Opened {proj} in Bambu Studio')
                return {'ok': True, 'file': proj}
            if method == 'connect':
                if not bambu_connect_installed(): return {'error': 'Bambu Connect is not installed on this PC.', 'need': 'connect'}
                if not env.exe: return {'error': "BambuForge's built-in slicer is missing (the engine folder). Unzip the download again into a new folder."}
                work = os.path.join(DATA, 'send'); shutil.rmtree(work, ignore_errors=True); os.makedirs(work, exist_ok=True)
                proj = os.path.join(work, 'project.3mf'); job = os.path.join(work, safe + '.gcode.3mf')
                res, last = None, None
                for attempt, extra in enumerate((0.0, 6.0, 12.0)):
                    if attempt and not build.plate_check(self._project, self._layer_h(), extra).get(plate, {}).get('tower'): continue
                    self._set_progress('Writing the project with these settings…' if not attempt else f'Moving the prime tower and trying again ({attempt + 1} of 3)…')
                    bambu.project_with_settings(self._project, proj, env, base, ch, name, log, self._printer, self._filament, self._plate, self._prof(), tower_extra=extra)
                    self._set_progress(f'Slicing plate {plate}…')
                    try:
                        res = bambu.slice_plate_export(env.exe, proj, plate, job, work, 3600, lambda t: self._set_progress(f'Slicing plate {plate}… {t // 60}m {t % 60:02d}s'), log)
                        break
                    except RuntimeError as e:
                        last = e; log('WARN', f'Slice attempt {attempt + 1} failed: {e}')
                        if not any(w in str(e).lower() for w in ('outside', 'printable', 'conflict', 'collid')): raise
                if res is None: raise last
                keep = os.path.join(DATA, 'connect'); os.makedirs(keep, exist_ok=True)
                final = os.path.join(keep, safe + '.gcode.3mf'); shutil.copy2(job, final)
                import urllib.parse as up
                url = 'bambu-connect://import-file?path=' + up.quote(final, safe='') + '&name=' + up.quote(f"{self._project['title']} plate {plate}", safe='') + '&version=1.0.0'
                log('STEP', f'Handing {final} to Bambu Connect')
                open_url(url)
                return {'ok': True, 'file': final, 'grams': res.get('grams'), 'seconds': res.get('seconds')}
            return {'error': 'Unknown way to print.'}
        except Exception as e:
            log('ERROR', traceback.format_exc()); return {'error': f"Couldn't get the plate ready: {e}"}
        finally:
            self._progress = None

    def open_link(self, url):
        if not str(url).startswith(('https://', 'http://')): return {'error': 'Only web links.'}
        import webbrowser; webbrowser.open(url); return {'ok': True}

    def set_print_method(self, method):
        self._prefs.setdefault('ui', {})['print_method'] = method; save_prefs(self._prefs); return {'ok': True}

    def printer_send(self, serial, plate, level, tray, base, rows, name, slot_map=None):
        """Slice one plate with these settings, upload it to the printer and start it."""
        if not self._project: return {'error': 'Open a file first.'}
        fl = self._floating()
        if fl: return {'error': fl}
        bad = self._plate_problems(plate)
        if bad: return {'error': ' '.join(bad) + ' Use Arrange plates (step 1) or move the parts, then send again.'}
        p = self._pr(serial)
        if p is None or not p.connected: return {'error': (p.error if p else None) or 'Not connected to the printer.'}
        model = (p.model or '').strip()
        if model and self._printer and model.lower() not in self._printer.lower():
            return {'error': f"This job is set up for the {self._printer.replace(' 0.4 nozzle', '')}, but that printer is a {model}. Pick its printer type in step 3 (Settings) first."}
        st = p.summary()
        if st['state'] in ('RUNNING', 'PREPARE', 'PAUSE'):
            return {'error': f"{p.name} is busy ({st['state_text']}). Wait for it to finish or stop it first."}
        env = self._env()
        if not env.exe: return {'error': "BambuForge's built-in slicer is missing (the engine folder). Unzip the download again into a new folder."}
        ch, err = self._changes(base, rows)
        self._last_rows = list(ch or []); self._last_base = base
        if err: return {'error': err}
        plate = int(plate)
        work = os.path.join(DATA, 'send'); shutil.rmtree(work, ignore_errors=True); os.makedirs(work, exist_ok=True)
        proj = os.path.join(work, 'project.3mf')
        safe = re.sub(r'[^A-Za-z0-9_.-]+', '_', f"{self._project['title']}_plate{plate}")[:60]
        remote = safe + '.gcode.3mf'
        try:
            # if Bambu says something is outside the plate (usually the prime tower), give the tower more room and try again
            res, last = None, None
            for attempt, extra in enumerate((0.0, 6.0, 12.0)):
                if attempt and not build.plate_check(self._project, self._layer_h(), extra).get(int(plate), {}).get('tower'):
                    continue                     # no room to move it further in

                self._set_progress('Writing the project with these settings…' if not attempt else f'Moving the prime tower and trying again ({attempt + 1} of 3)…')
                bambu.project_with_settings(self._project, proj, env, base, ch, name, log, self._printer, self._filament, self._plate, self._prof(), tower_extra=extra)
                self._set_progress(f'Slicing plate {plate} with Bambu Studio…')
                try:
                    res = bambu.slice_plate_export(env.exe, proj, plate, os.path.join(work, remote), work, 3600,
                                                   lambda s: self._set_progress(f'Slicing plate {plate} with Bambu Studio… {s // 60}m {s % 60:02d}s'), log)
                    break
                except RuntimeError as e:
                    last = e; m = str(e).lower()
                    log('WARN', f'Slice attempt {attempt + 1} failed: {e}')
                    if not any(w in m for w in ('outside', 'printable', 'conflict', 'collid')): raise
            if res is None: raise last
            self._set_progress(f'Sending to {p.name}…', 0)
            p.upload(os.path.join(work, remote), remote, lambda f: self._set_progress(f'Sending to {p.name}…', f))
            n_fil = len(json.loads(zipfile.ZipFile(proj).read('Metadata/project_settings.config')).get('filament_colour') or ['x'])
            p.job = {'name': f"{self._project['title']} · plate {plate}", 'grams': res.get('grams'), 'seconds': res.get('seconds'), 'plate': plate}
            mapping, use_ams, tray = None, int(tray) != -1, int(tray)
            if slot_map:                 # each colour prints from the AMS slot you picked (-1 = the external spool)
                sm = {int(k): int(v) for k, v in dict(slot_map).items()}
                chosen = [v for v in sm.values() if v >= 0]
                use_ams = bool(chosen)
                fallback = chosen[0] if chosen else 0
                mapping = [sm.get(i + 1, fallback) if sm.get(i + 1, fallback) >= 0 else fallback for i in range(n_fil)]
                log('INFO', 'AMS mapping (colour -> slot): ' + ', '.join(f'{k}->{"A" + str(v + 1) if v >= 0 else "external"}' for k, v in sorted(sm.items())))
            elif tray == -2:             # older choice: colour 1 -> AMS slot 1, colour 2 -> AMS slot 2...
                mapping = [i if i < 16 else 0 for i in range(n_fil)]
            p.start_print(remote, plate, level=bool(level), tray=tray if tray >= 0 else 0, use_ams=use_ams,
                          n_filaments=n_fil, job_name=p.job['name'], mapping=mapping)
            self._history_add({'printer': p.name, 'job': p.job['name'], 'result': 'Sent', 'at': time.strftime('%Y-%m-%d %H:%M')})
            return {'ok': True, 'job': p.job}
        except Exception as e:
            log('ERROR', traceback.format_exc())
            msg = str(e)
            if 'printable area' in msg.lower() or 'outside' in msg.lower():
                return {'error': "Bambu Studio still found part of the print outside the plate, even after moving the prime tower further in. Parts may be too close to the edge or to each other: use Arrange plates in step 1 (it leaves room for the tower), then send again. Copy log shows Bambu's exact message."}
            return {'error': f'Sending failed: {e}'}
        finally:
            self._progress = None

    def copy_log(self):
        try:
            with open(LOG, encoding='utf-8') as f: return ''.join(f.readlines()[-600:])
        except Exception:
            return '(the log is empty)'

    def startup_file(self):
        """The file you dragged onto the desktop icon (asked for once the page is ready)."""
        p = sys.argv[1] if len(sys.argv) > 1 else None
        sys.argv[1:] = []
        return os.path.abspath(p) if p and os.path.exists(p) else None

    def js_error(self, msg):
        log('ERROR', 'Page error: ' + str(msg)[:2000])

    def ready(self, info=None):
        log('INFO', 'Window ready. ' + (str(info) if info else ''))
        try:
            with open(os.path.join(DATA, 'ready.flag'), 'w') as f: f.write(str(os.getpid()))
        except Exception:
            pass

    def version(self):
        return {'name': APP_NAME, 'version': VERSION}


def on_drop(e):
    try:
        files = e['dataTransfer']['files']
        if files:
            path = files[0].get('pywebviewFullPath')
            if path:
                api._window.evaluate_js(f"window.studio.openPath({json.dumps(path)})")
    except Exception:
        log('ERROR', traceback.format_exc())


def set_windows_icon(window):
    """Give the window (and its taskbar button) the BambuForge Studio icon instead of Python's."""
    if sys.platform != 'win32':
        return
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('Evnflow.BambuForgeStudio')
    except Exception:
        log('WARN', 'Could not set the taskbar app id: ' + traceback.format_exc(limit=1))
    try:
        import clr
        clr.AddReference('System.Drawing'); clr.AddReference('System.Windows.Forms')
        from System import Action
        from System.Drawing import Icon
        form = window.native
        ico = os.path.join(os.path.dirname(HERE), 'BambuForgeStudio.ico')
        if form is not None and os.path.exists(ico):
            form.Invoke(Action(lambda: setattr(form, 'Icon', Icon(ico))))
    except Exception:
        log('WARN', 'Could not set the window icon: ' + traceback.format_exc(limit=2))


def bind(window):
    if sys.platform == 'win32':
        try:
            from webview.platforms import winforms
            log('INFO', f'Windows renderer: {winforms.renderer}')
            if winforms.renderer != 'edgechromium':
                import ctypes
                ctypes.windll.user32.MessageBoxW(None, "BambuForge Studio needs the Microsoft Edge WebView2 Runtime, but Windows isn't reporting it.\n\n"
                    "Close it and start BambuForge Studio.exe again: it offers to install WebView2. Restart your PC if it still doesn't open.", "BambuForge Studio", 0x30)
                window.destroy(); return
        except Exception:
            log('WARN', 'Renderer check failed: ' + traceback.format_exc(limit=2))
    set_windows_icon(window)
    # Dropped files: the page handles the drop itself and only asks Python for the file's full path.
    # (Listening for drag events through pywebview made it copy the whole event, over and over while dragging,
    # which is what took ~6 seconds.) A listener on a hidden element keeps WebView2 reporting dropped paths.
    try:
        from webview.dom import DOMEventHandler
        sink = window.dom.get_element('#dndSink')
        if sink is not None: sink.events.drop += DOMEventHandler(on_drop, True, True)
    except Exception:
        log('WARN', 'Drop setup failed: ' + traceback.format_exc(limit=1))
    js = os.environ.get('BFS_TEST_JS')          # used only for automated testing
    if js:
        threading.Timer(float(os.environ.get('BFS_TEST_DELAY', '12')), lambda: window.evaluate_js(js)).start()


def bambu_connect_installed():
    """Bambu Connect registers the bambu-connect:// link type when it's installed."""
    if sys.platform != 'win32': return False
    try:
        import winreg
        winreg.CloseKey(winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, 'bambu-connect')); return True
    except OSError:
        return False


def open_url(url):
    if sys.platform == 'win32': os.startfile(url)
    else: subprocess.Popen(['xdg-open', url])


def catch_downloads():
    """Downloads in the BambuForge browser window go straight into your model library (no Save dialog)."""
    try:
        webview.settings['ALLOW_DOWNLOADS'] = True
        from webview.platforms import edgechromium as ec
        def on_download_starting(self, sender, args):
            try:
                op = args.DownloadOperation
                name = os.path.basename(str(args.ResultFilePath)) or 'model'
                if not name.lower().endswith(models.MODEL_EXT):
                    return                                    # anything else: Windows' normal download handling
                dst = os.path.join(models.library_dir(), models.unique_name(models.library_dir(), name))
                args.ResultFilePath = dst
                args.Handled = True                           # no Save dialog, no download bar
                log('STEP', f'Models: downloading {name} into the library')
                def changed(o, e):
                    try:
                        st = str(o.State)
                        if st.endswith('Completed'): threading.Thread(target=api._download_done, args=(dst,), daemon=True).start()
                        elif st.endswith('Interrupted'): log('WARN', f'Models: download of {name} stopped ({o.InterruptReason})')
                    except Exception:
                        log('WARN', 'Download watch: ' + traceback.format_exc(limit=1))
                op.StateChanged += changed
            except Exception:
                log('ERROR', 'Catching a download failed: ' + traceback.format_exc())
        ec.EdgeChrome.on_download_starting = on_download_starting
        # the camera (Masks step): BambuForge's own page may use it without a second "allow?" box; other sites still ask
        _ready = ec.EdgeChrome.on_webview_ready
        def on_webview_ready(self, sender, args):
            _ready(self, sender, args)
            try:
                def on_perm(s, a):
                    try:
                        uri = str(a.Uri)
                        if str(a.PermissionKind).endswith('Camera') and (uri.startswith('http://127.0.0.1') or uri.startswith('http://localhost')):
                            from Microsoft.Web.WebView2.Core import CoreWebView2PermissionState
                            a.State = CoreWebView2PermissionState.Allow
                            log('INFO', 'Camera allowed for the Masks step')
                    except Exception:
                        log('WARN', 'Camera permission: ' + traceback.format_exc(limit=1))
                sender.CoreWebView2.PermissionRequested += on_perm
            except Exception:
                log('WARN', 'Camera permission hook: ' + traceback.format_exc(limit=1))
        ec.EdgeChrome.on_webview_ready = on_webview_ready
    except Exception:
        log('WARN', 'Download catching not available: ' + traceback.format_exc(limit=1))


def notify(title, text, kind='info'):
    """Ask the launcher's tray icon to show a Windows notification."""
    try:
        d = os.path.join(DATA, 'notify'); os.makedirs(d, exist_ok=True)
        tmp = os.path.join(d, f'{time.time():.3f}.tmp')
        with open(tmp, 'w', encoding='utf-8') as f: json.dump({'title': title, 'text': text, 'kind': kind}, f)
        os.replace(tmp, tmp[:-4] + '.json')
        log('INFO', f'Notification: {title}: {text}')
    except Exception:
        log('WARN', 'Notification failed: ' + traceback.format_exc(limit=1))


def printer_watch():
    """Tell you (through the tray) when a print finishes, fails, pauses or the printer reports a problem."""
    last = {}
    while True:
        time.sleep(5)
        for serial, p in list(getattr(api, '_live', {}).items()):
            try:
                if not p.connected: continue
                s = p.summary(); prev = last.get(serial, {})
                job = s.get('job') or 'Your print'
                if prev:
                    if s['state'] != prev.get('state'):
                        if s['state'] == 'FINISH': notify(f'{p.name}: done', f'{job} finished. Time to take it off the plate!')
                        elif s['state'] == 'FAILED': notify(f'{p.name}: stopped', f'{job} stopped or failed.', 'error')
                        elif s['state'] == 'PAUSE': notify(f'{p.name}: paused', f"{job} is paused ({s.get('stage_text', '')}).", 'warn')
                    for code in set(s['hms']) - set(prev.get('hms', [])):
                        d = api._hms().describe(code)
                        notify(f'{p.name}: problem', f"{d['code']}: {d['text']}", 'error')
                last[serial] = {'state': s['state'], 'hms': list(s['hms'])}
            except Exception:
                pass


def ipc_watch():
    """The tray icon asks the window to show itself or the app to quit by dropping a file in DATA/ipc."""
    os.makedirs(IPC, exist_ok=True)
    while True:
        time.sleep(0.5)
        try:
            for f in os.listdir(IPC):
                path = os.path.join(IPC, f)
                try: os.remove(path)
                except OSError: continue
                if f.startswith('show') and api._window:
                    api._window.show(); api._window.restore()
                elif f.startswith('quit') and api._window:
                    api._quitting = True; api._window.destroy()
        except Exception:
            pass


def on_closing():
    """Closing the window: ask whether to close or keep running in the tray (unless you ticked "remember my choice")."""
    if os.environ.get('BFS_TRAY') != '1' or getattr(api, '_quitting', False):
        return True
    choice = api.ui_prefs().get('close_action') or 'ask'
    if choice == 'quit':
        return True
    if choice == 'tray':
        api._to_tray(); return False
    try: api._window.evaluate_js('window.studio && window.studio.askClose && window.studio.askClose()')
    except Exception: return True
    return False


api = Api()
if __name__ == '__main__':
    log('INFO', f'===== {APP_NAME} {VERSION} started =====')
    # last time ended badly? offer the auto-saved work back
    try:
        if os.path.exists(LOCK) and os.path.exists(AUTOSAVE):
            import pickle
            with open(AUTOSAVE, 'rb') as f: api._recovery = pickle.load(f)
            log('INFO', 'Found auto-saved work from a session that did not close normally')
    except Exception:
        log('WARN', 'Could not read the auto-save: ' + traceback.format_exc(limit=1))
    with open(LOCK, 'w') as f: f.write(str(os.getpid()))
    for fn in (api._autosave_loop, printer_watch, ipc_watch):
        threading.Thread(target=fn, daemon=True).start()
    def warm_up():
        # read Bambu's printer and filament lists in the background, so opening the first file is quick
        try:
            t = time.time(); api._ensure_printer(); _ = api._prof().filaments
            log('INFO', f'Bambu profiles ready in {time.time() - t:.1f}s')
        except Exception:
            log('WARN', 'Profile warm-up failed: ' + traceback.format_exc(limit=1))
    threading.Thread(target=warm_up, daemon=True).start()
    try:
        os.remove(os.path.join(DATA, 'ready.flag'))
    except OSError:
        pass
    startup_report()
    os.makedirs(CACHE, exist_ok=True)
    api._window = webview.create_window(APP_NAME, url=os.path.join(HERE, 'ui', 'index.html'), js_api=api,
                                       width=1400, height=900, min_size=(1000, 650), background_color='#2D2D31', maximized=True)
    try:
        log('STEP', 'Starting the window…')
        kw = dict(http_server=True, debug=os.environ.get('BFS_DEBUG') == '1',
                  private_mode=False, storage_path=os.path.join(DATA, 'browser'))   # model sites remember that you signed in
        if sys.platform == 'win32':
            kw['gui'] = 'edgechromium'
            catch_downloads()
        else: kw['icon'] = os.path.join(HERE, 'ui', 'icon.png')
        api._window.events.closing += on_closing
        webview.start(bind, api._window, **kw)
        log('INFO', 'Window closed.')
        for f in (LOCK, AUTOSAVE):          # a normal close: nothing to recover next time
            try: os.remove(f)
            except OSError: pass
    except Exception:
        log('ERROR', 'Window failed to start: ' + traceback.format_exc())
        raise
