// BambuForge Studio: Masks. Scan your face with the PC camera, try a mask on live, then print it shaped to your face.
// Face tracking is Google's MediaPipe Face Mesh running entirely on this PC (vendor/facemesh); nothing is uploaded.
const $ = id => document.getElementById(id);
const X = () => window.studio && window.studio.ctx;
const IRIS_MM = 11.7;                      // the coloured part of the eye is about 11.7 mm across in almost everyone: it gives the real size
const DEF = { size: 100, gap: 2, th: 2, ud: 0 };
const M = {
  on: false, stream: null, cams: [], cam: null, fm: null, fmReady: false, busy: false,
  lm: null, W: 1280, H: 720, step: 'scan', view: 'live', type: 0, ...DEF,
  scanning: false, frames: [], scan: null, mask: null, maskKey: '', fps: 0, lastT: 0, imgSrc: null,
};
const TYPES = [
  ['Eye mask', 'M3 14 Q12 6 23 12 Q34 6 43 14 Q34 22 23 16 Q12 22 3 14Z'],
  ['Half mask', 'M6 8 Q23 4 40 8 Q40 24 23 29 Q6 24 6 8Z'],
  ['Full face', 'M8 3 Q23 -2 38 3 Q42 18 23 29 Q4 18 8 3Z'],
];
let TRIS = null, EYE_R = null, EYE_L = null, LIPS_IN = null;
let three = null;     // { r, sc, cam, maskMesh, faceMesh, ... } for the overlay; three3 for the 3D view
let three3 = null;

// ------------------------------------------------------------------ cameras
async function listCams() {
  let devs = [];
  try { devs = (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === 'videoinput'); } catch (_) {}
  const ui = (X() && X().ui ? X().ui() : {}) || {};
  const virt = /virtual|obs|snap camera|manycam|xsplit/i;
  M.cams = devs.map((d, i) => ({ id: d.deviceId || ('cam' + i), name: d.label || `Camera ${i + 1}`, kind: /usb|logitech|razer|elgato/i.test(d.label) ? 'USB' : (virt.test(d.label) ? 'Virtual' : 'On this PC'), virtual: virt.test(d.label) }));
  renderDD();
  return M.cams;
}
function camLabel(c) { return c ? `${c.kind === 'Virtual' ? 'Virtual camera' : c.kind}${c.res ? ' · ' + c.res : ''}` : 'click to choose'; }
function renderDD() {
  const c = M.cam && M.cams.find(x => x.id === M.cam.id) || M.cam;
  const b = $('fmDDB');
  b.querySelector('.fmnm').innerHTML = `<b>${esc(c ? c.name : (M.cams.length ? 'Choose a camera' : 'No camera found'))}</b><span>${esc(c ? camLabel(c) : (M.cams.length ? 'click to choose' : 'plug one in, or Add a camera'))}</span>`;
}
function renderMenu() {
  const m = $('fmMenu'); m.innerHTML = '';
  const groups = {}; M.cams.forEach(c => (groups[c.virtual ? 'Virtual' : 'On this PC'] = groups[c.virtual ? 'Virtual' : 'On this PC'] || []).push(c));
  if (!M.cams.length) m.insertAdjacentHTML('beforeend', '<div class="fmgrp">No cameras found</div>');
  Object.entries(groups).forEach(([g, list]) => {
    m.insertAdjacentHTML('beforeend', `<div class="fmgrp">${g}</div>`);
    list.forEach(c => {
      const on = M.cam && M.cam.id === c.id;
      const it = document.createElement('div'); it.className = 'fmit' + (on ? ' on' : '');
      it.innerHTML = `<span class="ck">${on ? '✓' : ''}</span><span class="fmthumb">${on ? '<canvas width="92" height="60"></canvas>' : '<span style="display:flex;align-items:center;justify-content:center;height:100%;font-size:15px">📷</span>'}</span><span class="fmnm"><b>${esc(c.name)}</b><span>${esc(camLabel(c))}${c.virtual ? ' · shows a video, not a real camera' : ''}</span></span>`;
      it.onclick = () => { hideMenu(); useCam(c); };
      m.appendChild(it);
    });
  });
  m.insertAdjacentHTML('beforeend', '<div class="sepl"></div>');
  const add = document.createElement('div'); add.className = 'fmadd'; add.innerHTML = '<span class="fmplus">+</span><span class="fmnm"><b style="color:var(--green2)">Add a camera…</b><span>your phone, or a network camera</span></span>';
  add.onclick = () => { hideMenu(); openAdd(); }; m.appendChild(add);
  const rf = document.createElement('div'); rf.className = 'fmadd'; rf.style.color = 'var(--text)'; rf.innerHTML = '<span class="fmplus" style="border-color:#4A4A51">⟳</span><span class="fmnm"><b>Look for cameras again</b><span>after plugging one in</span></span>';
  rf.onclick = async e => { e.stopPropagation(); rf.querySelector('.fmnm span').textContent = 'looking…'; await listCams(); renderMenu(); }; m.appendChild(rf);
}
function hideMenu() { $('fmMenu').classList.add('hidden'); $('fmDDB').classList.remove('open'); }
async function useCam(c) {
  stopCam();
  M.cam = c; renderDD();
  const [w, h] = $('fmRes').value.split('x').map(Number);
  try {
    M.stream = await navigator.mediaDevices.getUserMedia({ video: { deviceId: c.id && !c.id.startsWith('cam') ? { exact: c.id } : undefined, width: { ideal: w }, height: { ideal: h } }, audio: false });
  } catch (e) {
    hint(e && e.name === 'NotAllowedError' ? 'The camera was blocked. Allow it when Windows asks, or in Settings → Privacy & security → Camera.' : `That camera couldn't start (${e && e.name || e}). Is another app using it?`, true);
    $('fmBadge').textContent = 'Camera off'; $('fmDot').classList.remove('on'); return;
  }
  const v = $('fmVideo'); v.srcObject = M.stream; await v.play().catch(() => {});
  const t = M.stream.getVideoTracks()[0], s = t.getSettings ? t.getSettings() : {};
  c.res = `${s.width || w} × ${s.height || h}`; M.W = s.width || v.videoWidth || w; M.H = s.height || v.videoHeight || h;
  // labels only appear after the first permission: list again so names show
  if (!c.name || /^Camera \d/.test(c.name)) { await listCams(); M.cam = M.cams.find(x => x.id === c.id) || c; }
  M.cam.res = c.res; renderDD();
  try { X().api().set_ui_pref('fmCam', M.cam.name); } catch (_) {}
  $('fmBadge').textContent = `${M.cam.name} · ${M.cam.res}`; $('fmDot').classList.add('on');
  hint(M.scan ? 'Pick a mask, then adjust it until it fits.' : 'Look at the camera, then press Start scanning.');
  layout();
}
function stopCam() { if (M.stream) { M.stream.getTracks().forEach(t => t.stop()); M.stream = null; } $('fmVideo').srcObject = null; $('fmDot').classList.remove('on');
  M.imgSrc = null; $('fmImg').classList.add('hidden'); $('fmImg').removeAttribute('src'); $('fmVideo').classList.remove('hidden'); }

// ------------------------------------------------------------------ face tracking
async function startTracking() {
  if (M.fm || !window.FaceMesh) return;
  M.fm = new window.FaceMesh({ locateFile: f => `vendor/facemesh/${f}` });
  M.fm.setOptions({ maxNumFaces: 1, refineLandmarks: true, minDetectionConfidence: 0.5, minTrackingConfidence: 0.5 });
  M.fm.onResults(r => { M.lm = (r.multiFaceLandmarks && r.multiFaceLandmarks[0]) || null; if (r.image) { M.W = r.image.width || M.W; M.H = r.image.height || M.H; } });
  try { await M.fm.initialize(); M.fmReady = true; } catch (e) { hint("Face tracking couldn't start on this PC: " + (e && e.message || e), true); }
}
function source() { if (M.imgSrc) return M.imgSrc; const v = $('fmVideo'); return v && v.readyState >= 2 ? v : null; }
async function tick() {
  if (!M.on) return;
  requestAnimationFrame(tick);
  const src = source();
  if (src && M.fmReady && !M.busy) {
    M.busy = true; const t0 = performance.now();
    try { await M.fm.send({ image: src }); } catch (_) {}
    M.busy = false; const dt = performance.now() - t0; M.fps = M.fps * 0.9 + (1000 / Math.max(1, dt)) * 0.1;
    $('fmFps').textContent = M.lm ? `tracking · ${Math.round(M.fps)} fps` : 'no face in view';
    if (M.scanning) scanStep();
  }
  drawThumb(); renderOverlay(); if (M.view !== 'live' && three3) render3d();
}
function drawThumb() {
  const src = source(); if (!src) return;
  document.querySelectorAll('#fmDD .fmddb canvas, #fmMenu .fmit.on canvas').forEach(cv => { try { cv.getContext('2d').drawImage(src, 0, 0, cv.width, cv.height); } catch (_) {} });
}

// ------------------------------------------------------------------ geometry helpers
function initTopology() {
  if (TRIS) return;
  const E = window.FACEMESH_TESSELATION || [], tris = [];
  for (let i = 0; i + 2 < E.length; i += 3) {
    const [a, b] = E[i], [b2, c] = E[i + 1], [c2, a2] = E[i + 2];
    if (b === b2 && c === c2 && a === a2) tris.push([a, b, c]);
  }
  TRIS = tris;
  const loop = arr => [...new Set((arr || []).flat())];
  EYE_R = loop(window.FACEMESH_RIGHT_EYE); EYE_L = loop(window.FACEMESH_LEFT_EYE); LIPS_IN = loop(window.FACEMESH_LIPS);
}
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]], mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2], cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = a => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
const mean = (P, ids) => { let s = [0, 0, 0]; ids.forEach(i => s = add(s, P[i])); return mul(s, 1 / ids.length); };
// landmarks -> points in face coords (mm): x right, y up, z towards the camera; and how many mm one pixel is
function toFace(lm, W, H) {
  const px = lm.map(p => [p.x * W, p.y * H, p.z * W]);
  const iris = c => { const d1 = Math.hypot(px[c + 1][0] - px[c + 3][0], px[c + 1][1] - px[c + 3][1]), d2 = Math.hypot(px[c + 2][0] - px[c + 4][0], px[c + 2][1] - px[c + 4][1]); return (d1 + d2) / 2; };
  const irisPx = lm.length >= 478 ? (iris(468) + iris(473)) / 2 : 0;
  const mmpp = irisPx > 2 ? IRIS_MM / irisPx : 0.25;
  return { P: px.map(p => [p[0] * mmpp, -p[1] * mmpp, -p[2] * mmpp]), mmpp };
}
// the face's own frame: origin between the eyes, x across, y up the face, z out of it
function frameOf(P) {
  const eR = mean(P, [33, 133]), eL = mean(P, [263, 362]), o = mul(add(eR, eL), 0.5);
  const ex = norm(sub(eL, eR)); let up = norm(sub(P[10], P[152])); const ey = norm(sub(up, mul(ex, dot(up, ex)))); const ez = cross(ex, ey);
  return { o, ex, ey, ez };
}
const toCanon = (P, F) => P.map(p => { const d = sub(p, F.o); return [dot(d, F.ex), dot(d, F.ey), dot(d, F.ez)]; });

// ------------------------------------------------------------------ scanning: average many frames in the face's own frame
function startScan() {
  if (!M.lm) { hint('No face found yet. Look straight at the camera with your face well lit.', true); return; }
  M.frames = []; M.scanning = true; $('fmScan').textContent = 'Scanning…'; $('fmScan').disabled = true; hint('Turn your head slowly to the left… then to the right.');
}
function scanStep() {
  if (!M.lm || M.lm.length < 468) return;
  const { P, mmpp } = toFace(M.lm, M.W, M.H); const F = frameOf(P);
  const yaw = Math.atan2(F.ex[2], F.ex[0]) * 180 / Math.PI;
  M.frames.push({ C: toCanon(P.slice(0, 468), F), yaw, mmpp });
  const n = M.frames.length, need = 45, yaws = M.frames.map(f => f.yaw), spread = Math.max(...yaws) - Math.min(...yaws);
  const pct = Math.min(100, Math.round(n / need * 70 + Math.min(30, spread)));
  $('fmMeter').style.width = pct + '%';
  $('fmMeterT').textContent = pct < 100 ? `Scanning… ${pct}%  ${spread < 20 ? '(turn your head a little more to the ' + (yaw > 0 ? 'right' : 'left') + ')' : ''}` : 'Done.';
  if (pct >= 100) finishScan();
}
function finishScan() {
  M.scanning = false; $('fmScan').disabled = false; $('fmScan').textContent = 'Start scanning';
  // average each point over the frames where it's most reliable (facing the camera most)
  const fr = M.frames, n = fr.length, C = [];
  for (let i = 0; i < 468; i++) { let s = [0, 0, 0], w = 0; fr.forEach(f => { const ww = Math.cos(f.yaw * Math.PI / 180) ** 2; s = add(s, mul(f.C[i], ww)); w += ww; }); C.push(mul(s, 1 / w)); }
  const width = Math.abs(C[454][0] - C[234][0]);
  M.scan = { C, width, measured: width };
  $('fmWidth').value = width.toFixed(0); $('fmRescan').classList.remove('hidden');
  $('fmMeterT').textContent = `Done: 468 points from ${n} pictures. Face width ${width.toFixed(0)} mm (from the size of your irises).`;
  try { X().api().set_ui_pref('faceScan', { C: C.map(p => p.map(v => +v.toFixed(2))), width }); } catch (_) {}
  setStep('fit'); M.maskKey = '';
}
function scanScaled() {      // the scan, resized if you typed your real face width
  if (!M.scan) return null; const w = parseFloat($('fmWidth').value); const k = isFinite(w) && w > 60 && w < 250 ? w / M.scan.width : 1;
  return M.scan.C.map(p => mul(p, k));
}

// ------------------------------------------------------------------ the mask: the face surface in the mask's outline, pushed out by the gap, thickness added
function buildMask(C) {
  initTopology();
  const ud = M.ud, sz = M.size / 100, type = M.type;
  const eye = ids => { const c = mean(C, ids); let rx = 0, ry = 0; ids.forEach(i => { rx = Math.max(rx, Math.abs(C[i][0] - c[0])); ry = Math.max(ry, Math.abs(C[i][1] - c[1])); }); return { c, rx: rx * 1.35 + 2, ry: ry * 1.6 + 2 }; };
  const eR = eye(EYE_R), eL = eye(EYE_L), lips = eye(LIPS_IN);
  const inEll = (p, e, k = 1) => ((p[0] - e.c[0]) / (e.rx * k)) ** 2 + ((p[1] - e.c[1]) / (e.ry * k)) ** 2 < 1;
  const chinY = C[152][1], browY = Math.max(C[105][1], C[334][1]), halfW = Math.abs(C[454][0] - C[234][0]) / 2;
  const keep = t => {
    const c = mul(add(add(C[t[0]], C[t[1]]), C[t[2]]), 1 / 3), y = c[1] - ud;
    if (Math.abs(c[0]) > halfW * 0.98 * sz) return false;
    if (type === 0) {
      if (y < -13 * sz || y > browY + 8 * sz) return false; if (inEll(c, eR) || inEll(c, eL)) return false;
      if (Math.abs(c[0]) < 11 * sz && y < -4) return false;            // a bridge over the nose, not down it
      return true; }
    if (type === 1) { if (y > -6) return false; if (y < chinY - 2) return false; return true; }
    if (inEll(c, eR) || inEll(c, eL)) return false;
    if ($('fmMouth').checked && inEll(c, lips, 0.75)) return false;
    return y < browY + 30 * sz;
  };
  let tris = TRIS.filter(keep);
  // no "pinch" points (two bits of mask touching at one corner): they can't be made into a closed solid, so trim them
  for (let guard = 0; guard < 20; guard++) {
    const cnt = new Map(); tris.forEach(([a, b, c]) => [[a, b], [b, c], [c, a]].forEach(([x, y]) => { const k = x < y ? x + ',' + y : y + ',' + x; cnt.set(k, (cnt.get(k) || 0) + 1); }));
    const bdeg = new Map(); cnt.forEach((v, k) => { if (v === 1) k.split(',').forEach(i => bdeg.set(+i, (bdeg.get(+i) || 0) + 1)); });
    const pinch = new Set([...bdeg].filter(([, d]) => d > 2).map(([i]) => i));
    if (!pinch.size) break;
    tris = tris.filter(t => !t.some(i => pinch.has(i)));
  }
  if (!tris.length) return null;
  // make the surface smoother: split every triangle in four twice, smoothing the inner points
  let V = C.map(p => p.slice()), T = tris.map(t => t.slice());
  for (let pass = 0; pass < 2; pass++) {
    const mid = new Map(), NT = [];
    const m = (a, b) => { const k = a < b ? a + ',' + b : b + ',' + a; if (!mid.has(k)) { mid.set(k, V.length); V.push(mul(add(V[a], V[b]), 0.5)); } return mid.get(k); };
    T.forEach(([a, b, c]) => { const ab = m(a, b), bc = m(b, c), ca = m(c, a); NT.push([a, ab, ca], [ab, b, bc], [ca, bc, c], [ab, bc, ca]); });
    T = NT;
    const nb = V.map(() => new Set()), cnt = new Map();
    T.forEach(([a, b, c]) => { nb[a].add(b).add(c); nb[b].add(a).add(c); nb[c].add(a).add(b); [[a, b], [b, c], [c, a]].forEach(([x, y]) => { const k = x < y ? x + ',' + y : y + ',' + x; cnt.set(k, (cnt.get(k) || 0) + 1); }); });
    const bnd = new Set(), bnb = new Map(); cnt.forEach((v, k) => { if (v === 1) { const [x, y] = k.split(',').map(Number); bnd.add(x); bnd.add(y); (bnb.get(x) || bnb.set(x, []).get(x)).push(y); (bnb.get(y) || bnb.set(y, []).get(y)).push(x); } });
    // inner points: smoothed over their neighbours; edge points: smoothed along the edge only (a smooth outline, no jaggies)
    V = V.map((p, i) => {
      if (bnd.has(i)) { const nn = bnb.get(i) || []; if (nn.length !== 2) return p; const s = mul(add(V[nn[0]], V[nn[1]]), 0.5); return add(mul(p, 0.5), mul(s, 0.5)); }
      if (!nb[i].size) return p; let s = [0, 0, 0]; nb[i].forEach(j => s = add(s, V[j])); s = mul(s, 1 / nb[i].size); return add(mul(p, 0.6), mul(s, 0.4)); });
  }
  // keep only the vertices used, with normals
  const used = [...new Set(T.flat())], re = new Map(used.map((v, i) => [v, i]));
  const P = used.map(i => V[i]), TT = T.map(t => t.map(i => re.get(i)));
  const N = P.map(() => [0, 0, 0]);
  TT.forEach(([a, b, c]) => { const n = cross(sub(P[b], P[a]), sub(P[c], P[a])); [a, b, c].forEach(i => N[i] = add(N[i], n)); });
  for (let i = 0; i < N.length; i++) { N[i] = norm(N[i]); if (N[i][2] < 0) N[i] = mul(N[i], -1); }
  // inner skin (gap off the face) and outer skin (+ thickness); sides along every open edge
  const nP = P.length, out = [], idx = [];
  P.forEach((p, i) => out.push(add(p, mul(N[i], M.gap))));
  P.forEach((p, i) => out.push(add(p, mul(N[i], M.gap + M.th))));
  TT.forEach(([a, b, c]) => { const n = cross(sub(P[b], P[a]), sub(P[c], P[a])); const fwd = n[2] >= 0;
    if (fwd) { idx.push(a + nP, b + nP, c + nP, a, c, b); } else { idx.push(a + nP, c + nP, b + nP, a, b, c); } });
  const ecount = new Map();
  TT.forEach(([a, b, c]) => { const n = cross(sub(P[b], P[a]), sub(P[c], P[a])); const tri = n[2] >= 0 ? [a, b, c] : [a, c, b];
    [[tri[0], tri[1]], [tri[1], tri[2]], [tri[2], tri[0]]].forEach(([x, y]) => { const k = x < y ? x + ',' + y : y + ',' + x; const e = ecount.get(k); ecount.set(k, e ? { n: e.n + 1 } : { n: 1, x, y }); }); });
  ecount.forEach(e => { if (e.n !== 1) return; const { x, y } = e; idx.push(x, x + nP, y + nP, x, y + nP, y); });
  return { V: out, I: idx, faceP: P };
}

// ------------------------------------------------------------------ drawing: the live overlay (on the camera picture) and the 3D view
function ensureThree() {
  const c = X(); if (!c || three) return; const T = c.THREE;
  const r = new T.WebGLRenderer({ canvas: $('fmCanvas'), alpha: true, antialias: true });
  const sc = new T.Scene(); sc.add(new T.HemisphereLight(0xffffff, 0x445544, 1.0)); const dl = new T.DirectionalLight(0xffffff, 0.7); dl.position.set(0.3, 0.5, 1); sc.add(dl);
  const cam = new T.OrthographicCamera(0, 1, 0, -1, -5000, 5000);
  const mat = new T.MeshStandardMaterial({ color: 0x00AE42, roughness: 0.45, metalness: 0.05, transparent: true, opacity: 0.78, side: T.DoubleSide });
  const mesh = new T.Mesh(new T.BufferGeometry(), mat); mesh.matrixAutoUpdate = false; sc.add(mesh);
  const pts = new T.Points(new T.BufferGeometry(), new T.PointsMaterial({ color: 0x1CC25A, size: 2.5, sizeAttenuation: false })); pts.frustumCulled = false; sc.add(pts);
  three = { T, r, sc, cam, mesh, pts };
}
function layout() {
  const st = $('fmStage'), sw = st.clientWidth, sh = st.clientHeight; if (!sw) return;
  const k = Math.min(sw / M.W, sh / M.H), w = Math.round(M.W * k), h = Math.round(M.H * k);
  [$('fmVideo'), $('fmImg'), $('fmCanvas')].forEach(el => { el.style.width = w + 'px'; el.style.height = h + 'px'; el.style.left = Math.round((sw - w) / 2) + 'px'; el.style.top = Math.round((sh - h) / 2) + 'px'; });
  if (three) { three.r.setPixelRatio(devicePixelRatio); three.r.setSize(w, h, false); three.cam.left = 0; three.cam.right = M.W; three.cam.top = 0; three.cam.bottom = -M.H; three.cam.updateProjectionMatrix(); }
}
function maskGeometry(T, mk) {
  const g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(mk.V.flat(), 3)); g.setIndex(mk.I); g.computeVertexNormals(); return g;
}
function currentMask() {
  const C = scanScaled(); if (!C) return null;
  const key = JSON.stringify([M.type, M.size, M.gap, M.th, M.ud, $('fmMouth').checked, $('fmWidth').value]);
  if (key !== M.maskKey) { M.mask = buildMask(C); M.maskKey = key; if (three && M.mask) { three.mesh.geometry.dispose(); three.mesh.geometry = maskGeometry(three.T, M.mask); } if (three3) three3.dirty = true; }
  return M.mask;
}
function renderOverlay() {
  ensureThree(); if (!three) return; const T = three.T;
  if (M.W !== three._w || M.H !== three._h) { three._w = M.W; three._h = M.H; layout(); }
  const live = M.view === 'live';
  $('fmCanvas').classList.toggle('hidden', !live);
  if (!live) return;
  three.mesh.visible = false; three.pts.visible = false;
  if (M.lm && M.lm.length >= 468) {
    const { P, mmpp } = toFace(M.lm, M.W, M.H);
    if (M.step === 'scan' || !M.scan) {   // show the measured points while scanning
      const arr = []; P.forEach(p => arr.push(p[0] / mmpp, p[1] / mmpp, p[2] / mmpp));
      three.pts.geometry.setAttribute('position', new T.Float32BufferAttribute(arr, 3)); three.pts.visible = true;
    } else if (currentMask()) {
      // put the mask (made in the face's own frame, mm) onto the face as it is right now (camera pixels)
      const F = frameOf(P), s = 1 / mmpp;
      const m4 = new T.Matrix4().set(F.ex[0] * s, F.ey[0] * s, F.ez[0] * s, F.o[0] * s, F.ex[1] * s, F.ey[1] * s, F.ez[1] * s, F.o[1] * s, F.ex[2] * s, F.ey[2] * s, F.ez[2] * s, F.o[2] * s, 0, 0, 0, 1);
      three.mesh.matrix.copy(m4); three.mesh.matrixWorldNeedsUpdate = true; three.mesh.visible = true;
    }
  }
  three.r.render(three.sc, three.cam);
}
function ensure3d() {
  const c = X(); if (!c || three3) return; const T = c.THREE;
  const r = new T.WebGLRenderer({ canvas: $('fm3d'), antialias: true }); r.setClearColor(0x1e1e22, 1);
  const sc = new T.Scene(); sc.add(new T.HemisphereLight(0xffffff, 0x554433, 1.1)); const dl = new T.DirectionalLight(0xffffff, 0.6); dl.position.set(80, 120, 300); sc.add(dl);
  const cam = new T.PerspectiveCamera(30, 1, 1, 5000); cam.position.set(0, 0, 520);
  const grp = new T.Group(); sc.add(grp);
  const face = new T.Mesh(new T.BufferGeometry(), new T.MeshStandardMaterial({ color: 0xd9a787, roughness: 0.75, side: T.DoubleSide })); grp.add(face);
  const mask = new T.Mesh(new T.BufferGeometry(), new T.MeshStandardMaterial({ color: 0x00AE42, roughness: 0.4, side: T.DoubleSide })); grp.add(mask);
  three3 = { T, r, sc, cam, grp, face, mask, dirty: true, rot: { x: 0, y: 0.5 } };
  const cv = $('fm3d'); let d = null;
  cv.onpointerdown = e => { d = { x: e.clientX, y: e.clientY, r: { ...three3.rot } }; cv.setPointerCapture(e.pointerId); };
  cv.onpointermove = e => { if (!d) return; three3.rot.y = d.r.y + (e.clientX - d.x) * 0.01; three3.rot.x = Math.max(-1.2, Math.min(1.2, d.r.x + (e.clientY - d.y) * 0.01)); };
  cv.onpointerup = () => d = null;
  cv.onwheel = e => { e.preventDefault(); cam.position.z = Math.max(180, Math.min(1200, cam.position.z * (e.deltaY > 0 ? 1.1 : 0.9))); };
}
function render3d() {
  ensure3d(); const t = three3; if (!t) return; const T = t.T;
  const st = $('fmStage'), w = st.clientWidth, h = st.clientHeight; const cv = $('fm3d');
  cv.style.width = w + 'px'; cv.style.height = h + 'px'; cv.style.left = '0px'; cv.style.top = '0px';
  if (t._w !== w || t._h !== h) { t._w = w; t._h = h; t.r.setPixelRatio(devicePixelRatio); t.r.setSize(w, h, false); t.cam.aspect = w / h; t.cam.updateProjectionMatrix(); }
  if (t.dirty) {
    t.dirty = false; const C = scanScaled(); initTopology();
    if (C) { const g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(C.flat(), 3)); g.setIndex(TRIS.flat()); g.computeVertexNormals(); t.face.geometry.dispose(); t.face.geometry = g; }
    const mk = currentMask(); if (mk) { t.mask.geometry.dispose(); t.mask.geometry = maskGeometry(T, mk); }
  }
  t.face.visible = M.view === 'face'; t.mask.visible = !!M.mask;
  if (!d3moving()) t.rot.y += 0.0;   // still unless you drag
  t.grp.rotation.set(t.rot.x, t.rot.y, 0);
  t.r.render(t.sc, t.cam);
}
const d3moving = () => false;

// ------------------------------------------------------------------ the panel
function setStep(s) {
  if (s !== 'scan' && !M.scan) { hint('Scan your face first (step 1).', true); s = 'scan'; }
  M.step = s; document.querySelectorAll('#fmSteps span').forEach(x => x.classList.toggle('on', x.dataset.s === s));
  $('fmPScan').classList.toggle('hidden', s !== 'scan'); $('fmPFit').classList.toggle('hidden', s !== 'fit'); $('fmPPrint').classList.toggle('hidden', s !== 'print');
  hint({ scan: M.scan ? 'Your face is scanned. Scan again, or go to 2 Fit.' : 'Look at the camera, then press Start scanning.', fit: 'The mask sits on your face live. Adjust it until it fits.', print: 'Ready: send it to Model and plates.' }[s]);
}
function setView(v) {
  M.view = v; document.querySelectorAll('#fmView span').forEach(x => x.classList.toggle('on', x.dataset.v === v));
  $('fm3d').classList.toggle('hidden', v === 'live'); $('fmCanvas').classList.toggle('hidden', v !== 'live');
  if (M.imgSrc) $('fmImg').classList.toggle('hidden', v !== 'live'); else $('fmVideo').classList.toggle('hidden', v !== 'live');
  if (three3) three3.dirty = true;
}
function hint(t, bad) { $('fmHint').textContent = t; $('fmHint').style.color = bad ? '#FAC775' : ''; }
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
function bindSlider(id, key) {
  const r = $(id), n = $(id + 'N'); const show = () => { r.value = M[key]; if (document.activeElement !== n) n.value = M[key]; };
  r.oninput = () => { M[key] = +r.value; n.value = r.value; };
  n.onchange = () => { const v = parseFloat(n.value); if (isFinite(v)) M[key] = Math.min(+r.max, Math.max(+r.min, v)); show(); };
  n.onkeydown = e => { if (e.key === 'Enter') n.blur(); }; show();
}
function openAdd() { $('fmAdd').classList.remove('hidden'); tab('phone'); }
function tab(k) { document.querySelectorAll('#fmAddTabs span').forEach(s => s.classList.toggle('on', s.dataset.t === k)); $('fmAddPhone').classList.toggle('hidden', k !== 'phone'); $('fmAddNet').classList.toggle('hidden', k !== 'net'); }
function wire() {
  $('fmDDB').onclick = async e => { e.stopPropagation(); const m = $('fmMenu'), show = m.classList.contains('hidden'); if (show) { await listCams(); renderMenu(); } m.classList.toggle('hidden', !show); $('fmDDB').classList.toggle('open', show); };
  document.addEventListener('click', e => { if (!e.target.closest('#fmDD')) hideMenu(); });
  $('fmRes').onchange = () => { if (M.cam) useCam(M.cam); };
  $('fmMirror').onchange = () => $('fmStage').classList.toggle('mirror', $('fmMirror').checked);
  $('fmBright').onchange = () => $('fmStage').classList.toggle('bright', $('fmBright').checked);
  document.querySelectorAll('#fmSteps span').forEach(s => s.onclick = () => setStep(s.dataset.s));
  $('fmScan').onclick = startScan; $('fmRescan').onclick = () => { M.scan = null; setStep('scan'); startScan(); };
  $('fmWidth').onchange = () => { M.maskKey = ''; if (three3) three3.dirty = true; };
  $('fmTiles').innerHTML = TYPES.map(([n, d], i) => `<div class="fmtile ${i === M.type ? 'on' : ''}" data-i="${i}"><svg viewBox="0 0 46 30"><path d="${d}" fill="#00AE42"/>${i !== 1 ? '<ellipse cx="15" cy="12" rx="4" ry="2.5" fill="#35353A"/><ellipse cx="31" cy="12" rx="4" ry="2.5" fill="#35353A"/>' : ''}</svg>${n}</div>`).join('');
  $('fmTiles').querySelectorAll('.fmtile').forEach(t => t.onclick = () => { M.type = +t.dataset.i; $('fmTiles').querySelectorAll('.fmtile').forEach(x => x.classList.toggle('on', x === t)); });
  [['fmSize', 'size'], ['fmGap', 'gap'], ['fmTh', 'th'], ['fmUd', 'ud']].forEach(([id, k]) => bindSlider(id, k));
  document.querySelectorAll('#fmPFit .trs').forEach(b => b.onclick = () => { M[b.dataset.r] = DEF[b.dataset.r]; [['fmSize', 'size'], ['fmGap', 'gap'], ['fmTh', 'th'], ['fmUd', 'ud']].forEach(([id, k]) => { $(id).value = M[k]; $(id + 'N').value = M[k]; }); });
  document.querySelectorAll('#fmView span').forEach(s => s.onclick = () => setView(s.dataset.v));
  $('fmSend').onclick = sendMask;
  // add a camera
  $('fmAddX').onclick = () => $('fmAdd').classList.add('hidden');
  document.querySelectorAll('#fmAddTabs span').forEach(s => s.onclick = () => tab(s.dataset.t));
  $('fmLook').onclick = async () => { const before = M.cams.length; $('fmLookT').textContent = 'Looking…'; await listCams(); $('fmLookT').textContent = M.cams.length > before ? `Found ${M.cams.length - before} new camera${M.cams.length - before > 1 ? 's' : ''}: pick it in the list.` : `${M.cams.length} camera${M.cams.length === 1 ? '' : 's'} found. If your phone isn't there yet, check its app is running.`; };
  $('fmUrl').oninput = () => { if (!$('fmUName').dataset.typed) { const m = $('fmUrl').value.match(/\/\/([^/:]+)/); $('fmUName').value = m ? 'Camera at ' + m[1] : ''; } };
  $('fmUName').oninput = () => $('fmUName').dataset.typed = 1;
  const netOk = u => /^(https?):\/\//i.test(u);
  $('fmTest').onclick = () => { const u = $('fmUrl').value.trim(); if (!netOk(u)) { $('fmTestT').innerHTML = '<span style="color:#FAC775">Paste an http:// camera address.</span>'; return; }
    const img = new Image(); img.crossOrigin = 'anonymous'; $('fmTestT').textContent = 'Testing…';
    img.onload = () => $('fmTestT').innerHTML = `<span style="color:#5DCAA5">✓ Picture received (${img.naturalWidth} × ${img.naturalHeight})</span>`;
    img.onerror = () => $('fmTestT').innerHTML = '<span style="color:#FAC775">No picture from that address. Check it in a web browser first.</span>'; img.src = u; };
  $('fmAddNetB').onclick = () => { const u = $('fmUrl').value.trim(); if (!netOk(u)) { $('fmTestT').innerHTML = '<span style="color:#FAC775">Paste an http:// camera address.</span>'; return; }
    const c = { id: 'net:' + u, name: $('fmUName').value || 'Network camera', kind: 'Network', url: u }; M.cams.push(c); $('fmAdd').classList.add('hidden'); useNet(c); };
  new ResizeObserver(layout).observe($('fmStage'));
  try { navigator.mediaDevices.addEventListener('devicechange', () => listCams()); } catch (_) {}
}
function showImg(img) {   // a picture source (network camera): show it where the video would be
  const el = $('fmImg'); el.src = img.src; el.classList.remove('hidden'); $('fmVideo').classList.add('hidden'); M.imgSrc = img;
}
function useNet(c) {   // a network camera that gives pictures at a web address (MJPEG or a still picture)
  stopCam(); M.cam = c; renderDD();
  const img = $('fmImg'); img.crossOrigin = 'anonymous';
  img.onload = () => { M.W = img.naturalWidth; M.H = img.naturalHeight; layout(); };
  img.src = c.url; img.classList.remove('hidden'); $('fmVideo').classList.add('hidden'); M.imgSrc = img;
  $('fmBadge').textContent = c.name; $('fmDot').classList.add('on');
}
async function sendMask() {
  const mk = currentMask(); if (!mk) { hint('Scan your face and pick a mask first.', true); return; }
  // printing position: the inside facing the plate, sitting on it (Model and plates can turn it to the best way up)
  const lo = Math.min(...mk.V.map(p => p[2]));
  const verts = []; mk.V.forEach(p => verts.push(+p[0].toFixed(3), +p[1].toFixed(3), +(p[2] - lo).toFixed(3)));
  const c = X(); const d = await c.longJob('Making the mask…', () => c.api().mask_to_project($('fmName').value.trim() || 'My mask', verts, mk.I));
  if (!d || d.error) { hint((d && d.error) || "Couldn't make the mask.", true); return; }
  await c.show(d); c.pushUndo('Add a mask'); window.studio.goStep(1); c.status('The mask is on the plate. A copy is saved in Documents\\BambuForge\\Masks.');
}

// ------------------------------------------------------------------ open / close the step
async function enter() {
  if (M.on) return; M.on = true;
  $('fmStage').classList.toggle('mirror', $('fmMirror').checked);
  initTopology(); ensureThree();
  // a scan you made before
  try { const ui = await X().api().ui_prefs(); if (!M.scan && ui.faceScan && ui.faceScan.C) { M.scan = { C: ui.faceScan.C, width: ui.faceScan.width, measured: ui.faceScan.width }; $('fmWidth').value = (+ui.faceScan.width).toFixed(0); $('fmRescan').classList.remove('hidden'); $('fmMeterT').textContent = 'Using your last scan. Scan again any time.'; }
    if (!M.cam) { await listCams(); const want = ui.fmCam && M.cams.find(c => c.name === ui.fmCam); const first = want || M.cams.find(c => !c.virtual) || M.cams[0]; if (first) useCam(first); else hint('No camera found. Plug one in, or use Add a camera in the list on the right.', true); }
    else useCam(M.cam);
  } catch (_) {}
  startTracking(); requestAnimationFrame(tick); setStep(M.scan ? 'fit' : 'scan'); layout();
}
function leave() { if (!M.on) return; M.on = false; stopCam(); M.scanning = false; }
(function boot() {
  if (!X() || !$('fmStage')) { setTimeout(boot, 200); return; }
  wire();
  window.masks = { enter, leave, _state: () => M, _feedImage: url => { const img = $('fmImg'); img.onload = () => { M.W = img.naturalWidth; M.H = img.naturalHeight; layout(); }; img.src = url; img.classList.remove('hidden'); $('fmVideo').classList.add('hidden'); M.imgSrc = img; } };
})();
