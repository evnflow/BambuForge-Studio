# Building the portable release

The portable zip is: `BambuForge Studio.exe` (from `launcher/Launcher.cs`), `python/` (python-build-standalone 3.12, trimmed),
`lib/` (Windows wheels: numpy, trimesh, manifold3d, pywebview, pythonnet, paho-mqtt, …), `app/` (this repo's `app/`),
and `engine/` (Bambu Studio's official Windows build, trimmed to the slicer: `bambu-studio.exe` renamed `bambuforge-slicer.exe`,
its DLLs, `resources/profiles`, `shaders`, `printers`, `flush`, `info`, `data`, `filament_mixing`, `cert`, English `hms` files,
plus Microsoft's VC++ runtime DLLs).

Compile the launcher: `csc /target:winexe /win32icon:assets\BambuForgeStudio.ico /out:"BambuForge Studio.exe" launcher\Launcher.cs`
(or `mcs` on Linux with `-r:System.Windows.Forms.dll -r:System.Drawing.dll -r:System.Core.dll`).
