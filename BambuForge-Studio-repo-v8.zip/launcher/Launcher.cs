using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: System.Reflection.AssemblyTitle("BambuForge Studio")]
[assembly: System.Reflection.AssemblyVersion("2.0.0.0")]

// BambuForge Studio.exe: no install needed. Checks for Microsoft WebView2 (asks before installing it), starts the
// app with its own Python, and keeps a tray icon for Open / Copy logs / Quit and print alerts.
static class Launcher
{
    static readonly string Data = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "BambuForgeStudio");
    static readonly string Dir = AppDomain.CurrentDomain.BaseDirectory;
    static Process app;
    static NotifyIcon tray;

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    static extern bool DeleteFile(string name);

    [STAThread]
    static int Main(string[] args)
    {
        Directory.CreateDirectory(Data);
        if (args.Length > 0 && args[0] == "--logs") return CopyLogs();
        bool first;
        using (var mutex = new Mutex(true, "Evnflow.BambuForgeStudio.Launcher", out first))
        {
            if (!first) { Ipc("show"); return 0; }          // already running: just bring the window back
            Application.EnableVisualStyles();
            string py = Path.Combine(Dir, "python", "pythonw.exe"), main = Path.Combine(Dir, "app", "app.py");
            if (!File.Exists(py) || !File.Exists(main))
            {
                MessageBox.Show("Some of BambuForge Studio's files are missing.\n\nUnzip the whole download again (keep everything in the same folder).", "BambuForge Studio", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return 1;
            }
            Unblock();
            if (!EnsureWebView2()) return 2;
            var psi = new ProcessStartInfo(py, "\"" + main + "\"" + string.Concat(args.Select(a => " \"" + a.Replace("\"", "") + "\"")))
            { UseShellExecute = false, WorkingDirectory = Path.GetDirectoryName(main), CreateNoWindow = true };
            psi.EnvironmentVariables["PYTHONPATH"] = Path.Combine(Dir, "lib") + ";" + Path.Combine(Dir, "app");
            psi.EnvironmentVariables["PYTHONNOUSERSITE"] = "1";
            psi.EnvironmentVariables["BFS_TRAY"] = "1";
            string flag = Path.Combine(Data, "ready.flag");
            try { if (File.Exists(flag)) File.Delete(flag); } catch { }
            app = Process.Start(psi);
            for (int i = 0; i < 90 * 4 && !File.Exists(flag); i++)
            {
                if (app.WaitForExit(250))
                {
                    if (app.ExitCode != 0) Fail("BambuForge Studio stopped while starting (code " + app.ExitCode + ").");
                    return app.ExitCode == 0 ? 0 : 2;
                }
            }
            if (!File.Exists(flag) && !app.HasExited) Fail("BambuForge Studio is still starting after 90 seconds and hasn't shown its window.");
            RunTray();
            return 0;
        }
    }

    // ---------------------------------------------------------------- the files came from the internet: Windows marks
    // every one of them, and .NET then refuses to load the app's parts. You already chose "Run anyway", so clear the marks.
    static void Unblock()
    {
        string stamp = Path.Combine(Dir, "app", ".unblocked");
        if (File.Exists(stamp)) return;
        try
        {
            foreach (var f in Directory.EnumerateFiles(Dir, "*", SearchOption.AllDirectories)) DeleteFile(f + ":Zone.Identifier");
            File.WriteAllText(stamp, DateTime.Now.ToString("s"));
        }
        catch { }
    }

    // ---------------------------------------------------------------- Microsoft Edge WebView2 draws the window
    static bool HasWebView2()
    {
        const string id = "{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}";
        string[] keys = { @"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\" + id, @"SOFTWARE\Microsoft\EdgeUpdate\Clients\" + id };
        foreach (var hive in new[] { Registry.LocalMachine, Registry.CurrentUser })
            foreach (var k in keys)
                using (var key = hive.OpenSubKey(k))
                {
                    var v = key == null ? null : key.GetValue("pv") as string;
                    if (!string.IsNullOrEmpty(v) && v != "0.0.0.0") return true;
                }
        return false;
    }

    static bool EnsureWebView2()
    {
        if (HasWebView2()) return true;
        var r = MessageBox.Show("BambuForge Studio needs one small free part from Microsoft: Microsoft Edge WebView2. It draws the program's window, and it isn't on this PC yet.\n\n" +
                                "Download and install it now? (About 2 MB, takes about a minute. Nothing else on your PC changes.)",
                                "BambuForge Studio", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        if (r != DialogResult.Yes)
        {
            MessageBox.Show("OK. BambuForge Studio can't open its window without it. It will ask again next time you start it.", "BambuForge Studio");
            return false;
        }
        string setup = Path.Combine(Path.GetTempPath(), "MicrosoftEdgeWebview2Setup.exe");
        try
        {
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;    // TLS 1.2
            using (var wc = new WebClient()) wc.DownloadFile("https://go.microsoft.com/fwlink/p/?LinkId=2124703", setup);
            var p = Process.Start(new ProcessStartInfo(setup, "/silent /install") { UseShellExecute = true });
            p.WaitForExit(10 * 60 * 1000);
        }
        catch (Exception ex) { Log("WebView2 install failed: " + ex.Message); }
        finally { try { File.Delete(setup); } catch { } }
        for (int i = 0; i < 20 && !HasWebView2(); i++) Thread.Sleep(500);
        if (HasWebView2()) return true;
        if (MessageBox.Show("WebView2 couldn't be installed automatically. Open Microsoft's download page so you can install it yourself?\n\n(Choose the \"Evergreen Bootstrapper\", then start BambuForge Studio again.)",
                            "BambuForge Studio", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            try { Process.Start("https://developer.microsoft.com/microsoft-edge/webview2/"); } catch { }
        return false;
    }

    // ---------------------------------------------------------------- tray icon: Open, Copy logs, Quit, and print alerts
    static void RunTray()
    {
        tray = new NotifyIcon { Text = "BambuForge Studio", Visible = true };
        try { tray.Icon = new System.Drawing.Icon(Path.Combine(Dir, "BambuForgeStudio.ico")); } catch { tray.Icon = System.Drawing.SystemIcons.Application; }
        var menu = new ContextMenuStrip();
        menu.Items.Add("Open BambuForge Studio", null, (s, e) => Ipc("show"));
        menu.Items.Add("Copy logs (for help)", null, (s, e) => CopyLogs());
        menu.Items.Add("Open the log folder", null, (s, e) => { try { Process.Start("explorer.exe", "\"" + Data + "\""); } catch { } });
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Quit", null, (s, e) => Quit());
        tray.ContextMenuStrip = menu;
        tray.DoubleClick += (s, e) => Ipc("show");
        tray.BalloonTipClicked += (s, e) => Ipc("show");
        var timer = new System.Windows.Forms.Timer { Interval = 1000 };
        timer.Tick += (s, e) =>
        {
            if (app.HasExited) { tray.Visible = false; Application.Exit(); return; }
            ShowNotifications();
        };
        timer.Start();
        Application.Run();
        tray.Visible = false;
    }

    static void ShowNotifications()
    {
        string dir = Path.Combine(Data, "notify");
        if (!Directory.Exists(dir)) return;
        foreach (var f in Directory.GetFiles(dir, "*.json").OrderBy(x => x))
        {
            try
            {
                string json = File.ReadAllText(f, Encoding.UTF8);
                File.Delete(f);
                string title = Field(json, "title"), text = Field(json, "text"), kind = Field(json, "kind");
                tray.ShowBalloonTip(8000, title, text, kind == "error" ? ToolTipIcon.Error : kind == "warn" ? ToolTipIcon.Warning : ToolTipIcon.Info);
            }
            catch { }
        }
    }

    static string Field(string json, string name)
    {
        var m = System.Text.RegularExpressions.Regex.Match(json, "\"" + name + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"");
        if (!m.Success) return "";
        return System.Text.RegularExpressions.Regex.Unescape(m.Groups[1].Value);
    }

    static void Ipc(string what)
    {
        try { string d = Path.Combine(Data, "ipc"); Directory.CreateDirectory(d); File.WriteAllText(Path.Combine(d, what + "-" + DateTime.Now.Ticks), ""); } catch { }
    }

    static void Quit()
    {
        Ipc("quit");
        for (int i = 0; i < 40 && !app.HasExited; i++) Thread.Sleep(250);
        if (!app.HasExited) try { app.Kill(); } catch { }
        tray.Visible = false; Application.Exit();
    }

    // ---------------------------------------------------------------- logs
    static void Log(string s) { try { File.AppendAllText(Path.Combine(Data, "launcher.log"), DateTime.Now.ToString("s") + " " + s + "\r\n"); } catch { } }

    static string Tail(string file, int lines)
    {
        try
        {
            using (var fs = new FileStream(Path.Combine(Data, file), FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var r = new StreamReader(fs))
                return string.Join("\r\n", r.ReadToEnd().Replace("\r\n", "\n").Split('\n').Where(l => l.Length > 0).Reverse().Take(lines).Reverse());
        }
        catch { return ""; }
    }

    static void Fail(string headline)
    {
        string t = Tail("console.log", 6);
        if (t.Length == 0) t = Tail("studio.log", 6);
        if (MessageBox.Show(headline + "\n\n" + t + "\n\nCopy the logs now so you can paste them for help?", "BambuForge Studio", MessageBoxButtons.YesNo, MessageBoxIcon.Error) == DialogResult.Yes) CopyLogs();
    }

    static int CopyLogs()
    {
        var sb = new StringBuilder("BambuForge Studio logs, " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ", Windows " + Environment.OSVersion.Version + "\r\n");
        foreach (var f in new[] { "launcher.log", "console.log", "studio.log" })
            sb.Append("\r\n===== ").Append(f).Append(" =====\r\n").Append(Tail(f, f == "studio.log" ? 300 : 80)).Append("\r\n");
        try { Clipboard.SetText(sb.ToString()); MessageBox.Show("The logs are copied. Paste them into your chat for help.", "BambuForge Studio", MessageBoxButtons.OK, MessageBoxIcon.Information); }
        catch (Exception ex) { MessageBox.Show("Couldn't copy the logs (" + ex.Message + "). They are in " + Data, "BambuForge Studio"); }
        return 0;
    }
}
