<p align="center"><img src="assets/icon.png" width="128" alt="BambuForge Studio icon"></p>
<h1 align="center">BambuForge Studio</h1>
<p align="center">All-in-one app for Bambu Lab printers: open, split, slice, print, and find models.</p>

## What it does
- **Models**: search MakerWorld, Printables, Thingiverse, Cults, MyMiniFactory, Thangs and Free3D at once (or add your own sites), browse them in a built-in browser, and keep downloads in a local library.
- **1 Model and plates**: size, colours and painting, raised or wrap-around text; move and turn parts with rings and arrows, lay flat, copies, support map, prime tower placement, auto-orient and arrange.
- **2 Split and hollow**: cut models too big for your printer into pieces with pegs, dowels, dovetails, threads or magnets (place joints by hand if you like), hollow the pieces, lay them out automatically.
- **3 Settings**: every single-nozzle Bambu printer, plate and filament; finish options; real print time and filament from the built-in slicer.
- **4 Printers**: find printers on your network, watch and control them, pick AMS slots per colour with a live preview, send prints (LAN Only + Developer Mode).
- **Built-in slicer**: Bambu Lab's own slicing engine is included, so Bambu Studio doesn't need to be installed.

## Download
Grab the latest **BambuForgeStudio-…-portable.zip** from [Releases](../../releases). Unzip anywhere and run `BambuForge Studio.exe` (Windows 10/11).
Windows may say "Windows protected your PC": click **More info → Run anyway** (the app isn't code-signed). To avoid it, right-click the zip → Properties → **Unblock** before unzipping.

## Built with
- Python 3.12 (standalone build), [pywebview](https://pywebview.flowrl.com/) + Microsoft Edge WebView2, [three.js](https://threejs.org/), [trimesh](https://trimesh.org/), [manifold3d](https://github.com/elalish/manifold)
- [Bambu Studio](https://github.com/bambulab/BambuStudio)'s slicing engine (AGPL-3.0), used headless

## Repository layout
- `app/` – the program (Python back end, `ui/` front end)
- `launcher/` – `BambuForge Studio.exe` (C#): WebView2 check, tray icon, notifications
- `assets/` – icon and social preview

## Licence
GNU Affero General Public License v3.0 (see [LICENSE](LICENSE)). The built-in slicer is Bambu Lab's Bambu Studio engine, also AGPL-3.0; its source is at https://github.com/bambulab/BambuStudio.
