"""BambuForge Studio geometry engine: read STL/3MF/OBJ, measure, scale, export."""
import io, json, math, os, re, time, zipfile
import numpy as np
import trimesh

BED = (256.0, 256.0)          # P1S plate, mm
MAX_H = 250.0                 # printable height in the P1S profile
PLATE_STRIDE = 256.0 * 1.2    # kept for old callers; use stride() - Bambu lays plates out in a grid with a 20% gap


def stride():
    return BED[0] * 1.2, BED[1] * 1.2
DEFAULT_COLOR = "#9AA0A6"

_V = re.compile(rb'<vertex\s+x="([^"]+)"\s+y="([^"]+)"\s+z="([^"]+)"')
_T = re.compile(rb'<triangle\s+v1="(\d+)"\s+v2="(\d+)"\s+v3="(\d+)"')
_TP = re.compile(rb'<triangle\s+v1="\d+"\s+v2="\d+"\s+v3="\d+"([^>]*)/?>')
_PAINT = re.compile(rb'(?:paint_color|slic3rpe:mmu_segmentation|mmu_segmentation)="([0-9A-Fa-f]*)"')


def paint_state(code):
    """Bambu/Prusa store a painted triangle as a little bit-stream (hex, read from the end). Returns the
    filament number painted on it (0 = not painted, use the part's own filament); split triangles take the
    filament painted on most of their pieces."""
    if not code:
        return 0
    nibbles = [int(c, 16) for c in reversed(code)]
    pos = [0]
    def bits(n):
        v = 0
        for i in range(n):
            k, b = divmod(pos[0], 4)
            if k >= len(nibbles): raise ValueError
            v |= ((nibbles[k] >> b) & 1) << i
            pos[0] += 1
        return v
    counts = {}
    def node(depth=0):
        if depth > 12: raise ValueError
        split = bits(2)
        if split == 0:
            st = bits(2)
            if st == 3: st = 3 + bits(4)
            counts[st] = counts.get(st, 0) + 1
        else:
            bits(2)                           # which side is special
            for _ in range(split + 1): node(depth + 1)
    try:
        node()
    except ValueError:
        return 0
    if not counts: return 0
    return max(counts.items(), key=lambda kv: (kv[1], kv[0] != 0))[0]
_OBJ = re.compile(rb'<object\b([^>]*)>(.*?)</object>', re.S)
_ATTR = re.compile(rb'([\w:]+)="([^"]*)"')
_COMP = re.compile(rb'<component\b([^>]*)/?>')


class Part:
    """mesh = the part where it sits on its plate (plate coords). P maps local -> plate, A maps local -> assembled."""
    def __init__(self, name, local, P, plate=1, color=DEFAULT_COLOR, A=None, ext=1, face_ext=None):
        self.name, self.local, self.P, self.plate, self.color, self.A = name, local, P, plate, color, A
        self.mesh = local.copy(); self.mesh.apply_transform(P)
        self.scale = 1.0
        self.role = 'part'
        self.R0 = np.array(P[:3, :3], float)    # how it sat when opened, for "absolute" rotation
        self.ext = int(ext or 1)                 # the part's own filament slot (1-based)
        self.face_ext = None                     # filament slot per triangle, or None if the whole part is one colour
        self.set_face_ext(face_ext)

    def set_face_ext(self, fe):
        if fe is None or len(fe) != len(self.local.faces):
            self.face_ext = None; return
        fe = np.asarray(fe, np.uint8).copy()
        fe[fe == 0] = self.ext
        self.face_ext = None if np.all(fe == self.ext) else fe

    def exts(self):
        """Filament slot of every triangle."""
        return self.face_ext if self.face_ext is not None else np.full(len(self.local.faces), self.ext, np.uint8)

    def slots_used(self):
        return sorted(set(int(x) for x in np.unique(self.exts())))

    def display_to_assembled(self):
        """4x4 that moves the plate mesh to its assembled position (None if the file has no assembly)."""
        if self.A is None:
            return None
        return self.A @ np.linalg.inv(self.P)

    def info(self, idx):
        lo, hi = self.mesh.bounds
        ext = hi - lo
        fits_xy = sorted(ext[:2]) <= sorted(BED) if False else (min(ext[0], ext[1]) <= BED[0] and max(ext[0], ext[1]) <= BED[1])
        lift = float(lo[2])
        floating = lift > 0.05
        fits = bool(fits_xy and hi[2] <= MAX_H + 1e-6 and not floating)
        why = []
        if hi[2] > MAX_H + 1e-6: why.append(f"{hi[2]:.0f} mm tall (max {MAX_H:.0f})")
        if not fits_xy: why.append(f"{max(ext[0], ext[1]):.0f} mm wide (bed {BED[0]:.0f})")
        if floating: why.append(f"lifted {lift:.1f} mm off the plate (press Drop to plate to print it)")
        try:
            Rr = self.P[:3, :3] @ np.linalg.inv(getattr(self, 'R0', np.eye(3)))
            M4 = np.eye(4); M4[:3, :3] = Rr / np.cbrt(max(1e-12, abs(np.linalg.det(Rr))))
            eul = [round(float(np.degrees(a)), 2) + 0.0 for a in trimesh.transformations.euler_from_matrix(M4, 'sxyz')]
        except Exception:
            eul = [0.0, 0.0, 0.0]
        return dict(id=idx, name=self.name, plate=self.plate, color=self.color, role=self.role, ext=self.ext, slots=self.slots_used(), rot=eul, size=[round(float(x), 1) for x in ext],
                    min=[round(float(x), 2) for x in lo], tris=int(len(self.mesh.faces)), fits=fits, why=", ".join(why), lift=round(lift, 2),
                    volume_cm3=round(float(abs(self.mesh.volume)) / 1000, 1) if self.mesh.is_volume else None)


def _attrs(b):
    return {k.decode().split(':')[-1]: v.decode() for k, v in _ATTR.findall(b)}


def _mat(s):
    if not s:
        return np.eye(4)
    p = [float(x) for x in s.split()]
    m = np.eye(4)
    m[:3, 0] = p[0:3]; m[:3, 1] = p[3:6]; m[:3, 2] = p[6:9]
    m[:3, 3] = p[9:12]
    # 3MF stores row-vector matrices; transpose the 3x3 into column-vector form
    m[:3, :3] = np.array(p[:9]).reshape(3, 3).T
    return m


def _read_objects(data):
    objs = {}
    for a, body in _OBJ.findall(data):
        at = _attrs(a)
        o = {'comps': []}
        mesh_at = body.find(b'<mesh')
        if mesh_at >= 0:
            v = np.array(_V.findall(body), dtype=np.float64)
            t = np.array(_T.findall(body), dtype=np.int64)
            o['mesh'] = (v.reshape(-1, 3), t.reshape(-1, 3))
            paint = None
            if b'paint_color' in body or b'mmu_segmentation' in body:
                paint = np.zeros(len(o['mesh'][1]), np.uint8)
                for i, rest in enumerate(_TP.findall(body)):
                    m = _PAINT.search(rest)
                    if m: paint[i] = paint_state(m.group(1).decode())
            o['paint'] = paint
        for c in _COMP.findall(body):
            ca = _attrs(c)
            o['comps'].append((ca.get('path'), ca.get('objectid'), _mat(ca.get('transform'))))
        o['name'] = at.get('name')
        objs[at.get('id')] = o
    return objs


def load(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == '.3mf':
        return _load_3mf(path)
    m = trimesh.load(path, force='mesh', process=False)
    P = np.eye(4); P[:3, 3] = [-(m.bounds[0][0] + m.bounds[1][0]) / 2 + BED[0] / 2, -(m.bounds[0][1] + m.bounds[1][1]) / 2 + BED[1] / 2, -m.bounds[0][2]]
    name = os.path.splitext(os.path.basename(path))[0]
    return dict(title=name, parts=[Part(name, m, P, A=P.copy())], plates={1: "Plate 1"}, bambu=False, path=path,
                filaments=[{'color': '#00AE42', 'preset': None, 'type': 'PLA', 'colors': ['#00AE42'], 'ctype': 'single', 'effect': 'solid'}])


def _load_3mf(path):
    z = zipfile.ZipFile(path)
    names = {n.lstrip('/').lower(): n for n in z.namelist()}
    def read(p):
        key = p.lstrip('/').lower()
        return z.read(names[key]) if key in names else None
    cache = {}
    def objs_of(p):
        p = (p or '3D/3dmodel.model').lstrip('/')
        if p not in cache:
            d = read(p)
            cache[p] = _read_objects(d) if d else {}
        return cache[p]
    main = read('3D/3dmodel.model')
    if main is None:
        raise ValueError("This 3MF has no 3D/3dmodel.model inside.")
    # Bambu project extras
    plate_of, obj_name, obj_ext, skip, plate_names, assembly = {}, {}, {}, set(), {}, {}
    part_ext = {}
    colors, fil_ids, fil_types, fil_multi, fil_ctype = [], [], [], [], []
    cfg = read('Metadata/model_settings.config')
    bambu = cfg is not None
    if bambu:
        import xml.etree.ElementTree as ET
        root = ET.fromstring(cfg)
        for o in root.findall('object'):
            oid = o.get('id')
            for md in o.findall('metadata'):
                if md.get('key') == 'name': obj_name[oid] = md.get('value')
                if md.get('key') == 'extruder': obj_ext[oid] = int(md.get('value') or 1)
            for pt in o.findall('part'):
                st = pt.get('subtype') or 'normal_part'
                if st != 'normal_part': skip.add((oid, pt.get('id')))
                for md in pt.findall('metadata'):
                    if md.get('key') == 'extruder':
                        try: part_ext[(oid, pt.get('id'))] = int(md.get('value') or 0)
                        except ValueError: pass
        for ai in root.findall('assemble/assemble_item'):
            M = _mat(ai.get('transform'))
            off = [float(x) for x in (ai.get('offset') or '0 0 0').split()]
            M[:3, 3] += off
            assembly[ai.get('object_id')] = M
        for pl in root.findall('plate'):
            md = {m.get('key'): m.get('value') for m in pl.findall('metadata')}
            pid = int(md.get('plater_id', 1))
            if md.get('plater_name'): plate_names[pid] = md['plater_name']
            for mi in pl.findall('model_instance'):
                mm = {m.get('key'): m.get('value') for m in mi.findall('metadata')}
                if 'object_id' in mm: plate_of[mm['object_id']] = pid
        ps = read('Metadata/project_settings.config')
        if ps:
            try:
                pj = json.loads(ps)
                colors = pj.get('filament_colour', []) or []
                fil_ids = pj.get('filament_settings_id', []) or []
                fil_types = pj.get('filament_type', []) or []
                fil_multi = pj.get('filament_multi_colour', []) or []
                fil_ctype = pj.get('filament_colour_type', []) or []
            except Exception: colors = []
    top = objs_of(None)
    items = re.findall(rb'<item\b([^>]*)/?>', main)
    parts = []
    nplates = max(list(plate_of.values()) + [1])
    cols = max(1, math.ceil(math.sqrt(nplates)))
    for it in items:
        at = _attrs(it)
        if at.get('printable') == '0':
            continue
        oid = at.get('objectid')
        vs, fs, fe = [], [], []
        base_ext = obj_ext.get(oid, 1)
        def collect(table, i, T, depth=0, ext=0):
            o = table.get(i)
            if o is None or depth > 8:
                return
            if 'mesh' in o and len(o['mesh'][0]):
                v, f = o['mesh']
                vv = (np.c_[v, np.ones(len(v))] @ T.T)[:, :3]
                fs.append(f + sum(len(x) for x in vs)); vs.append(vv)
                e_part = ext or base_ext
                paint = o.get('paint')
                arr = np.full(len(f), e_part, np.uint8)
                if paint is not None:
                    arr = np.where(paint > 0, paint, arr).astype(np.uint8)
                fe.append(arr)
            for p, cid, M in o['comps']:
                if (oid, cid) in skip:
                    continue
                collect(objs_of(p) if p else table, cid, T @ M, depth + 1, part_ext.get((oid, cid), ext))
        collect(top, oid, np.eye(4))
        if not vs:
            continue
        local = trimesh.Trimesh(np.vstack(vs), np.vstack(fs), process=False)
        plate = plate_of.get(oid, 1)
        P = _mat(at.get('transform'))
        if bambu and nplates > 1:   # bring each part back onto its own plate's coordinates
            i = plate - 1
            sx, sy = stride()
            P = _tr(-(i % cols) * sx, (i // cols) * sy, 0) @ P
        e = base_ext
        color = colors[e - 1] if 0 < e <= len(colors) else DEFAULT_COLOR
        nm = obj_name.get(oid) or (top.get(oid) or {}).get('name') or f"Object {oid}"
        parts.append(Part(nm, local, P, plate, color[:7] if color.startswith('#') else DEFAULT_COLOR, assembly.get(oid),
                          ext=e, face_ext=np.concatenate(fe) if fe else None))
    if not parts:
        raise ValueError("No printable parts found in this file.")
    if not bambu:   # plain 3MF: sit everything on one plate, and it is already "assembled"
        lo = np.min([p.mesh.bounds[0] for p in parts], axis=0); hi = np.max([p.mesh.bounds[1] for p in parts], axis=0)
        D = _tr(-(lo[0] + hi[0]) / 2 + BED[0] / 2, -(lo[1] + hi[1]) / 2 + BED[1] / 2, -lo[2])
        for p in parts:
            p.A = p.P.copy(); p.P = D @ p.P; p.mesh.apply_transform(D)
    if any(p.A is None for p in parts):
        for p in parts: p.A = None    # partial assembly info is not trustworthy
    for pl in set(p.plate for p in parts):
        plate_names.setdefault(pl, f"Plate {pl}")
    used = max([max(p.slots_used()) for p in parts] + [1])
    n = max(len(colors), used, 1)
    filaments = []
    for i in range(n):
        c = colors[i] if i < len(colors) and str(colors[i]).startswith('#') else (DEFAULT_COLOR if i else DEFAULT_COLOR)
        multi = [x for x in str(fil_multi[i]).split() if x.startswith('#')] if i < len(fil_multi) else []
        preset = fil_ids[i] if i < len(fil_ids) else None
        filaments.append({'color': c[:7].upper(), 'preset': preset, 'type': fil_types[i] if i < len(fil_types) else 'PLA',
                          'colors': [x.upper() for x in multi] if len(multi) > 1 else [c.upper()],
                          'ctype': ('gradient' if (i < len(fil_ctype) and str(fil_ctype[i]) == '0') else 'multi') if len(multi) > 1 else 'single',
                          'effect': effect_of(preset)})
    return dict(title=os.path.splitext(os.path.basename(path))[0], parts=parts, plates=plate_names, bambu=bambu, path=path, filaments=filaments)


EFFECTS = ('solid', 'matte', 'silk', 'metal', 'translucent', 'clear', 'glow', 'sparkle', 'galaxy', 'marble', 'wood')


def effect_of(name):
    """What a filament looks like, from its name (Bambu PLA Glow -> glow, PETG Translucent -> translucent...)."""
    n = str(name or '').lower()
    for word, eff in (('glow', 'glow'), ('translucent', 'translucent'), ('clear', 'clear'), ('transparent', 'clear'), ('metal', 'metal'),
                      ('silk', 'silk'), ('sparkle', 'sparkle'), ('galaxy', 'galaxy'), ('marble', 'marble'), ('wood', 'wood'), ('matte', 'matte')):
        if word in n: return eff
    return 'solid'


def _tr(x, y, z):
    m = np.eye(4); m[:3, 3] = [x, y, z]; return m


def assembled_size(parts):
    """Longest side (and all three) of the assembled model's tightest box, or None without assembly info."""
    if not parts or any(p.A is None for p in parts):
        return None
    pts = []
    for p in parts:
        v = np.asarray(p.local.vertices)
        if len(v) > 20000: v = v[np.linspace(0, len(v) - 1, 20000).astype(int)]
        pts.append((np.c_[v, np.ones(len(v))] @ p.A.T)[:, :3])
    pts = np.vstack(pts)
    axis = pts.max(0) - pts.min(0)
    try:
        T, ext = trimesh.bounds.oriented_bounds(pts)
    except Exception:
        ext = axis
    ext = sorted([float(x) for x in ext], reverse=True)
    # an upright model is measured straight up (tip to tip), a tilted one along its longest side
    if axis[2] >= 0.98 * ext[0]:
        return {'length': float(axis[2]), 'upright': True, 'box': [float(x) for x in axis], 'min': [float(x) for x in pts.min(0)]}
    return {'length': ext[0], 'upright': False, 'box': ext, 'min': [float(x) for x in pts.min(0)]}


def plate_offset(plate, nplates):
    cols = max(1, math.ceil(math.sqrt(nplates)))
    i = plate - 1
    sx, sy = stride()
    return [(i % cols) * sx, -(i // cols) * sy]


def write_display(part, out_path, max_tris=1_500_000):
    """Binary for the viewer: [nv uint32][nt uint32][xyz float32 * nv][abc uint32 * nt]."""
    m = part.mesh
    V, F = np.asarray(m.vertices, np.float32), np.asarray(m.faces, np.uint32)
    fe = part.exts() if hasattr(part, 'exts') else np.ones(len(F), np.uint8)
    groups, vs, fs, nv = [], [], [], 0
    for ext in sorted(set(int(x) for x in np.unique(fe))):
        sel = F[fe == ext]
        used, inv = np.unique(sel.ravel(), return_inverse=True)
        v, f = V[used], inv.reshape(-1, 3).astype(np.uint32)
        budget = max(2000, int(max_tris * len(f) / max(1, len(F))))
        if len(f) > budget:
            try:
                import fast_simplification
                v2, f2 = fast_simplification.simplify(v, f, target_reduction=1 - budget / len(f))
                if len(f2): v, f = np.asarray(v2, np.float32), np.asarray(f2, np.uint32)
            except Exception:
                pass
        groups.append({'ext': ext, 'start': sum(len(x) for x in fs) * 3, 'count': len(f) * 3})
        fs.append(f + nv); vs.append(v); nv += len(v)
    v, f = (np.vstack(vs) if vs else V), (np.vstack(fs) if fs else F)
    with open(out_path, 'wb') as fh:
        fh.write(np.array([len(v), len(f)], np.uint32).tobytes())
        fh.write(np.asarray(v, np.float32).tobytes()); fh.write(np.asarray(f, np.uint32).tobytes())
    part._groups = groups
    return len(f)


def scale_parts(parts, factor):
    """Uniform scale. On the plates each part grows from the centre of its base; the assembly scales as a whole."""
    S = np.diag([factor, factor, factor, 1.0])
    for p in parts:
        lo, hi = p.mesh.bounds
        base = np.array([(lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2, lo[2]])
        p.local.apply_scale(factor)
        P = p.P.copy(); P[:3, 3] = 0
        m = p.local.copy(); m.apply_transform(P)
        nlo, nhi = m.bounds
        nb = np.array([(nlo[0] + nhi[0]) / 2, (nlo[1] + nhi[1]) / 2, nlo[2]])
        P[:3, 3] = base - nb
        p.P = P; p.mesh = m; p.mesh.apply_translation(base - nb)
        if p.A is not None:
            p.A = S @ p.A @ np.linalg.inv(S)
        p.scale *= factor


def export(parts, path, nplates):
    ext = os.path.splitext(path)[1].lower()
    if ext == '.stl':
        trimesh.util.concatenate([p.mesh for p in parts]).export(path)
        return
    scene = trimesh.Scene()
    for i, p in enumerate(parts):
        m = p.mesh.copy()
        ox, oy = plate_offset(p.plate, nplates)
        m.apply_translation([ox, oy, 0])
        nm = f"{i + 1:02d} {p.name}"
        scene.add_geometry(m, geom_name=nm, node_name=nm)
    scene.export(path)
