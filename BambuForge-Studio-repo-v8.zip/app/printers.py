"""Talk to Bambu printers on your network (LAN Only + Developer Mode): find them, watch them, control them, send prints.

Protocols (Bambu's local interfaces): MQTT over TLS on port 8883 (user "bblp", password = the printer's access code),
FTPS with implicit TLS on port 990 for uploading sliced files, SSDP broadcasts on UDP 2021 for discovery.
"""
import base64, ftplib, glob, json, os, socket, ssl, sys, threading, time

try:
    import paho.mqtt.client as mqtt
except Exception:          # the app still runs; the Printers tab says what is missing
    mqtt = None

MODELS = {  # what printers report about themselves -> the name people know
    'BL-P001': 'X1 Carbon', 'BL-P002': 'X1', 'C11': 'P1P', 'C12': 'P1S', 'C13': 'X1E', 'N1': 'A1 mini', 'N2S': 'A1',
    'O1D': 'H2D', 'O1E': 'H2D Pro', 'O1S': 'H2S', 'N7': 'P2S', 'O1C': 'H2C', '3DPrinter-X1-Carbon': 'X1 Carbon', '3DPrinter-X1': 'X1',
}
STAGES = {  # stg_cur codes -> what the printer is doing
    0: 'Printing', 1: 'Levelling the bed', 2: 'Heating the bed', 3: 'Sweeping XY mechanism', 4: 'Changing filament',
    5: 'Paused (M400)', 6: 'Paused: filament ran out', 7: 'Heating the nozzle', 8: 'Calibrating extrusion', 9: 'Scanning the bed surface',
    10: 'Inspecting the first layer', 11: 'Identifying the build plate', 12: 'Calibrating the micro lidar', 13: 'Homing the toolhead',
    14: 'Cleaning the nozzle tip', 15: 'Checking the extruder temperature', 16: 'Paused by you', 17: 'Paused: front cover fell',
    18: 'Calibrating the micro lidar', 19: 'Calibrating extrusion flow', 20: 'Paused: nozzle temperature fault',
    21: 'Paused: bed temperature fault', 22: 'Unloading filament', 23: 'Paused: skipped step', 24: 'Loading filament',
    25: 'Calibrating motor noise', 26: 'Paused: AMS lost', 27: 'Paused: heat-break fan too slow', 28: 'Paused: chamber temperature fault',
    29: 'Cooling the chamber', 30: 'Paused by G-code', 31: 'Motor noise show-off', 32: 'Paused: filament on the nozzle',
    33: 'Paused: cutter fault', 34: 'Paused: first layer problem', 35: 'Paused: nozzle clog', -1: 'Idle', 255: 'Idle',
}
STATE_TEXT = {'IDLE': 'Idle', 'PREPARE': 'Preparing', 'RUNNING': 'Printing', 'PAUSE': 'Paused', 'FINISH': 'Finished', 'FAILED': 'Failed', 'SLICING': 'Slicing'}


# ------------------------------------------------------------------ keeping access codes safe on Windows
def protect(text):
    if sys.platform == 'win32':
        try:
            import ctypes
            from ctypes import wintypes
            class BLOB(ctypes.Structure): _fields_ = [('cbData', wintypes.DWORD), ('pbData', ctypes.POINTER(ctypes.c_char))]
            data = text.encode()
            inp = BLOB(len(data), ctypes.cast(ctypes.create_string_buffer(data, len(data)), ctypes.POINTER(ctypes.c_char)))
            out = BLOB()
            if ctypes.windll.crypt32.CryptProtectData(ctypes.byref(inp), None, None, None, None, 0, ctypes.byref(out)):
                b = ctypes.string_at(out.pbData, out.cbData); ctypes.windll.kernel32.LocalFree(out.pbData)
                return 'dpapi:' + base64.b64encode(b).decode()
        except Exception:
            pass
    return 'b64:' + base64.b64encode(text.encode()).decode()


def unprotect(s):
    if not s: return ''
    if s.startswith('dpapi:') and sys.platform == 'win32':
        import ctypes
        from ctypes import wintypes
        class BLOB(ctypes.Structure): _fields_ = [('cbData', wintypes.DWORD), ('pbData', ctypes.POINTER(ctypes.c_char))]
        raw = base64.b64decode(s[6:])
        inp = BLOB(len(raw), ctypes.cast(ctypes.create_string_buffer(raw, len(raw)), ctypes.POINTER(ctypes.c_char)))
        out = BLOB()
        if ctypes.windll.crypt32.CryptUnprotectData(ctypes.byref(inp), None, None, None, None, 0, ctypes.byref(out)):
            b = ctypes.string_at(out.pbData, out.cbData); ctypes.windll.kernel32.LocalFree(out.pbData)
            return b.decode()
        return ''
    if s.startswith('b64:'): return base64.b64decode(s[4:]).decode()
    return s


# ------------------------------------------------------------------ finding printers
def discover(seconds=4.0):
    """Listen for the SSDP announcements Bambu printers broadcast (and ask them to announce)."""
    found = {}
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    try:
        s.bind(('', 2021))
    except OSError:
        s.bind(('', 0))
    s.settimeout(0.5)
    msg = ('M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1990\r\nMAN: "ssdp:discover"\r\nMX: 1\r\n'
           'ST: urn:bambulab-com:device:3dprinter:1\r\n\r\n').encode()
    for dest in (('255.255.255.255', 2021), ('239.255.255.250', 1990)):
        try: s.sendto(msg, dest)
        except OSError: pass
    end = time.time() + seconds
    while time.time() < end:
        try:
            data, addr = s.recvfrom(4096)
        except socket.timeout:
            continue
        except OSError:
            break
        txt = data.decode('utf-8', 'replace')
        if 'bambu' not in txt.lower(): continue
        h = {}
        for line in txt.split('\r\n')[1:]:
            if ':' in line:
                k, v = line.split(':', 1); h[k.strip().lower()] = v.strip()
        serial = h.get('usn', '').strip()
        if not serial: continue
        code = h.get('devmodel.bambu.com', '')
        found[serial] = {'serial': serial, 'ip': h.get('location', addr[0]).replace('http://', '').split(':')[0] or addr[0],
                         'name': h.get('devname.bambu.com', serial), 'model_code': code, 'model': MODELS.get(code, code or 'Bambu printer'),
                         'connect': h.get('devconnect.bambu.com', ''), 'bind': h.get('devbind.bambu.com', '')}
    s.close()
    return list(found.values())


# ------------------------------------------------------------------ one printer
def _merge(dst, src):
    """Printers (P1/A1 especially) send only what changed: merge it in, matching AMS units and trays by id."""
    for k, v in src.items():
        if isinstance(v, dict) and isinstance(dst.get(k), dict):
            _merge(dst[k], v)
        elif (isinstance(v, list) and isinstance(dst.get(k), list) and v and all(isinstance(x, dict) and 'id' in x for x in v)
              and all(isinstance(x, dict) and 'id' in x for x in dst[k])):
            by = {str(x['id']): x for x in dst[k]}
            for x in v:
                if str(x['id']) in by: _merge(by[str(x['id'])], x)
                else: dst[k].append(x)
        else:
            dst[k] = v


class Printer:
    def __init__(self, serial, ip, code, name='', model='', log=None):
        self.serial, self.ip, self.code, self.name, self.model = serial, ip, code, name or serial, model
        self.log = log or (lambda lvl, msg: None)
        self.state = {}
        self.last = 0.0
        self.error = None
        self.connected = False
        self.cmd_results = []
        self.client = None
        self.lock = threading.Lock()
        self.job = None            # what we sent: {'name', 'grams', 'seconds', 'plate', 'started'}

    # --- connection
    def connect(self, timeout=8.0):
        if mqtt is None:
            self.error = 'The MQTT library is missing; run Install.cmd again.'; return False
        self.error = None
        c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f'bfs-{os.getpid()}-{self.serial[-4:]}', protocol=mqtt.MQTTv311)
        c.username_pw_set('bblp', self.code)
        ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE   # printers use a self-signed certificate
        c.tls_set_context(ctx)
        c.on_connect = self._on_connect; c.on_message = self._on_message; c.on_disconnect = self._on_disconnect
        self.client = c
        try:
            c.connect(self.ip, int(os.environ.get('BFS_MQTT_PORT', '8883')), keepalive=30)
        except Exception as e:
            self.error = f"Couldn't reach the printer at {self.ip} ({e}). Check it is on, on the same network, and in LAN Only mode."
            return False
        c.loop_start()
        t0 = time.time()
        while time.time() - t0 < timeout and not self.connected and not self.error:
            time.sleep(0.1)
        if not self.connected and not self.error:
            self.error = 'The printer did not answer. Is LAN Only mode on?'
        if self.connected:
            self.pushall()
        return self.connected

    def close(self):
        try:
            if self.client: self.client.loop_stop(); self.client.disconnect()
        except Exception:
            pass
        self.connected = False

    def _on_connect(self, client, userdata, flags, rc, props=None):
        code = rc.value if hasattr(rc, 'value') else rc
        if code == 0:
            self.connected = True
            client.subscribe(f'device/{self.serial}/report')
            self.log('INFO', f'Printer {self.name}: connected')
        else:
            self.error = ('Wrong access code. Check it on the printer: Settings → WLAN.' if code in (4, 5, 134, 135)
                          else f'The printer refused the connection (code {code}).')
            self.log('WARN', f'Printer {self.name}: connect refused {code}')

    def _on_disconnect(self, client, userdata, flags, rc=None, props=None):
        self.connected = False

    def _on_message(self, client, userdata, msg):
        try:
            data = json.loads(msg.payload)
        except Exception:
            return
        with self.lock:
            _merge(self.state, data)
            self.last = time.time()
            p = data.get('print', {})
            if isinstance(p, dict) and p.get('result') and p.get('command') not in (None, 'push_status'):
                self.cmd_results.append({'command': p.get('command'), 'result': p.get('result'), 'reason': p.get('reason', ''), 't': time.time()})
                if str(p.get('result')).lower() not in ('success', 'ok'):
                    self.log('WARN', f"Printer {self.name}: command {p.get('command')} -> {p.get('result')} {p.get('reason', '')}")

    # --- sending commands
    def _publish(self, payload):
        if not self.connected: raise RuntimeError('Not connected to the printer.')
        self.client.publish(f'device/{self.serial}/request', json.dumps(payload), qos=1)
        self.log('STEP', f'Printer {self.name}: sent ' + json.dumps(payload)[:300])

    def pushall(self):
        self._publish({'pushing': {'sequence_id': '0', 'command': 'pushall'}})
        self._publish({'info': {'sequence_id': '0', 'command': 'get_version'}})

    def gcode(self, line):
        self._publish({'print': {'sequence_id': '0', 'command': 'gcode_line', 'param': line.rstrip() + '\n'}})

    def pause(self): self._publish({'print': {'sequence_id': '0', 'command': 'pause'}})
    def resume(self): self._publish({'print': {'sequence_id': '0', 'command': 'resume'}})
    def stop(self): self._publish({'print': {'sequence_id': '0', 'command': 'stop'}})
    def home(self): self.gcode('G28')
    def nozzle_temp(self, t): self.gcode(f'M104 S{int(t)}')
    def bed_temp(self, t): self.gcode(f'M140 S{int(t)}')

    def fan(self, which, pct):
        idx = {'part': 1, 'aux': 2, 'chamber': 3}[which]
        self.gcode(f'M106 P{idx} S{int(round(max(0, min(100, pct)) * 2.55))}')

    def light(self, on):
        self._publish({'system': {'sequence_id': '0', 'command': 'ledctrl', 'led_node': 'chamber_light', 'led_mode': 'on' if on else 'off',
                                  'led_on_time': 500, 'led_off_time': 500, 'loop_times': 0, 'interval_time': 0}})

    def load(self, tray):
        t = self.nozzle_target() or 220
        self._publish({'print': {'sequence_id': '0', 'command': 'ams_change_filament', 'target': int(tray), 'curr_temp': t, 'tar_temp': t}})

    def unload(self):
        t = self.nozzle_target() or 220
        self._publish({'print': {'sequence_id': '0', 'command': 'ams_change_filament', 'target': 255, 'curr_temp': t, 'tar_temp': t}})

    def calibrate(self, bed=True, vibration=False, motor=False):
        opt = (2 if bed else 0) | (4 if vibration else 0) | (8 if motor else 0)
        if not opt: raise ValueError('Pick at least one calibration.')
        self._publish({'print': {'sequence_id': '0', 'command': 'calibration', 'option': opt}})

    def ams_set(self, tray, fil_id, ftype, color, tmin, tmax):
        """Tell the printer which filament is in an AMS slot (brand/type/colour), like Bambu Studio's slot editor."""
        c = color.lstrip('#').upper()[:6] + 'FF'
        self._publish({'print': {'sequence_id': '0', 'command': 'ams_filament_setting', 'ams_id': int(tray) // 4, 'tray_id': int(tray) % 4,
                                 'tray_info_idx': fil_id, 'tray_color': c, 'nozzle_temp_min': int(tmin), 'nozzle_temp_max': int(tmax),
                                 'tray_type': ftype, 'setting_id': ''}})

    def nozzle_target(self):
        try: return int(float(self.state.get('print', {}).get('nozzle_target_temper') or 0))
        except Exception: return 0

    # --- sending a print
    def upload(self, path, remote_name, progress=None):
        ftp = ImplicitFTPS()
        ftp.connect(self.ip, int(os.environ.get('BFS_FTPS_PORT', '990')), timeout=20)
        ftp.login('bblp', self.code)
        ftp.prot_p()
        size = os.path.getsize(path); sent = [0]
        def cb(block):
            sent[0] += len(block)
            if progress: progress(sent[0] / max(1, size))
        with open(path, 'rb') as f:
            ftp.storbinary(f'STOR {remote_name}', f, blocksize=65536, callback=cb)
        try: ftp.quit()
        except Exception: pass

    def start_print(self, remote_name, plate, level=True, tray=0, use_ams=True, n_filaments=4, job_name=None, mapping=None):
        mapping = mapping or [int(tray)] * max(1, n_filaments)
        cmd = {'print': {'sequence_id': '0', 'command': 'project_file', 'param': f'Metadata/plate_{int(plate)}.gcode',
                         'project_id': '0', 'profile_id': '0', 'task_id': '0', 'subtask_id': '0',
                         'subtask_name': job_name or remote_name.replace('.gcode.3mf', ''),
                         'file': remote_name, 'url': f'file:///sdcard/{remote_name}', 'md5': '',
                         'timelapse': False, 'bed_type': 'auto', 'bed_levelling': bool(level), 'bed_leveling': bool(level),
                         'flow_cali': False, 'vibration_cali': False, 'layer_inspect': False,
                         'use_ams': bool(use_ams)}}
        if use_ams: cmd['print']['ams_mapping'] = mapping
        self._publish(cmd)

    # --- what the screen shows
    def summary(self):
        with self.lock:
            p = dict(self.state.get('print', {}))
        online = self.connected and (time.time() - self.last < 120)
        st = p.get('gcode_state', 'IDLE')
        try: stage = int(p.get('stg_cur', -1))
        except Exception: stage = -1
        rem = p.get('mc_remaining_time')
        try: rem = int(rem)
        except Exception: rem = None
        pct = p.get('mc_percent')
        try: pct = int(pct)
        except Exception: pct = None
        ams = []
        try:
            for unit in (p.get('ams') or {}).get('ams', []):
                for tr in unit.get('tray', []):
                    idx = int(unit.get('id', 0)) * 4 + int(tr.get('id', 0))
                    ams.append({'index': idx, 'type': tr.get('tray_type') or '', 'color': '#' + (tr.get('tray_color') or '808080FF')[:6],
                                'name': tr.get('tray_sub_brands') or tr.get('tray_type') or '', 'empty': not tr.get('tray_type'),
                                'id': tr.get('tray_info_idx') or ''})
        except Exception:
            pass
        tray_now = (p.get('ams') or {}).get('tray_now') if isinstance(p.get('ams'), dict) else None
        hms = []
        for h in p.get('hms') or []:
            try:
                code = f"{int(h.get('attr', 0)):08X}{int(h.get('code', 0)):08X}"
                hms.append(code)
            except Exception:
                pass
        err = p.get('print_error')
        try: err = int(err)
        except Exception: err = 0
        lights = {l.get('node'): l.get('mode') for l in (p.get('lights_report') or []) if isinstance(l, dict)}
        upg = p.get('upgrade_state') or {}
        ver = ''
        for m in (self.state.get('info') or {}).get('module', []) or []:
            if m.get('name') == 'ota': ver = m.get('sw_ver', '')
        if st == 'PREPARE':          # the printer still reports the last job's numbers until printing starts
            pct, rem = 0, None
        g_total = round(self.job['grams']) if self.job and self.job.get('grams') else None
        return {'serial': self.serial, 'name': self.name, 'model': self.model, 'ip': self.ip, 'online': online, 'error': self.error,
                'state': st, 'state_text': STATE_TEXT.get(st, st.title() if isinstance(st, str) else str(st)),
                'stage': stage, 'stage_text': STAGES.get(stage, f'Stage {stage}'), 'percent': pct, 'remaining_min': rem,
                'layer': p.get('layer_num'), 'layers': p.get('total_layer_num'), 'job': p.get('subtask_name') or (self.job or {}).get('name'),
                'nozzle': p.get('nozzle_temper'), 'nozzle_target': p.get('nozzle_target_temper'),
                'bed': p.get('bed_temper'), 'bed_target': p.get('bed_target_temper'),
                'part_fan': p.get('cooling_fan_speed'), 'aux_fan': p.get('big_fan1_speed'), 'chamber_fan': p.get('big_fan2_speed'),
                'light': lights.get('chamber_light'), 'ams': ams, 'tray_now': tray_now, 'hms': hms, 'print_error': err,
                'firmware': ver, 'update_available': str(upg.get('new_version_state', '')) == '1',
                'grams_total': g_total, 'grams_used': round(g_total * pct / 100) if (g_total and pct is not None) else None,
                'cmd_results': self.cmd_results[-5:]}


class ImplicitFTPS(ftplib.FTP_TLS):
    """Bambu printers use FTPS with implicit TLS on port 990 (the connection is encrypted from the first byte)."""
    def __init__(self):
        ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        super().__init__(context=ctx)
        self._sock = None

    @property
    def sock(self): return self._sock

    @sock.setter
    def sock(self, value):
        if value is not None and not isinstance(value, ssl.SSLSocket):
            value = self.context.wrap_socket(value)
        self._sock = value

    def ntransfercmd(self, cmd, rest=None):
        conn, size = ftplib.FTP.ntransfercmd(self, cmd, rest)
        if self._prot_p:
            conn = self.context.wrap_socket(conn, session=self.sock.session)   # printers expect the TLS session to be reused
        return conn, size


# ------------------------------------------------------------------ error codes
class HMS:
    """Descriptions of printer error codes, from the files Bambu Studio itself ships and keeps up to date."""
    def __init__(self, dirs):
        self.hms, self.err = {}, {}
        for d in dirs:
            for f in sorted(glob.glob(os.path.join(d, 'hms_en_*.json'))):
                try:
                    j = json.load(open(f, encoding='utf-8'))
                except Exception:
                    continue
                data = j.get('data', j)
                for it in (data.get('device_hms') or {}).get('en', []):
                    self.hms.setdefault(str(it.get('ecode', '')).upper(), it.get('intro', ''))
                for it in (data.get('device_error') or {}).get('en', []):
                    self.err.setdefault(str(it.get('ecode', '')).upper(), it.get('intro', ''))

    def describe(self, code16):
        c = code16.upper()
        nice = '-'.join(c[i:i + 4] for i in range(0, 16, 4))
        return {'code': nice, 'text': self.hms.get(c) or 'See the Bambu wiki for this code.',
                'link': f'https://e.bambulab.com/index.php?e={c}&s=device_hms&lang=en'}

    def describe_error(self, n):
        c = f'{int(n):08X}'
        return {'code': f'{c[:4]}-{c[4:]}', 'text': self.err.get(c) or 'See the Bambu wiki for this code.',
                'link': f'https://e.bambulab.com/index.php?e={c}&s=device_hms&lang=en'}
