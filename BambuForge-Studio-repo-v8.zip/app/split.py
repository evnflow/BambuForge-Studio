"""Split too-tall parts into bed-height pieces and join them back together.

Everything here works on a part standing upright on its plate (z up, base at z=0).
Joint types: dpeg (keyed D-peg, glue), dowels (two round pins, glue), magnets (pockets
for round magnets), sleeve (hollow-core coupler for tube sections), none (flat glue face).
"""
import math
import numpy as np
import manifold3d as mf
import trimesh

SEG = 96
JOINTS = {
    'dpeg':     'Keyed D-peg + glue',
    'dowels':   'Twin dowels + glue',
    'dovetail': 'Dovetail slide lock (removable)',
    'twist':    'Twist-lock bayonet (removable)',
    'thread':   'Screw thread (removable)',
    'magnets':  'Magnets (removable)',
    'sleeve':   'Hollow-core sleeve + glue',
    'none':     'Flat glue face only',
}
# extra height a joint adds on top of the piece below the cut (spigots and tongues)
EXTRA_H = {'twist': 10.0, 'thread': 12.0, 'dovetail': 5.0}
MAGNETS = {'6x3': (6.0, 3.0), '8x3': (8.0, 3.0), '10x3': (10.0, 3.0), '12x3': (12.0, 3.0)}


class NotSolid(Exception):
    pass


FID = 1_000_000   # face ids at or above this carry a filament slot (face id - FID) through every cut


def to_mf(m, face_ext=None):
    """Manifold solid from a trimesh. Welds duplicate vertices first (STL files store every triangle separately).
    face_ext (filament slot per triangle) rides along as the face id, so cuts keep each face's colour."""
    t = trimesh.Trimesh(np.asarray(m.vertices, np.float64), np.asarray(m.faces, np.int64), process=True)
    t.merge_vertices(digits_vertex=5)
    fid = None
    if face_ext is not None and len(face_ext) == len(t.faces):
        fid = (np.asarray(face_ext, np.uint32) + FID).astype(np.uint32)
    def make(tt, ids):
        kw = {'face_id': ids} if ids is not None else {}
        return mf.Manifold(mf.Mesh(vert_properties=np.asarray(tt.vertices, np.float32), tri_verts=np.asarray(tt.faces, np.uint32), **kw))
    M = make(t, fid)
    if M.status() != mf.Error.NoError or M.is_empty():
        n0 = len(t.faces)
        trimesh.repair.fill_holes(t); trimesh.repair.fix_normals(t)
        if fid is not None:
            fid = np.concatenate([fid, np.full(len(t.faces) - n0, fid[0] if len(fid) else FID + 1, np.uint32)])[:len(t.faces)]
        M = make(t, fid)
    if M.status() != mf.Error.NoError or M.is_empty():
        raise NotSolid("This part isn't a closed solid (it has holes or gaps in its surface), so it can't be cut cleanly. "
                       "Repair it first (Bambu Studio: right-click > Fix model) and open it again.")
    return M


def to_tm_ext(M, default_ext=1):
    """trimesh plus the filament slot of every triangle (new cut faces get the part's own filament)."""
    g = M.to_mesh()
    tm = trimesh.Trimesh(np.asarray(g.vert_properties[:, :3], np.float64), np.asarray(g.tri_verts, np.int64), process=False)
    fid = np.asarray(g.face_id, np.int64) if g.face_id is not None and len(g.face_id) == len(tm.faces) else None
    if fid is None:
        return tm, None
    fe = np.where(fid >= FID, fid - FID, default_ext).astype(np.int64)
    fe[(fe <= 0) | (fe > 64)] = default_ext
    return tm, fe.astype(np.uint8)


def to_tm(M):
    g = M.to_mesh()
    return trimesh.Trimesh(np.asarray(g.vert_properties[:, :3], np.float64), np.asarray(g.tri_verts, np.int64), process=False)


# ------------------------------------------------------------------ measuring cross-sections
class Sections:
    """Cross-sections of a solid every `step` mm, cached."""
    def __init__(self, solid, step=1.5):
        self.solid, self.step = solid, step
        lo, hi = solid.bounding_box()[2], solid.bounding_box()[5]
        self.z0, self.z1 = lo, hi
        self.cache = {}

    def at(self, z):
        k = round(z / self.step)
        if k not in self.cache:
            self.cache[k] = self.solid.slice(k * self.step)
        return self.cache[k]

    def window(self, z, half):
        """Region present in every slice within z±half (what a straight pin/hole can pass through)."""
        R = None
        k0, k1 = math.floor((z - half) / self.step), math.ceil((z + half) / self.step)
        for k in range(k0, k1 + 1):
            s = self.at(k * self.step)
            R = s if R is None else R ^ s
            if R.is_empty():
                return R
        return R


def inscribed(cs, iters=14):
    """Largest circle that fits in a cross-section: (radius, centre). Binary search on inward offset."""
    if cs is None or cs.is_empty() or cs.area() <= 0:
        return 0.0, None
    b = cs.bounds()
    lo, hi = 0.0, max(b[2] - b[0], b[3] - b[1]) / 2
    best = cs
    for _ in range(iters):
        mid = (lo + hi) / 2
        inset = cs.offset(-mid, mf.JoinType.Round, 2, SEG)
        if inset.is_empty() or inset.area() < 1e-4:
            hi = mid
        else:
            lo, best = mid, inset
    pts = np.vstack([np.asarray(p) for p in best.to_polygons()])
    return lo, pts.mean(axis=0)


def holes_in(cs):
    """Contours that are holes (clockwise / negative area)."""
    out = []
    for p in cs.to_polygons():
        p = np.asarray(p)
        a = 0.5 * np.sum(p[:, 0] * np.roll(p[:, 1], -1) - np.roll(p[:, 0], -1) * p[:, 1])
        if a < 0:
            out.append(p)
    return out


# ------------------------------------------------------------------ choosing cut heights
def plan_cuts(mesh, max_h=245.0, min_h=120.0, pin_half=26.0, step=2.5, progress=None):
    """Pick cut heights so every piece is <= max_h tall, preferring the fattest, most solid places to cut."""
    solid = to_mf(mesh)
    S = Sections(solid)
    z0, z1 = S.z0, S.z1
    H = z1 - z0
    if H <= max_h:
        return []
    n = math.ceil(H / max_h)                       # fewest pieces that fit
    cands = np.arange(z0 + min_h * 0.5, z1 - min_h * 0.5 + 1e-6, step)
    score = {}
    for i, z in enumerate(cands):
        r, _ = inscribed(S.window(z, pin_half), iters=10)
        score[round(float(z), 3)] = r
        if progress and i % 10 == 0:
            progress(i / len(cands))
    keys = sorted(score)
    lo_h = max(min_h * 0.5, min(min_h, H / n * 0.6))
    # DP: maximise the weakest cut, then the total
    from functools import lru_cache

    @lru_cache(None)
    def best(prev, k):
        if k == 0:
            return (1e9, 0.0, ()) if lo_h <= z1 - prev <= max_h else None
        out = None
        for z in keys:
            if lo_h <= z - prev <= max_h:
                sub = best(z, k - 1)
                if sub is None:
                    continue
                cand = (min(sub[0], score[z]), sub[1] + score[z], (z,) + sub[2])
                if out is None or cand[:2] > out[:2]:
                    out = cand
        return out
    res = None
    for extra in range(0, 3):                      # if no plan fits, allow one more piece
        res = best(round(float(z0), 3), n - 1 + extra)
        if res:
            break
    if not res:
        return [z0 + H * i / n for i in range(1, n)]
    return list(res[2])


# ------------------------------------------------------------------ joint geometry
def dsec(r, f):
    return mf.CrossSection.circle(r, SEG) ^ mf.CrossSection.square((4 * r, 4 * r)).translate((-2 * r, -f))


def dpeg_solid(r, f, L, ch):
    body = mf.Manifold.extrude(dsec(r, f), L)
    prof = mf.CrossSection([np.array([(0, 0), (r - ch, 0), (r + 0.01, ch + 0.01), (r + 0.01, L - ch - 0.01), (r - ch, L), (0, L)])], mf.FillRule.EvenOdd)
    return body ^ mf.Manifold.revolve(prof, SEG)


def round_pin(r, L, ch):
    """Dowel with a small flat along one side so it prints lying down (layers run along the pin = strong)."""
    return dpeg_solid(r, r * 0.8, L, ch)


def hole_cutter(sec, z, depth_dn, depth_up, ch=0.6, r_for_ch=None):
    h = mf.Manifold.extrude(sec, depth_dn + depth_up).translate((0, 0, z - depth_dn))
    if r_for_ch:
        h = h + mf.Manifold.cylinder(ch, r_for_ch, r_for_ch + ch, SEG).translate((0, 0, z - ch))
        h = h + mf.Manifold.cylinder(ch, r_for_ch + ch, r_for_ch, SEG).translate((0, 0, z))
    return h


def spread_points(region, n, margin):
    """n points well spread inside a region (farthest-point picking on the inset region)."""
    inset = region.offset(-margin, mf.JoinType.Round, 2, SEG)
    if inset.is_empty():
        return []
    pts = np.vstack([np.asarray(p) for p in inset.to_polygons()])
    # densify candidates: polygon vertices + interior grid
    b = inset.bounds()
    gx, gy = np.meshgrid(np.linspace(b[0], b[2], 25), np.linspace(b[1], b[3], 25))
    grid = np.c_[gx.ravel(), gy.ravel()]
    keep = [p for p in grid if not (mf.CrossSection.square((0.2, 0.2)).translate((p[0] - 0.1, p[1] - 0.1)) - inset).area() > 1e-6]
    cand = np.vstack([pts] + ([np.array(keep)] if keep else []))
    chosen = [cand[np.argmax(np.linalg.norm(cand - cand.mean(0), axis=1))]]
    while len(chosen) < n:
        d = np.min(np.linalg.norm(cand[:, None, :] - np.array(chosen)[None], axis=2), axis=1)
        chosen.append(cand[np.argmax(d)])
    return chosen


class JointResult:
    def __init__(self):
        self.cutters = []        # Manifolds removed from the solid (both sides)
        self.add_lower = []      # Manifolds joined onto the piece below the cut (spigots, tongues)
        self.cut_upper = []      # Manifolds removed from the piece above the cut (sockets, grooves)
        self.extra = []          # (name, Manifold standing at the cut, lie_flat: bool)
        self.note = ''
        self.kind = ''


def make_joint(S, z, kind, clr=0.2, magnet='8x3'):
    """Design one joint at height z. Falls back to a simpler joint if the requested one doesn't fit."""
    j = JointResult()
    sec = S.at(z)
    tube = len(holes_in(sec)) > 0
    if kind == 'sleeve' and not tube:
        kind = 'dpeg'
    if kind == 'dpeg' or kind == 'dowels':
        r_in, c = inscribed(S.window(z, 26.0))
        if tube and r_in < 6.5:
            kind = 'sleeve'
    if kind == 'dpeg':
        r_in, c = inscribed(S.window(z, 26.0))
        R = min(10.0, r_in - 4.0 - clr)
        if R < 3.0:
            j.note = 'too thin here for a peg; glue face only'
            kind = 'none'
        else:
            L = 50.0 if R >= 8 else max(16.0, 5 * R)
            F = R * 0.7
            j.cutters.append(hole_cutter(dsec(R + clr, F + clr), z, L / 2 + 1, L / 2 + 1, 0.6, R + clr).translate((c[0], c[1], 0)))
            j.extra.append((f'D-peg {2 * R:.0f} mm', dpeg_solid(R, F, L, 0.8).translate((c[0], c[1], z - L / 2)), True))
            j.note = f'D-peg Ø{2 * R:.0f} × {L:.0f} mm, fits one way only'
    if kind == 'dowels':
        reg = S.window(z, 16.0)
        pr = 3.0
        pts = spread_points(reg, 2, pr + clr + 3.0)
        if len(pts) < 2 or np.linalg.norm(pts[0] - pts[1]) < 4 * pr:
            return make_joint(S, z, 'dpeg', clr, magnet)
        L = 30.0
        for p in pts:
            j.cutters.append(mf.Manifold.cylinder(L + 2, pr + clr, pr + clr, SEG).translate((p[0], p[1], z - L / 2 - 1)))
            j.extra.append(('Dowel Ø6 mm', round_pin(pr, L, 0.5).translate((p[0], p[1], z - L / 2)), True))
        j.note = 'two Ø6 × 30 mm dowels (also stop it twisting)'
    if kind in ('thread', 'twist'):
        r_in, c = inscribed(S.window(z, 16.0))
        R = min(16.0, r_in - 3.0 - clr)
        if R < 6.0:
            j.note = f'too thin here for a {"screw thread" if kind == "thread" else "twist-lock"}; using a D-peg instead'
            return _fallback(S, z, 'dpeg', clr, magnet, j.note)
        L = 12.0 if kind == 'thread' else 10.0
        if kind == 'thread':
            pitch = 6.0
            prof = mf.CrossSection.circle(R - 1.4, SEG) + mf.CrossSection.circle(R - 0.7, SEG).translate((0.7, 0))
            twist = L / pitch * 360.0
            spig = mf.Manifold.extrude(prof, L, int(L * 4), twist).translate((c[0], c[1], z - 0.01))
            sock = mf.Manifold.extrude(prof.offset(clr + 0.1, mf.JoinType.Round, 2, SEG), L + 1.0, int(L * 4) + 4, twist * (L + 1.0) / L).translate((c[0], c[1], z - 0.01))
            j.note = f'screw thread Ø{2 * R:.0f} mm, {pitch:.0f} mm pitch, 2 turns: screw the upper piece on clockwise'
        else:
            body = mf.Manifold.cylinder(L, R - 2.0, R - 2.0, SEG)
            lugs, slots = [], []
            for k in range(3):
                a = k * 120.0
                lug = mf.Manifold.cube((2.6, 4.0, 3.0)).translate((R - 2.6, -2.0, L - 4.0)).rotate((0, 0, a))
                lugs.append(lug)
                entry = mf.Manifold.cube((2.6 + 2 * clr + 0.2, 4.0 + 2 * clr, L + 0.6)).translate((R - 2.6 - clr - 0.1, -2.0 - clr, -0.01)).rotate((0, 0, a))
                ring = mf.CrossSection.square((2.6 + 2 * clr + 0.2, 3.0 + 2 * clr)).translate((R - 2.6 - clr - 0.1, L - 4.0 - clr))
                half = math.degrees(math.atan2(2.0 + clr + 0.2, R - 2.6 - clr)) + 1.5   # angular half-width of a lug
                arc = mf.Manifold.revolve(ring, SEG, 30.0 + 2 * half)   # revolve makes Y the axis; it stands on Z
                arc = arc.rotate((0, 0, a - 30.0 - half))                 # from 30 deg before the entry slot to just past it
                slots += [entry, arc]
            spig = (body + mf.Manifold.batch_boolean(lugs, mf.OpType.Add)).translate((c[0], c[1], z - 0.01))
            sock = (mf.Manifold.cylinder(L + 0.6, R - 2.0 + clr, R - 2.0 + clr, SEG) + mf.Manifold.batch_boolean(slots, mf.OpType.Add)).translate((c[0], c[1], z - 0.01))
            j.note = 'twist-lock: push the upper piece on (3 lugs) and turn it 30° anticlockwise to lock'
        j.add_lower.append(spig)
        j.cut_upper.append(sock)
    if kind == 'dovetail':
        reg = S.window(z, 8.0)
        r_in, c = inscribed(reg)
        if r_in < 9.0:
            return _fallback(S, z, 'dpeg', clr, magnet, 'too narrow here for a dovetail; using a D-peg instead')
        pts = np.vstack([np.asarray(p) for p in reg.to_polygons()])
        cov = np.cov((pts - pts.mean(0)).T); ev, evec = np.linalg.eigh(cov)
        ang = math.degrees(math.atan2(evec[1, 1], evec[0, 1]))           # slide along the long axis
        h, wb = 5.0, min(12.0, r_in)
        wt = wb + 2 * h * math.tan(math.radians(15))
        prof = mf.CrossSection([np.array([(-wb / 2, 0), (wb / 2, 0), (wt / 2, h), (-wt / 2, h)])], mf.FillRule.EvenOdd)
        span = 600.0
        bar = mf.Manifold.extrude(prof, span).rotate((90, 0, 0)).rotate((0, 0, 90))   # profile in YZ, running along X
        bar = bar.translate((-span / 2, 0, 0)).rotate((0, 0, ang)).translate((c[0], c[1], z - 0.01))
        lower_face = mf.Manifold.extrude(S.at(z - 0.5).offset(-0.8, mf.JoinType.Round, 2, SEG), h + 0.02).translate((0, 0, z - 0.01))
        tongue = bar ^ lower_face
        prof2 = prof.offset(clr, mf.JoinType.Miter, 2)
        groove = mf.Manifold.extrude(prof2, span).rotate((90, 0, 0)).rotate((0, 0, 90))
        groove = groove.translate((-span / 2, 0, -clr)).rotate((0, 0, ang)).translate((c[0], c[1], z - 0.01))
        if tongue.is_empty() or tongue.volume() < 50:
            return _fallback(S, z, 'dpeg', clr, magnet, 'dovetail would be too small here; using a D-peg instead')
        j.add_lower.append(tongue)
        j.cut_upper.append(groove)
        j.note = 'dovetail: slide the upper piece on from the side, then it can only lift off by sliding back'
    if kind == 'magnets':
        d, h = MAGNETS.get(magnet, MAGNETS['8x3'])
        reg = S.window(z, h + 2)
        r_in, _ = inscribed(reg)
        n = 2 if r_in < 25 else 3
        pts = spread_points(reg, n, d / 2 + clr + 2.4)
        if len(pts) < 2:
            j.note = f'too small for {magnet} mm magnets; glue face only'
            kind = 'none'
        else:
            for p in pts:
                j.cutters.append(mf.Manifold.cylinder(2 * (h + 0.2), d / 2 + clr, d / 2 + clr, SEG).translate((p[0], p[1], z - h - 0.2)))
            j.note = f'{len(pts)} pairs of {magnet} mm magnets ({2 * len(pts)} magnets), {h + 0.2:.1f} mm deep pockets'
            j.magnets = 2 * len(pts)
    if kind == 'sleeve':
        cop = sleeve(S, z, clr)
        if cop is None:
            return make_joint(S, z, 'none', clr, magnet)
        j.extra.append(('Sleeve coupler', cop, False))
        j.note = 'hollow-core sleeve (keyed by the bore shape, keeps a wire channel)'
    if kind == 'none' and not j.note:
        j.note = 'flat glue face'
    j.kind = kind
    return j


def _fallback(S, z, kind, clr, magnet, why):
    j = make_joint(S, z, kind, clr, magnet)
    j.note = why + ('; ' + j.note if j.note else '')
    return j


def sleeve(S, z, clr, depth=25.0, wall=3.0, step=0.75):
    """Best-fit plug inside a tube: at each depth its outline fits every bore section passed on the way in,
    with an even wall so a wire channel stays open."""
    def bore(zz):
        hs = holes_in(S.at(zz))
        if not hs:
            return None
        big = max(hs, key=lambda p: abs(0.5 * np.sum(p[:, 0] * np.roll(p[:, 1], -1) - np.roll(p[:, 0], -1) * p[:, 1])))
        return mf.CrossSection([big[::-1]], mf.FillRule.EvenOdd)
    seam = bore(z)
    if seam is None:
        return None
    slabs = []
    for side in (1, -1):
        B = seam
        n = int(depth / step)
        for k in range(n):
            b2 = bore(z + side * (k + 1) * step)
            if b2 is None:
                return None
            B = B ^ b2
            lead = 0.6 if k == n - 1 else 0.0
            outer = B.offset(-clr - 0.05 - lead, mf.JoinType.Miter, 2)
            ring = outer - B.offset(-clr - 0.05 - wall, mf.JoinType.Miter, 2)
            if ring.is_empty():
                return None
            z0 = z + k * step - 0.01 if side > 0 else z - (k + 1) * step - 0.01
            slabs.append(mf.Manifold.extrude(ring, step + 0.02).translate((0, 0, z0)))
    M = mf.Manifold.batch_boolean(slabs, mf.OpType.Add)
    return M if M.volume() > 1 else None


# ------------------------------------------------------------------ doing the split
def split_part(mesh, cuts, kinds, clr=0.2, magnet='8x3', progress=None, face_ext=None):
    """Returns (pieces, extras, notes). pieces: list of (Manifold, zlow, zhigh). extras: (name, Manifold, lie_flat)."""
    solid = to_mf(mesh, face_ext)
    S = Sections(solid, step=0.75)
    cuts = sorted(cuts)
    notes, extras = [], []
    cutters, adds, socks = [], [], []
    for i, z in enumerate(cuts):
        spec = kinds[i] if i < len(kinds) else 'dpeg'
        if isinstance(spec, (list, tuple)):          # placed by hand in the joint editor
            j = JointResult(); j.kind = 'custom'; notes_i = []
            for sp in spec:
                c_, a_, s_, e_, n_ = spec_geometry(sp, z, clr)
                j.cutters += c_; j.add_lower += a_; j.cut_upper += s_; j.extra += e_; notes_i.append(n_)
            j.note = ', '.join(notes_i) if notes_i else 'flat glue face'
            if not spec: j.kind = 'none'
            cutters += j.cutters
            adds.append(j.add_lower); socks.append(j.cut_upper)
            extras += [(f'{name} (cut {i + 1})', m, flat) for name, m, flat in j.extra]
            notes.append(dict(z=round(float(z), 1), kind=j.kind, note=j.note))
            if progress: progress((i + 1) / (len(cuts) + 1))
            continue
        j = make_joint(S, z, spec, clr, magnet)
        # holes and sockets must stay inside the part (never break through the surface), except a dovetail's open end
        checks = j.cutters + ([] if j.kind == 'dovetail' else j.cut_upper)
        for c in checks:
            if (c ^ solid).volume() < c.volume() - 1.0:
                j = make_joint(S, z, 'none', clr, magnet); j.note = 'that joint would break through the surface here; glue face only'
                break
        cutters += j.cutters
        adds.append(j.add_lower); socks.append(j.cut_upper)
        extras += [(f'{name} (cut {i + 1})', m, flat) for name, m, flat in j.extra]
        notes.append(dict(z=round(float(z), 1), kind=j.kind, note=j.note))
        if progress: progress((i + 1) / (len(cuts) + 1))
    if cutters:
        solid = solid - mf.Manifold.batch_boolean(cutters, mf.OpType.Add)
    bounds = [S.z0] + cuts + [S.z1 + 1]
    pieces = []
    for i in range(len(bounds) - 1):
        p = solid.trim_by_plane((0, 0, 1), bounds[i]) if i > 0 else solid
        p = p.trim_by_plane((0, 0, -1), -bounds[i + 1])
        if i < len(cuts) and adds[i]:
            p = p + mf.Manifold.batch_boolean(adds[i], mf.OpType.Add)          # spigot / tongue on top of this piece
        if i > 0 and socks[i - 1]:
            p = p - mf.Manifold.batch_boolean(socks[i - 1], mf.OpType.Add)     # matching socket / groove in the next
        pieces.append((p, bounds[i], min(bounds[i + 1], S.z1)))
    return pieces, extras, notes


# ================================================================== hand-placed joints (the joint editor)
# A spec is a dict: kind = dpeg | dowel | magnet | twist | thread, x, y (centre on the cut face, mm),
# d = outer diameter of the peg / dowel / spigot, dep = how far it goes into each piece,
# md, mt = magnet diameter and thickness (magnets only).
EDITABLE = ('dpeg', 'dowel', 'magnet', 'twist', 'thread')


def spec_geometry(sp, z, clr):
    """Real geometry for one hand-placed joint: cutters (both pieces), add_lower, cut_upper, extras, note."""
    k, x, y = sp['kind'], float(sp['x']), float(sp['y'])
    cut, add, sock, extra = [], [], [], []
    if k in ('dpeg', 'dowel'):
        R, dep = float(sp['d']) / 2, float(sp['dep'])
        L = max(6.0, 2 * dep - 2.0)                       # 1 mm spare at the bottom of each hole for glue
        F = R * (0.7 if k == 'dpeg' else 0.8)
        cut.append(hole_cutter(dsec(R + clr, F + clr) if k == 'dpeg' else mf.CrossSection.circle(R + clr, SEG), z, dep, dep, 0.6, R + clr).translate((x, y, 0)))
        solid = dpeg_solid(R, F, L, min(0.8, R / 4)).translate((x, y, z - L / 2))
        extra.append((f"{'D-peg' if k == 'dpeg' else 'Dowel'} Ø{2 * R:g} mm", solid, True))
        note = f"{'D-peg' if k == 'dpeg' else 'dowel'} Ø{2 * R:g} × {L:g} mm"
    elif k == 'magnet':
        md, mt = float(sp['md']), float(sp['mt'])
        pr, ph = md / 2 + clr, mt + 0.2
        cut.append(mf.Manifold.cylinder(2 * ph, pr, pr, SEG).translate((x, y, z - ph)))
        note = f'magnet pair {md:g} × {mt:g} mm'
    elif k in ('twist', 'thread'):
        R, L = float(sp['d']) / 2, float(sp['dep'])
        if k == 'thread':
            pitch = 6.0
            prof = mf.CrossSection.circle(R - 1.4, SEG) + mf.CrossSection.circle(R - 0.7, SEG).translate((0.7, 0))
            twist = L / pitch * 360.0
            add.append(mf.Manifold.extrude(prof, L, int(L * 4), twist).translate((x, y, z - 0.01)))
            sock.append(mf.Manifold.extrude(prof.offset(clr + 0.1, mf.JoinType.Round, 2, SEG), L + 1.0, int(L * 4) + 4, twist * (L + 1.0) / L).translate((x, y, z - 0.01)))
            note = f'screw thread Ø{2 * R:g} mm, 6 mm pitch: screw the upper piece on clockwise'
        else:
            body = mf.Manifold.cylinder(L, R - 2.0, R - 2.0, SEG)
            lugs, slots = [], []
            for kk in range(3):
                a = kk * 120.0
                lugs.append(mf.Manifold.cube((2.6, 4.0, 3.0)).translate((R - 2.6, -2.0, L - 4.0)).rotate((0, 0, a)))
                slots.append(mf.Manifold.cube((2.6 + 2 * clr + 0.2, 4.0 + 2 * clr, L + 0.6)).translate((R - 2.6 - clr - 0.1, -2.0 - clr, -0.01)).rotate((0, 0, a)))
                ring = mf.CrossSection.square((2.6 + 2 * clr + 0.2, 3.0 + 2 * clr)).translate((R - 2.6 - clr - 0.1, L - 4.0 - clr))
                half = math.degrees(math.atan2(2.0 + clr + 0.2, R - 2.6 - clr)) + 1.5
                slots.append(mf.Manifold.revolve(ring, SEG, 30.0 + 2 * half).rotate((0, 0, a - 30.0 - half)))
            add.append((body + mf.Manifold.batch_boolean(lugs, mf.OpType.Add)).translate((x, y, z - 0.01)))
            sock.append((mf.Manifold.cylinder(L + 0.6, R - 2.0 + clr, R - 2.0 + clr, SEG) + mf.Manifold.batch_boolean(slots, mf.OpType.Add)).translate((x, y, z - 0.01)))
            note = f'twist-lock Ø{2 * R:g} mm: push on and turn 30° anticlockwise'
    else:
        raise ValueError('unknown joint kind ' + str(k))
    return cut, add, sock, extra, note


def spec_reach(sp):
    """(radius, depth below the cut, depth above the cut) that a joint occupies, for wall checks."""
    k = sp['kind']
    if k == 'magnet':
        return float(sp['md']) / 2 + 0.2, float(sp['mt']) + 0.2, float(sp['mt']) + 0.2
    if k in ('twist', 'thread'):
        return float(sp['d']) / 2 + 0.3, 0.0, float(sp['dep']) + 1.0
    return float(sp['d']) / 2 + 0.2, float(sp['dep']), float(sp['dep'])


def check_specs(solid, z, specs, wall, z_lo, z_hi):
    """Exact checks against the real part. Returns one list of problems per joint: dicts lvl (red/amber) and text."""
    out = [[] for _ in specs]
    fats = []
    for i, sp in enumerate(specs):
        r, dn, up = spec_reach(sp)
        x, y = float(sp['x']), float(sp['y'])
        n = i + 1
        if dn + wall > z - z_lo + 1e-6:
            out[i].append(dict(lvl='red', text=f'Joint {n} goes {dn:g} mm down but the piece below is only {z - z_lo:.0f} mm (needs {wall:g} mm left)'))
        if up + wall > z_hi - z + 1e-6:
            out[i].append(dict(lvl='red', text=f'Joint {n} goes {up:g} mm up but the piece above is only {z_hi - z:.0f} mm (needs {wall:g} mm left)'))
        def body(extra):
            lo = z - (dn + extra if dn > 0 else 1.0)
            hi = z + up + extra
            return mf.Manifold.cylinder(hi - lo, r + extra, r + extra, SEG).translate((x, y, lo))
        core = body(0.0)
        inside = (core ^ solid).volume()
        if inside < core.volume() * 0.995 - 0.5:
            out[i].append(dict(lvl='red', text=f'Joint {n} cuts through the outside of the part'))
        else:
            fat = body(wall)
            if (fat ^ solid).volume() < fat.volume() * 0.995 - 0.5:
                out[i].append(dict(lvl='red', text=f'Joint {n}: the wall around it is thinner than {wall:g} mm somewhere; move it in or make it smaller'))
            else:
                fat2 = body(wall + 1.5)
                if (fat2 ^ solid).volume() < fat2.volume() * 0.995 - 0.5:
                    out[i].append(dict(lvl='amber', text=f'Joint {n}: the wall is close to the {wall:g} mm minimum'))
        fats.append((body(wall), core))
    for i in range(len(specs)):
        for k in range(i + 1, len(specs)):
            if (fats[i][0] ^ fats[k][1]).volume() > 0.5:
                out[i].append(dict(lvl='red', text=f'Joints {i + 1} and {k + 1} overlap or are too close'))
    return out


def auto_specs(S, z, kind, clr=0.2, magnet=(8.0, 3.0)):
    """Starting positions for the editor (the same choices Auto-place makes)."""
    if kind == 'magnet':
        md, mt = magnet
        reg = S.window(z, mt + 2)
        r_in, _ = inscribed(reg)
        n = 2 if r_in < 25 else 3
        pts = spread_points(reg, n, md / 2 + clr + 4.6)
        return [dict(kind='magnet', x=round(float(p[0]), 2), y=round(float(p[1]), 2), md=md, mt=mt, d=md + 2 * clr, dep=mt + 0.2) for p in pts]
    if kind == 'dowel':
        reg = S.window(z, 16.0)
        pts = spread_points(reg, 2, 3.0 + clr + 4.6)
        return [dict(kind='dowel', x=round(float(p[0]), 2), y=round(float(p[1]), 2), d=6.0, dep=16.0) for p in pts]
    if kind in ('twist', 'thread'):
        r_in, c = inscribed(S.window(z, 16.0))
        if c is None or r_in < 9.0:
            return []
        R = max(6.0, min(16.0, r_in - 4.7 - clr))
        return [dict(kind=kind, x=round(float(c[0]), 2), y=round(float(c[1]), 2), d=round(2 * R, 1), dep=12.0 if kind == 'thread' else 10.0)]
    for half in (26.0, 12.0, 4.0):
        r_in, c = inscribed(S.window(z, half))
        if c is not None and r_in > 6.0:
            break
    if c is None or r_in < 6.0:
        return []                      # too thin or hollow here: the editor says so and suggests the sleeve
    R = max(3.0, min(10.0, r_in - 4.7 - clr))
    return [dict(kind='dpeg', x=round(float(c[0]), 2), y=round(float(c[1]), 2), d=round(2 * R, 1), dep=26.0 if R >= 8 else round(max(8.0, 2.5 * R + 1), 1))]
