"""Hollow a part: an even inner wall all round, solid ends where joints sit, and an optional wire channel."""
import math
import numpy as np
import manifold3d as mf
import split

SEG = 64


def hollow(mesh, wall=3.0, solid_bottom=3.0, solid_top=3.0, channel=0.0, step=1.0, progress=None, face_ext=None):
    solid = split.to_mf(mesh, face_ext)
    S = split.Sections(solid, step=0.5)
    z0, z1 = S.z0 + max(wall, solid_bottom), S.z1 - max(wall, solid_top)
    slabs = []
    zs = np.arange(z0, z1, step)
    for i, z in enumerate(zs):
        # what is solid everywhere within one wall-thickness above and below, pulled in by the wall:
        # that keeps the wall at least `wall` thick even on sloping surfaces
        win = S.window(z + step / 2, wall)
        if win.is_empty():
            continue
        inner = win.offset(-wall, mf.JoinType.Round, 2, SEG)
        if inner.is_empty() or inner.area() < 4.0:
            continue
        slabs.append(mf.Manifold.extrude(inner, min(step, z1 - z) + 0.02).translate((0, 0, z - 0.01)))
        if progress and i % 10 == 0:
            progress(i / max(1, len(zs)))
    cavity = mf.Manifold.batch_boolean(slabs, mf.OpType.Add) if slabs else None
    before = solid.volume()
    out = solid - cavity if cavity is not None else solid
    note = []
    if channel and channel > 0:
        mid = S.at((S.z0 + S.z1) / 2)
        r_in, c = split.inscribed(mid)
        if r_in * 2 < channel + 2 * wall:
            note.append(f'the part is too thin for a {channel:.0f} mm wire channel, so none was added')
        else:
            out = out - mf.Manifold.cylinder(S.z1 - S.z0 + 2, channel / 2, channel / 2, SEG).translate((c[0], c[1], S.z0 - 1))
            note.append(f'{channel:.0f} mm wire channel straight through (pegs at the ends will block it: use sleeve or magnet joints for wired parts)')
    saved = before - out.volume()
    note.insert(0, f'{wall:g} mm walls, {saved / 1000:.0f} cm³ less material ({100 * saved / before:.0f}%)' if cavity is not None else 'too small to hollow')
    return out, '; '.join(note), saved
