"""Fonts for 3D text: every font installed on the PC (plus ones you add or download), read straight from the font files."""
import json, math, os, re, sys, threading, time, urllib.request
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
_lock = threading.Lock()
_index = None


def data_dir():
    base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~/.local/share')
    d = os.path.join(base, 'BambuForgeStudio', 'fonts'); os.makedirs(d, exist_ok=True)
    return d


def font_dirs():
    out = [data_dir()]
    if sys.platform == 'win32':
        out += [os.path.join(os.environ.get('WINDIR', r'C:\Windows'), 'Fonts'),
                os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Microsoft', 'Windows', 'Fonts')]
    else:
        out += ['/usr/share/fonts', '/usr/local/share/fonts', os.path.expanduser('~/.fonts'), os.path.expanduser('~/.local/share/fonts')]
    return [d for d in out if d and os.path.isdir(d)]


def _scan_file(path):
    from fontTools.ttLib import TTFont
    f = TTFont(path, fontNumber=0, lazy=True)
    name = f['name']
    def nm(*ids):
        for i in ids:
            r = name.getDebugName(i)
            if r: return r
        return None
    fam = nm(16, 1); sub = (nm(17, 2) or 'Regular').lower()
    os2 = f['OS/2'] if 'OS/2' in f else None
    weight = os2.usWeightClass if os2 else (700 if 'bold' in sub else 400)
    italic = bool(os2 and (os2.fsSelection & 1)) or 'italic' in sub or 'oblique' in sub
    f.close()
    if not fam: return None
    return {'family': fam, 'bold': weight >= 600 or 'bold' in sub, 'italic': italic, 'weight': weight, 'sub': sub, 'path': path}


def index(rescan=False):
    """{family: {'regular'|'bold'|'italic'|'bolditalic': path}}; cached on disk and only re-read for new or changed files."""
    global _index
    with _lock:
        if _index is not None and not rescan: return _index
        cache_p = os.path.join(data_dir(), '.index.json')
        try: cache = json.load(open(cache_p, encoding='utf-8'))
        except Exception: cache = {}
        files, entries = {}, []
        for d in font_dirs():
            for root, _, names in os.walk(d):
                for n in names:
                    if n.lower().endswith(('.ttf', '.otf', '.ttc')):
                        p = os.path.join(root, n)
                        try: files[p] = os.path.getmtime(p)
                        except OSError: pass
        new_cache = {}
        for p, mt in files.items():
            c = cache.get(p)
            if c and c.get('mt') == mt: e = c.get('e')
            else:
                try: e = _scan_file(p)
                except Exception: e = None
            new_cache[p] = {'mt': mt, 'e': e}
            if e: entries.append(e)
        try: json.dump(new_cache, open(cache_p, 'w', encoding='utf-8'))
        except Exception: pass
        fams = {}
        for e in entries:
            key = ('bold' if e['bold'] else '') + ('italic' if e['italic'] else '') or 'regular'
            v = fams.setdefault(e['family'], {})
            # prefer the plainest file for each slot (e.g. "Bold" over "Bold Condensed")
            if key not in v or len(e['sub']) < len(v[key + '_sub']):
                v[key] = e['path']; v[key + '_sub'] = e['sub']
        _index = {k: {s: p for s, p in v.items() if not s.endswith('_sub')} for k, v in fams.items()}
        return _index


def families():
    return sorted(index().keys(), key=str.lower)


# ------------------------------------------------------------------ outlines
class _FlatPen:
    """Turns glyph outlines (lines, quadratic and cubic curves) into closed polylines."""
    def __init__(self, steps=7):
        from fontTools.pens.basePen import BasePen
        outer = self
        class P(BasePen):
            def _moveTo(s, pt): outer.cur = [pt]; outer.contours.append(outer.cur)
            def _lineTo(s, pt): outer.cur.append(pt)
            def _curveToOne(s, p1, p2, p3):
                p0 = outer.cur[-1]
                for i in range(1, steps + 1):
                    t = i / steps; u = 1 - t
                    outer.cur.append((u**3 * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t**3 * p3[0],
                                      u**3 * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t**3 * p3[1]))
            def _qCurveToOne(s, p1, p2):
                p0 = outer.cur[-1]
                for i in range(1, steps + 1):
                    t = i / steps; u = 1 - t
                    outer.cur.append((u * u * p0[0] + 2 * u * t * p1[0] + t * t * p2[0], u * u * p0[1] + 2 * u * t * p1[1] + t * t * p2[1]))
            def _closePath(s): pass
            def _endPath(s): pass
        self.contours, self.cur = [], None
        self.pen = None; self._P = P

    def bind(self, glyphset):
        self.pen = self._P(glyphset); return self.pen


_font_cache = {}


def _load(path):
    from fontTools.ttLib import TTFont
    if path not in _font_cache:
        f = TTFont(path, fontNumber=0)
        _font_cache[path] = (f, f.getGlyphSet(), f.getBestCmap() or {})
    return _font_cache[path]


def pick(family, bold, italic):
    """The font file for this family and style, and what still has to be faked (no bold/italic file)."""
    v = index().get(family) or index().get(next((k for k in index() if k.lower() == str(family).lower()), ''), {})
    if not v:
        fam = families(); v = index()[fam[0]] if fam else {}
    want = ('bold' if bold else '') + ('italic' if italic else '') or 'regular'
    if want in v: return v[want], False, False
    if bold and italic and 'bold' in v: return v['bold'], False, True
    if bold and italic and 'italic' in v: return v['italic'], True, False
    if bold and 'bold' in v: return v['bold'], False, False
    if italic and 'italic' in v: return v['italic'], False, False
    path = v.get('regular') or next(iter(v.values()))
    return path, bool(bold), bool(italic)


def layout(text, family, size_mm, bold=False, italic=False, underline=False, spacing=0.0):
    """Every letter of `text` as closed outlines in mm, laid out on one line centred on 0; letter height (capital H) = size_mm.
    Returns {'glyphs': [{'ch', 'x' (centre), 'w', 'contours': [[[x,y]...]...]}], 'width', 'height', 'underline': rect or None}."""
    path, fake_bold, fake_italic = pick(family, bold, italic)
    f, gs, cmap = _load(path)
    upm = f['head'].unitsPerEm
    cap = getattr(f['OS/2'], 'sCapHeight', 0) if 'OS/2' in f else 0
    if not cap or cap <= 0:
        try:
            g = cmap.get(ord('H')); fp = _FlatPen(); gs[g].draw(fp.bind(gs)); ys = [p[1] for c in fp.contours for p in c]; cap = max(ys) - min(ys)
        except Exception: cap = upm * 0.7
    k = float(size_mm) / cap
    hmtx = f['hmtx']
    glyphs, pen_x = [], 0.0
    for ch in str(text):
        gname = cmap.get(ord(ch)) or cmap.get(ord('?'))
        adv = hmtx[gname][0] * k if gname in hmtx.metrics else upm * 0.5 * k
        if ch.strip() and gname:
            fp = _FlatPen(); gs[gname].draw(fp.bind(gs))
            cs = [[[(x * k), (y * k)] for x, y in c] for c in fp.contours if len(c) >= 3]
            if fake_italic: cs = [[[x + y * 0.21, y] for x, y in c] for c in cs]
            xs = [p[0] for c in cs for p in c]
            if xs:
                mid = (min(xs) + max(xs)) / 2
                glyphs.append({'ch': ch, 'x': pen_x + mid, 'w': max(xs) - min(xs), 'contours': [[[round(x - mid, 3), round(y - size_mm / 2, 3)] for x, y in c] for c in cs]})
        pen_x += adv + float(spacing)
    total = pen_x - float(spacing)
    for g in glyphs: g['x'] = round(g['x'] - total / 2, 3)
    ul = None
    if underline and total > 0:
        t = max(0.4, size_mm * 0.08); y = -size_mm / 2 - size_mm * 0.16
        ul = [[-total / 2, y - t], [total / 2, y - t], [total / 2, y], [-total / 2, y]]
    return {'glyphs': glyphs, 'width': round(total, 3), 'height': size_mm, 'underline': ul, 'fake_bold': fake_bold,
            'file': os.path.basename(path)}


# ------------------------------------------------------------------ free fonts to download (open licence, from Google Fonts' GitHub)
FREE = {}   # filled from free_fonts.json (name -> list of raw URLs: regular, bold, italic, bolditalic)


def free_list():
    global FREE
    if not FREE:
        try: FREE.update(json.load(open(os.path.join(HERE, 'free_fonts.json'), encoding='utf-8')))
        except Exception: pass
    have = set(index().keys())
    return [{'name': n, 'installed': n in have} for n in sorted(FREE)]


def download(name):
    free_list()
    urls = FREE.get(name)
    if not urls: raise ValueError('That font is not in the free list.')
    d = data_dir(); got = []
    for u in urls:
        fn = os.path.join(d, re.sub(r'[^A-Za-z0-9_.\[\]-]+', '_', u.rsplit('/', 1)[-1]))
        if not os.path.exists(fn):
            req = urllib.request.Request(u, headers={'User-Agent': 'BambuForgeStudio'})
            with urllib.request.urlopen(req, timeout=60) as r, open(fn + '.tmp', 'wb') as out: out.write(r.read())
            os.replace(fn + '.tmp', fn)
        got.append(fn)
    index(rescan=True)
    return got


def add_file(path):
    import shutil
    dst = os.path.join(data_dir(), os.path.basename(path)); shutil.copy2(path, dst)
    e = _scan_file(dst)
    index(rescan=True)
    return e['family'] if e else None
