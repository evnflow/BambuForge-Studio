"""Models: browse model sites in a BambuForge browser window, catch downloads into a library, search every site."""
import json, os, re, shutil, time, urllib.parse

BUILT_IN = [   # name, home page, search address ({q} = the words), colour
    ('MakerWorld', 'https://makerworld.com/en', 'https://makerworld.com/en/search/models?keyword={q}', '#00AE42'),
    ('Printables', 'https://www.printables.com', 'https://www.printables.com/search/models?q={q}', '#FA6831'),
    ('Thingiverse', 'https://www.thingiverse.com', 'https://www.thingiverse.com/search?q={q}&type=things', '#248BFB'),
    ('Cults', 'https://cults3d.com/en', 'https://cults3d.com/en/search?q={q}', '#8E44AD'),
    ('MyMiniFactory', 'https://www.myminifactory.com', 'https://www.myminifactory.com/search/?query={q}', '#D81B60'),
    ('Thangs', 'https://thangs.com', 'https://thangs.com/search/{q}', '#00897B'),
    ('Free3D', 'https://free3d.com', 'https://free3d.com/3d-models/{q}', '#F9A825'),
]
COLOURS = ['#5D4037', '#3949AB', '#00838F', '#7CB342', '#F4511E', '#6D4C41', '#8E24AA', '#039BE5']
MODEL_EXT = ('.3mf', '.stl', '.obj', '.step', '.stp', '.zip')
# common search addresses many sites use, tried in order for sites you add
GUESSES = ['/search?q={q}', '/search?query={q}', '/search/?q={q}', '/?s={q}', '/search/{q}']


def _documents():
    """The real Documents folder (it may have been moved, e.g. into OneDrive)."""
    import sys
    if sys.platform == 'win32':
        try:
            import ctypes, uuid
            class GUID(ctypes.Structure):
                _fields_ = [('Data1', ctypes.c_uint32), ('Data2', ctypes.c_uint16), ('Data3', ctypes.c_uint16), ('Data4', ctypes.c_ubyte * 8)]
            g = uuid.UUID('{FDD39AD0-238F-46AF-ADB4-6C85480369C7}')            # FOLDERID_Documents
            guid = GUID(g.fields[0], g.fields[1], g.fields[2], (ctypes.c_ubyte * 8)(*g.bytes[8:]))
            p = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(guid), 0, None, ctypes.byref(p)) == 0:
                path = p.value; ctypes.windll.ole32.CoTaskMemFree(p)
                if path: return path
        except Exception:
            pass
    return os.path.join(os.path.expanduser('~'), 'Documents')


_LIB = None


def library_dir():
    """Documents\\BambuForge\\Library; if that can't be made (a missing or offline Documents folder), BambuForge's own data folder."""
    global _LIB
    if _LIB and os.path.isdir(_LIB): return _LIB
    tries = [os.path.join(_documents(), 'BambuForge', 'Library'),
             os.path.join(os.environ.get('LOCALAPPDATA') or os.path.expanduser('~/.local/share'), 'BambuForgeStudio', 'Library'),
             os.path.join(os.path.expanduser('~'), 'BambuForge Library')]
    last = None
    for d in tries:
        try:
            os.makedirs(d, exist_ok=True)
            if os.path.isdir(d):
                _LIB = d; return d
        except OSError as e:
            last = e
    raise last or OSError('No folder for the model library could be made.')


def _meta_path(): return os.path.join(library_dir(), '.library.json')


def load_meta():
    try: return json.load(open(_meta_path(), encoding='utf-8'))
    except Exception: return {}


def save_meta(m):
    tmp = _meta_path() + '.tmp'
    json.dump(m, open(tmp, 'w', encoding='utf-8'), indent=1); os.replace(tmp, _meta_path())


def sites(prefs):
    """Built-in sites (unless hidden) plus the ones you added, in your order."""
    st = prefs.get('sites') or {}
    hidden = set(st.get('hidden', []))
    out = [{'name': n, 'home': h, 'search': s, 'color': c, 'builtin': True} for n, h, s, c in BUILT_IN if n not in hidden]
    out += [dict(x, builtin=False) for x in st.get('mine', [])]
    order = st.get('order') or []
    first = {x['name']: i for i, x in enumerate(out)}          # (a list is empty while it's being sorted, so look up positions first)
    out.sort(key=lambda x: order.index(x['name']) if x['name'] in order else 1000 + first[x['name']])
    return out


def clean_url(u):
    u = (u or '').strip()
    if not u: return None
    if not re.match(r'^https?://', u, re.I): u = 'https://' + u
    p = urllib.parse.urlparse(u)
    if not p.netloc or '.' not in p.netloc: return None
    return u.rstrip('/')


def guess_name(u):
    host = urllib.parse.urlparse(u).netloc.lower()
    host = host[4:] if host.startswith('www.') else host
    base = host.split('.')[0]
    return base[:1].upper() + base[1:] if base else host


def search_url(site, q):
    q = urllib.parse.quote(q.strip())
    tpl = site.get('search')
    if tpl: return tpl.replace('{q}', q)
    return site['home'].rstrip('/') + GUESSES[0].replace('{q}', q)


def learn_search(site_home, url_after_search, q):
    """You searched once on a site you added: work out its search address from where it took you."""
    if not url_after_search or not q: return None
    enc = [urllib.parse.quote(q), urllib.parse.quote_plus(q), q.replace(' ', '+'), q.replace(' ', '%20'), q]
    for e in enc:
        if e and e in url_after_search:
            return url_after_search.replace(e, '{q}', 1)
    return None


def library(prefs=None):
    d, meta = library_dir(), load_meta()
    out = []
    for f in sorted(os.listdir(d), key=lambda n: -os.path.getmtime(os.path.join(d, n))):
        p = os.path.join(d, f)
        if f.startswith('.') or not os.path.isfile(p) or not f.lower().endswith(MODEL_EXT): continue
        m = meta.get(f, {})
        out.append({'file': f, 'path': p, 'size': os.path.getsize(p), 'when': time.strftime('%b %d %I:%M %p', time.localtime(os.path.getmtime(p))),
                    'source': m.get('source', 'Added by you'), 'page': m.get('page'), 'kind': f.rsplit('.', 1)[-1].upper()})
    return out


def unique_name(folder, name):
    name = re.sub(r'[\\/:*?"<>|]+', '_', name).strip() or 'model'
    base, ext = os.path.splitext(name); n = 1; out = name
    while os.path.exists(os.path.join(folder, out)):
        n += 1; out = f'{base} ({n}){ext}'
    return out


def add_to_library(src_path, source=None, page=None, move=False):
    d = library_dir(); name = unique_name(d, os.path.basename(src_path)); dst = os.path.join(d, name)
    (shutil.move if move else shutil.copy2)(src_path, dst)
    meta = load_meta(); meta[name] = {'source': source or 'Added by you', 'page': page, 'added': time.time()}; save_meta(meta)
    return dst


def note_download(path, source, page):
    meta = load_meta(); name = os.path.basename(path)
    meta[name] = {'source': source, 'page': page, 'added': time.time()}; save_meta(meta)


def remove(file):
    p = os.path.join(library_dir(), os.path.basename(file))
    if os.path.exists(p): os.remove(p)
    meta = load_meta(); meta.pop(os.path.basename(file), None); save_meta(meta)


def model_in_zip(path):
    """Many sites download a .zip: pull the model files out of it into the library."""
    import zipfile
    out = []
    try:
        with zipfile.ZipFile(path) as z:
            for n in z.namelist():
                if n.lower().endswith(('.3mf', '.stl', '.obj', '.step', '.stp')) and not n.startswith('__MACOSX'):
                    d = library_dir(); name = unique_name(d, os.path.basename(n))
                    with z.open(n) as src, open(os.path.join(d, name), 'wb') as dst: shutil.copyfileobj(src, dst)
                    out.append(os.path.join(d, name))
    except Exception:
        pass
    return out
