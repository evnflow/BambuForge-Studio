// BambuForge Studio: Masks. Scan your face with the PC camera, try a mask on live, then print it shaped to your face.
// Face tracking is Google's MediaPipe Face Mesh running entirely on this PC (vendor/facemesh); nothing is uploaded.
const $ = id => document.getElementById(id);
const X = () => window.studio && window.studio.ctx;
const IRIS_MM = 11.7;                      // the coloured part of the eye is about 11.7 mm across in almost everyone: it gives the real size
const DEF = { size: 100, gap: 2, th: 2, ud: 0, reach: 8, ogap: 12.7 };
const HALF_INCH = 12.7;
const M = {
  on: false, stream: null, cams: [], cam: null, fm: null, fmReady: false, busy: false,
  lm: null, W: 1280, H: 720, step: 'scan', view: 'live', type: 0, ...DEF, typeChosen: false,
  scanning: false, frames: [], scan: null, mask: null, maskKey: '', fps: 0, lastT: 0, imgSrc: null,
};
const TYPES = [
  ['Eye mask', 'M3 14 Q12 6 23 12 Q34 6 43 14 Q34 22 23 16 Q12 22 3 14Z'],
  ['Half mask', 'M6 8 Q23 4 40 8 Q40 24 23 29 Q6 24 6 8Z'],
  ['Full face', 'M8 3 Q23 -2 38 3 Q42 18 23 29 Q4 18 8 3Z'],
  ['Your mask', 'M10 6 L36 6 L36 24 L10 24Z'],
];
let TRIS = null, EYE_R = null, EYE_L = null, LIPS_IN = null;
let three = null;     // { r, sc, cam, maskMesh, faceMesh, ... } for the overlay; three3 for the 3D view
let three3 = null;

// ------------------------------------------------------------------ cameras
async function listCams() {
  let devs = [];
  try { devs = (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === 'videoinput'); } catch (_) {}
  const ui = (X() && X().ui ? X().ui() : {}) || {};
  const virt = /virtual|obs|snap camera|manycam|xsplit/i;
  M.cams = devs.map((d, i) => ({ id: d.deviceId || ('cam' + i), name: d.label || `Camera ${i + 1}`, kind: /usb|logitech|razer|elgato/i.test(d.label) ? 'USB' : (virt.test(d.label) ? 'Virtual' : 'On this PC'), virtual: virt.test(d.label) }));
  renderDD();
  return M.cams;
}
function camLabel(c) { return c ? `${c.kind === 'Virtual' ? 'Virtual camera' : c.kind}${c.res ? ' · ' + c.res : ''}` : 'click to choose'; }
function renderDD() {
  const c = M.cam && M.cams.find(x => x.id === M.cam.id) || M.cam;
  const b = $('fmDDB');
  b.querySelector('.fmnm').innerHTML = `<b>${esc(c ? c.name : (M.cams.length ? 'Choose a camera' : 'No camera found'))}</b><span>${esc(c ? camLabel(c) : (M.cams.length ? 'click to choose' : 'plug one in, or Add a camera'))}</span>`;
}
function renderMenu() {
  const m = $('fmMenu'); m.innerHTML = '';
  const groups = {}; M.cams.forEach(c => (groups[c.virtual ? 'Virtual' : 'On this PC'] = groups[c.virtual ? 'Virtual' : 'On this PC'] || []).push(c));
  if (!M.cams.length) m.insertAdjacentHTML('beforeend', '<div class="fmgrp">No cameras found</div>');
  Object.entries(groups).forEach(([g, list]) => {
    m.insertAdjacentHTML('beforeend', `<div class="fmgrp">${g}</div>`);
    list.forEach(c => {
      const on = M.cam && M.cam.id === c.id;
      const it = document.createElement('div'); it.className = 'fmit' + (on ? ' on' : '');
      it.innerHTML = `<span class="ck">${on ? '✓' : ''}</span><span class="fmthumb">${on ? '<canvas width="92" height="60"></canvas>' : '<span style="display:flex;align-items:center;justify-content:center;height:100%;font-size:15px">📷</span>'}</span><span class="fmnm"><b>${esc(c.name)}</b><span>${esc(camLabel(c))}${c.virtual ? ' · shows a video, not a real camera' : ''}</span></span>`;
      it.onclick = () => { hideMenu(); useCam(c); };
      m.appendChild(it);
    });
  });
  m.insertAdjacentHTML('beforeend', '<div class="sepl"></div>');
  const add = document.createElement('div'); add.className = 'fmadd'; add.innerHTML = '<span class="fmplus">+</span><span class="fmnm"><b style="color:var(--green2)">Add a camera…</b><span>your phone, or a network camera</span></span>';
  add.onclick = () => { hideMenu(); openAdd(); }; m.appendChild(add);
  const rf = document.createElement('div'); rf.className = 'fmadd'; rf.style.color = 'var(--text)'; rf.innerHTML = '<span class="fmplus" style="border-color:#4A4A51">⟳</span><span class="fmnm"><b>Look for cameras again</b><span>after plugging one in</span></span>';
  rf.onclick = async e => { e.stopPropagation(); rf.querySelector('.fmnm span').textContent = 'looking…'; await listCams(); renderMenu(); }; m.appendChild(rf);
}
function hideMenu() { $('fmMenu').classList.add('hidden'); $('fmDDB').classList.remove('open'); }
async function useCam(c) {
  stopCam();
  M.cam = c; renderDD();
  const [w, h] = $('fmRes').value.split('x').map(Number);
  try {
    M.stream = await navigator.mediaDevices.getUserMedia({ video: { deviceId: c.id && !c.id.startsWith('cam') ? { exact: c.id } : undefined, width: { ideal: w }, height: { ideal: h } }, audio: false });
  } catch (e) {
    hint(e && e.name === 'NotAllowedError' ? 'The camera was blocked. Allow it when Windows asks, or in Settings → Privacy & security → Camera.' : `That camera couldn't start (${e && e.name || e}). Is another app using it?`, true);
    $('fmBadge').textContent = 'Camera off'; $('fmDot').classList.remove('on'); return;
  }
  const v = $('fmVideo'); v.srcObject = M.stream; await v.play().catch(() => {});
  const t = M.stream.getVideoTracks()[0], s = t.getSettings ? t.getSettings() : {};
  c.res = `${s.width || w} × ${s.height || h}`; M.W = s.width || v.videoWidth || w; M.H = s.height || v.videoHeight || h;
  // labels only appear after the first permission: list again so names show
  if (!c.name || /^Camera \d/.test(c.name)) { await listCams(); M.cam = M.cams.find(x => x.id === c.id) || c; }
  M.cam.res = c.res; renderDD();
  try { X().api().set_ui_pref('fmCam', M.cam.name); } catch (_) {}
  $('fmBadge').textContent = `${M.cam.name} · ${M.cam.res}`; $('fmDot').classList.add('on');
  hint(M.scan ? 'Pick a mask, then adjust it until it fits.' : 'Look at the camera, then press Start scanning.');
  layout();
}
function stopCam() { if (M.stream) { M.stream.getTracks().forEach(t => t.stop()); M.stream = null; } $('fmVideo').srcObject = null; $('fmDot').classList.remove('on');
  M.imgSrc = null; $('fmImg').classList.add('hidden'); $('fmImg').removeAttribute('src'); $('fmVideo').classList.remove('hidden'); }

// ------------------------------------------------------------------ face tracking
async function startTracking() {
  if (M.fm || !window.FaceMesh) return;
  M.fm = new window.FaceMesh({ locateFile: f => `vendor/facemesh/${f}` });
  M.fm.setOptions({ maxNumFaces: 1, refineLandmarks: true, minDetectionConfidence: 0.5, minTrackingConfidence: 0.5 });
  M.fm.onResults(r => { M.lm = (r.multiFaceLandmarks && r.multiFaceLandmarks[0]) || null; if (r.image) { M.W = r.image.width || M.W; M.H = r.image.height || M.H; } });
  try { await M.fm.initialize(); M.fmReady = true; } catch (e) { hint("Face tracking couldn't start on this PC: " + (e && e.message || e), true); }
}
function source() { if (M.imgSrc) return M.imgSrc; const v = $('fmVideo'); return v && v.readyState >= 2 ? v : null; }
async function tick() {
  if (!M.on) return;
  requestAnimationFrame(tick);
  const src = source();
  if (src && M.fmReady && !M.busy) {
    M.busy = true; const t0 = performance.now();
    try { await M.fm.send({ image: src }); } catch (_) {}
    M.busy = false; const dt = performance.now() - t0; M.fps = M.fps * 0.9 + (1000 / Math.max(1, dt)) * 0.1;
    $('fmFps').textContent = M.lm ? `tracking · ${Math.round(M.fps)} fps` : 'no face in view';
    if (M.scanning) scanStep();
  }
  drawThumb(); renderOverlay(); if (M.view !== 'live') render3d();
}
function drawThumb() {
  const src = source(); if (!src) return;
  document.querySelectorAll('#fmDD .fmddb canvas, #fmMenu .fmit.on canvas').forEach(cv => { try { cv.getContext('2d').drawImage(src, 0, 0, cv.width, cv.height); } catch (_) {} });
}

// ------------------------------------------------------------------ geometry helpers
function initTopology() {
  if (TRIS) return;
  const E = window.FACEMESH_TESSELATION || [], tris = [];
  for (let i = 0; i + 2 < E.length; i += 3) {
    const [a, b] = E[i], [b2, c] = E[i + 1], [c2, a2] = E[i + 2];
    if (b === b2 && c === c2 && a === a2) tris.push([a, b, c]);
  }
  TRIS = tris;
  const loop = arr => [...new Set((arr || []).flat())];
  EYE_R = loop(window.FACEMESH_RIGHT_EYE); EYE_L = loop(window.FACEMESH_LEFT_EYE); LIPS_IN = loop(window.FACEMESH_LIPS);
}
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]], mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2], cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = a => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
const mean = (P, ids) => { let s = [0, 0, 0]; ids.forEach(i => s = add(s, P[i])); return mul(s, 1 / ids.length); };
// landmarks -> points in face coords (mm): x right, y up, z towards the camera; and how many mm one pixel is
function toFace(lm, W, H) {
  const px = lm.map(p => [p.x * W, p.y * H, p.z * W]);
  const iris = c => { const d1 = Math.hypot(px[c + 1][0] - px[c + 3][0], px[c + 1][1] - px[c + 3][1]), d2 = Math.hypot(px[c + 2][0] - px[c + 4][0], px[c + 2][1] - px[c + 4][1]); return (d1 + d2) / 2; };
  const irisPx = lm.length >= 478 ? (iris(468) + iris(473)) / 2 : 0;
  const mmpp = irisPx > 2 ? IRIS_MM / irisPx : 0.25;
  return { P: px.map(p => [p[0] * mmpp, -p[1] * mmpp, -p[2] * mmpp]), mmpp };
}
// the face's own frame: origin between the eyes, x across, y up the face, z out of it
function frameOf(P) {
  const eR = mean(P, [33, 133]), eL = mean(P, [263, 362]), o = mul(add(eR, eL), 0.5);
  const ex = norm(sub(eL, eR)); let up = norm(sub(P[10], P[152])); const ey = norm(sub(up, mul(ex, dot(up, ex)))); const ez = cross(ex, ey);
  return { o, ex, ey, ez };
}
const toCanon = (P, F) => P.map(p => { const d = sub(p, F.o); return [dot(d, F.ex), dot(d, F.ey), dot(d, F.ez)]; });

// ------------------------------------------------------------------ scanning: average many frames in the face's own frame
function startScan() {
  if (!M.lm) { hint('No face found yet. Look straight at the camera with your face well lit.', true); return; }
  M.frames = []; M.scanning = true; $('fmScan').textContent = 'Scanning…'; $('fmScan').disabled = true; hint('Turn your head slowly to the left… then to the right.');
}
function scanStep() {
  if (!M.lm || M.lm.length < 468) return;
  const { P, mmpp } = toFace(M.lm, M.W, M.H); const F = frameOf(P);
  const yaw = Math.atan2(F.ex[2], F.ex[0]) * 180 / Math.PI;
  M.frames.push({ C: toCanon(P.slice(0, 468), F), yaw, mmpp });
  const n = M.frames.length, need = 45, yaws = M.frames.map(f => f.yaw), spread = Math.max(...yaws) - Math.min(...yaws);
  const pct = Math.min(100, Math.round(n / need * 70 + Math.min(30, spread)));
  $('fmMeter').style.width = pct + '%';
  $('fmMeterT').textContent = pct < 100 ? `Scanning… ${pct}%  ${spread < 20 ? '(turn your head a little more to the ' + (yaw > 0 ? 'right' : 'left') + ')' : ''}` : 'Done.';
  if (pct >= 100) finishScan();
}
function finishScan() {
  M.scanning = false; $('fmScan').disabled = false; $('fmScan').textContent = 'Start scanning';
  // average each point over the frames where it's most reliable (facing the camera most)
  const fr = M.frames, n = fr.length, C = [];
  for (let i = 0; i < 468; i++) { let s = [0, 0, 0], w = 0; fr.forEach(f => { const ww = Math.cos(f.yaw * Math.PI / 180) ** 2; s = add(s, mul(f.C[i], ww)); w += ww; }); C.push(mul(s, 1 / w)); }
  const width = Math.abs(C[454][0] - C[234][0]);
  M.scan = { C, width, measured: width };
  $('fmWidth').value = width.toFixed(0); $('fmRescan').classList.remove('hidden');
  $('fmMeterT').textContent = `Done: 468 points from ${n} pictures. Face width ${width.toFixed(0)} mm (from the size of your irises).`;
  try { X().api().set_ui_pref('faceScan', { C: C.map(p => p.map(v => +v.toFixed(2))), width }); } catch (_) {}
  setStep('fit'); M.maskKey = '';
}
function scanScaled() {      // the scan, resized if you typed your real face width
  if (!M.scan) return null; const w = parseFloat($('fmWidth').value); const k = isFinite(w) && w > 60 && w < 250 ? w / M.scan.width : 1;
  return M.scan.C.map(p => mul(p, k));
}

// ------------------------------------------------------------------ the mask: the face surface cut to a smooth outline, pushed out by the gap, thickness added
let SURF = null, SURFKEY = '';
function faceSurface(C) {     // the face mesh, made finer and smoother (once per scan)
  initTopology();
  const key = C.length + ':' + C[1].join(',') + ':' + C[152].join(',');
  if (SURF && SURFKEY === key) return SURF;
  let V = C.map(p => p.slice()), T = TRIS.map(t => t.slice());
  for (let pass = 0; pass < 2; pass++) {
    const mid = new Map(), NT = [];
    const m = (a, b) => { const k = a < b ? a + ',' + b : b + ',' + a; if (!mid.has(k)) { mid.set(k, V.length); V.push(mul(add(V[a], V[b]), 0.5)); } return mid.get(k); };
    T.forEach(([a, b, c]) => { const ab = m(a, b), bc = m(b, c), ca = m(c, a); NT.push([a, ab, ca], [ab, b, bc], [ca, bc, c], [ab, bc, ca]); });
    T = NT; V = smoothPass(V, T, 0.4);
  }
  SURF = { V, T }; SURFKEY = key; return SURF;
}
function edgeCounts(T) { const cnt = new Map(); T.forEach(([a, b, c]) => [[a, b], [b, c], [c, a]].forEach(([x, y]) => { const k = x < y ? x + ',' + y : y + ',' + x; cnt.set(k, (cnt.get(k) || 0) + 1); })); return cnt; }
function smoothPass(V, T, k) {
  const nb = V.map(() => new Set()); T.forEach(([a, b, c]) => { nb[a].add(b).add(c); nb[b].add(a).add(c); nb[c].add(a).add(b); });
  const bnd = new Map(); edgeCounts(T).forEach((v, key) => { if (v === 1) { const [x, y] = key.split(',').map(Number); (bnd.get(x) || bnd.set(x, []).get(x)).push(y); (bnd.get(y) || bnd.set(y, []).get(y)).push(x); } });
  return V.map((p, i) => {
    if (bnd.has(i)) { const nn = bnd.get(i); if (nn.length !== 2) return p; return add(mul(p, 1 - k), mul(add(V[nn[0]], V[nn[1]]), k / 2)); }
    if (!nb[i].size) return p; let s = [0, 0, 0]; nb[i].forEach(j => s = add(s, V[j])); return add(mul(p, 1 - k), mul(s, k / nb[i].size));
  });
}
// the outline of each kind of mask, as "inside < 0", in the face's own frame (mm)
function outline(C) {
  initTopology();
  const ell = ids => { const c = mean(C, ids); let rx = 0, ry = 0; ids.forEach(i => { rx = Math.max(rx, Math.abs(C[i][0] - c[0])); ry = Math.max(ry, Math.abs(C[i][1] - c[1])); }); return { c, rx, ry }; };
  const eR = ell(EYE_R), eL = ell(EYE_L), lips = ell(LIPS_IN);
  const hole = (p, e, kx, ky, add) => ((p[0] - e.c[0]) / (e.rx * kx + add)) ** 2 + ((p[1] - e.c[1]) / (e.ry * ky + add)) ** 2 - 1;   // < 0 inside the hole
  const sz = M.size / 100, ud = M.ud, hw = Math.abs(C[454][0] - C[234][0]) / 2, chinY = C[152][1], browY = Math.max(C[105][1], C[334][1]);
  const eyes = p => Math.min(hole(p, eR, 1.25, 1.7, 2.5), hole(p, eL, 1.25, 1.7, 2.5));
  if (M.type === 0) return p => {   // eye mask: a band across the eyes with a bridge over the nose
    const cy = 2 + ud, h = 15 * sz, w = hw * 1.02 * sz;
    const band = Math.pow(Math.pow(Math.abs(p[0] / w), 4) + Math.pow(Math.abs((p[1] - cy) / h), 2.2), 0.5) - 1;
    return Math.max(band, -eyes(p)); };
  if (M.type === 1) return p => {   // half mask: from just under the eyes (higher over the nose) down past the chin
    const x = p[0] / (hw * sz), top = -12 + ud + 9 * Math.max(0, 1 - x * x);
    return Math.max(p[1] - top, (chinY - 6) - p[1], Math.abs(p[0]) - hw * 1.04 * sz); };
  return p => {                    // full face, eye holes, a mouth opening if you want one
    let f = Math.max(p[1] - (browY + 22 * sz + ud), Math.abs(p[0]) - hw * 1.04 * sz, (chinY - 6) - p[1]);
    f = Math.max(f, -eyes(p)); if ($('fmMouth').checked) f = Math.max(f, -hole(p, lips, 0.85, 0.9, 1));
    return f; };
}
// cut the surface exactly along the outline (no zig-zags along triangle edges)
function clip(V, T, F) {
  const f = V.map(F), out = V.slice(), mid = new Map(), NT = [];
  const cut = (a, b) => { const k = a < b ? a + ',' + b : b + ',' + a; if (!mid.has(k)) { const t = f[a] / (f[a] - f[b]); mid.set(k, out.length); out.push(add(V[a], mul(sub(V[b], V[a]), t))); } return mid.get(k); };
  T.forEach(tr => {
    const ins = tr.map(i => f[i] < 0), n = ins.filter(Boolean).length;
    if (n === 3) { NT.push(tr); return; } if (n === 0) return;
    const r = ins.indexOf(n === 1); const a = tr[r], b = tr[(r + 1) % 3], c = tr[(r + 2) % 3];
    if (n === 1) NT.push([a, cut(a, b), cut(a, c)]);           // a is the only one inside
    else NT.push([cut(a, b), b, c], [cut(a, b), c, cut(a, c)]); // a is the only one outside
  });
  const used = [...new Set(NT.flat())], re = new Map(used.map((v, i) => [v, i]));
  return { V: used.map(i => out[i]), T: NT.map(t => t.map(i => re.get(i))) };
}
function loops(T) {    // the open edges, chained into loops
  const nxt = new Map(); edgeCounts(T).forEach((v, k) => { if (v === 1) { const [x, y] = k.split(',').map(Number); (nxt.get(x) || nxt.set(x, []).get(x)).push(y); (nxt.get(y) || nxt.set(y, []).get(y)).push(x); } });
  const seen = new Set(), out = [];
  nxt.forEach((_, s) => { if (seen.has(s)) return; const L = [s]; seen.add(s); let prev = -1, cur = s;
    for (let g = 0; g < 100000; g++) { const n = (nxt.get(cur) || []).find(x => x !== prev && !seen.has(x)); if (n === undefined) break; L.push(n); seen.add(n); prev = cur; cur = n; }
    out.push(L); });
  return out;
}
// carry the outer edge a little further, round the side of the face and under the chin (the face scan stops at its edge)
function extendRim(V, T, reach, C) {
  if (reach <= 0.2) return { V, T };
  const L = loops(T).sort((a, b) => b.length - a.length)[0]; if (!L || L.length < 6) return { V, T };
  const ctr = mean(C, [1, 4, 6]); const n0 = V.length, NV = V.slice(), NT = T.slice();
  L.forEach(i => { const p = V[i], d = norm([p[0] - ctr[0], (p[1] - ctr[1]) * 0.8, 0]); const back = -Math.min(1, Math.abs(p[0]) / 70) * 0.55;
    NV.push(add(p, mul(norm([d[0], d[1], back]), reach))); });
  for (let k = 0; k < L.length; k++) { const a = L[k], b = L[(k + 1) % L.length], a2 = n0 + k, b2 = n0 + (k + 1) % L.length; NT.push([a, b, b2], [a, b2, a2]); }
  return { V: NV, T: NT };
}
// the solid: inner skin (gap off the face), outer skin (+ thickness), and walls round every open edge
function shell(P, TT, gap, th) {
  const N = P.map(() => [0, 0, 0]);
  TT.forEach(([a, b, c]) => { const n = cross(sub(P[b], P[a]), sub(P[c], P[a])); [a, b, c].forEach(i => N[i] = add(N[i], n)); });
  for (let i = 0; i < N.length; i++) { N[i] = norm(N[i]); if (N[i][2] < 0) N[i] = mul(N[i], -1); }
  const nP = P.length, out = [], idx = [];
  P.forEach((p, i) => out.push(add(p, mul(N[i], gap))));
  P.forEach((p, i) => out.push(add(p, mul(N[i], gap + th))));
  const oriented = TT.map(([a, b, c]) => cross(sub(P[b], P[a]), sub(P[c], P[a]))[2] >= 0 ? [a, b, c] : [a, c, b]);
  oriented.forEach(([a, b, c]) => idx.push(a + nP, b + nP, c + nP, a, c, b));
  const ec = new Map();
  oriented.forEach(([a, b, c]) => [[a, b], [b, c], [c, a]].forEach(([x, y]) => { const k = x < y ? x + ',' + y : y + ',' + x; const e = ec.get(k); ec.set(k, e ? { n: e.n + 1 } : { n: 1, x, y }); }));
  ec.forEach(e => { if (e.n !== 1) return; const { x, y } = e; idx.push(x, x + nP, y + nP, x, y + nP, y); });
  return { V: out, I: idx, faceP: P };
}
function noPinch(T) {   // two bits touching at one corner can't become a closed solid: trim them
  for (let g = 0; g < 20; g++) {
    const bdeg = new Map(); edgeCounts(T).forEach((v, k) => { if (v === 1) k.split(',').forEach(i => bdeg.set(+i, (bdeg.get(+i) || 0) + 1)); });
    const pinch = new Set([...bdeg].filter(([, d]) => d > 2).map(([i]) => i)); if (!pinch.size) break;
    T = T.filter(t => !t.some(i => pinch.has(i)));
  }
  return T;
}
function buildMask(C) {
  if (M.type === 3) return null;     // your own mask is drawn separately
  const S = faceSurface(C);
  let { V, T } = clip(S.V, S.T, outline(C));
  T = noPinch(T); if (!T.length) return null;
  const used = [...new Set(T.flat())], re = new Map(used.map((v, i) => [v, i])); V = used.map(i => V[i]); T = T.map(t => t.map(i => re.get(i)));
  ({ V, T } = extendRim(V, T, M.reach, C));
  for (let k = 0; k < 2; k++) V = smoothPass(V, T, 0.35);       // a smooth edge, not a jagged one
  return shell(V, T, M.gap, M.th);
}

// ------------------------------------------------------------------ your own mask (a part in Model and plates): put it on your face, check the fit, shape its back
function faceGrid(C, cell = 1.5) {   // the face surface as a height map in the face's own frame (front-most z at each x, y)
  initTopology();
  let x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
  C.forEach(p => { x0 = Math.min(x0, p[0]); x1 = Math.max(x1, p[0]); y0 = Math.min(y0, p[1]); y1 = Math.max(y1, p[1]); });
  const nx = Math.ceil((x1 - x0) / cell) + 2, ny = Math.ceil((y1 - y0) / cell) + 2, Z = new Float32Array(nx * ny).fill(NaN);
  TRIS.forEach(([a, b, c]) => {
    const A = C[a], B = C[b], Cc = C[c];
    const i0 = Math.max(0, Math.floor((Math.min(A[0], B[0], Cc[0]) - x0) / cell)), i1 = Math.min(nx - 1, Math.ceil((Math.max(A[0], B[0], Cc[0]) - x0) / cell));
    const j0 = Math.max(0, Math.floor((Math.min(A[1], B[1], Cc[1]) - y0) / cell)), j1 = Math.min(ny - 1, Math.ceil((Math.max(A[1], B[1], Cc[1]) - y0) / cell));
    const d = (B[1] - Cc[1]) * (A[0] - Cc[0]) + (Cc[0] - B[0]) * (A[1] - Cc[1]); if (Math.abs(d) < 1e-9) return;
    for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) {
      const x = x0 + i * cell, y = y0 + j * cell;
      const l1 = ((B[1] - Cc[1]) * (x - Cc[0]) + (Cc[0] - B[0]) * (y - Cc[1])) / d, l2 = ((Cc[1] - A[1]) * (x - Cc[0]) + (A[0] - Cc[0]) * (y - Cc[1])) / d, l3 = 1 - l1 - l2;
      if (l1 < -1e-6 || l2 < -1e-6 || l3 < -1e-6) continue;
      const z = l1 * A[2] + l2 * B[2] + l3 * Cc[2], k = j * nx + i; if (!(Z[k] >= z)) Z[k] = z;
    }
  });
  return { x0, y0, cell, nx, ny, Z, at(x, y) { const i = Math.round((x - x0) / cell), j = Math.round((y - y0) / cell); if (i < 0 || j < 0 || i >= nx || j >= ny) return NaN; return Z[j * nx + i]; } };
}
const OWN = { part: -1, pos0: null, idx: null, c0: null, R: null, s: 1, t: [0, 0, 0], key: '', shaped: null, colors: null, nrm0: null };
const ROTS = (() => {   // the 24 ways a box can sit
  const out = [], axes = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
  axes.forEach(x => axes.forEach(y => { if (Math.abs(dot(x, y)) > 0.5) return; const z = cross(x, y); out.push([x, y, z]); }));
  return out;
})();
const rot = (R, p) => [R[0][0] * p[0] + R[1][0] * p[1] + R[2][0] * p[2], R[0][1] * p[0] + R[1][1] * p[1] + R[2][1] * p[2], R[0][2] * p[0] + R[1][2] * p[1] + R[2][2] * p[2]];
async function loadOwn(pid) {
  const c = X(); const st = c.state(); if (!st || !st.parts[pid]) return false;
  hint('Loading your mask…');
  const r = await c.api().part_proxy(pid, 120000); if (!r || r.error) { hint((r && r.error) || "Couldn't read that part.", true); return false; }
  const V = r.v; let lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < V.length; i += 3) for (let k = 0; k < 3; k++) { lo[k] = Math.min(lo[k], V[i + k]); hi[k] = Math.max(hi[k], V[i + k]); }
  OWN.c0 = [(lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2, (lo[2] + hi[2]) / 2];
  OWN.pos0 = new Float32Array(V.length); for (let i = 0; i < V.length; i += 3) { OWN.pos0[i] = V[i] - OWN.c0[0]; OWN.pos0[i + 1] = V[i + 1] - OWN.c0[1]; OWN.pos0[i + 2] = V[i + 2] - OWN.c0[2]; }
  OWN.idx = r.f; OWN.part = pid; OWN.name = st.parts[pid].name;
  const T = c.THREE, g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(OWN.pos0, 3)); g.setIndex(OWN.idx); g.computeVertexNormals(); OWN.nrm0 = g.attributes.normal.array;
  autoFit(); return true;
}
// try every way round; keep the one that covers the face best, sized to the face, sitting the gap off it
function autoFit() {
  const C = scanScaled(); if (!C || !OWN.pos0) return;
  const G = faceGrid(C), faceW = Math.abs(C[454][0] - C[234][0]), n = OWN.pos0.length / 3, step = Math.max(1, Math.floor(n / 2500));
  let best = null;
  ROTS.forEach(R => {
    const P = []; for (let i = 0; i < n; i += step) P.push(rot(R, [OWN.pos0[3 * i], OWN.pos0[3 * i + 1], OWN.pos0[3 * i + 2]]));
    let xl = Infinity, xh = -Infinity; P.forEach(p => { xl = Math.min(xl, p[0]); xh = Math.max(xh, p[0]); });
    const s = Math.max(0.3, Math.min(3, faceW * 1.08 / Math.max(1, xh - xl)));
    const H = headModel(C);
    for (const ty of [-50, -35, -20, -5, 10, 25]) {
      const gaps = [], fgaps = [], P2 = P.map(p => [p[0] * s, p[1] * s + ty, p[2] * s]);
      P2.forEach(p => { const z = G.at(p[0], p[1]); if (!isNaN(z)) gaps.push(p[2] - z); });
      if (gaps.length < P2.length * 0.25) continue;
      gaps.sort((a, b) => a - b);
      // sit the front (over the mouth) the gap off the head; the sides get wrapped afterwards
      P2.forEach(p => { const a = Math.atan2(p[0], p[2] - H.zc); if (Math.abs(a) < 35 * Math.PI / 180) fgaps.push(Math.hypot(p[0], p[2] - H.zc) - H.at(a, p[1])); });
      fgaps.sort((a, b) => a - b);
      const tz = fgaps.length > 20 ? M.ogap - fgaps[Math.floor(fgaps.length * 0.02)] : M.ogap - gaps[Math.floor(gaps.length * 0.03)];
      const spread = gaps[Math.floor(gaps.length * 0.5)] - gaps[Math.floor(gaps.length * 0.03)];
      const score = gaps.length / P2.length - spread / 120;
      if (!best || score > best.score) best = { score, R, s, t: [0, ty, tz] };
    }
  });
  if (!best) { hint("Couldn't place it on your face automatically: use the turn buttons and sliders.", true); best = { R: ROTS[0], s: 1, t: [0, -20, 30] }; }
  OWN.R = best.R; OWN.s = best.s; OWN.t = best.t; OWN.user = { s: 100, ud: 0, fb: 0, tilt: 0, lr: 0, yaw: 0 }; syncOwnSliders(); OWN.key = '';
  hint('Your mask is on your face. Fine-tune it with the sliders; red means it would touch.');
}
function ownMatrix() {   // canonical = turn · tilt · (s · R · (p - c0)) + t   (as numbers the back end can use too)
  const u = Object.assign({ s: 100, ud: 0, fb: 0, tilt: 0, lr: 0, yaw: 0 }, OWN.user || {}), s = OWN.s * u.s / 100;
  const a = u.tilt * Math.PI / 180, b = u.yaw * Math.PI / 180;
  const Rx = [[1, 0, 0], [0, Math.cos(a), -Math.sin(a)], [0, Math.sin(a), Math.cos(a)]];       // nod
  const Ry = [[Math.cos(b), 0, Math.sin(b)], [0, 1, 0], [-Math.sin(b), 0, Math.cos(b)]];       // turn
  const mm = (A, B) => A.map((r, i) => [0, 1, 2].map(j => r[0] * B[0][j] + r[1] * B[1][j] + r[2] * B[2][j]));
  const R0 = [0, 1, 2].map(r => [0, 1, 2].map(c2 => OWN.R[c2][r]));                          // the quarter-turn choice, as a matrix
  const m = mm(mm(Ry, Rx), R0).map(r => r.map(v => v * s));
  const t = [OWN.t[0] + u.lr, OWN.t[1] + u.ud, OWN.t[2] - u.fb];      // Closer = towards the face
  return { m, t };   // canon = m · p + t   (p already centred)
}
// the head round the face: the scan, carried on past its edges (the head goes on round the sides; under the chin it
// narrows to the neck), as a radius at each angle round a vertical axis behind the face and each height
let HEAD = null, HEADKEY = '';
function headModel(C) {
  const key = SURFKEY + '|' + C[1].join(',');
  if (HEAD && HEADKEY === key) return HEAD;
  const chinY = C[152][1], browY = Math.max(C[105][1], C[334][1]);
  // the axis: a circle (centred on the midline) fitted to the cheeks, seen from above
  let A11 = 0, A12 = 0, A22 = 0, b1 = 0, b2 = 0;
  C.forEach(p => { if (Math.abs(p[0]) < 15 || p[1] < chinY + 10 || p[1] > browY) return; const z = p[2], rhs = -(p[0] * p[0] + z * z); A11 += z * z; A12 += z; A22 += 1; b1 += z * rhs; b2 += rhs; });
  const det = A11 * A22 - A12 * A12; let zc = NaN, R = NaN;
  if (Math.abs(det) > 1e-6) { const E = (b1 * A22 - b2 * A12) / det, F = (A11 * b2 - A12 * b1) / det; zc = -E / 2; R = Math.sqrt(Math.max(1, zc * zc - F)); }
  if (!(R > 45 && R < 160)) { zc = C[1][2] - 95; R = 85; }
  const S = faceSurface(C), dA = 3 * Math.PI / 180, dy = 3, a0 = -Math.PI, na = Math.round(2 * Math.PI / dA), y0 = chinY - 90, ny = Math.ceil((browY + 70 - y0) / dy) + 1;
  const Rm = new Float32Array(na * ny).fill(NaN);
  S.V.forEach(p => { const a = Math.atan2(p[0], p[2] - zc), r = Math.hypot(p[0], p[2] - zc), i = Math.floor((a - a0) / dA), j = Math.floor((p[1] - y0) / dy);
    if (i < 0 || j < 0 || i >= na || j >= ny) return; const k = j * na + i; if (!(Rm[k] >= r)) Rm[k] = r; });
  const known = Rm.map(v => !isNaN(v)), ext = y => R * (y >= chinY ? 1 : Math.max(0.62, 1 - (chinY - y) / 85));
  let F = Rm.map((v, k) => isNaN(v) ? ext(y0 + (Math.floor(k / na) + 0.5) * dy) : v);
  for (let pass = 0; pass < 6; pass++) {     // blend the carried-on part into the scan
    const G = F.slice();
    for (let j = 0; j < ny; j++) for (let i = 0; i < na; i++) { const k = j * na + i; if (known[k]) continue; let s2 = 0, w = 0;
      for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) { const jj = j + dj, ii = (i + di + na) % na; if (jj < 0 || jj >= ny) continue; s2 += F[jj * na + ii]; w++; }
      G[k] = s2 / w; }
    F = G;
  }
  HEAD = { zc, R, a0, dA, na, y0, dy, ny, Rm: F, at(a, y) { const i = Math.min(na - 1, Math.max(0, Math.floor((a - a0) / dA))), j = Math.min(ny - 1, Math.max(0, Math.floor((y - y0) / dy))); return F[j * na + i]; } };
  HEADKEY = key; return HEAD;
}
const smooth01 = (x, a, b) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
// wrap the sides round the face: move each bit of the mask in or out round the head so its inside sits the gap off the face.
// The front (over the mouth) keeps its shape and only moves out where it would be closer than the gap. The whole thickness
// moves together, so the mask keeps its own thickness
function wrapSides(P, Nx, Nz, H, gap) {
  const n = P.length / 3, A = new Float32Array(n), Rr = new Float32Array(n), inner = new Float32Array(H.na * H.ny).fill(Infinity);
  for (let i = 0; i < n; i++) {
    const x = P[3 * i], z = P[3 * i + 2] - H.zc, a = Math.atan2(x, z), r = Math.hypot(x, z); A[i] = a; Rr[i] = r;
    const radial = Nx[i] * Math.sin(a) + Nz[i] * Math.cos(a);
    if (radial < -0.2) { const ci = Math.floor((a - H.a0) / H.dA), cj = Math.floor((P[3 * i + 1] - H.y0) / H.dy); if (ci >= 0 && cj >= 0 && ci < H.na && cj < H.ny) { const k = cj * H.na + ci; inner[k] = Math.min(inner[k], r); } }
  }
  let D = new Float32Array(H.na * H.ny).fill(NaN);
  for (let j = 0; j < H.ny; j++) for (let i = 0; i < H.na; i++) { const k = j * H.na + i; if (!isFinite(inner[k])) continue;
    const a = H.a0 + (i + 0.5) * H.dA, w = smooth01(Math.abs(a), 25 * Math.PI / 180, 45 * Math.PI / 180);   // 0 over the mouth, 1 at the sides
    const need = H.Rm[k] + gap - inner[k]; D[k] = need * w + Math.max(0, need) * (1 - w); }   // sides follow the face; the front only moves out if it's too close
  for (let pass = 0; pass < 4; pass++) {
    const E = new Float32Array(D.length).fill(NaN);
    for (let j = 0; j < H.ny; j++) for (let i = 0; i < H.na; i++) { let s2 = 0, w = 0;
      for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) { const jj = j + dj, ii = i + di; if (ii < 0 || jj < 0 || ii >= H.na || jj >= H.ny) continue; const v = D[jj * H.na + ii]; if (isNaN(v)) continue; s2 += v; w++; }
      if (w) E[j * H.na + i] = s2 / w * (isNaN(D[j * H.na + i]) ? 0.8 : 1); }
    D = E;
  }
  for (let i = 0; i < n; i++) { const ci = Math.floor((A[i] - H.a0) / H.dA), cj = Math.floor((P[3 * i + 1] - H.y0) / H.dy); if (ci < 0 || cj < 0 || ci >= H.na || cj >= H.ny) continue;
    const d = D[cj * H.na + ci]; if (isNaN(d)) continue; Rr[i] += d; P[3 * i] = Rr[i] * Math.sin(A[i]); P[3 * i + 2] = H.zc + Rr[i] * Math.cos(A[i]); }
  // last check: nothing closer than the gap anywhere (edges and corners included): push those spots out
  const ming = new Float32Array(H.na * H.ny).fill(Infinity), cell = new Int32Array(n).fill(-1);
  for (let i = 0; i < n; i++) { const ci = Math.floor((A[i] - H.a0) / H.dA), cj = Math.floor((P[3 * i + 1] - H.y0) / H.dy); if (ci < 0 || cj < 0 || ci >= H.na || cj >= H.ny) continue;
    const k = cj * H.na + ci; cell[i] = k; ming[k] = Math.min(ming[k], Rr[i] - H.Rm[k]); }
  const X = new Float32Array(H.na * H.ny); for (let k = 0; k < X.length; k++) X[k] = isFinite(ming[k]) ? Math.max(0, gap - ming[k]) : 0;
  const X2 = new Float32Array(X.length);
  for (let j = 0; j < H.ny; j++) for (let i = 0; i < H.na; i++) { let m2 = 0; for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) { const jj = j + dj, ii = i + di; if (ii < 0 || jj < 0 || ii >= H.na || jj >= H.ny) continue; m2 = Math.max(m2, X[jj * H.na + ii]); } X2[j * H.na + i] = m2; }
  for (let i = 0; i < n; i++) { if (cell[i] < 0 || !X2[cell[i]]) continue; Rr[i] += X2[cell[i]]; P[3 * i] = Rr[i] * Math.sin(A[i]); P[3 * i + 2] = H.zc + Rr[i] * Math.cos(A[i]); }
}
function ownGeometry() {   // the mask in the face's frame, shaped if asked, coloured by how close it is to the face
  const C = scanScaled(); if (!C || !OWN.pos0) return null;
  const key = JSON.stringify([OWN.R, OWN.s, OWN.t, OWN.user, M.ogap, $('fmShape').checked, $('fmShapeMode').value, $('fmWidth').value]);
  if (key === OWN.key && OWN.geo) return OWN.geo;
  const { m, t } = ownMatrix(), n = OWN.pos0.length / 3, P = new Float32Array(OWN.pos0.length), Nx = new Float32Array(n), Nz = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const x = OWN.pos0[3 * i], y = OWN.pos0[3 * i + 1], z = OWN.pos0[3 * i + 2];
    P[3 * i] = m[0][0] * x + m[0][1] * y + m[0][2] * z + t[0]; P[3 * i + 1] = m[1][0] * x + m[1][1] * y + m[1][2] * z + t[1]; P[3 * i + 2] = m[2][0] * x + m[2][1] * y + m[2][2] * z + t[2];
    const nx = OWN.nrm0[3 * i], ny = OWN.nrm0[3 * i + 1], nz = OWN.nrm0[3 * i + 2];
    Nx[i] = m[0][0] * nx + m[0][1] * ny + m[0][2] * nz; Nz[i] = m[2][0] * nx + m[2][1] * ny + m[2][2] * nz;
  }
  const H = headModel(C), mode = $('fmShapeMode').value;
  if ($('fmShape').checked) { if (mode === 'sides') wrapSides(P, Nx, Nz, H, M.ogap); else shapeToFace(P, Nz, faceGrid(C), M.ogap, mode); }
  // how close each bit is to the head: red = touching, amber = closer than your gap, green = fine
  const col = new Float32Array(P.length); let minGap = Infinity;
  for (let i = 0; i < n; i++) { const x = P[3 * i], z = P[3 * i + 2] - H.zc, a = Math.atan2(x, z), g = Math.hypot(x, z) - H.at(a, P[3 * i + 1]);
    minGap = Math.min(minGap, g);
    const c = g < 2 ? [0.9, 0.2, 0.2] : g < M.ogap - 0.6 ? [0.95, 0.62, 0.15] : [0.0, 0.68, 0.26]; col[3 * i] = c[0]; col[3 * i + 1] = c[1]; col[3 * i + 2] = c[2]; }
  OWN.key = key; OWN.geo = { P, col, minGap };
  const gt = $('fmGapInfo'); if (gt) gt.textContent = isFinite(minGap) ? `closest point: ${minGap.toFixed(1)} mm (${(minGap / 25.4).toFixed(2)}")` : '';
  gapWarn();
  return OWN.geo;
}
function headMeshFor3d(T) {   // the carried-on head, for the 3D view (so you can see what the sides wrap round)
  const C = scanScaled(); if (!C) return null; const H = headModel(C), pos = [], idx = [], aMax = 120 * Math.PI / 180;
  const ia0 = Math.floor((-aMax - H.a0) / H.dA), ia1 = Math.ceil((aMax - H.a0) / H.dA), w = ia1 - ia0 + 1;
  for (let j = 0; j < H.ny; j++) for (let i = ia0; i <= ia1; i++) { const a = H.a0 + (i + 0.5) * H.dA, r = H.Rm[j * H.na + i], y = H.y0 + (j + 0.5) * H.dy; pos.push(r * Math.sin(a), y, H.zc + r * Math.cos(a)); }
  for (let j = 0; j < H.ny - 1; j++) for (let i = 0; i < w - 1; i++) { const k = j * w + i; idx.push(k, k + 1, k + w, k + 1, k + w + 1, k + w); }
  const g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals(); return g;
}
// move the mask's back onto the face (keeping its thickness): a smooth field of z shifts over x, y
function shapeToFace(P, Nz, G, gap, mode) {
  const cell = 2.5, n = P.length / 3; let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (let i = 0; i < n; i++) { x0 = Math.min(x0, P[3 * i]); x1 = Math.max(x1, P[3 * i]); y0 = Math.min(y0, P[3 * i + 1]); y1 = Math.max(y1, P[3 * i + 1]); }
  const nx = Math.ceil((x1 - x0) / cell) + 1, ny = Math.ceil((y1 - y0) / cell) + 1, inner = new Float32Array(nx * ny).fill(Infinity);
  for (let i = 0; i < n; i++) { if (Nz[i] > -0.2) continue; const ci = Math.floor((P[3 * i] - x0) / cell), cj = Math.floor((P[3 * i + 1] - y0) / cell), k = cj * nx + ci; inner[k] = Math.min(inner[k], P[3 * i + 2]); }
  let D = new Float32Array(nx * ny).fill(NaN);
  for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) { const k = j * nx + i; if (!isFinite(inner[k])) continue; const z = G.at(x0 + (i + 0.5) * cell, y0 + (j + 0.5) * cell); if (isNaN(z)) continue;
    let d = z + gap - inner[k]; if (mode === 'push') d = Math.max(0, d); D[k] = d; }
  for (let pass = 0; pass < 4; pass++) {   // smooth it, and let it fade out past the face
    const E = new Float32Array(nx * ny).fill(NaN);
    for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) { let s = 0, w = 0;
      for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) { const ii = i + di, jj = j + dj; if (ii < 0 || jj < 0 || ii >= nx || jj >= ny) continue; const v = D[jj * nx + ii]; if (isNaN(v)) continue; s += v; w++; }
      if (w) E[j * nx + i] = s / w * (isNaN(D[j * nx + i]) ? 0.8 : 1); }
    D = E;
  }
  for (let i = 0; i < n; i++) { const ci = Math.floor((P[3 * i] - x0) / cell), cj = Math.floor((P[3 * i + 1] - y0) / cell); const v = D[cj * nx + ci]; if (!isNaN(v)) P[3 * i + 2] += v; }
}
function ownToMesh(mesh) {   // keep a three.js mesh in step with your own mask (positions + red/green), only when something changed
  const g = ownGeometry(); if (!g) return false; const T = X().THREE;
  if (mesh.userData.key !== OWN.key || mesh.geometry.index === null) {
    let geo = mesh.geometry;
    if (!geo.attributes.position || geo.attributes.position.count * 3 !== g.P.length) { geo.dispose(); geo = new T.BufferGeometry(); geo.setIndex(OWN.idx); mesh.geometry = geo;
      geo.setAttribute('position', new T.BufferAttribute(new Float32Array(g.P.length), 3)); geo.setAttribute('color', new T.BufferAttribute(new Float32Array(g.P.length), 3)); }
    geo.attributes.position.array.set(g.P); geo.attributes.position.needsUpdate = true; geo.attributes.color.array.set(g.col); geo.attributes.color.needsUpdate = true;
    geo.computeVertexNormals(); geo.computeBoundingSphere(); mesh.userData.key = OWN.key;
  }
  return true;
}
function syncOwnSliders() { const u = Object.assign({ s: 100, ud: 0, fb: 0, tilt: 0, lr: 0, yaw: 0 }, OWN.user || {}); [['fmOs', 's'], ['fmOud', 'ud'], ['fmOfb', 'fb'], ['fmOtilt', 'tilt'], ['fmOlr', 'lr'], ['fmOyaw', 'yaw']].forEach(([id, k]) => { $(id).value = u[k]; $(id + 'N').value = u[k]; }); }
function turnOwn(axis) {   // a quarter turn about the face's x, y or z axis
  if (!OWN.R) return; const q = { x: [[1, 0, 0], [0, 0, 1], [0, -1, 0]], y: [[0, 0, -1], [0, 1, 0], [1, 0, 0]], z: [[0, 1, 0], [-1, 0, 0], [0, 0, 1]] }[axis];
  OWN.R = OWN.R.map(row => [0, 1, 2].map(c2 => row[0] * q[0][c2] + row[1] * q[1][c2] + row[2] * q[2][c2])); OWN.key = '';
}

// ------------------------------------------------------------------ drawing: the live overlay (on the camera picture) and the 3D view
function ensureThree() {
  const c = X(); if (!c || three) return; const T = c.THREE;
  const r = new T.WebGLRenderer({ canvas: $('fmCanvas'), alpha: true, antialias: true });
  const sc = new T.Scene(); sc.add(new T.HemisphereLight(0xffffff, 0x445544, 1.0)); const dl = new T.DirectionalLight(0xffffff, 0.7); dl.position.set(0.3, 0.5, 1); sc.add(dl);
  const cam = new T.OrthographicCamera(0, 1, 0, -1, -5000, 5000);
  const mat = new T.MeshStandardMaterial({ color: 0x00AE42, roughness: 0.45, metalness: 0.05, transparent: true, opacity: 0.78, side: T.DoubleSide });
  const mesh = new T.Mesh(new T.BufferGeometry(), mat); mesh.matrixAutoUpdate = false; sc.add(mesh);
  const own = new T.Mesh(new T.BufferGeometry(), new T.MeshStandardMaterial({ vertexColors: true, roughness: 0.45, transparent: true, opacity: 0.85, side: T.DoubleSide })); own.matrixAutoUpdate = false; sc.add(own);
  const pts = new T.Points(new T.BufferGeometry(), new T.PointsMaterial({ color: 0x1CC25A, size: 2.5, sizeAttenuation: false })); pts.frustumCulled = false; sc.add(pts);
  three = { T, r, sc, cam, mesh, pts, own };
}
function layout() {
  const st = $('fmStage'), sw = st.clientWidth, sh = st.clientHeight; if (!sw) return;
  const k = Math.min(sw / M.W, sh / M.H), w = Math.round(M.W * k), h = Math.round(M.H * k);
  [$('fmVideo'), $('fmImg'), $('fmCanvas')].forEach(el => { el.style.width = w + 'px'; el.style.height = h + 'px'; el.style.left = Math.round((sw - w) / 2) + 'px'; el.style.top = Math.round((sh - h) / 2) + 'px'; });
  if (three) { three.r.setPixelRatio(devicePixelRatio); three.r.setSize(w, h, false); three.cam.left = 0; three.cam.right = M.W; three.cam.top = 0; three.cam.bottom = -M.H; three.cam.updateProjectionMatrix(); }
}
function maskGeometry(T, mk) {
  const g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(mk.V.flat(), 3)); g.setIndex(mk.I); g.computeVertexNormals(); return g;
}
function currentMask() {
  const C = scanScaled(); if (!C) return null;
  const key = JSON.stringify([M.type, M.size, M.gap, M.th, M.ud, M.reach, $('fmMouth').checked, $('fmWidth').value]);
  if (key !== M.maskKey) { M.mask = buildMask(C); M.maskKey = key; if (three && M.mask) { three.mesh.geometry.dispose(); three.mesh.geometry = maskGeometry(three.T, M.mask); }
    if (three3 && M.mask) { three3.mask.geometry.dispose(); three3.mask.geometry = maskGeometry(three3.T, M.mask); } }
  return M.mask;
}
function renderOverlay() {
  ensureThree(); if (!three) return; const T = three.T;
  if (M.W !== three._w || M.H !== three._h) { three._w = M.W; three._h = M.H; layout(); }
  const live = M.view === 'live';
  $('fmCanvas').classList.toggle('hidden', !live);
  if (!live) return;
  three.mesh.visible = false; three.pts.visible = false; three.own.visible = false;
  if (M.lm && M.lm.length >= 468) {
    const { P, mmpp } = toFace(M.lm, M.W, M.H);
    if (M.step === 'scan' || !M.scan) {   // show the measured points while scanning
      const arr = []; P.forEach(p => arr.push(p[0] / mmpp, p[1] / mmpp, p[2] / mmpp));
      three.pts.geometry.setAttribute('position', new T.Float32BufferAttribute(arr, 3)); three.pts.visible = true;
    } else {
      // put the mask (made in the face's own frame, mm) onto the face as it is right now (camera pixels)
      const F = frameOf(P), s = 1 / mmpp;
      const m4 = new T.Matrix4().set(F.ex[0] * s, F.ey[0] * s, F.ez[0] * s, F.o[0] * s, F.ex[1] * s, F.ey[1] * s, F.ez[1] * s, F.o[1] * s, F.ex[2] * s, F.ey[2] * s, F.ez[2] * s, F.o[2] * s, 0, 0, 0, 1);
      if (M.type === 3) { if (ownToMesh(three.own)) { three.own.matrix.copy(m4); three.own.matrixWorldNeedsUpdate = true; three.own.visible = true; } }
      else if (currentMask()) { three.mesh.matrix.copy(m4); three.mesh.matrixWorldNeedsUpdate = true; three.mesh.visible = true; }
    }
  }
  three.r.render(three.sc, three.cam);
}
function ensure3d() {
  const c = X(); if (!c || three3) return; const T = c.THREE;
  const r = new T.WebGLRenderer({ canvas: $('fm3d'), antialias: true }); r.setClearColor(0x1e1e22, 1);
  const sc = new T.Scene(); sc.add(new T.HemisphereLight(0xffffff, 0x554433, 1.1)); const dl = new T.DirectionalLight(0xffffff, 0.6); dl.position.set(80, 120, 300); sc.add(dl);
  const cam = new T.PerspectiveCamera(30, 1, 1, 5000); cam.position.set(0, 0, 520);
  const grp = new T.Group(); sc.add(grp);
  const face = new T.Mesh(new T.BufferGeometry(), new T.MeshStandardMaterial({ color: 0xd9a787, roughness: 0.75, side: T.DoubleSide })); grp.add(face);
  const mask = new T.Mesh(new T.BufferGeometry(), new T.MeshStandardMaterial({ color: 0x00AE42, roughness: 0.4, side: T.DoubleSide })); grp.add(mask);
  const own = new T.Mesh(new T.BufferGeometry(), new T.MeshStandardMaterial({ vertexColors: true, roughness: 0.4, side: T.DoubleSide })); grp.add(own);
  const head = new T.Mesh(new T.BufferGeometry(), new T.MeshStandardMaterial({ color: 0xc9967a, roughness: 0.85, transparent: true, opacity: 0.35, side: T.DoubleSide, depthWrite: false })); grp.add(head);
  three3 = { T, r, sc, cam, grp, face, mask, own, head, dirty: true, rot: { x: 0, y: 0.5 } };
  const cv = $('fm3d'); let d = null;
  cv.onpointerdown = e => { d = { x: e.clientX, y: e.clientY, r: { ...three3.rot } }; cv.setPointerCapture(e.pointerId); };
  cv.onpointermove = e => { if (!d) return; three3.rot.y = d.r.y + (e.clientX - d.x) * 0.01; three3.rot.x = Math.max(-1.2, Math.min(1.2, d.r.x + (e.clientY - d.y) * 0.01)); };
  cv.onpointerup = () => d = null;
  cv.onwheel = e => { e.preventDefault(); cam.position.z = Math.max(180, Math.min(1200, cam.position.z * (e.deltaY > 0 ? 1.1 : 0.9))); };
}
function render3d() {
  ensure3d(); const t = three3; if (!t) return; const T = t.T;
  const st = $('fmStage'), w = st.clientWidth, h = st.clientHeight; const cv = $('fm3d');
  cv.style.width = w + 'px'; cv.style.height = h + 'px'; cv.style.left = '0px'; cv.style.top = '0px';
  if (t._w !== w || t._h !== h) { t._w = w; t._h = h; t.r.setPixelRatio(devicePixelRatio); t.r.setSize(w, h, false); t.cam.aspect = w / h; t.cam.updateProjectionMatrix(); }
  if (t.dirty) {
    t.dirty = false; const C = scanScaled(); initTopology();
    if (C) { const g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(C.flat(), 3)); g.setIndex(TRIS.flat()); g.computeVertexNormals(); t.face.geometry.dispose(); t.face.geometry = g;
      const hg = headMeshFor3d(T); if (hg) { t.head.geometry.dispose(); t.head.geometry = hg; } }
    const mk = M.type === 3 ? null : currentMask(); if (mk) { t.mask.geometry.dispose(); t.mask.geometry = maskGeometry(T, mk); }
  }
  if (M.type !== 3) currentMask();
  const ownOn = M.type === 3 && ownToMesh(t.own);
  t.face.visible = M.view === 'face'; t.head.visible = M.view === 'face' && M.type === 3; t.mask.visible = M.type !== 3 && !!M.mask; t.own.visible = !!ownOn;
  if (!d3moving()) t.rot.y += 0.0;   // still unless you drag
  t.grp.rotation.set(t.rot.x, t.rot.y, 0);
  t.r.render(t.sc, t.cam);
}
const d3moving = () => false;

// ------------------------------------------------------------------ the panel
function setStep(s) {
  if (s !== 'scan' && !M.scan) { hint('Scan your face first (step 1).', true); s = 'scan'; }
  M.step = s; document.querySelectorAll('#fmSteps span').forEach(x => x.classList.toggle('on', x.dataset.s === s));
  $('fmPScan').classList.toggle('hidden', s !== 'scan'); $('fmPFit').classList.toggle('hidden', s !== 'fit'); $('fmPPrint').classList.toggle('hidden', s !== 'print');
  hint({ scan: M.scan ? 'Your face is scanned. Scan again, or go to 2 Fit.' : 'Look at the camera, then press Start scanning.', fit: 'The mask sits on your face live. Adjust it until it fits.', print: 'Ready: send it to Model and plates.' }[s]);
}
function setView(v) {
  M.view = v; document.querySelectorAll('#fmView span').forEach(x => x.classList.toggle('on', x.dataset.v === v));
  $('fm3d').classList.toggle('hidden', v === 'live'); $('fmCanvas').classList.toggle('hidden', v !== 'live');
  if (M.imgSrc) $('fmImg').classList.toggle('hidden', v !== 'live'); else $('fmVideo').classList.toggle('hidden', v !== 'live');
  if (three3) three3.dirty = true;
}
function hint(t, bad) { $('fmHint').textContent = t; $('fmHint').style.color = bad ? '#FAC775' : ''; }
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
function bindSlider(id, key) {
  const r = $(id), n = $(id + 'N'); const show = () => { r.value = M[key]; if (document.activeElement !== n) n.value = M[key]; };
  r.oninput = () => { M[key] = +r.value; n.value = r.value; };
  n.onchange = () => { const v = parseFloat(n.value); if (isFinite(v)) M[key] = Math.min(+r.max, Math.max(+r.min, v)); show(); };
  n.onkeydown = e => { if (e.key === 'Enter') n.blur(); }; show();
}
function gapWarn() {   // closer than ½ inch, by the setting or by where you moved it: say so (and ask again before printing)
  const w = $('fmGapWarn'); if (!w) return; const g = OWN.geo && OWN.geo.minGap;
  const bySetting = M.ogap < HALF_INCH - 0.05, byPlace = M.type === 3 && isFinite(g) && g < HALF_INCH - 1.0;
  w.classList.toggle('hidden', !(bySetting || byPlace));
  if (bySetting) w.textContent = `⚠ The gap is ${M.ogap} mm (${(M.ogap / 25.4).toFixed(2)}"), closer than ½ inch (12.7 mm): it may rub your skin or fog up.`;
  else if (byPlace) w.textContent = `⚠ Part of the mask is ${g.toFixed(1)} mm (${(g / 25.4).toFixed(2)}") from your face, closer than ½ inch. Move it back a little (Closer), or carry on if that's what you want.`;
  $('fmGap2N').title = `${M.ogap} mm = ${(M.ogap / 25.4).toFixed(2)} inch`;
}
function fillOwnParts() {
  const st = X().state(); const ps = st ? st.parts : [];
  $('fmOwnPart').innerHTML = ps.length ? ps.map((p, i) => `<option value="${i}">${esc(p.name)} · ${p.size.map(v => v.toFixed(0)).join(' × ')} mm</option>`).join('') : '<option value="-1">Nothing open yet: use Open a mask file…</option>';
  if (OWN.part >= 0 && ps[OWN.part]) $('fmOwnPart').value = OWN.part;
}
async function chooseType(i, auto) {
  M.type = i; if (!auto) M.typeChosen = true; $('fmTiles').querySelectorAll('.fmtile').forEach(x => x.classList.toggle('on', +x.dataset.i === i));
  const own = i === 3; $('fmOwn').classList.toggle('hidden', !own); $('fmGen').classList.toggle('hidden', own); $('fmOwnGapRow').classList.toggle('hidden', !own);
  $('fmMouth').closest('label').classList.toggle('hidden', own);
  if (own) { fillOwnParts(); const st = X().state(); if (OWN.part < 0 && st && st.parts.length) { const pick = st.parts.length - 1; $('fmOwnPart').value = pick; await loadOwn(pick); } else if (!st || !st.parts.length) hint('Open your mask file with "Open a mask file…".'); }
  if (three3) three3.dirty = true;
}
function openAdd() { $('fmAdd').classList.remove('hidden'); tab('phone'); }
function tab(k) { document.querySelectorAll('#fmAddTabs span').forEach(s => s.classList.toggle('on', s.dataset.t === k)); $('fmAddPhone').classList.toggle('hidden', k !== 'phone'); $('fmAddNet').classList.toggle('hidden', k !== 'net'); }
function wire() {
  $('fmDDB').onclick = async e => { e.stopPropagation(); const m = $('fmMenu'), show = m.classList.contains('hidden'); if (show) { await listCams(); renderMenu(); } m.classList.toggle('hidden', !show); $('fmDDB').classList.toggle('open', show); };
  document.addEventListener('click', e => { if (!e.target.closest('#fmDD')) hideMenu(); });
  $('fmRes').onchange = () => { if (M.cam) useCam(M.cam); };
  $('fmMirror').onchange = () => $('fmStage').classList.toggle('mirror', $('fmMirror').checked);
  $('fmBright').onchange = () => $('fmStage').classList.toggle('bright', $('fmBright').checked);
  document.querySelectorAll('#fmSteps span').forEach(s => s.onclick = () => setStep(s.dataset.s));
  $('fmScan').onclick = startScan; $('fmRescan').onclick = () => { M.scan = null; setStep('scan'); startScan(); };
  $('fmWidth').onchange = () => { M.maskKey = ''; if (three3) three3.dirty = true; };
  $('fmTiles').innerHTML = TYPES.map(([n, d], i) => `<div class="fmtile ${i === M.type ? 'on' : ''}" data-i="${i}"><svg viewBox="0 0 46 30"><path d="${d}" fill="#00AE42"/>${i === 0 || i === 2 ? '<ellipse cx="15" cy="12" rx="4" ry="2.5" fill="#35353A"/><ellipse cx="31" cy="12" rx="4" ry="2.5" fill="#35353A"/>' : (i === 3 ? '<path d="M14 15 h18 M23 9 v12" stroke="#35353A" stroke-width="3"/>' : '')}</svg>${n}</div>`).join('');
  $('fmTiles').querySelectorAll('.fmtile').forEach(t => t.onclick = () => chooseType(+t.dataset.i));
  [['fmSize', 'size'], ['fmGap', 'gap'], ['fmTh', 'th'], ['fmUd', 'ud'], ['fmReach', 'reach'], ['fmGap2', 'ogap']].forEach(([id, k]) => bindSlider(id, k));
  const syncAll = () => { [['fmSize', 'size'], ['fmGap', 'gap'], ['fmTh', 'th'], ['fmUd', 'ud'], ['fmReach', 'reach'], ['fmGap2', 'ogap']].forEach(([id, k]) => { $(id).value = M[k]; $(id + 'N').value = M[k]; }); gapWarn(); };
  ['fmGap2'].forEach(id => { const r = $(id), n = $(id + 'N'); const o = r.oninput, on = n.onchange; r.oninput = () => { o(); gapWarn(); }; n.onchange = () => { on(); gapWarn(); }; });
  document.querySelectorAll('#fmPFit .trs[data-r]').forEach(b => b.onclick = () => { M[b.dataset.r] = DEF[b.dataset.r]; syncAll(); });
  gapWarn();
  // your own mask
  [['fmOs', 's'], ['fmOud', 'ud'], ['fmOfb', 'fb'], ['fmOtilt', 'tilt'], ['fmOlr', 'lr'], ['fmOyaw', 'yaw']].forEach(([id, k]) => { const r = $(id), n = $(id + 'N');
    r.oninput = () => { OWN.user = Object.assign({ s: 100, ud: 0, fb: 0, tilt: 0, lr: 0, yaw: 0 }, OWN.user || {}); OWN.user[k] = +r.value; n.value = r.value; };
    n.onchange = () => { const v = parseFloat(n.value); if (isFinite(v)) { OWN.user[k] = Math.min(+r.max, Math.max(+r.min, v)); } syncOwnSliders(); }; n.onkeydown = e => { if (e.key === 'Enter') n.blur(); }; });
  document.querySelectorAll('#fmOwn .trs[data-o]').forEach(b => b.onclick = () => { OWN.user[b.dataset.o] = b.dataset.o === 's' ? 100 : 0; syncOwnSliders(); });
  document.querySelectorAll('#fmOwn [data-turn]').forEach(b => b.onclick = () => turnOwn(b.dataset.turn));
  $('fmOwnFit').onclick = () => autoFit();
  $('fmOwnPart').onchange = () => loadOwn(+$('fmOwnPart').value);
  $('fmOwnOpen').onclick = async () => { const c = X(); const d = await c.longJob('Adding the mask…', () => c.api().add_model_dialog()); if (!d) return; if (d.error) { hint(d.error, true); return; }
    await c.show(d, { keep: true, quiet: true }); fillOwnParts(); const last = c.state().parts.length - 1; $('fmOwnPart').value = last; loadOwn(last); };
  document.querySelectorAll('#fmView span').forEach(s => s.onclick = () => setView(s.dataset.v));
  $('fmSend').onclick = sendMask;
  // add a camera
  $('fmAddX').onclick = () => $('fmAdd').classList.add('hidden');
  document.querySelectorAll('#fmAddTabs span').forEach(s => s.onclick = () => tab(s.dataset.t));
  $('fmLook').onclick = async () => { const before = M.cams.length; $('fmLookT').textContent = 'Looking…'; await listCams(); $('fmLookT').textContent = M.cams.length > before ? `Found ${M.cams.length - before} new camera${M.cams.length - before > 1 ? 's' : ''}: pick it in the list.` : `${M.cams.length} camera${M.cams.length === 1 ? '' : 's'} found. If your phone isn't there yet, check its app is running.`; };
  $('fmUrl').oninput = () => { if (!$('fmUName').dataset.typed) { const m = $('fmUrl').value.match(/\/\/([^/:]+)/); $('fmUName').value = m ? 'Camera at ' + m[1] : ''; } };
  $('fmUName').oninput = () => $('fmUName').dataset.typed = 1;
  const netOk = u => /^(https?):\/\//i.test(u);
  $('fmTest').onclick = () => { const u = $('fmUrl').value.trim(); if (!netOk(u)) { $('fmTestT').innerHTML = '<span style="color:#FAC775">Paste an http:// camera address.</span>'; return; }
    const img = new Image(); img.crossOrigin = 'anonymous'; $('fmTestT').textContent = 'Testing…';
    img.onload = () => $('fmTestT').innerHTML = `<span style="color:#5DCAA5">✓ Picture received (${img.naturalWidth} × ${img.naturalHeight})</span>`;
    img.onerror = () => $('fmTestT').innerHTML = '<span style="color:#FAC775">No picture from that address. Check it in a web browser first.</span>'; img.src = u; };
  $('fmAddNetB').onclick = () => { const u = $('fmUrl').value.trim(); if (!netOk(u)) { $('fmTestT').innerHTML = '<span style="color:#FAC775">Paste an http:// camera address.</span>'; return; }
    const c = { id: 'net:' + u, name: $('fmUName').value || 'Network camera', kind: 'Network', url: u }; M.cams.push(c); $('fmAdd').classList.add('hidden'); useNet(c); };
  new ResizeObserver(layout).observe($('fmStage'));
  try { navigator.mediaDevices.addEventListener('devicechange', () => listCams()); } catch (_) {}
}
function showImg(img) {   // a picture source (network camera): show it where the video would be
  const el = $('fmImg'); el.src = img.src; el.classList.remove('hidden'); $('fmVideo').classList.add('hidden'); M.imgSrc = img;
}
function useNet(c) {   // a network camera that gives pictures at a web address (MJPEG or a still picture)
  stopCam(); M.cam = c; renderDD();
  const img = $('fmImg'); img.crossOrigin = 'anonymous';
  img.onload = () => { M.W = img.naturalWidth; M.H = img.naturalHeight; layout(); };
  img.src = c.url; img.classList.remove('hidden'); $('fmVideo').classList.add('hidden'); M.imgSrc = img;
  $('fmBadge').textContent = c.name; $('fmDot').classList.add('on');
}
async function sendMask() {
  if (M.type === 3) {
    if (!OWN.pos0) { hint('Pick or open your mask first.', true); return; }
    const close = Math.min(M.ogap, (OWN.geo && OWN.geo.minGap) || Infinity);
    if (close < HALF_INCH - 1.0 && !confirm(`Part of the mask would be ${close.toFixed(1)} mm (${(close / 25.4).toFixed(2)}") from your face, closer than ½ inch (12.7 mm).\n\nIt may rub your skin or fog up. Make it anyway?`)) return;
    const c = X(), { m, t } = ownMatrix(); initTopology();
    const H = headModel(scanScaled()), head = { zc: H.zc, a0: H.a0, dA: H.dA, na: H.na, y0: H.y0, dy: H.dy, ny: H.ny, Rm: Array.from(H.Rm, v => +v.toFixed(2)) };
    const d = await c.longJob('Shaping your mask…', () => c.api().mask_shape(OWN.part, OWN.c0, m, t, scanScaled(), TRIS, M.ogap, $('fmShape').checked ? $('fmShapeMode').value : 'none', $('fmName').value.trim() || OWN.name, head));
    if (!d || d.error) { hint((d && d.error) || "Couldn't shape the mask.", true); return; }
    await c.show(d); c.pushUndo('Shape a mask to my face'); window.studio.goStep(1); c.status('Your mask is shaped to your face (Ctrl+Z undoes it). A copy is saved in Documents\\BambuForge\\Masks.'); OWN.part = -1; OWN.pos0 = null; return;
  }
  const mk = currentMask(); if (!mk) { hint('Scan your face and pick a mask first.', true); return; }
  // printing position: the inside facing the plate, sitting on it (Model and plates can turn it to the best way up)
  const lo = Math.min(...mk.V.map(p => p[2]));
  const verts = []; mk.V.forEach(p => verts.push(+p[0].toFixed(3), +p[1].toFixed(3), +(p[2] - lo).toFixed(3)));
  const c = X(); const d = await c.longJob('Making the mask…', () => c.api().mask_to_project($('fmName').value.trim() || 'My mask', verts, mk.I));
  if (!d || d.error) { hint((d && d.error) || "Couldn't make the mask.", true); return; }
  await c.show(d); c.pushUndo('Add a mask'); window.studio.goStep(1); c.status('The mask is on the plate. A copy is saved in Documents\\BambuForge\\Masks.');
}

// ------------------------------------------------------------------ open / close the step
async function enter() {
  if (M.on) return; M.on = true;
  $('fmStage').classList.toggle('mirror', $('fmMirror').checked);
  initTopology(); ensureThree();
  // a scan you made before
  try { const ui = await X().api().ui_prefs(); if (!M.scan && ui.faceScan && ui.faceScan.C) { M.scan = { C: ui.faceScan.C, width: ui.faceScan.width, measured: ui.faceScan.width }; $('fmWidth').value = (+ui.faceScan.width).toFixed(0); $('fmRescan').classList.remove('hidden'); $('fmMeterT').textContent = 'Using your last scan. Scan again any time.'; }
    if (!M.cam) { await listCams(); const want = ui.fmCam && M.cams.find(c => c.name === ui.fmCam); const first = want || M.cams.find(c => !c.virtual) || M.cams[0]; if (first) useCam(first); else hint('No camera found. Plug one in, or use Add a camera in the list on the right.', true); }
    else useCam(M.cam);
  } catch (_) {}
  startTracking(); requestAnimationFrame(tick); setStep(M.scan ? 'fit' : 'scan'); layout();
  const st = X().state(); if (!M.typeChosen && st && st.parts.length) chooseType(3, true);
}
function leave() { if (!M.on) return; M.on = false; stopCam(); M.scanning = false; }
(function boot() {
  if (!X() || !$('fmStage')) { setTimeout(boot, 200); return; }
  wire();
  window.masks = { enter, leave, _state: () => M, _feedImage: url => { const img = $('fmImg'); img.onload = () => { M.W = img.naturalWidth; M.H = img.naturalHeight; layout(); }; img.src = url; img.classList.remove('hidden'); $('fmVideo').classList.add('hidden'); M.imgSrc = img; } };
})();
