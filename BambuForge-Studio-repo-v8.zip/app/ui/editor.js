// Joint editor: place pegs, dowels, magnets, twist-locks and threads by hand on a real cut.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/OrbitControls.js';

const $ = id => document.getElementById(id);
const CLR = 0.2;
const COMMON = [[2,1],[3,1],[3,2],[4,2],[5,1],[5,2],[6,1],[6,2],[6,3],[8,1],[8,2],[8,3],[10,1],[10,2],[10,3],[12,2],[12,3],[15,3]];
const OTHER = [[1,1],[2,2],[3,3],[4,1],[4,3],[4,4],[5,3],[5,5],[6,4],[6,5],[6,6],[8,4],[8,5],[10,4],[10,5],[12,1],[12,4],[12,5],[15,2],[15,4],[15,5],[18,3],[20,2],[20,3],[20,5],[25,3],[25,5],[30,3],[30,5]];
const LOOSE = { dpeg: true, dowel: true, magnet: true, twist: false, thread: false };
const NAMES = { dpeg: 'Keyed D-peg', dowel: 'Dowel', magnet: 'Magnet pair', twist: 'Twist-lock spigot', thread: 'Screw thread' };
const DEF = { dowel: { d: 6, dep: 16 }, dpeg: { d: 20, dep: 26 }, twist: { d: 26, dep: 10 }, thread: { d: 26, dep: 12 } };
const CUT_TYPES = { dpeg: 'Keyed D-peg + glue', dowel: 'Twin dowels + glue', magnet: 'Magnets (removable)', twist: 'Twist-lock (removable)', thread: 'Screw thread (removable)',
                    dovetail: 'Dovetail slide lock (automatic)', sleeve: 'Hollow-core sleeve (automatic)', none: 'Flat glue face only' };
const COL = { ok: [0, 174, 66], amber: [240, 160, 48], red: [232, 90, 90] };

let ed = null;            // { api, idx, cutIndex, data, joints, sel, onDone }
let renderer, scene, camera, controls, lower, upper, jointGroup, spinning = false, magMat;

$('jMag').innerHTML = `<optgroup label="Common for 3D printing">${COMMON.map(o).join('')}</optgroup><optgroup label="Other sizes">${OTHER.map(o).join('')}</optgroup><optgroup label="Your own"><option value="custom">Custom size…</option></optgroup>`;
function o([d, t]) { return `<option value="${d}x${t}">${d} mm × ${t} mm</option>`; }
$('jCutType').innerHTML = Object.entries(CUT_TYPES).map(([k, v]) => `<option value="${k}">${v}</option>`).join('');

// ---------------------------------------------------------------- open / close
export async function openEditor(opts) {
  ed = { ...opts, joints: [], sel: 0, problems: [], exact: false, seq: 0 };
  const norm = k => ({ dowels: 'dowel', magnets: 'magnet' }[k] || k);
  const kind = opts.cut.specs ? null : (CUT_TYPES[norm(opts.cut.kind)] ? norm(opts.cut.kind) : 'dpeg');
  const data = await opts.busyJob('Opening the joint editor…', () => opts.api.cut_editor(opts.idx, opts.cuts, opts.cutIndex, kind, [8, 3]));
  if (data.error) { opts.status(data.error, true); ed = null; return; }
  ed.data = data;
  ed.cutType = opts.cut.specs ? (opts.cut.specs[0] ? opts.cut.specs[0].kind : 'none') : kind;
  ed.joints = opts.cut.specs ? JSON.parse(JSON.stringify(opts.cut.specs)) : (data.specs || []);
  $('jCutType').value = ed.cutType;
  $('jed').classList.remove('hidden');
  if (!renderer) init3d();
  await loadPieces();
  resize3d(); frame();
  draw(); scheduleCheck();
}
function close(save) {
  if (!ed) return;
  const red = ed.joints.some((j, i) => status(i) === 'red');
  if (save) ed.onDone(editable(ed.cutType) ? JSON.parse(JSON.stringify(ed.joints)) : null, ed.cutType, red);
  $('jed').classList.add('hidden'); ed = null;
}
$('jDone').onclick = () => close(true);
$('jCancel').onclick = () => close(false);
const editable = k => ['dpeg', 'dowel', 'magnet', 'twist', 'thread'].includes(k);

// ---------------------------------------------------------------- 3D scene (Z up, the cut at z = 0)
function init3d() {
  renderer = new THREE.WebGLRenderer({ antialias: true }); renderer.setPixelRatio(window.devicePixelRatio);
  $('jv3').appendChild(renderer.domElement);
  scene = new THREE.Scene(); scene.background = new THREE.Color(0x1e1e22);
  camera = new THREE.PerspectiveCamera(40, 1, 0.5, 20000); camera.up.set(0, 0, 1);
  controls = new OrbitControls(camera, renderer.domElement); controls.enableDamping = true;
  scene.add(new THREE.HemisphereLight(0xffffff, 0x444450, 1.1));
  const sun = new THREE.DirectionalLight(0xffffff, 1.2); sun.position.set(300, -400, 600); scene.add(sun);
  magMat = new THREE.MeshStandardMaterial({ color: 0xc8ccd2, metalness: 0.8, roughness: 0.3 });
  lower = new THREE.Group(); upper = new THREE.Group(); jointGroup = new THREE.Group();
  scene.add(lower, upper, jointGroup);
  renderer.domElement.addEventListener('pointerdown', down3d);
  new ResizeObserver(resize3d).observe($('jv3'));
  (function loop() { requestAnimationFrame(loop); if (!ed) return;
    if (spinning) { const a = 0.006, t = controls.target, x = camera.position.x - t.x, y = camera.position.y - t.y; camera.position.x = t.x + x * Math.cos(a) - y * Math.sin(a); camera.position.y = t.y + x * Math.sin(a) + y * Math.cos(a); }
    controls.update(); renderer.render(scene, camera); })();
}
function resize3d() { if (!renderer) return; const r = $('jv3').getBoundingClientRect(); if (r.width < 10) return; renderer.setSize(r.width, r.height); camera.aspect = r.width / r.height; camera.updateProjectionMatrix(); }
async function slab(file) {
  const buf = await (await fetch(file + '?v=' + Date.now())).arrayBuffer();
  const h = new Uint32Array(buf, 0, 2), g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(buf, 8, h[0] * 3), 3));
  g.setIndex(new THREE.BufferAttribute(new Uint32Array(buf, 8 + h[0] * 12, h[1] * 3), 1));
  g.computeVertexNormals(); g.translate(0, 0, -ed.data.z);
  return g;
}
async function loadPieces() {
  [lower, upper].forEach(g => g.clear());
  const wood = () => new THREE.MeshStandardMaterial({ color: 0x8a6a55, roughness: 0.8, transparent: true, opacity: 0.35, depthWrite: false, side: THREE.DoubleSide });
  const [gl, gu] = await Promise.all(ed.data.files.map(slab));
  const ml = new THREE.Mesh(gl, wood()), mu = new THREE.Mesh(gu, wood());
  lower.add(ml); upper.add(mu); lower.userData.mesh = ml; upper.userData.mesh = mu;
  const pts = ed.data.outline.flat(); const cx = pts.reduce((a, p) => a + p[0], 0) / pts.length, cy = pts.reduce((a, p) => a + p[1], 0) / pts.length;
  ed.cx = cx; ed.cy = cy;
}
function frame() { const r = Math.max(60, ...ed.data.outline.flat().map(p => Math.hypot(p[0] - ed.cx, p[1] - ed.cy))) * 3.2;
  controls.target.set(ed.cx, ed.cy, 0); camera.position.set(ed.cx + r * 0.8, ed.cy - r, r * 0.6); camera.near = r / 200; camera.far = r * 50; camera.updateProjectionMatrix(); }

function mats(st, solid) { const c = COL[st], color = new THREE.Color(c[0] / 255, c[1] / 255, c[2] / 255);
  return { color, mat: new THREE.MeshStandardMaterial({ color, transparent: !solid, opacity: solid ? 1 : 0.45, depthWrite: solid, emissive: color, emissiveIntensity: solid ? 0.15 : 0.3, roughness: 0.6 }) }; }
function dShape(r) { const s = new THREE.Shape(), a0 = Math.asin(-0.7); s.absarc(0, 0, r, a0, Math.PI - a0, false); s.lineTo(r * Math.cos(a0), -0.7 * r); return s; }
function solidOf(j, h, mat, r) { r = r || j.d / 2;
  if (j.kind === 'dpeg') { const g = new THREE.ExtrudeGeometry(dShape(r), { depth: h, bevelEnabled: false, curveSegments: 32 }); g.translate(0, 0, -h / 2); return new THREE.Mesh(g, mat); }
  const g = new THREE.CylinderGeometry(r, r, h, 48); g.rotateX(Math.PI / 2); return new THREE.Mesh(g, mat); }
function tag(o, i) { o.traverse(x => { x.userData.idx = i; x.userData.pick = true; }); return o; }
function draw3d() {
  if (!scene || !ed) return;
  const ap = +$('jApart').value, ex = +$('jExplode').value;
  lower.position.z = -ex; upper.position.z = ap + ex;
  const xr = $('jXray').checked;
  [lower, upper].forEach(g => { const m = g.userData.mesh; if (m) { m.material.opacity = xr ? 0.35 : 1; m.material.depthWrite = !xr; } });
  jointGroup.clear(); [lower, upper].forEach(g => g.children.filter(c => c.userData.joint).forEach(c => g.remove(c)));
  ed.joints.forEach((j, i) => {
    const st = status(i), r = j.d / 2, hole = mats(st, false), part = mats(st, true);
    const ghost = (parent, z0, h) => { const m = solidOf(j, h, hole.mat); m.position.set(j.x, j.y, z0 + h / 2); m.add(new THREE.LineSegments(new THREE.EdgesGeometry(m.geometry, 20), new THREE.LineBasicMaterial({ color: hole.color }))); m.userData.joint = true; parent.add(tag(m, i)); };
    if (LOOSE[j.kind]) {
      ghost(lower, -j.dep, j.dep); ghost(upper, 0, j.dep);
      if (j.kind === 'magnet') [-j.dep / 2, ap + j.dep / 2].forEach(z => { const m = solidOf(j, j.mt, magMat, j.md / 2); m.position.set(j.x, j.y, z); jointGroup.add(tag(m, i)); });
      else { const m = solidOf(j, Math.max(6, j.dep * 2 - 2), part.mat); m.position.set(j.x, j.y, ap / 2); jointGroup.add(tag(m, i)); }
    } else {
      const sp = solidOf(j, j.dep, part.mat); sp.position.set(j.x, j.y, j.dep / 2); sp.userData.joint = true; lower.add(tag(sp, i));
      if (j.kind === 'twist') for (let k = 0; k < 3; k++) { const a = k * 2.094; const lug = new THREE.Mesh(new THREE.BoxGeometry(4, 4, 3), part.mat); lug.position.set(j.x + Math.cos(a) * (r - 1), j.y + Math.sin(a) * (r - 1), j.dep - 2.5); lug.userData.joint = true; lower.add(lug); }
      if (j.kind === 'thread') { const p = []; for (let t = 0; t <= 720 * j.dep / 12; t += 8) { const a = t * Math.PI / 180; p.push(new THREE.Vector3(j.x + Math.cos(a) * (r + 0.4), j.y + Math.sin(a) * (r + 0.4), t / 360 * 6)); } const ln = new THREE.Line(new THREE.BufferGeometry().setFromPoints(p), new THREE.LineBasicMaterial({ color: 0xffffff })); ln.userData.joint = true; lower.add(ln); }
      ghost(upper, 0, j.dep + 0.6);
    }
    if (i === ed.sel) { const ring = new THREE.Mesh(new THREE.RingGeometry(r + 1.5, r + 2.3, 48), new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide })); ring.position.set(j.x, j.y, LOOSE[j.kind] ? ap / 2 : 0.3); jointGroup.add(ring); }
  });
}
const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(); let drag3 = null;
function pick(e) { const r = renderer.domElement.getBoundingClientRect(); ndc.set((e.clientX - r.left) / r.width * 2 - 1, -(e.clientY - r.top) / r.height * 2 + 1); ray.setFromCamera(ndc, camera); }
function down3d(e) {
  if (!ed) return; pick(e);
  const objs = []; scene.traverse(o => { if (o.isMesh && o.userData.pick) objs.push(o); });
  const hit = ray.intersectObjects(objs, false)[0]; if (!hit) return;
  ed.sel = hit.object.userData.idx; remember(); const p = new THREE.Vector3(); hit.object.getWorldPosition(p);
  drag3 = new THREE.Plane(new THREE.Vector3(0, 0, 1), -p.z); controls.enabled = false; spinning = false; draw();
}
window.addEventListener('pointermove', e => { if (!drag3 || !ed) return; pick(e); const p = new THREE.Vector3(); if (ray.ray.intersectPlane(drag3, p)) { const j = ed.joints[ed.sel]; j.x = +p.x.toFixed(2); j.y = +p.y.toFixed(2); quick(); } });
window.addEventListener('pointerup', () => { if (drag3) { drag3 = null; controls.enabled = true; scheduleCheck(); } if (drag2) { drag2 = null; scheduleCheck(); } });

// ---------------------------------------------------------------- fast 2D checks while dragging, exact checks after
function inPoly(x, y, poly) { let c = false; for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) { const [xi, yi] = poly[i], [xj, yj] = poly[j]; if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) c = !c; } return c; }
function inside(x, y) { let n = 0; ed.data.outline.forEach(p => { if (inPoly(x, y, p)) n++; }); return n % 2 === 1; }
function edgeDist(x, y) { let m = 1e9; ed.data.outline.forEach(poly => { for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) { const [ax, ay] = poly[j], [bx, by] = poly[i]; const dx = bx - ax, dy = by - ay; let t = ((x - ax) * dx + (y - ay) * dy) / (dx * dx + dy * dy || 1); t = Math.max(0, Math.min(1, t)); m = Math.min(m, Math.hypot(x - ax - t * dx, y - ay - t * dy)); } }); return m; }
function quickProblems() {
  const w = +$('jWall').value, d = ed.data;
  return ed.joints.map((j, i) => { const p = [], r = j.d / 2, n = i + 1;
    const wl = inside(j.x, j.y) ? edgeDist(j.x, j.y) - r : -1;
    if (wl < 0) p.push({ lvl: 'red', text: `Joint ${n} cuts through the outside of the part` });
    else if (wl < w) p.push({ lvl: 'red', text: `Joint ${n}: wall only ${wl.toFixed(1)} mm at the cut (needs ${w} mm)` });
    else if (wl < w + 1.5) p.push({ lvl: 'amber', text: `Joint ${n}: wall is thin at the cut (${wl.toFixed(1)} mm)` });
    const dn = LOOSE[j.kind] ? j.dep : 0, up = LOOSE[j.kind] ? j.dep : j.dep + 1;
    if (dn + w > d.z - d.z_lo) p.push({ lvl: 'red', text: `Joint ${n} is too deep for the piece below (${(d.z - d.z_lo).toFixed(0)} mm)` });
    if (up + w > d.z_hi - d.z) p.push({ lvl: 'red', text: `Joint ${n} is too deep for the piece above (${(d.z_hi - d.z).toFixed(0)} mm)` });
    ed.joints.forEach((o2, k) => { if (k > i && Math.hypot(o2.x - j.x, o2.y - j.y) < (o2.d + j.d) / 2 + w) p.push({ lvl: 'red', text: `Joints ${n} and ${k + 1} overlap or are too close` }); });
    return p; });
}
function status(i) { const p = ed.problems[i] || []; return p.some(q => q.lvl === 'red') ? 'red' : p.some(q => q.lvl === 'amber') ? 'amber' : 'ok'; }
function quick() { ed.problems = quickProblems(); ed.exact = false; draw(false); }
let timer = null;
function scheduleCheck() {
  if (!ed) return; ed.problems = quickProblems(); ed.exact = false; draw(false);
  clearTimeout(timer); const seq = ++ed.seq;
  timer = setTimeout(async () => {
    if (!ed || !ed.joints.length) return;
    $('jChecking').textContent = 'Checking against the real part…';
    const r = await ed.api.check_joints(ed.idx, ed.data.z, ed.data.z_lo, ed.data.z_hi, ed.joints, +$('jWall').value);
    if (!ed || seq !== ed.seq) return;
    $('jChecking').textContent = r.error ? 'Check failed: ' + r.error : 'Checked through the whole depth of both pieces';
    if (!r.error) { ed.problems = r.problems; ed.exact = true; draw(false); }
  }, 350);
}

// ---------------------------------------------------------------- panel, 2D view, side view
function sizeLabel(j) { return `${+(+j.md).toFixed(2)}×${+(+j.mt).toFixed(2)}`; }
function setMag(j, md, mt) { Object.assign(j, { kind: 'magnet', md, mt, d: +(md + 2 * CLR).toFixed(2), dep: +(mt + 0.2).toFixed(2) }); }
function draw(recheck) {
  if (!ed) return;
  if (recheck !== false) { scheduleCheck(); return; }
  const all = ed.problems.flat(), red = all.filter(p => p.lvl === 'red'), amb = all.filter(p => p.lvl === 'amber'), w = $('jWarn');
  const set = (bg, fg, icon, t) => { w.style.background = bg; w.style.color = fg; w.textContent = (icon ? icon + ' ' : '') + t; };
  if (!editable(ed.cutType)) set('rgba(0,174,66,0.14)', '#5DCAA5', '', `${CUT_TYPES[ed.cutType]}: made automatically when you press Make pieces. Pick an editable type to place joints by hand.`);
  else if (!ed.joints.length) set('rgba(240,160,48,0.16)', '#FAC775', '⚠', 'No joints at this cut: it will be a flat glue face');
  else if (red.length) set('rgba(232,90,90,0.18)', '#F09595', '⚠', red.map(p => p.text).join(' · '));
  else if (amb.length) set('rgba(240,160,48,0.16)', '#FAC775', '⚠', amb.map(p => p.text).join(' · '));
  else set('rgba(0,174,66,0.14)', '#5DCAA5', '✓', `All joints fit, with at least ${$('jWall').value} mm of wall everywhere` + (ed.exact ? ' (checked through both pieces)' : ''));
  const chips = $('jChips');
  chips.innerHTML = ed.joints.map((j, i) => { const c = COL[status(i)].join(','); return `<button class="jchip ${i === ed.sel ? 'on' : ''}" data-i="${i}"><span class="jdot" style="background:rgb(${c})"></span>${i + 1} · ${NAMES[j.kind]}${j.kind === 'magnet' ? ' ' + sizeLabel(j) : ''}</button>`; }).join('') || '<span class="dim small">No joints yet: Auto-place or Add one</span>';
  chips.querySelectorAll('[data-i]').forEach(b => b.onclick = () => { ed.sel = +b.dataset.i; draw(false); });
  $('jUniWrap').classList.toggle('hidden', ed.joints.filter(j => j.kind === 'magnet').length < 2);
  const mags = {}; ed.joints.filter(j => j.kind === 'magnet').forEach(j => { const k = sizeLabel(j).replace('×', ' × '); mags[k] = (mags[k] || 0) + 2; });
  $('jBuy').textContent = Object.keys(mags).length ? 'Magnets to buy for this cut: ' + Object.entries(mags).map(([k, n]) => `${n} of ${k} mm`).join(', ') + ' (half of them flipped, so they attract)' : '';
  const j = ed.joints[ed.sel];
  ['jKind', 'jAdd', 'jDel', 'jDia', 'jDep'].forEach(id => $(id).disabled = !editable(ed.cutType));
  if (j) {
    $('jSelTitle').textContent = `Joint ${ed.sel + 1} · ${NAMES[j.kind]}`; $('jKind').value = j.kind;
    const mag = j.kind === 'magnet';
    $('jMagRow').classList.toggle('hidden', !mag); $('jDiaRow').classList.toggle('hidden', mag); $('jDepRow').classList.toggle('hidden', mag);
    if (mag) { const v = `${+j.md}x${+j.mt}`, has = [...$('jMag').options].some(x => x.value === v); $('jMag').value = has ? v : 'custom'; $('jCustRow').classList.toggle('hidden', has); if (!has) { $('jCD').value = j.md; $('jCT').value = j.mt; } }
    else { $('jCustRow').classList.add('hidden'); $('jDia').value = j.d; $('jDep').value = j.dep; $('jDiaO').textContent = (+j.d).toFixed(1) + ' mm'; $('jDepO').textContent = j.dep + ' mm'; }
  } else { $('jSelTitle').textContent = 'No joint selected'; ['jMagRow', 'jCustRow', 'jDiaRow', 'jDepRow'].forEach(id => $(id).classList.add('hidden')); }
  $('jWallO').textContent = $('jWall').value + ' mm';
  $('jCutNote').textContent = `Cut at ${ed.data.z.toFixed(1)} mm · piece below ${(ed.data.z - ed.data.z_lo).toFixed(0)} mm · above ${(ed.data.z_hi - ed.data.z).toFixed(0)} mm`;
  draw2d(); drawSide(); draw3d();
}
let drag2 = null, view2 = null;
function draw2d() {
  if ($('jTop').classList.contains('hidden')) return;
  const pts = ed.data.outline.flat(), xs = pts.map(p => p[0]), ys = pts.map(p => p[1]);
  const minx = Math.min(...xs), maxx = Math.max(...xs), miny = Math.min(...ys), maxy = Math.max(...ys);
  const s = Math.min(360 / (maxx - minx || 1), 320 / (maxy - miny || 1)), ox = 200 - (minx + maxx) / 2 * s, oy = 180 + (miny + maxy) / 2 * s;
  view2 = { s, ox, oy };
  const P = ([x, y]) => `${ox + x * s},${oy - y * s}`;
  let g = `<path d="${ed.data.outline.map(p => 'M' + p.map(P).join('L') + 'Z').join('')}" fill="#8a6a55" fill-rule="evenodd" stroke="#B2B3B5"/>`;
  ed.joints.forEach((j, i) => { const c = COL[status(i)].join(','), px = ox + j.x * s, py = oy - j.y * s, r = j.d / 2 * s;
    const shape = j.kind === 'dpeg' ? `<path d="M ${px - r * 0.71} ${py + r * 0.7} A ${r} ${r} 0 1 1 ${px + r * 0.71} ${py + r * 0.7} Z"/>` : `<circle cx="${px}" cy="${py}" r="${r}"/>`;
    g += `<g data-i="${i}" style="cursor:grab" fill="rgba(${c},0.42)" stroke="rgb(${c})" stroke-width="${i === ed.sel ? 2.5 : 1.2}">${shape}</g><text x="${px}" y="${py + 4}" text-anchor="middle" font-size="12" fill="#fff" pointer-events="none">${i + 1}</text>`; });
  $('jTop').innerHTML = g;
  $('jTop').querySelectorAll('g[data-i]').forEach(el => el.addEventListener('pointerdown', e => {
    const i = +el.dataset.i; ed.sel = i; remember(); const r = $('jTop').getBoundingClientRect(), k = 400 / r.width;
    drag2 = { i, x: e.clientX, y: e.clientY, jx: ed.joints[i].x, jy: ed.joints[i].y, k }; e.preventDefault(); draw(false); }));
}
window.addEventListener('pointermove', e => { if (!drag2 || !ed) return; const j = ed.joints[drag2.i]; j.x = +(drag2.jx + (e.clientX - drag2.x) * drag2.k / view2.s).toFixed(2); j.y = +(drag2.jy - (e.clientY - drag2.y) * drag2.k / view2.s).toFixed(2); quick(); });
function drawSide() {
  const d = ed.data, hb = d.z - d.z_lo, ha = d.z_hi - d.z, sc = 220 / Math.max(hb + ha, 1), cut = 20 + ha * sc, j = ed.joints[ed.sel];
  let s = `<rect x="40" y="20" width="120" height="${ha * sc - 2}" fill="#8a6a55"/><rect x="40" y="${cut + 2}" width="120" height="${hb * sc - 2}" fill="#8a6a55"/><line x1="30" x2="170" y1="${cut}" y2="${cut}" stroke="#E6E6E8" stroke-dasharray="4 3"/>`;
  if (j) { const c = COL[status(ed.sel)].join(','), up = LOOSE[j.kind] ? j.dep : j.dep + 1, dn = LOOSE[j.kind] ? j.dep : 0, k = Math.max(sc, j.kind === 'magnet' ? 4 : sc), hw = Math.min(60, j.d * k / 2);
    s += `<rect x="${100 - hw}" y="${cut - up * k}" width="${hw * 2}" height="${(up + dn) * k}" fill="rgba(${c},0.42)" stroke="rgb(${c})" stroke-width="1.5"/>`;
    s += `<text x="100" y="12" text-anchor="middle" font-size="11" fill="#B2B3B5">joint ${ed.sel + 1}: ${j.kind === 'magnet' ? sizeLabel(j).replace('×', ' × ') + ' mm magnets' : (+j.d).toFixed(1) + ' mm wide'}${k > sc ? ' (drawn bigger)' : ''}</text>`; }
  s += `<text x="44" y="34" font-size="11" fill="#fff">piece above ${ha.toFixed(0)} mm</text><text x="44" y="${cut + 16}" font-size="11" fill="#fff">piece below ${hb.toFixed(0)} mm</text>`;
  $('jSide').innerHTML = s;
}

// ---------------------------------------------------------------- controls
$('j2d').onclick = () => { $('jv3').classList.add('hidden'); $('jOpts').classList.add('hidden'); $('jTop').classList.remove('hidden'); $('j2d').classList.add('on'); $('j3d').classList.remove('on'); $('jViewLbl').textContent = 'Cut face from above: drag a joint to move it'; draw(false); };
$('j3d').onclick = () => { $('jv3').classList.remove('hidden'); $('jOpts').classList.remove('hidden'); $('jTop').classList.add('hidden'); $('j3d').classList.add('on'); $('j2d').classList.remove('on'); $('jViewLbl').textContent = '3D: drag to rotate, wheel to zoom, drag a joint to move it'; resize3d(); draw(false); };
$('jXray').onchange = draw3d; $('jApart').oninput = draw3d; $('jExplode').oninput = draw3d;
$('jSpin').onclick = () => { spinning = !spinning; $('jSpin').classList.toggle('on', spinning); };
async function autoPlace() {
  const t = ed.cutType;
  ed.joints = editable(t) ? await ed.api.auto_joints(ed.idx, ed.data.z, t, magSel()) : [];
  ed.sel = 0; draw();
}
function magSel() { const m = ed.joints.find(j => j.kind === 'magnet'); return m ? [m.md, m.mt] : [8, 3]; }
$('jCutType').onchange = () => { remember(); ed.cutType = $('jCutType').value; autoPlace(); };
$('jAuto').onclick = () => { remember(); autoPlace(); };
$('jKind').onchange = e => { const j = ed.joints[ed.sel]; if (!j) return; remember(); const k = e.target.value;
  if (k === 'magnet') { const [md, mt] = magSel(); setMag(j, md, mt); } else { Object.assign(j, { kind: k, ...DEF[k] }); delete j.md; delete j.mt; } draw(); };
function applyMag(md, mt) { const j = ed.joints[ed.sel]; if (!j || j.kind !== 'magnet') return; remember();
  if ($('jUniform').checked) ed.joints.filter(q => q.kind === 'magnet').forEach(q => setMag(q, md, mt)); else setMag(j, md, mt); draw(); }
$('jMag').onchange = e => { $('jCErr').textContent = ''; if (e.target.value === 'custom') { $('jCustRow').classList.remove('hidden'); $('jCD').focus(); return; } const [md, mt] = e.target.value.split('x').map(Number); applyMag(md, mt); };
$('jCApply').onclick = () => { const md = parseFloat($('jCD').value), mt = parseFloat($('jCT').value);
  if (!isFinite(md) || md < 1 || md > 50) { $('jCErr').textContent = 'Enter the magnet width across, between 1 and 50 mm'; return; }
  if (!isFinite(mt) || mt < 0.5 || mt > 20) { $('jCErr').textContent = 'Enter the magnet thickness, between 0.5 and 20 mm'; return; }
  $('jCErr').textContent = ''; applyMag(Math.round(md * 10) / 10, Math.round(mt * 10) / 10); };
['jCD', 'jCT'].forEach(id => $(id).addEventListener('input', () => $('jCErr').textContent = ''));
$('jUniform').onchange = () => { const j = ed.joints[ed.sel]; if ($('jUniform').checked && j && j.kind === 'magnet') applyMag(j.md, j.mt); };
$('jDia').oninput = e => { const j = ed.joints[ed.sel]; if (j) { j.d = +e.target.value; quick(); } };
$('jDep').oninput = e => { const j = ed.joints[ed.sel]; if (j) { j.dep = +e.target.value; quick(); } };
$('jDia').onchange = scheduleCheck; $('jDep').onchange = scheduleCheck;
['jDia', 'jDep'].forEach(id => $(id).addEventListener('pointerdown', remember));
$('jWall').oninput = () => quick(); $('jWall').onchange = scheduleCheck;
$('jAdd').onclick = () => { remember(); const cur = ed.joints[ed.sel]; const k = cur ? cur.kind : (editable(ed.cutType) ? ed.cutType : 'dpeg');
  const j = { kind: k, x: +(ed.cx + 4 * ed.joints.length).toFixed(2), y: +(ed.cy - 4).toFixed(2), ...(DEF[k] || {}) };
  if (k === 'magnet') setMag(j, cur ? cur.md : 8, cur ? cur.mt : 3);
  ed.joints.push(j); ed.sel = ed.joints.length - 1; draw(); };
$('jDel').onclick = () => { if (ed.joints.length) { remember(); ed.joints.splice(ed.sel, 1); ed.sel = Math.max(0, ed.sel - 1); draw(); } };
window.addEventListener('keydown', e => { if (ed && e.key === 'Escape') close(false); });
export function editorOpen() { return !!ed; }

// ---------------------------------------------------------------- undo / redo inside the editor
function remember() { if (!ed) return; ed.hist = ed.hist || []; ed.hist.push(JSON.stringify({ j: ed.joints, t: ed.cutType, s: ed.sel })); if (ed.hist.length > 100) ed.hist.shift(); ed.fut = []; }
function back(from, to) { if (!ed || !from || !from.length) return; to.push(JSON.stringify({ j: ed.joints, t: ed.cutType, s: ed.sel })); const o = JSON.parse(from.pop()); ed.joints = o.j; ed.cutType = o.t; ed.sel = o.s; $('jCutType').value = ed.cutType; draw(); }
export function editorUndo() { if (ed) { ed.fut = ed.fut || []; back(ed.hist, ed.fut); } }
export function editorRedo() { if (ed) { ed.hist = ed.hist || []; back(ed.fut, ed.hist); } }
