// How a filament looks: solid, gradient/multicolour, see-through, glow, metal, silk, sparkle...
export function rgba(hex) {
  const h = String(hex || '#888888').replace('#', ''); const n = parseInt(h.slice(0, 6), 16);
  const a = h.length >= 8 ? parseInt(h.slice(6, 8), 16) / 255 : 1;
  return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a.toFixed(2)})`;
}
const CHECK = 'repeating-conic-gradient(#bbb 0% 25%, #eee 0% 50%) 50% / 8px 8px';
export function swatchCss(f) {
  const cs = (f && f.colors && f.colors.length ? f.colors : [f && f.color || '#888888']).map(String);
  const eff = f && f.effect || 'solid';
  let alphaFix = c => c;
  if (eff === 'translucent') alphaFix = c => c.length >= 9 ? c : c.slice(0, 7) + '99';
  if (eff === 'clear') alphaFix = c => c.slice(0, 7) + '40';
  const cols = cs.map(c => rgba(alphaFix(c)));
  let base;
  if (cols.length > 1 && f.ctype === 'multi') { const st = 100 / cols.length; base = `linear-gradient(135deg, ${cols.map((c, i) => `${c} ${i * st}% ${(i + 1) * st}%`).join(', ')})`; }
  else if (cols.length > 1) base = `linear-gradient(135deg, ${cols.join(', ')})`;
  else base = `linear-gradient(${cols[0]}, ${cols[0]})`;
  const layers = [];
  if (eff === 'metal' || eff === 'silk') layers.push('linear-gradient(135deg, rgba(255,255,255,.65) 0%, rgba(255,255,255,0) 35%, rgba(255,255,255,.35) 55%, rgba(0,0,0,.15) 100%)');
  if (eff === 'sparkle' || eff === 'galaxy') layers.push('radial-gradient(circle at 25% 30%, #fff 0 1px, transparent 2px), radial-gradient(circle at 70% 60%, #fff 0 1px, transparent 2px), radial-gradient(circle at 45% 80%, #fff 0 1px, transparent 2px)');
  if (eff === 'marble') layers.push('linear-gradient(120deg, transparent 40%, rgba(255,255,255,.4) 45%, transparent 52%)');
  if (eff === 'wood') layers.push('repeating-linear-gradient(90deg, rgba(0,0,0,.12) 0 2px, transparent 2px 6px)');
  layers.push(base);
  if (eff === 'translucent' || eff === 'clear' || cs.some(c => c.length >= 9 && !c.toUpperCase().endsWith('FF'))) layers.push(CHECK);
  let css = `background:${layers.join(', ')};`;
  if (eff === 'glow') css += `box-shadow:0 0 8px 2px ${rgba(cs[0].slice(0, 7) + 'CC')};`;
  return css;
}
