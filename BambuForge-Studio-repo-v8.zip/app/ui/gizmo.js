// 3D handles for the Plates step: thin see-through rotate rings with a degree protractor, move arrows,
// plus the Measure tool, the Section (slice-open) view and the support heat map.
import * as THREE from 'three';
const AX = { x: new THREE.Vector3(1, 0, 0), y: new THREE.Vector3(0, 1, 0), z: new THREE.Vector3(0, 0, 1) };
const COL = { x: 0xE85A5A, y: 0x1CC25A, z: 0x378ADD };
const BASIS = { x: ['y', 'z'], y: ['z', 'x'], z: ['x', 'y'] };   // u, w: angle = atan2(w, u) turns right-handed about the axis
const RING = 0.35, HOT = 0.9;

export function makeTools(o) {
  // o: { scene, camera, controls, dom, tagEl, selected(): mesh|null, onRotate(axis, deg), onMove(dx, dy, dz), onMeasure(text) }
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  const rot = new THREE.Group(), mov = new THREE.Group(), proto = new THREE.Group();
  o.scene.add(rot, mov, proto);
  ['x', 'y', 'z'].forEach(a => {
    const g = new THREE.Group(); g.userData.axis = a;
    const mat = new THREE.MeshBasicMaterial({ color: COL[a], depthTest: false, transparent: true, opacity: RING });
    g.add(new THREE.Mesh(new THREE.TorusGeometry(1, 0.004, 6, 160), mat));
    const hit = new THREE.Mesh(new THREE.TorusGeometry(1, 0.06, 6, 64), new THREE.MeshBasicMaterial({ visible: false })); hit.userData.pick = a; g.add(hit);
    [0.35, -0.35].forEach((off, i) => { const c = new THREE.Mesh(new THREE.ConeGeometry(0.035, 0.1, 16), mat); const an = Math.PI / 4 + off * 0.25;
      c.position.set(Math.cos(an), Math.sin(an), 0); c.rotation.z = an + (i ? Math.PI : 0); c.userData.pick = a; g.add(c); });
    g.userData.mat = mat; if (a === 'x') g.rotation.y = Math.PI / 2; if (a === 'y') g.rotation.x = -Math.PI / 2;
    g.traverse(x => x.renderOrder = 10); rot.add(g);
    const h = new THREE.Group(); h.userData.axis = a; const m2 = new THREE.MeshBasicMaterial({ color: COL[a], depthTest: false, transparent: true, opacity: .55 });
    const sh = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 1, 8), m2); sh.position.y = .5;
    const hd = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.15, 16), m2); hd.position.y = 1.06;
    const ht = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 1.2, 8), new THREE.MeshBasicMaterial({ visible: false })); ht.position.y = .6;
    [sh, hd, ht].forEach(x => { x.userData.pick = a; x.renderOrder = 10; }); h.add(sh, hd, ht); h.userData.mat = m2;
    if (a === 'x') h.rotation.z = -Math.PI / 2; if (a === 'z') h.rotation.x = Math.PI / 2; mov.add(h);
  });
  rot.visible = mov.visible = false;
  let mode = null, drag = null, base = null;     // base: the selected mesh's resting transform
  const box = m => { m.geometry.computeBoundingBox(); return m.geometry.boundingBox.clone().applyMatrix4(m.matrixWorld); };
  function place() {
    const m = o.selected(); if (!m || !mode) { rot.visible = mov.visible = false; return; }
    const b = box(m), c = b.getCenter(new THREE.Vector3()), s = b.getSize(new THREE.Vector3()).length() * 0.62;
    rot.position.copy(c); mov.position.set(c.x, c.y, b.min.z); rot.scale.setScalar(s); mov.scale.setScalar(s * 0.9);
    rot.visible = mode === 'rotate'; mov.visible = mode === 'move';
  }
  function setMode(m) { mode = m; place(); }
  function pick(e) { const r = o.dom.getBoundingClientRect(); ndc.set((e.clientX - r.left) / r.width * 2 - 1, -(e.clientY - r.top) / r.height * 2 + 1); ray.setFromCamera(ndc, o.camera); return r; }
  function tag(p, text) { const r = o.dom.getBoundingClientRect(), v = p.clone().project(o.camera); const t = o.tagEl;
    const x = Math.min(r.width - 50, Math.max(50, (v.x + 1) / 2 * r.width)), y = Math.min(r.height - 10, Math.max(36, (1 - v.y) / 2 * r.height));   // stay inside the 3D view
    t.style.left = x + 'px'; t.style.top = y + 'px'; t.textContent = text; t.classList.remove('hidden'); }
  const planeHit = (n, c) => { const p = new THREE.Vector3(); return ray.ray.intersectPlane(new THREE.Plane().setFromNormalAndCoplanarPoint(n, c), p) ? p : null; };
  const angIn = (a, v) => { const [u, w] = BASIS[a]; return Math.atan2(v.dot(AX[w]), v.dot(AX[u])); };
  const hitOf = G => ray.intersectObjects(G.children.flatMap(g => g.children).filter(x => x.userData.pick), false)[0];
  function axisT(a) { const p0 = mov.position, d = AX[a], w0 = ray.ray.origin.clone().sub(p0), b = d.dot(ray.ray.direction), dd = d.dot(w0), ee = ray.ray.direction.dot(w0), den = 1 - b * b; return den < 1e-6 ? 0 : (dd - b * ee) / den; }
  function drawProto(a, a0, d) {
    proto.clear(); const [u, w] = BASIS[a], c = rot.position, r = rot.scale.x, U = AX[u], W = AX[w];
    const P = (th, rr) => c.clone().addScaledVector(U, Math.cos(th) * rr).addScaledVector(W, Math.sin(th) * rr);
    const pts = []; for (let k = 0; k < 72; k++) { const th = k * Math.PI / 36, big = k % 9 === 0, mid = k % 3 === 0; pts.push(P(th, r), P(th, r * (big ? 1.12 : mid ? 1.07 : 1.04))); }
    const lm = op => new THREE.LineBasicMaterial({ color: 0xffffff, depthTest: false, transparent: true, opacity: op });
    proto.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(pts), lm(.55)));
    proto.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints([c, P(a0, r)]), lm(.35)));
    proto.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints([c, P(a0 + d, r * 1.1)]), new THREE.LineBasicMaterial({ color: COL[a], depthTest: false, transparent: true, opacity: .9 })));
    const n = Math.max(2, Math.ceil(Math.abs(d) / (Math.PI / 90))), fan = [c]; for (let k = 0; k <= n; k++) fan.push(P(a0 + d * k / n, r * .98));
    const idx = []; for (let k = 1; k <= n; k++) idx.push(0, k, k + 1); const g = new THREE.BufferGeometry().setFromPoints(fan); g.setIndex(idx);
    proto.add(new THREE.Mesh(g, new THREE.MeshBasicMaterial({ color: COL[a], transparent: true, opacity: .15, side: THREE.DoubleSide, depthTest: false })));
    proto.children.forEach(x => x.renderOrder = 11);
  }
  // rotate the mesh on screen about its centre and keep it sitting where it was (the server does it for real on release)
  function previewRot(m, axis, ang) {
    const c = base.c, R = new THREE.Matrix4().makeRotationAxis(AX[axis], ang);
    const M = new THREE.Matrix4().makeTranslation(c.x, c.y, c.z).multiply(R).multiply(new THREE.Matrix4().makeTranslation(-c.x, -c.y, -c.z)).multiply(base.matrix);
    m.matrixAutoUpdate = false; m.matrix.copy(M); m.matrixWorldNeedsUpdate = true; m.updateMatrixWorld(true);
    const b = box(m); const dz = base.minz - b.min.z;
    m.matrix.premultiply(new THREE.Matrix4().makeTranslation(0, 0, dz)); m.updateMatrixWorld(true);
  }
  function down(e) {
    if (!mode || e.button !== 0) return false;
    const m = o.selected(); if (!m) return false;
    pick(e);
    if (rot.visible) { const h = hitOf(rot); if (h) {
      const a = h.object.userData.pick, c = rot.position.clone(), p = planeHit(AX[a], c); if (!p) return false;
      m.updateMatrixWorld(true); base = { matrix: m.matrix.clone(), c, minz: box(m).min.z };
      drag = { type: 'rot', a, c, a0: angIn(a, p.clone().sub(c)), last: 0, d: 0 };
      rot.children.forEach(g => { g.visible = g.userData.axis === a; g.userData.mat.opacity = HOT; }); drawProto(a, drag.a0, 0); return true; } }
    if (mov.visible) {
      const h = hitOf(mov);
      if (h) { const a = h.object.userData.pick; drag = { type: 'axis', a, p0: m.position.clone(), t0: axisT(a), d: 0, minz: box(m).min.z }; return true; }
      const hit = ray.intersectObject(m, false)[0];
      if (hit) { const p = planeHit(AX.z, new THREE.Vector3(0, 0, box(m).min.z)); if (p) { drag = { type: e.shiftKey ? 'lift' : 'slide', p0: p, o0: m.position.clone(), y: e.clientY, d: 0 }; return true; } }
    }
    return false;
  }
  function moveEv(e) {
    const m = o.selected();
    if (!drag) {             // brighten the ring or arrow under the pointer
      if (!mode) return; pick(e);
      [[rot, RING], [mov, .55]].forEach(([G, b]) => { if (!G.visible) return; const h = hitOf(G); G.children.forEach(g => g.userData.mat.opacity = h && h.object.userData.pick === g.userData.axis ? HOT : b); });
      o.dom.style.cursor = (rot.visible && hitOf(rot)) || (mov.visible && hitOf(mov)) ? 'grab' : ''; return;
    }
    pick(e);
    if (drag.type === 'rot') { const p = planeHit(AX[drag.a], drag.c); if (!p) return;
      let d = angIn(drag.a, p.clone().sub(drag.c)) - drag.a0; d = Math.atan2(Math.sin(d), Math.cos(d));
      if (!e.ctrlKey) d = Math.round(d / (Math.PI / 36)) * (Math.PI / 36);
      d += Math.round((drag.last - d) / (2 * Math.PI)) * 2 * Math.PI; drag.last = d; drag.d = d;
      previewRot(m, drag.a, d); drawProto(drag.a, drag.a0, d);
      const [u, w] = BASIS[drag.a], th = drag.a0 + d, r = rot.scale.x * 1.18;
      tag(drag.c.clone().addScaledVector(AX[u], Math.cos(th) * r).addScaledVector(AX[w], Math.sin(th) * r), `${drag.a.toUpperCase()}: ${d >= 0 ? '+' : ''}${(d * 180 / Math.PI).toFixed(e.ctrlKey ? 1 : 0)}°`); return; }
    if (drag.type === 'axis') { const t = axisT(drag.a) - drag.t0;
      if (drag.a === 'z') { m.position.copy(drag.p0); m.position.z += Math.max(-drag.minz, t); }
      else { m.position.copy(drag.p0).addScaledVector(AX[drag.a], t); }
      drag.d = t; place(); tag(mov.position, `${drag.a.toUpperCase()}: ${t >= 0 ? '+' : ''}${t.toFixed(1)} mm`); return; }
    if (drag.type === 'slide') { const p = planeHit(AX.z, drag.p0); if (!p) return; m.position.set(drag.o0.x + p.x - drag.p0.x, drag.o0.y + p.y - drag.p0.y, drag.o0.z); place();
      tag(mov.position, `moved ${(m.position.x - drag.o0.x).toFixed(1)}, ${(m.position.y - drag.o0.y).toFixed(1)} mm`); return; }
    if (drag.type === 'lift') { const dz = Math.max(0, (drag.y - e.clientY) * 0.4); m.position.z = drag.o0.z + dz; place(); tag(mov.position, `lifted ${dz.toFixed(1)} mm`); }
  }
  async function up() {
    if (!drag) return false;
    const d = drag, m = o.selected(); drag = null; o.tagEl.classList.add('hidden'); proto.clear();
    rot.children.forEach(g => { g.visible = true; g.userData.mat.opacity = RING; });
    if (d.type === 'rot') { const deg = d.d * 180 / Math.PI; if (Math.abs(deg) > 0.05) await o.onRotate(d.a, deg); else { m.matrixAutoUpdate = true; } }
    else if (m) { const dx = m.position.x - (d.o0 || d.p0).x, dy = m.position.y - (d.o0 || d.p0).y, dz = m.position.z - (d.o0 || d.p0).z;
      if (Math.hypot(dx, dy, dz) > 0.2) await o.onMove(dx, dy, dz); else m.position.copy(d.o0 || d.p0); }
    place(); return true;
  }
  // ---------- measure: click two points
  let mpts = [], mline = null, measuring = false;
  function setMeasure(on) { measuring = on; mpts = []; if (mline) { o.scene.remove(mline); mline = null; } o.tagEl.classList.add('hidden'); }
  function measureClick(hit) {
    if (!measuring || !hit) return false;
    mpts.push(hit.point.clone()); if (mpts.length > 2) mpts = [hit.point.clone()];
    if (mline) { o.scene.remove(mline); mline = null; }
    if (mpts.length === 2) {
      mline = new THREE.Line(new THREE.BufferGeometry().setFromPoints(mpts), new THREE.LineBasicMaterial({ color: 0xffd23f, depthTest: false })); mline.renderOrder = 12; o.scene.add(mline);
      const dv = mpts[1].clone().sub(mpts[0]), d = dv.length();
      tag(mpts[0].clone().add(mpts[1]).multiplyScalar(.5), `${d.toFixed(1)} mm`);
      o.onMeasure(`${d.toFixed(1)} mm  (X ${Math.abs(dv.x).toFixed(1)} · Y ${Math.abs(dv.y).toFixed(1)} · Z ${Math.abs(dv.z).toFixed(1)})`);
    } else o.onMeasure('Now click the second point.');
    return true;
  }
  return { setMode, place, down, move: moveEv, up, setMeasure, measureClick, get dragging() { return !!drag; }, _dbg: () => ({ rotVisible: rot.visible, movVisible: mov.visible, mode, pos: rot.position.toArray(), scale: rot.scale.x, sel: !!o.selected() }) };
}

// ---------- section view: one clipping plane for every part material
export const sectionPlane = new THREE.Plane(new THREE.Vector3(0, 0, -1), 1e9);
export function applySection(meshes, on) {
  meshes.forEach(m => (Array.isArray(m.material) ? m.material : [m.material]).forEach(mt => { mt.clippingPlanes = on ? [sectionPlane] : []; mt.clipShadows = true; mt.side = on ? THREE.DoubleSide : mt.side; mt.needsUpdate = true; }));
}

// ---------- support heat map: an overlay that paints downward faces (that aren't on the plate) red
export function heatOverlay(mesh, angle = 45) {
  const g = mesh.geometry.index ? mesh.geometry.toNonIndexed() : mesh.geometry.clone();
  const pos = g.attributes.position, n = pos.count, col = new Float32Array(n * 4);
  mesh.updateMatrixWorld(true);
  const M = mesh.matrixWorld, a = new THREE.Vector3(), b = new THREE.Vector3(), c = new THREE.Vector3(), lim = -Math.cos((90 - angle) * Math.PI / 180);
  let zmin = Infinity; for (let i = 0; i < n; i++) { a.fromBufferAttribute(pos, i).applyMatrix4(M); zmin = Math.min(zmin, a.z); }
  let area = 0;
  for (let i = 0; i < n; i += 3) {
    a.fromBufferAttribute(pos, i).applyMatrix4(M); b.fromBufferAttribute(pos, i + 1).applyMatrix4(M); c.fromBufferAttribute(pos, i + 2).applyMatrix4(M);
    const nn = new THREE.Vector3().subVectors(b, a).cross(new THREE.Vector3().subVectors(c, a)); const ar = nn.length() / 2; nn.normalize();
    const bad = nn.z < lim && Math.max(a.z, b.z, c.z) > zmin + 0.4;
    if (bad) area += ar;
    for (let k = 0; k < 3; k++) { col[(i + k) * 4] = 0.91; col[(i + k) * 4 + 1] = 0.19; col[(i + k) * 4 + 2] = 0.16; col[(i + k) * 4 + 3] = bad ? 0.85 : 0; }
  }
  g.setAttribute('color', new THREE.BufferAttribute(col, 4));
  const ov = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 }));
  ov.matrixAutoUpdate = false; ov.matrix.copy(mesh.matrixWorld); ov.userData.heat = true; ov.userData.area = area;
  return ov;
}
