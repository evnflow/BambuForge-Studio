"""Put text on a model: raised (embossed) or cut in (engraved), lying on the surface you clicked."""
import math
import numpy as np
import manifold3d as mf
import split


def text_solid(shapes, depth, sink):
    """shapes: [{'outer': [[x,y]...], 'holes': [[[x,y]...]...]}] in mm, centred on 0,0. Extruded from -sink to +depth."""
    secs = []
    for s in shapes:
        cont = [np.asarray(s['outer'], np.float64)] + [np.asarray(h, np.float64) for h in s.get('holes', []) if len(h) >= 3]
        cont = [c for c in cont if len(c) >= 3]
        if not cont: continue
        cs = mf.CrossSection(cont, mf.FillRule.EvenOdd)
        if not cs.is_empty(): secs.append(cs)
    if not secs: raise ValueError('There is no text to add.')
    cs = secs[0]
    for x in secs[1:]: cs = cs + x
    h = depth + sink
    if h <= 0: raise ValueError('Text depth must be more than 0.')
    return mf.Manifold.extrude(cs, h).translate((0, 0, -sink))


def frame(point, normal, angle_deg):
    """4x4 that puts the text's (x right, y up, z out) onto the surface at point, facing out along normal."""
    n = np.asarray(normal, float); n /= np.linalg.norm(n) or 1
    up = np.array([0, 0, 1.0]) if abs(n[2]) < 0.9 else np.array([0, 1.0, 0])
    x = np.cross(up, n); x /= np.linalg.norm(x) or 1
    y = np.cross(n, x)
    a = math.radians(angle_deg)
    xr, yr = x * math.cos(a) + y * math.sin(a), -x * math.sin(a) + y * math.cos(a)
    M = np.eye(4); M[:3, 0], M[:3, 1], M[:3, 2], M[:3, 3] = xr, yr, n, point
    return M


def add_text(part, shapes, point, normal, depth=1.0, mode='raise', slot=None, angle=0.0):
    """Returns (trimesh, filament per triangle). The text gets filament `slot` (raised text) or keeps the part's colours (cut in)."""
    depth = max(0.2, float(depth))
    M = frame(point, normal, angle)[:3, :].astype(np.float64)
    solid = split.to_mf(part.mesh, part.exts() if part.face_ext is not None else None)
    if mode == 'raise':
        # the letters stand `depth` above the surface; below it they only fill into the part (up to 3 mm), so on a
        # curved surface no corner floats, and on a thin wall nothing pokes out of the other side
        above = text_solid(shapes, depth, 0.0).transform(M)
        below = text_solid(shapes, 0.0, 3.0).transform(M) ^ solid
        T = above + below
        slot = int(slot or part.ext)
        # the text's own faces carry its filament slot through the union
        g = T.to_mesh()
        T = mf.Manifold(mf.Mesh(vert_properties=np.array(g.vert_properties[:, :3], np.float32, copy=True, order="C"), tri_verts=np.array(g.tri_verts, np.uint32, copy=True, order="C"),
                                face_id=np.full(len(g.tri_verts), split.FID + slot, np.uint32)))
        out = solid + T
    else:
        T = text_solid(shapes, 0.6, depth).transform(M)
        out = solid - T
    if out.is_empty(): raise ValueError('The text missed the model. Click right on its surface.')
    return split.to_tm_ext(out, part.ext)


# ------------------------------------------------------------------ text that wraps around curved surfaces
def _closest_on_tris(p, a, b, c):
    """Closest point on each triangle (a, b, c are n x 3) to point p (Ericson's method, vectorised)."""
    ab, ac, ap = b - a, c - a, p - a
    d1, d2 = (ab * ap).sum(1), (ac * ap).sum(1)
    bp = p - b; d3, d4 = (ab * bp).sum(1), (ac * bp).sum(1)
    cp = p - c; d5, d6 = (ab * cp).sum(1), (ac * cp).sum(1)
    vc = d1 * d4 - d3 * d2; vb = d5 * d2 - d1 * d6; va = d3 * d6 - d5 * d4
    den = va + vb + vc; den[den == 0] = 1e-12
    v = vb / den; w = vc / den
    res = a + ab * v[:, None] + ac * w[:, None]
    m = (d1 <= 0) & (d2 <= 0); res[m] = a[m]
    m = (d3 >= 0) & (d4 <= d3); res[m] = b[m]
    m = (d6 >= 0) & (d5 <= d6); res[m] = c[m]
    m = (vc <= 0) & (d1 >= 0) & (d3 <= 0); t = d1 / np.where(d1 - d3 == 0, 1e-12, d1 - d3); res[m] = (a + ab * t[:, None])[m]
    m = (vb <= 0) & (d2 >= 0) & (d6 <= 0); t = d2 / np.where(d2 - d6 == 0, 1e-12, d2 - d6); res[m] = (a + ac * t[:, None])[m]
    m = (va <= 0) & ((d4 - d3) >= 0) & ((d5 - d6) >= 0)
    t = (d4 - d3) / np.where((d4 - d3) + (d5 - d6) == 0, 1e-12, (d4 - d3) + (d5 - d6)); res[m] = (b + (c - b) * t[:, None])[m]
    return res


class Surface:
    """Find the nearest point on a mesh, and a smooth surface direction there."""
    def __init__(self, mesh, cell=2.0):
        self.tri = np.asarray(mesh.triangles, np.float64)
        self.cen = self.tri.mean(1); self.nrm = np.asarray(mesh.face_normals, np.float64); self.area = np.asarray(mesh.area_faces, np.float64)
        # a coarse grid of triangle centres, so finding the nearby ones doesn't mean checking every triangle
        self.h = cell; self.lo = self.cen.min(0) - cell
        ijk = np.floor((self.cen - self.lo) / cell).astype(np.int64); self.dim = ijk.max(0) + 3
        key = (ijk[:, 0] * self.dim[1] + ijk[:, 1]) * self.dim[2] + ijk[:, 2]
        self.order = np.argsort(key, kind='stable'); self.keys = key[self.order]

    _OFF = {r: np.stack(np.meshgrid(*(np.arange(-r, r + 1),) * 3, indexing='ij'), -1).reshape(-1, 3) for r in (1, 2, 4, 8)}

    def _near(self, q, want=96):
        c = np.floor((np.asarray(q) - self.lo) / self.h).astype(np.int64)
        for r in (1, 2, 4, 8):
            IJK = c + self._OFF[r]
            ok = np.all((IJK >= 0) & (IJK < self.dim), axis=1); IJK = IJK[ok]
            ks = (IJK[:, 0] * self.dim[1] + IJK[:, 1]) * self.dim[2] + IJK[:, 2]
            a = np.searchsorted(self.keys, ks, 'left'); b = np.searchsorted(self.keys, ks, 'right')
            idx = np.concatenate([self.order[x:y] for x, y in zip(a, b) if y > x]) if np.any(b > a) else np.array([], int)
            if len(idx) >= 24 or r == 8: return idx if len(idx) else np.arange(len(self.cen))
        return np.arange(len(self.cen))

    def project(self, q, smooth=2.0, ref=None):
        """Nearest point on the surface to q, and the smoothed surface direction there.
        ref: the side we're on (a direction). On thin parts the nearest point can be on the far side; only faces
        facing roughly the same way as ref are used, so letters never jump through to the other side."""
        cand = self._near(q)
        if ref is not None:
            same = cand[self.nrm[cand] @ np.asarray(ref, float) > 0.2]
            if len(same): cand = same
        d = ((self.cen[cand] - q) ** 2).sum(1)
        k = cand[np.argpartition(d, min(96, len(d) - 1))[:96]] if len(d) > 96 else cand
        pts = _closest_on_tris(q, self.tri[k, 0], self.tri[k, 1], self.tri[k, 2])
        j = int(np.argmin(((pts - q) ** 2).sum(1)))
        p = pts[j]; n0 = self.nrm[k[j]]
        nb = self._near(p, 8)
        near = nb[(((self.cen[nb] - p) ** 2).sum(1) < smooth * smooth) & (self.nrm[nb] @ n0 > 0.3)]   # never average with the far side
        w = self.area[near][:, None] * self.nrm[near]
        n = w.sum(0) if len(near) else n0
        if np.dot(n, n0) < 0.3: n = n0
        return p, n / (np.linalg.norm(n) or 1)

    def normal_at(self, p, n0, smooth=2.0):
        nb = self._near(p, 8)
        near = nb[(((self.cen[nb] - p) ** 2).sum(1) < smooth * smooth) & (self.nrm[nb] @ n0 > 0.3)]
        w = (self.area[near][:, None] * self.nrm[near]).sum(0) if len(near) else n0
        if np.dot(w, n0) < 0.3: w = n0
        return w / (np.linalg.norm(w) or 1)

    def ray(self, o, d, max_len=8.0):
        """The first surface hit by the ray o + t*d (0 < t < max_len): (point, face normal) or None."""
        d = np.asarray(d, float); d = d / (np.linalg.norm(d) or 1); o = np.asarray(o, float)
        cand = set()
        for s in np.arange(0, max_len + 1.5, 1.5):
            cand.update(self._near(o + d * min(s, max_len), 8)[:3000].tolist())
        if not cand: return None
        idx = np.fromiter(cand, int)
        T = self.tri[idx]; e1 = T[:, 1] - T[:, 0]; e2 = T[:, 2] - T[:, 0]
        h = np.cross(d, e2); a = (e1 * h).sum(1); ok = np.abs(a) > 1e-12
        f = np.zeros_like(a); f[ok] = 1.0 / a[ok]
        s_ = o - T[:, 0]; u = f * (s_ * h).sum(1)
        q = np.cross(s_, e1); v = f * (q * d).sum(1); t = f * (q * e2).sum(1)
        hit = ok & (u >= -1e-9) & (v >= -1e-9) & (u + v <= 1 + 1e-9) & (t > 1e-6) & (t < max_len)
        if not hit.any(): return None
        j = np.argmin(np.where(hit, t, np.inf))
        return o + d * t[j], self.nrm[idx[j]]

    def drop(self, q, n, reach=3.0):
        """The surface point under q seen from outside along n: a ray from above, so only the visible surface counts
        (never walls hidden inside the part, like where an inlay meets the case). Falls back to the nearest point."""
        n = np.asarray(n, float); n = n / (np.linalg.norm(n) or 1)
        r = self.ray(np.asarray(q, float) + n * reach, -n, 2 * reach)
        if r is not None and np.dot(r[1], n) > 0.05:
            return r[0], self.normal_at(r[0], r[1])
        return self.project(q, ref=n)

    def thickness(self, p, n, max_len=200.0):
        """How much solid is under p, straight in along -n. Touching bodies (an inlay sitting in its pocket) count as one."""
        d = -np.asarray(n, float); d /= np.linalg.norm(d) or 1
        o = np.asarray(p, float) - d * -0.02
        cand = set()
        for s in np.arange(0, max_len, 1.5):
            idx = self._near(o + d * s, 8)
            cand.update(idx[:4000].tolist())
            if s > 30 and len(cand) > 200000: break
        if not cand: return None
        idx = np.fromiter(cand, int)
        T = self.tri[idx]; e1 = T[:, 1] - T[:, 0]; e2 = T[:, 2] - T[:, 0]
        h = np.cross(d, e2); a = (e1 * h).sum(1); ok = np.abs(a) > 1e-12
        f = np.zeros_like(a); f[ok] = 1.0 / a[ok]
        s_ = o - T[:, 0]; u = f * (s_ * h).sum(1)
        q = np.cross(s_, e1); v = f * (q * d).sum(1); t = f * (q * e2).sum(1)
        hit = ok & (u >= -1e-9) & (v >= -1e-9) & (u + v <= 1 + 1e-9) & (t > 0.0)
        if not hit.any(): return None
        ts = t[hit]; leaving = (self.nrm[idx[hit]] @ d) > 0
        order = np.argsort(ts); ts, leaving = ts[order], leaving[order]
        entering = ts[~leaving]
        for i in range(len(ts)):
            if leaving[i]:
                if np.any(np.abs(entering - ts[i]) < 0.15): continue   # straight into another body that touches: still solid
                return float(ts[i] + 0.02)
        return float(ts[-1] + 0.02)


def walk(surface, point, normal, angle_deg, length, step=0.5):
    """Walk along the surface from `point` in the text's direction, both ways; returns arc -> (position, tangent, normal)."""
    M = frame(point, normal, angle_deg)
    t0, n0 = M[:3, 0], M[:3, 2]
    p0, n0s = surface.drop(np.asarray(point, float), n0)
    out = {0.0: (p0, t0 - n0s * np.dot(t0, n0s), n0s)}
    for sign in (1, -1):
        p, t, n = p0.copy(), t0.copy(), n0s.copy()
        s = 0.0
        while s < length:
            q = p + sign * t * step
            p2, n2 = surface.drop(q, n)
            mv = p2 - p
            if np.linalg.norm(mv) < 1e-6: break
            t = sign * mv; t -= n2 * np.dot(t, n2); t /= (np.linalg.norm(t) or 1)
            p, n = p2, n2; s += step
            out[sign * s] = (p.copy(), t.copy(), n.copy())
    return out


def add_text_wrapped(part, glyphs, point, normal, depth=1.0, mode='raise', slot=None, angle=0.0):
    """Like add_text, but every letter is laid on the surface where it falls, so the words follow the shape."""
    depth = max(0.2, float(depth))
    surf = Surface(part.mesh)
    span = max([abs(g['x']) for g in glyphs] + [1.0]) + 2.0
    path = walk(surf, point, normal, angle, span)
    keys = np.array(sorted(path))
    solid = split.to_mf(part.mesh, part.exts() if part.face_ext is not None else None)
    parts = []
    for g in glyphs:
        s = keys[int(np.argmin(np.abs(keys - g['x'])))]
        p, t, n = path[s]
        y = np.cross(n, t)
        M = np.eye(4); M[:3, 0], M[:3, 1], M[:3, 2], M[:3, 3] = t, y, n, p
        M = M[:3, :].astype(np.float64)
        if mode == 'raise':
            parts.append(text_solid(g['shapes'], depth, 0.0).transform(M))
            parts.append(text_solid(g['shapes'], 0.0, 3.0).transform(M) ^ solid)
        else:
            parts.append(text_solid(g['shapes'], 0.6, depth).transform(M))
    T = mf.Manifold.batch_boolean(parts, mf.OpType.Add)
    if mode == 'raise':
        slot = int(slot or part.ext)
        gm = T.to_mesh()
        T = mf.Manifold(mf.Mesh(vert_properties=np.array(gm.vert_properties[:, :3], np.float32, copy=True, order='C'),
                                tri_verts=np.array(gm.tri_verts, np.uint32, copy=True, order='C'),
                                face_id=np.full(len(gm.tri_verts), split.FID + slot, np.uint32)))
        out = solid + T
    else:
        out = solid - T
    if out.is_empty(): raise ValueError('The text missed the model. Click right on its surface.')
    return split.to_tm_ext(out, part.ext)


# ================================================================== text tool v2: real fonts, styles, line shapes, bending
import fonts as _fonts
import trimesh as _tm


def _cs(contours, grow=0.0):
    cont = [np.asarray(c, np.float64) for c in contours if len(c) >= 3]
    if not cont: return None
    cs = mf.CrossSection(cont, mf.FillRule.NonZero)
    if grow: cs = cs.offset(grow, mf.JoinType.Round)
    return None if cs.is_empty() else cs


def _extrude(cs, z0, z1):
    return mf.Manifold.extrude(cs, max(0.05, z1 - z0)).translate((0, 0, z0))


def _frame_from(p, t, n):
    n = np.asarray(n, float); n = n / (np.linalg.norm(n) or 1)
    t = np.asarray(t, float); t = t - n * np.dot(t, n); t = t / (np.linalg.norm(t) or 1)
    y = np.cross(n, t)
    M = np.eye(4); M[:3, 0], M[:3, 1], M[:3, 2], M[:3, 3] = t, y, n, p
    return M


def _bend(man, P_at, surf, cx, step=0.6):
    """Bend a letter (in its own coords: u along the line, v across, w up) onto the surface: every point goes to the surface
    spot u along / v across from the line, then w out along the surface there. Projections are done on a grid and interpolated."""
    m = man.to_mesh(); V = np.asarray(m.vert_properties[:, :3], float); F = np.asarray(m.tri_verts, int)
    tmesh = _tm.Trimesh(V, F, process=False)
    V2, F2 = _tm.remesh.subdivide_to_size(tmesh.vertices, tmesh.faces, max_edge=step)
    u0, u1 = V2[:, 0].min() - step, V2[:, 0].max() + step; v0, v1 = V2[:, 1].min() - step, V2[:, 1].max() + step
    us = np.arange(u0, u1 + step, step); vs = np.arange(v0, v1 + step, step)
    GP = np.zeros((len(us), len(vs), 3)); GN = np.zeros((len(us), len(vs), 3))
    for i, u in enumerate(us):
        p, t, n = P_at(cx + u)
        side = np.cross(n, t); side /= (np.linalg.norm(side) or 1)
        for j, v in enumerate(vs):
            q, qn = surf.drop(p + side * v, n)
            GP[i, j], GN[i, j] = q, qn
    fi = (V2[:, 0] - u0) / step; fj = (V2[:, 1] - v0) / step
    i0 = np.clip(np.floor(fi).astype(int), 0, len(us) - 2); j0 = np.clip(np.floor(fj).astype(int), 0, len(vs) - 2)
    a = (fi - i0)[:, None]; b = (fj - j0)[:, None]
    def bil(G):
        return (G[i0, j0] * (1 - a) * (1 - b) + G[i0 + 1, j0] * a * (1 - b) + G[i0, j0 + 1] * (1 - a) * b + G[i0 + 1, j0 + 1] * a * b)
    P = bil(GP); N = bil(GN); N /= np.linalg.norm(N, axis=1, keepdims=True) + 1e-12
    out = P + N * V2[:, 2:3]
    return mf.Manifold(mf.Mesh(vert_properties=np.array(out, np.float32, order='C'), tri_verts=np.array(F2, np.uint32, order='C')))


def text_solids(part_mesh, item, surf=None):
    """The solids for one text item, in plate coords: ('add'|'sub', manifold, keep_inside_part)."""
    it = dict(item)
    size = max(1.0, float(it.get('size', 10)))
    L = _fonts.layout(it.get('text', ''), it.get('font', 'Arial'), size, it.get('bold'), it.get('italic'), it.get('under'), float(it.get('spacing', 0)))
    grow = size * 0.035 if L.get('fake_bold') else 0.0
    style, path = it.get('style', 'raise'), it.get('path', 'straight')
    th, emb = max(0.2, float(it.get('th', 1.2))), max(0.0, float(it.get('emb', 0.4)))
    diag = float(np.linalg.norm(part_mesh.extents)) + 10
    z = {'raise': (0.0, th), 'flat': (-emb, th - emb), 'cut': (-th, 0.6), 'through': (-diag, 0.6)}[style]
    point, normal = np.asarray(it['point'], float), np.asarray(it['normal'], float)
    M0 = frame(point, normal, float(it.get('rot', 0)))
    xr, n0 = M0[:3, 0], M0[:3, 2]
    total = L['width'] or 1.0
    surf = surf or Surface(part_mesh)
    wrap = path == 'wrap'
    if wrap:
        wp = walk(surf, point, normal, float(it.get('rot', 0)), total / 2 + size * 2)
        keys = np.array(sorted(wp))
        def P_at(s):
            k = keys[int(np.argmin(np.abs(keys - s)))]; p, t, n = wp[k]; return p, t, n
    A = np.radians(float(it.get('arc', 90))); Rr = total / abs(A) if abs(A) > 1e-3 else 1e9
    pieces = [(g['x'], g['contours']) for g in L['glyphs']]
    if L.get('underline'):
        pieces.append((0.0, [L['underline']]))
    out = []
    for cx, contours in pieces:
        cs = _cs(contours, grow)
        if cs is None: continue
        letter = _extrude(cs, *z)
        if wrap:
            if style in ('flat', 'through'):        # flat tiles, and straight-through holes, stay flat at their spot on the surface
                p, t, n = P_at(cx); out.append(letter.transform(_frame_from(p, t, n)[:3, :]))
            else:
                out.append(_bend(letter.translate((0, 0, 0)), P_at, surf, cx))
            continue
        along, off, ang = cx, 0.0, 0.0
        if path == 'arc' and abs(A) > 1e-3:
            tt = cx / Rr; along = Rr * np.sin(tt); off = np.sign(A) * (Rr - Rr * np.cos(tt)); ang = np.sign(A) * tt
        if path == 'wave':
            H, Lw = float(it.get('waveH', 2)), max(1.0, float(it.get('waveL', 20)))
            off = H * np.sin(cx / Lw * 2 * np.pi); ang = np.arctan(H * 2 * np.pi / Lw * np.cos(cx / Lw * 2 * np.pi)) * 0.6
        R2 = np.eye(4); c, s = np.cos(ang), np.sin(ang); R2[:2, :2] = [[c, -s], [s, c]]; R2[:2, 3] = [along, off]
        out.append(letter.transform((M0 @ R2)[:3, :]))
    if not out: raise ValueError('There is no text to add.')
    return style, mf.Manifold.batch_boolean(out, mf.OpType.Add)


def apply_texts(base_mesh, base_exts, default_ext, items, base_mf=None, surf=None):
    """Rebuild a part: its mesh before any text, plus every text item in order. Returns (trimesh, filament per triangle).
    base_mf / surf: the part already converted / indexed (kept between edits, so each edit is quick)."""
    solid = base_mf if base_mf is not None else split.to_mf(base_mesh, base_exts)
    surf = surf or Surface(base_mesh)
    for it in items:
        style, T = text_solids(base_mesh, it, surf)
        if style in ('raise', 'flat'):
            if style == 'raise':
                below = T ^ solid                                        # the part of the letters inside the model (fills curved gaps)
                T = T + below
            slot = int(it.get('slot') or default_ext)
            gm = T.to_mesh()
            T = mf.Manifold(mf.Mesh(vert_properties=np.array(gm.vert_properties[:, :3], np.float32, order='C'),
                                    tri_verts=np.array(gm.tri_verts, np.uint32, order='C'),
                                    face_id=np.full(len(gm.tri_verts), split.FID + slot, np.uint32)))
            solid = solid + T
        else:
            solid = solid - T
    if solid.is_empty(): raise ValueError('Nothing is left of the part after that cut.')
    return split.to_tm_ext(solid, default_ext)


def _ray_hit(surf, o, d, max_len=80.0):
    """Distance along the ray o + t*d to the first triangle (t > 0.02), using only triangles near the ray."""
    cand = set()
    for s in np.arange(0, max_len, 1.5):
        q = o + d * s
        for i in surf._near(q, 8)[:4000]: cand.add(int(i))
    if not cand: return None
    idx = np.fromiter(cand, int)
    T = surf.tri[idx]; e1 = T[:, 1] - T[:, 0]; e2 = T[:, 2] - T[:, 0]
    h = np.cross(d, e2); a = (e1 * h).sum(1); ok = np.abs(a) > 1e-12
    f = np.zeros_like(a); f[ok] = 1.0 / a[ok]
    s_ = o - T[:, 0]; u = f * (s_ * h).sum(1)
    q = np.cross(s_, e1); v = f * (q * d).sum(1); t = f * (q * e2).sum(1)
    hit = ok & (u >= 0) & (v >= 0) & (u + v <= 1) & (t > 0.02)
    return float(t[hit].min()) if hit.any() else None


def preview_frames(part_mesh, item, surf=None):
    """Where each letter goes (for the live preview), and how thick the part is under the text (for Cut in).
    Returns layout + frames [(p, t, n)] per letter (and underline) in the part's coords."""
    it = dict(item); size = max(1.0, float(it.get('size', 10)))
    L = _fonts.layout(it.get('text', ''), it.get('font', 'Arial'), size, it.get('bold'), it.get('italic'), it.get('under'), float(it.get('spacing', 0)))
    surf = surf or Surface(part_mesh)
    point, normal = np.asarray(it['point'], float), np.asarray(it['normal'], float)
    M0 = frame(point, normal, float(it.get('rot', 0))); xr, yr, n0 = M0[:3, 0], M0[:3, 1], M0[:3, 2]
    total = L['width'] or 1.0; path = it.get('path', 'straight')
    A = np.radians(float(it.get('arc', 90))); Rr = total / abs(A) if abs(A) > 1e-3 else 1e9
    if path == 'wrap':
        wp = walk(surf, point, normal, float(it.get('rot', 0)), total / 2 + size * 2); keys = np.array(sorted(wp))
    xs = [g['x'] for g in L['glyphs']] + ([0.0] if L.get('underline') else [])
    frames, thick = [], np.inf
    for cx in xs:
        if path == 'wrap':
            k = keys[int(np.argmin(np.abs(keys - cx)))]; p, t, n = wp[k]
        else:
            along, off, ang = cx, 0.0, 0.0
            if path == 'arc' and abs(A) > 1e-3:
                tt = cx / Rr; along = Rr * np.sin(tt); off = np.sign(A) * (Rr - Rr * np.cos(tt)); ang = np.sign(A) * tt
            if path == 'wave':
                H, Lw = float(it.get('waveH', 2)), max(1.0, float(it.get('waveL', 20)))
                off = H * np.sin(cx / Lw * 2 * np.pi); ang = np.arctan(H * 2 * np.pi / Lw * np.cos(cx / Lw * 2 * np.pi)) * 0.6
            p = point + xr * along + yr * off; n = n0; t = xr * np.cos(ang) + yr * np.sin(ang)
        frames.append([np.round(p, 4).tolist(), np.round(t, 5).tolist(), np.round(n, 5).tolist()])
        if it.get('style') == 'cut':
            d = surf.thickness(np.asarray(p), np.asarray(n))
            if d is not None: thick = min(thick, d)
    L['frames'] = frames; L['thick'] = None if not np.isfinite(thick) else round(float(thick), 2)
    return L
