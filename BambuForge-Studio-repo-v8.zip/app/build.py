"""Turn the split plan into real parts, lay them out on plates, and write a Bambu Studio project."""
import io, json, math, os, uuid, zipfile
import numpy as np
import trimesh
import manifold3d as mf
import engine, split

HERE = os.path.dirname(os.path.abspath(__file__))
EXCL = (0.0, 0.0, 18.0, 28.0)       # no-print corner of the current printer (P1S/X1 cutter); set per printer
MARGIN, GAP = 8.0, 10.0


def _tr(x, y, z):
    m = np.eye(4); m[:3, 3] = [x, y, z]; return m


def _rx(deg):
    a = math.radians(deg); c, s = math.cos(a), math.sin(a)
    m = np.eye(4); m[1, 1], m[1, 2], m[2, 1], m[2, 2] = c, -s, s, c; return m


def apply_split(project, idx, cuts, kinds, clr=0.2, magnet='8x3', progress=None):
    """Replace part idx with its pieces plus the joint parts. Returns the cut notes."""
    part = project['parts'][idx]
    pieces, extras, notes = split.split_part(part.mesh, cuts, kinds, clr, magnet, progress, part.exts() if part.face_ext is not None else None)
    to_asm = part.A @ np.linalg.inv(part.P) if part.A is not None else None   # plate coords -> assembled
    new = []
    for i, (M, zl, zh) in enumerate(pieces):
        local, fe = split.to_tm_ext(M, part.ext)
        P = _tr(0, 0, -local.bounds[0][2])
        p = engine.Part(f"{part.name} {i + 1}/{len(pieces)}", local, P, part.plate, part.color, to_asm, ext=part.ext, face_ext=fe)
        p.role = 'piece'; p.scale = part.scale
        new.append(p)
    for name, M, flat in extras:
        local = split.to_tm(M)
        R = _rx(90) if flat else np.eye(4)                   # pins lie on their flat side
        m = local.copy(); m.apply_transform(R)
        P = _tr(0, 0, -m.bounds[0][2]) @ R
        p = engine.Part(name, local, P, part.plate, part.color, to_asm, ext=part.ext)
        p.role = 'joint'; p.scale = part.scale
        new.append(p)
    project['parts'][idx:idx + 1] = new
    project.setdefault('notes', []).append(dict(part=part.name, cuts=notes))
    return notes


def layout(project):
    """Pack every part onto as few P1S plates as possible (biggest first, never in the cutter corner)."""
    parts = project['parts']
    for p in parts:   # centre each part's footprint on the origin first
        lo, hi = p.mesh.bounds
        D = _tr(-(lo[0] + hi[0]) / 2, -(lo[1] + hi[1]) / 2, -lo[2])
        p.P = D @ p.P; p.mesh.apply_transform(D)
    order = sorted(range(len(parts)), key=lambda i: -(parts[i].mesh.extents[0] * parts[i].mesh.extents[1]))
    plates = []      # list of lists of rects (x0,y0,x1,y1)
    bw, bd = engine.BED
    colours = len({k for p in parts for k in p.slots_used()})
    ts = tower_size(colours, max_h=max([float(p.mesh.extents[2]) for p in parts] + [1.0]), cfg=project.get('tower_cfg'))
    project.pop('tower_pos', None)          # arranging puts the tower back in its automatic spot
    # keep the back-right corner free for the prime tower (it sits 10 mm in from the edges)
    reserve = [(bw - MARGIN - 10.0 - ts[0], bd - MARGIN - 10.0 - ts[1], bw, bd)] if ts else []
    for i in order:
        p = parts[i]
        placed = False
        for rot in (0, 90):
            w, d = (p.mesh.extents[0], p.mesh.extents[1]) if rot == 0 else (p.mesh.extents[1], p.mesh.extents[0])
            if w > bw - 2 * MARGIN + 1e-6 or d > bd - 2 * MARGIN + 1e-6:
                continue
            for pi, rects in enumerate(plates + [list(reserve)]):
                spot = _find(rects, w, d, bw, bd)
                if spot is None:
                    continue
                x, y = spot
                if pi == len(plates): plates.append(list(reserve))
                plates[pi].append((x, y, x + w, y + d))
                R = np.eye(4)
                if rot:
                    R[:2, :2] = [[0, -1], [1, 0]]
                T = _tr(x + w / 2, y + d / 2, 0) @ R
                p.P = T @ p.P; p.mesh.apply_transform(T)
                p.plate = pi + 1
                placed = True
                break
            if placed:
                break
        if not placed:
            p.plate = len(plates) + 1; plates.append([(0, 0, bw, bd)])   # too big: its own plate (fit check flags it)
    names = {}
    for pi in range(len(plates)):
        on = [p for p in parts if p.plate == pi + 1]
        roles = {getattr(p, 'role', 'piece') for p in on}
        names[pi + 1] = f"Plate {pi + 1}" + (" - joints" if roles == {'joint'} else "")
    project['plates'] = names


def _hit(a, b):
    return not (a[2] + GAP <= b[0] or b[2] + GAP <= a[0] or a[3] + GAP <= b[1] or b[3] + GAP <= a[1])


def _find(rects, w, d, bw, bd, step=4.0):
    excl = (EXCL[0] - GAP, EXCL[1] - GAP, EXCL[2], EXCL[3])
    y = MARGIN
    while y + d <= bd - MARGIN + 1e-6:
        x = MARGIN
        while x + w <= bw - MARGIN + 1e-6:
            r = (x, y, x + w, y + d)
            if (EXCL[2] - EXCL[0] < 1 or not _hit(r, excl)) and all(not _hit(r, o) for o in rects):
                return x, y
            x += step
        y += step
    return None


# ------------------------------------------------------------------ Bambu project writer
def _m34(M):
    return ' '.join('%.9g' % v for v in [M[0, 0], M[1, 0], M[2, 0], M[0, 1], M[1, 1], M[2, 1], M[0, 2], M[1, 2], M[2, 2], M[0, 3], M[1, 3], M[2, 3]])


def write_bambu_project(project, path):
    parts = project['parts']
    plates = sorted(project['plates'])
    NP = max(plates); cols = math.ceil(math.sqrt(NP)); sx, sy = engine.stride()
    files, objs = {}, []
    for k, p in enumerate(parts, 1):
        m = p.mesh
        c = (m.bounds[0] + m.bounds[1]) / 2
        local = np.asarray(m.vertices) - c
        mid, cid = 2 * k - 1, 2 * k
        fp = f'3D/Objects/object_{cid}.model'
        b = io.StringIO()
        b.write('<?xml version="1.0" encoding="UTF-8"?>\n<model unit="millimeter" xml:lang="en-US" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02" xmlns:BambuStudio="http://schemas.bambulab.com/package/2021" xmlns:p="http://schemas.microsoft.com/3dmanufacturing/production/2015/06" requiredextensions="p">\n <metadata name="BambuStudio:3mfVersion">1</metadata>\n <resources>\n')
        b.write(f'  <object id="{mid}" p:UUID="{uuid.uuid4()}" type="model">\n   <mesh>\n    <vertices>\n')
        b.write(''.join('     <vertex x="%.5f" y="%.5f" z="%.5f"/>\n' % tuple(v) for v in local))
        b.write('    </vertices>\n    <triangles>\n')
        fe = p.exts() if getattr(p, 'face_ext', None) is not None else None
        if fe is None:
            b.write(''.join('     <triangle v1="%d" v2="%d" v3="%d"/>\n' % tuple(f) for f in m.faces))
        else:   # painted triangles: Bambu's own paint code for the filament slot
            b.write(''.join(('     <triangle v1="%d" v2="%d" v3="%d"/>\n' % tuple(f)) if e == p.ext else
                            ('     <triangle v1="%d" v2="%d" v3="%d" paint_color="%s"/>\n' % (f[0], f[1], f[2], paint_code(int(e))))
                            for f, e in zip(m.faces, fe)))
        b.write('    </triangles>\n   </mesh>\n  </object>\n </resources>\n <build/>\n</model>\n')
        files[fp] = b.getvalue()
        i = p.plate - 1
        item = _tr(c[0] + (i % cols) * sx, c[1] - (i // cols) * sy, c[2])
        A = None
        if p.A is not None:
            A = p.A @ np.linalg.inv(p.P) @ _tr(*c)
        objs.append(dict(name=p.name, mid=mid, cid=cid, fp=fp, item=item, A=A, plate=p.plate, nf=len(m.faces), role=getattr(p, 'role', 'piece'), ext=getattr(p, 'ext', 1)))
    main = ['<?xml version="1.0" encoding="UTF-8"?>', '<model unit="millimeter" xml:lang="en-US" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02" xmlns:BambuStudio="http://schemas.bambulab.com/package/2021" xmlns:p="http://schemas.microsoft.com/3dmanufacturing/production/2015/06" requiredextensions="p">',
            ' <metadata name="Application">BambuStudio-02.03.01.51</metadata>', ' <metadata name="BambuStudio:3mfVersion">1</metadata>',
            f' <metadata name="Title">{_x(project["title"])} - made with BambuForge Studio</metadata>', ' <resources>']
    for o in objs:
        main.append(f'  <object id="{o["cid"]}" p:UUID="{uuid.uuid4()}" type="model">\n   <components>\n    <component p:path="/{o["fp"]}" objectid="{o["mid"]}" p:UUID="{uuid.uuid4()}" transform="1 0 0 0 1 0 0 0 1 0 0 0"/>\n   </components>\n  </object>')
    main.append(' </resources>\n <build p:UUID="%s">' % uuid.uuid4())
    for o in objs:
        main.append(f'  <item objectid="{o["cid"]}" p:UUID="{uuid.uuid4()}" transform="{_m34(o["item"])}" printable="1"/>')
    main.append(' </build>\n</model>\n')
    files['3D/3dmodel.model'] = '\n'.join(main)
    ms = ['<?xml version="1.0" encoding="UTF-8"?>', '<config>']
    for o in objs:
        ms.append(f'  <object id="{o["cid"]}">\n    <metadata key="name" value="{_x(o["name"])}"/>\n    <metadata key="extruder" value="{o["ext"]}"/>')
        if o['role'] == 'joint':
            ms.append('    <metadata key="wall_loops" value="6"/>\n    <metadata key="sparse_infill_density" value="100%"/>')
        ms.append(f'    <part id="{o["mid"]}" subtype="normal_part">\n      <metadata key="name" value="{_x(o["name"])}"/>\n      <metadata key="matrix" value="1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1"/>\n      <metadata key="extruder" value="{o["ext"]}"/>\n      <mesh_stat face_count="{o["nf"]}" edges_fixed="0" degenerate_facets="0" facets_removed="0" facets_reversed="0" backwards_edges="0"/>\n    </part>\n  </object>')
    ident = 1000
    for pl in range(1, NP + 1):
        ms.append(f'  <plate>\n    <metadata key="plater_id" value="{pl}"/>\n    <metadata key="plater_name" value="{_x(project["plates"].get(pl, ""))}"/>\n    <metadata key="locked" value="false"/>')
        for o in objs:
            if o['plate'] == pl:
                ident += 1
                ms.append(f'    <model_instance>\n      <metadata key="object_id" value="{o["cid"]}"/>\n      <metadata key="instance_id" value="0"/>\n      <metadata key="identify_id" value="{ident}"/>\n    </model_instance>')
        ms.append('  </plate>')
    if all(o['A'] is not None for o in objs):
        ms.append('  <assemble>')
        for o in objs:
            ms.append(f'   <assemble_item object_id="{o["cid"]}" instance_id="0" transform="{_m34(o["A"])}" offset="0 0 0" />')
        ms.append('  </assemble>')
    ms.append('</config>\n')
    files['Metadata/model_settings.config'] = '\n'.join(ms)
    with open(os.path.join(HERE, 'bambu_template.json'), encoding='utf-8') as f:
        files['Metadata/project_settings.config'] = f.read()
    files['[Content_Types].xml'] = '<?xml version="1.0" encoding="UTF-8"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">\n <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>\n <Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/>\n <Default Extension="png" ContentType="image/png"/>\n</Types>\n'
    files['_rels/.rels'] = '<?xml version="1.0" encoding="UTF-8"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n <Relationship Target="/3D/3dmodel.model" Id="rel-1" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/>\n</Relationships>\n'
    files['3D/_rels/3dmodel.model.rels'] = '<?xml version="1.0" encoding="UTF-8"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n' + ''.join(f' <Relationship Target="/{o["fp"]}" Id="rel-{i + 1}" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/>\n' for i, o in enumerate(objs)) + '</Relationships>\n'
    tmp = path + '.tmp'
    with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as z:
        for name in ['[Content_Types].xml', '_rels/.rels', '3D/3dmodel.model', '3D/_rels/3dmodel.model.rels'] + [o['fp'] for o in objs] + ['Metadata/model_settings.config', 'Metadata/project_settings.config']:
            z.writestr(name, files[name])
    os.replace(tmp, path)


def paint_code(slot):
    """Bambu's code for a whole triangle painted with filament `slot` (1-based)."""
    return '%X' % (slot << 2) if slot < 3 else '%XC' % (slot - 3)


def _x(s):
    return str(s).replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;')


# ------------------------------------------------------------------ print orientation
def _rot(axis, deg):
    a = math.radians(deg); c, s = math.cos(a), math.sin(a)
    m = np.eye(4)
    if axis == 'x': m[1, 1], m[1, 2], m[2, 1], m[2, 2] = c, -s, s, c
    else: m[0, 0], m[0, 2], m[2, 0], m[2, 2] = c, s, -s, c
    return m


def _score(v, f):
    a, b, c = v[f[:, 0]], v[f[:, 1]], v[f[:, 2]]
    n = np.cross(b - a, c - a); ln = np.linalg.norm(n, axis=1); ok = ln > 1e-12
    n, ln, a, b, c = n[ok], ln[ok], a[ok], b[ok], c[ok]
    area = ln / 2; nz = n[:, 2] / ln
    zmin = v[:, 2].min(); ztop = np.maximum(np.maximum(a[:, 2], b[:, 2]), c[:, 2])
    on_bed = (nz < -0.99) & (ztop < zmin + 0.05)
    overhang = area[(nz < -0.866) & ~on_bed & (ztop > zmin + 0.3)].sum()
    return float(overhang), float(area[on_bed].sum())


def orient_options(part):
    """Candidate print orientations with how much support each needs and how much sits on the bed."""
    cands = {'As it is': np.eye(4), 'Upside down': _rot('x', 180), 'On its side (front)': _rot('x', 90),
             'On its side (back)': _rot('x', -90), 'On its side (left)': _rot('y', 90), 'On its side (right)': _rot('y', -90)}
    # largest flat face straight down
    m = part.mesh
    fn, fa = m.face_normals, m.area_faces
    key = np.round(fn, 2)
    uniq, inv = np.unique(key, axis=0, return_inverse=True)
    sums = np.bincount(inv.ravel(), weights=fa)
    nbest = uniq[np.argmax(sums)]
    nbest = nbest / (np.linalg.norm(nbest) or 1)
    if abs(nbest[2] + 1) > 1e-3:
        R = np.eye(4); R[:3, :3] = trimesh.geometry.align_vectors(nbest, [0, 0, -1])[:3, :3]
        cands['Biggest flat face down'] = R
    v, f = np.asarray(m.vertices), np.asarray(m.faces)
    if len(f) > 120000:
        idx = np.linspace(0, len(f) - 1, 120000).astype(int); f = f[idx]
    out = []
    for name, R in cands.items():
        vr = v @ R[:3, :3].T
        ext = vr.max(0) - vr.min(0)
        fits = ext[2] <= engine.MAX_H and min(ext[0], ext[1]) <= engine.BED[0] - 2 * MARGIN and max(ext[0], ext[1]) <= engine.BED[1] - 2 * MARGIN
        oh, bed = _score(vr, f)
        out.append(dict(name=name, R=R, fits=fits, overhang=oh, bed=bed, height=float(ext[2])))
    return out


def orient(part, mode='auto'):
    opts = orient_options(part)
    if mode == 'auto':
        ok = [o for o in opts if o['fits']] or opts
        best = min(ok, key=lambda o: (o['overhang'] - 0.3 * o['bed'], o['height']))
    else:
        best = next((o for o in opts if o['name'] == mode), opts[0])
    lo, hi = part.mesh.bounds
    cxy = np.array([(lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2])
    m = part.mesh.copy(); m.apply_transform(best['R'])
    nlo, nhi = m.bounds
    D = _tr(cxy[0] - (nlo[0] + nhi[0]) / 2, cxy[1] - (nlo[1] + nhi[1]) / 2, -nlo[2])
    T = D @ best['R']
    part.P = T @ part.P; part.mesh.apply_transform(T)
    return best


def move_part(part, dx, dy, plate=None, dz=0.0):
    T = _tr(dx, dy, dz)
    part.P = T @ part.P; part.mesh.apply_transform(T)
    if plate: part.plate = int(plate)
    lo, hi = part.mesh.bounds
    return bool(lo[0] >= -0.5 and lo[1] >= -0.5 and hi[0] <= engine.BED[0] + 0.5 and hi[1] <= engine.BED[1] + 0.5)



# ------------------------------------------------------------------ turning, laying flat, dropping to the plate
def rotate_part(part, axis, deg, keep_lift=True):
    """Turn a part about its own centre; it stays on the plate (or at the height it was lifted to)."""
    lo, hi = part.mesh.bounds
    lift = max(0.0, float(lo[2])) if keep_lift else 0.0
    c = (lo + hi) / 2
    ax = {'x': [1, 0, 0], 'y': [0, 1, 0], 'z': [0, 0, 1]}[axis]
    R = trimesh.transformations.rotation_matrix(math.radians(float(deg)), ax, c)
    m = part.mesh.copy(); m.apply_transform(R)
    nlo = m.bounds[0]
    T = _tr(0, 0, lift - nlo[2]) @ R
    part.P = T @ part.P; part.mesh.apply_transform(T)


def lay_flat(part, point):
    """Rest the part on the face you clicked: that face goes face-down on the plate."""
    m = part.mesh
    i = int(np.argmin(((m.triangles_center - np.asarray(point, float)) ** 2).sum(1)))
    n = m.face_normals[i]
    # use the whole flat area the face belongs to, so a slightly bumpy face still lies properly
    R = np.eye(4); R[:3, :3] = trimesh.geometry.align_vectors(n, [0, 0, -1])[:3, :3]
    lo, hi = m.bounds; c = (lo + hi) / 2
    T0 = _tr(*c) @ R @ _tr(*(-c))
    mm = m.copy(); mm.apply_transform(T0)
    T = _tr(0, 0, -mm.bounds[0][2]) @ T0
    part.P = T @ part.P; part.mesh.apply_transform(T)
    return float(np.degrees(np.arccos(np.clip(-n[2], -1, 1))))


def drop_to_plate(part):
    dz = -float(part.mesh.bounds[0][2])
    T = _tr(0, 0, dz)
    part.P = T @ part.P; part.mesh.apply_transform(T)
    return dz



def rotate_matrix(part, R3, keep_lift=True):
    """Turn a part by any rotation (3x3) about its own centre, then sit it back at the same height."""
    lo, hi = part.mesh.bounds
    lift = max(0.0, float(lo[2])) if keep_lift else 0.0
    c = (lo + hi) / 2
    R = np.eye(4); R[:3, :3] = np.asarray(R3, float)
    T0 = _tr(*c) @ R @ _tr(*(-c))
    m = part.mesh.copy(); m.apply_transform(T0)
    T = _tr(0, 0, lift - m.bounds[0][2]) @ T0
    part.P = T @ part.P; part.mesh.apply_transform(T)


def euler_R(x, y, z):
    return trimesh.transformations.euler_matrix(math.radians(x), math.radians(y), math.radians(z), 'sxyz')[:3, :3]


def set_absolute(part, x, y, z):
    """Make the part face the given X/Y/Z angles, measured from how it sat when the file was opened."""
    cur = part.P[:3, :3] @ np.linalg.inv(part.R0)
    cur = cur / np.cbrt(max(1e-12, abs(np.linalg.det(cur))))
    rotate_matrix(part, euler_R(x, y, z) @ cur.T)



def euler_of(part):
    """The part's turn on the plate as X, Y, Z degrees (applied X then Y then Z, like Bambu Studio)."""
    Rm = part.P[:3, :3]
    sy = math.hypot(Rm[0, 0], Rm[1, 0])
    if sy > 1e-6:
        x, y, z = math.atan2(Rm[2, 1], Rm[2, 2]), math.atan2(-Rm[2, 0], sy), math.atan2(Rm[1, 0], Rm[0, 0])
    else:
        x, y, z = math.atan2(-Rm[1, 2], Rm[1, 1]), math.atan2(-Rm[2, 0], sy), 0.0
    out = []
    for v in (x, y, z):
        d = round(math.degrees(v) % 360.0, 2)
        out.append(0.0 if d >= 359.995 else d)
    return out


def _euler_matrix(xd, yd, zd):
    x, y, z = (math.radians(float(v)) for v in (xd, yd, zd))
    Rx = trimesh.transformations.rotation_matrix(x, [1, 0, 0])
    Ry = trimesh.transformations.rotation_matrix(y, [0, 1, 0])
    Rz = trimesh.transformations.rotation_matrix(z, [0, 0, 1])
    return Rz @ Ry @ Rx


def turn_by_matrix(part, R, keep_lift=True):
    """Apply rotation R (4x4) about the part's centre; it stays on the plate (or at its lifted height)."""
    lo, hi = part.mesh.bounds
    lift = max(0.0, float(lo[2])) if keep_lift else 0.0
    c = (lo + hi) / 2
    T0 = _tr(*c) @ R @ _tr(*(-c))
    m = part.mesh.copy(); m.apply_transform(T0)
    T = _tr(0, 0, lift - m.bounds[0][2]) @ T0
    part.P = T @ part.P; part.mesh.apply_transform(T)


def set_rotation(part, xd, yd, zd):
    cur = np.eye(4); cur[:3, :3] = part.P[:3, :3]
    turn_by_matrix(part, _euler_matrix(xd, yd, zd) @ np.linalg.inv(cur))


def duplicate(project, idx, n):
    import copy as _copy
    src = project['parts'][idx]
    made = []
    for i in range(int(n)):
        q = _copy.deepcopy(src)
        q.name = f"{src.name} copy {i + 1}" if n > 1 else f"{src.name} copy"
        project['parts'].append(q); made.append(q)
    return made


def align(parts, how, bed=None):
    """Line up the parts of one plate: left edges, centred front-to-back, or spaced evenly across the plate."""
    bw, bd = bed or engine.BED
    if not parts: return
    if how == 'left':
        x0 = min(p.mesh.bounds[0][0] for p in parts)
        for p in parts: move_part(p, x0 - p.mesh.bounds[0][0], 0)
    elif how == 'centre':
        for p in parts:
            lo, hi = p.mesh.bounds; move_part(p, 0, bd / 2 - (lo[1] + hi[1]) / 2)
    elif how == 'space':
        ps = sorted(parts, key=lambda p: p.mesh.bounds[0][0])
        widths = [p.mesh.extents[0] for p in ps]
        if sum(widths) + 2.0 * (len(ps) + 1) > bw - 2 * MARGIN:
            raise ValueError("There isn't room to space these parts out side by side. Try Auto-orient + arrange instead.")
        gap = (bw - 2 * MARGIN - sum(widths)) / (len(ps) + 1)
        x = MARGIN + gap
        for p, w in zip(ps, widths):
            move_part(p, x - p.mesh.bounds[0][0], 0); x += w + gap


def overhang_area(part, angle=45.0):
    """mm² of downward-facing surface steeper than `angle` that isn't sitting on the plate (what needs support)."""
    m = part.mesh
    n, a = m.face_normals, m.area_faces
    z = m.triangles_center[:, 2]
    lim = -math.cos(math.radians(90 - angle))
    return float(a[(n[:, 2] < lim) & (z > m.bounds[0][2] + 0.4)].sum())



def place_new(project, new, keep):
    """Find room for new parts on the existing plates (then new plates) without touching parts already placed."""
    plates = {}
    for p in keep:
        lo, hi = p.mesh.bounds
        plates.setdefault(p.plate, []).append((lo[0], lo[1], hi[0], hi[1]))
    bw, bd = engine.BED
    for p in new:
        lo, hi = p.mesh.bounds
        D = _tr(-(lo[0] + hi[0]) / 2, -(lo[1] + hi[1]) / 2, -lo[2]); p.P = D @ p.P; p.mesh.apply_transform(D)
        w, d = p.mesh.extents[0], p.mesh.extents[1]
        placed = False
        for pl in sorted(plates) + [max(list(plates) + [0]) + 1]:
            spot = _find(plates.get(pl, []), w, d, bw, bd)
            if spot is None: continue
            x, y = spot
            T = _tr(x + w / 2, y + d / 2, 0); p.P = T @ p.P; p.mesh.apply_transform(T)
            p.plate = pl; plates.setdefault(pl, []).append((x, y, x + w, y + d)); placed = True
            break
        if not placed:
            pl = max(plates) + 1; T = _tr(bw / 2, bd / 2, 0); p.P = T @ p.P; p.mesh.apply_transform(T); p.plate = pl; plates[pl] = [(0, 0, bw, bd)]
    for pl in plates:
        project['plates'].setdefault(pl, f'Plate {pl}')


# ------------------------------------------------------------------ plate checks: inside the plate, not overlapping, room for the prime tower
TOWER_W, TOWER_BRIM, PRIME_VOL, RIB_W = 35.0, 3.0, 45.0, 8.0


MIN_DEPTH_BY_HEIGHT = [(5.0, 5.0), (100.0, 20.0), (250.0, 40.0), (350.0, 60.0)]   # Bambu Studio's WipeTower table


def _min_depth(h):
    t = MIN_DEPTH_BY_HEIGHT
    if h <= t[0][0]: return t[0][1]
    for (h0, d0), (h1, d1) in zip(t, t[1:]):
        if h < h1: return d0 + (h - h0) / (h1 - h0) * (d1 - d0)
    return t[-1][1]


def bambu_tower(colours, layer_h=0.2, max_h=50.0, prime_vol=45.0, gap=1.5, rib=8.0, extra_rib=0.0):
    """The prime tower size, worked out exactly the way Bambu Studio 2.x does (PartPlate::estimate_wipe_tower_size,
    rib-wall tower): it's a square, `side` mm each way."""
    if colours < 2: return None
    volume = prime_vol * (colours - 1)
    depth = math.sqrt(volume / max(0.04, float(layer_h)) * gap)
    volume_depth = depth
    depth = max(_min_depth(max_h), depth)
    rib = min(rib, depth / 2)
    return rib / math.sqrt(2) + max(depth + extra_rib, volume_depth)


def tower_size(colours, layer_h=0.2, extra=0.0, max_h=50.0, cfg=None):
    """How much plate the tower needs: (footprint width, footprint depth, pad, side). pad = brim plus a safety gap
    (Bambu's upload slicer is more cautious than its window, so we leave extra room)."""
    cfg = cfg or {}
    if colours < 2 or cfg.get('enabled') is False: return None
    width, brim, rib = float(cfg.get('width', TOWER_W)), float(cfg.get('brim', TOWER_BRIM)), cfg.get('rib', True)
    if rib:
        # Measured from a real Bambu Studio 2.9 print (0.12 mm, 2 colours): the formula says 29.4 mm, the printed tower with
        # its rib walls came out about 43-44 mm square, starting ~4 mm before its x/y. So allow 1.5x the formula.
        side = bambu_tower(colours, layer_h, max_h) * 1.5
        w = d = side
    else:
        d = max(_min_depth(max_h), PRIME_VOL * (colours - 1) / (max(0.04, float(layer_h)) * width) * 1.5) * 1.3
        w = width
    pad = brim + 4.0 + float(extra)
    return w + 2 * pad, d + 2 * pad, pad, (w, d)


def _hull(pts):
    pts = sorted(set(map(tuple, np.round(pts, 2))))
    if len(pts) < 3: return np.array(pts)
    def cross(o, a, b): return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lo, up = [], []
    for p in pts:
        while len(lo) >= 2 and cross(lo[-2], lo[-1], p) <= 0: lo.pop()
        lo.append(p)
    for p in reversed(pts):
        while len(up) >= 2 and cross(up[-2], up[-1], p) <= 0: up.pop()
        up.append(p)
    return np.array(lo[:-1] + up[:-1])


def _inside(poly, X, Y):
    """Points (X, Y) inside the convex polygon poly (counter-clockwise)."""
    ok = np.ones(X.shape, bool)
    for i in range(len(poly)):
        (x0, y0), (x1, y1) = poly[i], poly[(i + 1) % len(poly)]
        ok &= (x1 - x0) * (Y - y0) - (y1 - y0) * (X - x0) >= -1e-9
    return ok


def _footprint(p):
    v = p.mesh.vertices
    if len(v) > 20000: v = v[np.random.default_rng(0).choice(len(v), 20000, replace=False)]
    return _hull(v[:, :2])


def overlap_area(a, b, cell=1.0):
    """Roughly how many mm² two parts' footprints share (0 = they don't touch)."""
    (ax0, ay0, _), (ax1, ay1, _) = a.mesh.bounds; (bx0, by0, _), (bx1, by1, _) = b.mesh.bounds
    x0, y0, x1, y1 = max(ax0, bx0), max(ay0, by0), min(ax1, bx1), min(ay1, by1)
    if x1 - x0 < 0.5 or y1 - y0 < 0.5: return 0.0
    ha, hb = _footprint(a), _footprint(b)
    if len(ha) < 3 or len(hb) < 3: return 0.0
    X, Y = np.meshgrid(np.arange(x0 + cell / 2, x1, cell), np.arange(y0 + cell / 2, y1, cell))
    return float((_inside(ha, X, Y) & _inside(hb, X, Y)).sum() * cell * cell)


def _free_spot(rects, w, d, bw, bd, step=4.0, inset=0.0):
    """Somewhere w x d is free, trying the back-right corner first (where Bambu puts the tower), kept `inset` mm in from the edges."""
    excl = (EXCL[0] - GAP, EXCL[1] - GAP, EXCL[2], EXCL[3])
    m = MARGIN + inset
    y = bd - m - d
    while y >= m - 1e-6:
        x = bw - m - w
        while x >= m - 1e-6:
            r = (x, y, x + w, y + d)
            if (EXCL[2] - EXCL[0] < 1 or not _hit(r, excl)) and all(not _hit(r, o) for o in rects):
                return x, y
            x -= step
        y -= step
    return None


def _rect_hits(r, rects, gap):
    return any(not (r[2] + gap <= o[0] or o[2] + gap <= r[0] or r[3] + gap <= o[1] or o[3] + gap <= r[1]) for o in rects)


def plate_check(project, layer_h=0.2, extra=0.0):
    """For every plate: parts past the edge, parts overlapping, and where the prime tower goes (or that there's no room)."""
    bw, bd = engine.BED
    out = {}
    for pl in sorted(project['plates']):
        on = [p for p in project['parts'] if p.plate == pl]
        outside = [p.name for p in on if p.mesh.bounds[0][0] < -0.5 or p.mesh.bounds[0][1] < -0.5 or p.mesh.bounds[1][0] > bw + 0.5 or p.mesh.bounds[1][1] > bd + 0.5]
        over = []
        for i in range(len(on)):
            for j in range(i + 1, len(on)):
                a = overlap_area(on[i], on[j])
                if a >= 2.0: over.append((on[i].name, on[j].name, int(round(a))))
        colours = len({k for p in on for k in p.slots_used()})
        h = float(max([float(p.mesh.bounds[1][2]) for p in on] + [1.0]))
        cfg = project.get('tower_cfg') or {}
        size = tower_size(colours, layer_h, extra, h, cfg)
        tower, room = None, True
        if size:
            fw, fd, pad, (tw, td) = size
            rects = [(p.mesh.bounds[0][0], p.mesh.bounds[0][1], p.mesh.bounds[1][0], p.mesh.bounds[1][1]) for p in on]
            man = (project.get('tower_pos') or {}).get(pl)
            if man:                               # you placed it yourself: keep it there, and say if it's a problem
                x, y = float(man[0]), float(man[1])
                foot = (x - pad, y - pad, x + tw + pad, y + td + pad)
                prob = None
                if foot[0] < 0 or foot[1] < 0 or foot[2] > bw or foot[3] > bd:
                    prob = f"the printed tower would reach past the plate edge (it covers {foot[0]:.0f}-{foot[2]:.0f} x {foot[1]:.0f}-{foot[3]:.0f} mm, plate is {bw:.0f})"
                elif _rect_hits(foot, rects, 2.0):
                    prob = "it is touching a part; move it at least 5 mm away"
                tower = {'x': round(x, 2), 'y': round(y, 2), 'manual': True, 'problem': prob}
            else:
                spot = _free_spot(rects, fw, fd, bw, bd, inset=10.0 + float(extra))
                if spot: tower = {'x': round(float(spot[0]) + pad, 2), 'y': round(float(spot[1]) + pad, 2), 'manual': False, 'problem': None}
                else: room = False
            if tower: tower.update({'w': round(float(tw), 1), 'd': round(float(td), 1), 'h': round(h, 1), 'brim': float(cfg.get('brim', TOWER_BRIM)), 'pad': round(float(pad), 1),
                                    'rib': cfg.get('rib', True), 'foot': [round(float(tower['x'] - pad), 1), round(float(tower['y'] - pad), 1), round(float(tower['x'] + tw + pad), 1), round(float(tower['y'] + td + pad), 1)]})
        out[pl] = {'outside': outside, 'overlap': over, 'tower': tower, 'tower_room': room, 'colours': colours}
    return out


def tower_positions(project, checks=None, extra=0.0):
    """wipe_tower_x / wipe_tower_y for the project settings: one entry per plate, in plate order."""
    checks = checks or plate_check(project, extra=extra)
    xs, ys = [], []
    for pl in sorted(project['plates']):
        t = (checks.get(pl) or {}).get('tower')
        xs.append('%.3f' % (t['x'] if t else 165.0)); ys.append('%.3f' % (t['y'] if t else 219.984))
    return xs, ys
