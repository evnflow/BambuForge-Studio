"""Everything that talks to Bambu Studio: its profiles, user presets, cloud-sync files,
command-line slicing and the program itself. Ported from BambuForge (tested there)."""
import json, math, os, re, shutil, subprocess, sys, time, zipfile
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OPT = json.load(open(os.path.join(HERE, 'bambu_options.json'), encoding='utf-8'))
META = {"name", "inherits", "from", "setting_id", "instantiation", "type", "description", "compatible_printers",
        "compatible_printers_condition", "version", "filament_id"}
IS_WIN = sys.platform == 'win32'


# ------------------------------------------------------------------ options
def opt(key):
    return OPT.get(key)

def _num(v):
    try:
        f = float(v)
        return f if math.isfinite(f) else None
    except (TypeError, ValueError):
        return None

def _fmt(x):
    return ('%.12f' % x).rstrip('0').rstrip('.')

def normalize(key, raw):
    """(value exactly as Bambu writes it, error)"""
    d = OPT.get(key)
    v = str(raw if raw is not None else '').strip()
    if d is None: return None, f"Bambu Studio has no setting called '{key}'"
    if not d.get('process'): return None, "Not a print (process) setting; it belongs to the printer or filament"
    t = d['type']
    base = {'coPercents': 'coPercent', 'coFloatsOrPercents': 'coFloatOrPercent'}.get(t, t[:-1] if t.endswith('s') else t)
    def rng(x):
        if 'min' in d and x < d['min']: return f"Lowest allowed is {_fmt(d['min'])}"
        if 'max' in d and x > d['max']: return f"Highest allowed is {_fmt(d['max'])}"
    if base == 'coBool':
        lv = v.lower()
        if lv in ('1', 'true', 'yes', 'on', 'enabled'): return '1', None
        if lv in ('0', 'false', 'no', 'off', 'disabled'): return '0', None
        return None, 'Must be on or off'
    if base == 'coInt':
        if not re.fullmatch(r'-?\d+', v): return None, 'Must be a whole number'
        e = rng(int(v)); return (None, e) if e else (str(int(v)), None)
    if base == 'coFloat':
        x = _num(v)
        if x is None: return None, 'Must be a number'
        e = rng(x); return (None, e) if e else (_fmt(x), None)
    if base == 'coPercent':
        x = _num(v[:-1].strip() if v.endswith('%') else v)
        if x is None: return None, 'Must be a percentage, e.g. 15%'
        e = rng(x); return (None, e) if e else (_fmt(x) + '%', None)
    if base == 'coFloatOrPercent':
        if v.endswith('%'):
            x = _num(v[:-1].strip()); return (_fmt(x) + '%', None) if x is not None else (None, 'Must be a number or a percentage')
        x = _num(v); return (_fmt(x), None) if x is not None else (None, 'Must be a number or a percentage')
    if base == 'coEnum':
        ev, el = d.get('enum_values', []), d.get('enum_labels', [])
        for x in ev:
            if x.lower() == v.lower(): return x, None
        for i, lab in enumerate(el):
            if i < len(ev) and lab.lower() == v.lower(): return ev[i], None
        return None, 'Must be one of: ' + ', '.join(ev)
    if base == 'coString': return v, None
    return None, f"This kind of setting ({t}) can't be edited here"

def friendly(key, value):
    d = OPT.get(key)
    if d is None or value is None: return value
    if d['type'] in ('coBool', 'coBools'): return {'1': 'On', '0': 'Off'}.get(value, value)
    if d['type'] == 'coEnum':
        ev, el = d.get('enum_values', []), d.get('enum_labels', [])
        if value in ev and ev.index(value) < len(el): return el[ev.index(value)]
    return value

def label(key):
    d = OPT.get(key) or {}
    lab = d.get('label') or key
    if d.get('full_label') and len(lab.split()) == 1: lab = d['full_label']
    if d.get('category') == 'Speed' and 'speed' not in lab.lower(): lab += ' speed'
    return lab


# ------------------------------------------------------------------ Bambu Studio on this PC
class Env:
    def __init__(self):
        appdata = os.environ.get('APPDATA') or os.path.expanduser('~/.config')
        self.data = os.environ.get('BFS_BAMBU_DATA') or os.path.join(appdata, 'BambuStudio')
        # Slicing uses the engine built into BambuForge (Bambu's own slicer, see engine/). An installed Bambu Studio is only
        # needed for "open in Bambu Studio", and is the fallback if the built-in engine is missing.
        self.desktop_exe = self._find_exe()
        self.engine = self._find_engine()
        self.exe = self.engine or self.desktop_exe
        self.preset_folder = self.selected_printer = None
        conf = os.path.join(self.data, 'BambuStudio.conf')
        if os.path.exists(conf):
            c = open(conf, encoding='utf-8', errors='replace').read()
            m = re.search(r'"preset_folder"\s*:\s*"([^"]*)"', c); self.preset_folder = m.group(1) if m else None
            m = re.search(r'"machine"\s*:\s*"([^"]*)"', c); self.selected_printer = m.group(1) if m else None
        self.system_dir = None
        cands = [os.path.join(self.data, 'system', 'BBL', 'process')]
        if self.exe: cands.append(os.path.join(os.path.dirname(self.exe), 'resources', 'profiles', 'BBL', 'process'))
        for c in cands:
            if os.path.isdir(c) and len([f for f in os.listdir(c) if f.endswith('.json')]) > 20:
                self.system_dir = c; break
        self.system = {}
        self.vendor_version = None
        if self.system_dir:
            for f in os.listdir(self.system_dir):
                if not f.endswith('.json'): continue
                try:
                    j = json.load(open(os.path.join(self.system_dir, f), encoding='utf-8'))
                    if j.get('name'): self.system[j['name']] = j
                except Exception:
                    pass
            bbl = os.path.join(os.path.dirname(os.path.dirname(self.system_dir)), 'BBL.json')
            try: self.vendor_version = json.load(open(bbl, encoding='utf-8')).get('version')
            except Exception: pass
        self.folders = []
        ur = os.path.join(self.data, 'user')
        if os.path.isdir(ur):
            for d in os.listdir(ur):
                pd = os.path.join(ur, d, 'process')
                self.folders.append({'id': d, 'dir': pd, 'signed_in': d == self.preset_folder,
                                     'label': 'Local only (not signed in)' if d == 'default' else f"Account {d}" + ('  (signed in)' if d == self.preset_folder else '')})
        self.folders.sort(key=lambda f: (0 if f['signed_in'] else (2 if f['id'] == 'default' else 1)))

    @staticmethod
    def _find_engine():
        ov = os.environ.get('BFS_ENGINE')
        if ov: return ov if os.path.exists(ov) else None
        here = os.path.dirname(os.path.abspath(__file__))
        # renamed so it never looks like a running Bambu Studio to Windows (or to our own "is Bambu Studio open?" check)
        for p in (os.path.join(os.path.dirname(here), 'engine', 'bambuforge-slicer.exe' if IS_WIN else 'bambuforge-slicer'),):
            if os.path.exists(p): return p
        return None

    def engine_version(self):
        try:
            v = os.path.join(os.path.dirname(self.engine), 'ENGINE_VERSION.txt') if self.engine else None
            return open(v, encoding='utf-8').read().strip() if v and os.path.exists(v) else None
        except Exception:
            return None

    @staticmethod
    def _find_exe():
        ov = os.environ.get('BF_BAMBU_EXE')
        if ov and os.path.exists(ov): return ov
        paths = []
        if IS_WIN:
            import winreg
            for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
                for root in (r'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall', r'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'):
                    try:
                        with winreg.OpenKey(hive, root) as k:
                            for i in range(winreg.QueryInfoKey(k)[0]):
                                try:
                                    with winreg.OpenKey(k, winreg.EnumKey(k, i)) as s:
                                        dn = winreg.QueryValueEx(s, 'DisplayName')[0]
                                        if 'bambu studio' not in str(dn).lower(): continue
                                        for v in ('InstallLocation', 'DisplayIcon'):
                                            try:
                                                p = str(winreg.QueryValueEx(s, v)[0]).split(',')[0].strip('"')
                                                paths.append(os.path.join(p, 'bambu-studio.exe') if v == 'InstallLocation' else p)
                                            except OSError: pass
                                except OSError: pass
                    except OSError: pass
            paths.append(os.path.join(os.environ.get('ProgramFiles', r'C:\Program Files'), 'Bambu Studio', 'bambu-studio.exe'))
        for p in paths:
            if p.lower().endswith('bambu-studio.exe') and os.path.exists(p): return p
        return None

    def preset_version(self):
        parts = [str(int(x)) if x.isdigit() else '0' for x in (self.vendor_version or '2.0.0.0').split('.')]
        return '.'.join((parts + ['0'] * 4)[:4])

    def resolve(self, name):
        chain, seen, cur = [], set(), name
        while cur and cur in self.system and cur not in seen:
            seen.add(cur); chain.append(self.system[cur]); cur = self.system[cur].get('inherits')
        res = {}
        for j in reversed(chain):
            for k, v in j.items():
                if k not in META: res[k] = v
        return res

    def printers(self):
        s = set()
        for p in self.system.values():
            if p.get('instantiation') == 'true': s.update(p.get('compatible_printers', []))
        return sorted(s)

    def bases_for(self, printer):
        out = [n for n, p in self.system.items() if p.get('instantiation') == 'true' and (not printer or printer in p.get('compatible_printers', []))]
        return sorted(out, key=lambda n: (layer_of(n), n))

    def closest_base(self, printer, like=None, layer=0.2):
        lst = self.bases_for(printer)
        if not lst: return None
        target = layer_of(like) if like else layer
        if target >= 99: target = layer or 0.2
        q = quality_of(like) if like else 'High Quality'
        return min(lst, key=lambda n: (abs(layer_of(n) - target), 0 if quality_of(n) == q else 1))


def layer_of(n):
    m = re.match(r'^(\d+(?:\.\d+)?)mm', n or '')
    return float(m.group(1)) if m else 99.0

def quality_of(n):
    m = re.match(r'^\d+(?:\.\d+)?mm\s+(.*?)\s*@', n or '')
    return m.group(1) if m else ''

def nozzle_of(printer):
    m = re.search(r'(\d+(?:\.\d+)?)\s*nozzle', printer or '')
    return float(m.group(1)) if m else 0.4

def base_values(parent, key):
    """What the base preset holds for a key (list sized the way Bambu stores it)."""
    if key in parent:
        v = parent[key]
        return [str(x) for x in v] if isinstance(v, list) else [str(v)]
    d = OPT.get(key)
    if not d or 'default' not in d: return None
    return [d['default']] * vector_len(parent, key)

def vector_len(parent, key):
    d = OPT.get(key)
    if not d or not d['type'].endswith('s'): return 1
    if isinstance(parent.get(key), list): return max(1, len(parent[key]))
    if d.get('variant') and isinstance(parent.get('print_extruder_variant'), list): return max(1, len(parent['print_extruder_variant']))
    return 1


# ------------------------------------------------------------------ choosing settings from the shapes
def measure(mesh):
    v = np.asarray(mesh.vertices, np.float64); f = np.asarray(mesh.faces)
    a, b, c = v[f[:, 0]], v[f[:, 1]], v[f[:, 2]]
    n = np.cross(b - a, c - a); ln = np.linalg.norm(n, axis=1); ok = ln > 1e-12
    n, ln, a, b, c = n[ok], ln[ok], a[ok], b[ok], c[ok]
    area = ln / 2; nz = n[:, 2] / ln
    zmin = v[:, 2].min(); zmax_t = np.maximum(np.maximum(a[:, 2], b[:, 2]), c[:, 2])
    bed = area[(nz < -0.99) & (zmax_t < zmin + 0.05)].sum()
    bridge = area[(nz < -0.999) & ~(zmax_t < zmin + 0.05)].sum()
    oh = area[(nz < -0.866) & (nz >= -0.999) & (zmax_t > zmin + 0.3)].sum()
    if bridge > 1000: oh += bridge
    zb = np.minimum(19, ((nz + 1) / 2 * 20).astype(int))
    ph = np.arctan2(n[:, 1], n[:, 0]); pb = np.minimum(39, ((ph + math.pi) / (2 * math.pi) * 40).astype(int))
    bins = np.bincount(zb * 40 + pb, weights=area, minlength=800)
    tot = area.sum()
    ext = v.max(0) - v.min(0)
    return dict(W=float(ext[0]), D=float(ext[1]), H=float(ext[2]), area=float(tot), overhang=float(oh), bed=float(bed),
                volume=float(abs(mesh.volume)), sculpt=float((bins > tot * 0.0005).sum() / 800.0))

def recommend(parts, env, printer, title):
    M = [dict(measure(p.mesh), name=p.name, plate=p.plate) for p in parts]
    tot_area = sum(m['area'] for m in M) or 1
    sculpt = sum(m['sculpt'] * m['area'] for m in M) / tot_area
    organic = sculpt >= 0.25
    tallest = max(M, key=lambda m: m['H']); maxH = tallest['H']
    vol = sum(m['volume'] for m in M)
    nz = nozzle_of(printer)
    if organic and maxH < 50: want, why = nz * 0.30, 'small, curved, detailed surfaces: fine layers make them smooth'
    elif organic: want, why = nz * 0.40, 'sculpted, curved surfaces where layer lines would show; best quality-for-time balance'
    else: want, why = nz * 0.50, 'mostly flat/straight surfaces, where layer lines hardly show; faster and stronger'
    base = env.closest_base(printer, None, want)
    if organic and maxH >= 50:
        hq = [n for n in env.bases_for(printer) if abs(layer_of(n) - layer_of(base)) < 1e-6 and quality_of(n) == 'High Quality']
        if hq: base = hq[0]
    lh = layer_of(base)
    rows = []
    add = lambda k, v, n: rows.append({'key': k, 'value': v, 'why': n})
    add('layer_height', _fmt(lh), why)
    slender = max(m['H'] / max(1, min(m['W'], m['D'])) for m in M)
    if maxH > 150 or slender > 4: add('wall_loops', '4', f"tallest part {maxH:.0f} mm: 4 walls make it stiff and strong at any joint")
    else: add('wall_loops', '3', '3 walls: stronger and cleaner surfaces than the default 2')
    if vol > 200000: add('sparse_infill_density', '15%', f"large parts ({vol / 1000:.0f} cm³): 15% gyroid is plenty strong without wasting filament")
    else: add('sparse_infill_density', '20%', 'smaller parts: a little more infill for strength')
    add('sparse_infill_pattern', 'gyroid', 'strong in every direction and prints quietly')
    shells = max(3, math.ceil(1.0 / lh - 1e-6))
    add('top_shell_layers', str(shells), f"about 1 mm of solid top skin at {_fmt(lh)} mm layers")
    add('bottom_shell_layers', str(shells), 'about 1 mm of solid bottom skin, flat and strong')
    needs = [m for m in M if m['overhang'] > 30 and m['overhang'] > m['area'] * 0.01]
    if needs:
        add('enable_support', '1', f"{len(needs)} part{' has' if len(needs) == 1 else 's have'} down-facing surfaces flatter than 30° ({sum(m['overhang'] for m in needs) / 100:.0f} cm²)")
        add('support_type', 'tree(auto)' if organic else 'normal(auto)', 'tree supports touch curved shapes lightly and peel off cleanly' if organic else 'normal supports suit flat, square overhangs')
        add('support_threshold_angle', '30', 'support anything flatter than 30° from horizontal')
    else:
        add('enable_support', '0', 'no overhangs that need support')
    tippy = sorted([m for m in M if m['H'] > 40 and (m['H'] / max(1, min(m['W'], m['D'])) > 3 or m['bed'] < 300)], key=lambda m: -m['H'])
    if tippy:
        t = tippy[0]
        add('brim_type', 'outer_only', f"{t['H']:.0f} mm tall on a {min(t['W'], t['D']):.0f} mm base: a brim stops it tipping or lifting")
        add('brim_width', _fmt(max(3, min(10, round(t['H'] / 40)))), 'about 1 mm of brim per 40 mm of height')
    else:
        add('brim_type', 'auto_brim', 'parts sit flat and wide, Bambu adds a brim only if needed')
    # tall, narrow parts wobble near the top at full speed: use Bambu's own "Slow down by height"
    wobbly = sorted([m for m in M if m['H'] > 100 and m['H'] / max(1, min(m['W'], m['D'])) > 2.5], key=lambda m: -m['H'])
    if wobbly:
        t = wobbly[0]
        par = env.resolve(base)
        def first(k, d):
            v = par.get(k, d); v = v[0] if isinstance(v, list) else v
            try: return float(v)
            except Exception: return d
        spd, acc = first('outer_wall_speed', 200.0), first('default_acceleration', 10000.0)
        h0, h1 = max(60.0, round(t['H'] * 0.5)), round(t['H'])
        add('enable_height_slowdown', '1', f"{t['name']} is {t['H']:.0f} mm tall on a {min(t['W'], t['D']):.0f} mm base: slowing down near the top stops it wobbling or being knocked over")
        add('slowdown_start_height', _fmt(h0), 'start easing off at half the height, where wobble begins')
        add('slowdown_start_speed', _fmt(spd), 'normal outer-wall speed at that point')
        add('slowdown_start_acc', _fmt(acc), 'normal acceleration at that point')
        add('slowdown_end_height', _fmt(h1), 'fully slowed by the top of the tallest part')
        add('slowdown_end_speed', _fmt(max(30, round(spd * 0.65))), 'about two-thirds speed at the top')
        add('slowdown_end_acc', _fmt(max(500, round(acc * 0.4))), 'gentler moves at the top so the part is not shaken')
    add('seam_position', 'aligned' if organic else 'back', 'keeps the seam in one line that is easy to hide in the texture' if organic else 'puts the seam at the back')
    add('elefant_foot_compensation', '0.15', 'stops the first layer flaring, so parts that join sit flush')
    clean = re.sub(r'\s+', ' ', title.replace('_', ' ')).strip()
    name = ('%.2f' % lh)[1:] + 'mm ' + clean
    plates = {}
    for m in M:
        p = plates.setdefault(m['plate'], {'n': 0, 'tallest': 0, 'support': False})
        p['n'] += 1; p['tallest'] = max(p['tallest'], m['H']); p['support'] |= m in needs
    summary = [f"{len(M)} parts · tallest {maxH:.0f} mm ({tallest['name']})", f"Shape: {'sculpted / organic' if organic else 'mostly flat and geometric'} · solid volume {vol / 1000:.0f} cm³"]
    return dict(base=base, name=name, rows=rows, summary=summary,
                plates={k: f"{v['n']} part{'s' if v['n'] != 1 else ''}, tallest {v['tallest']:.0f} mm, {'needs supports' if v['support'] else 'no supports'}" for k, v in plates.items()})


# ------------------------------------------------------------------ writing the preset exactly like Bambu Studio
BAD_CHARS = set('\\/:*?"<>|')

def validate_name(env, name):
    if not name or not name.strip(): return 'Give the preset a name.'
    if name != name.strip(): return "The name can't start or end with a space."
    if any(c in BAD_CHARS for c in name): return 'The name can\'t contain any of these characters:  \\ / : * ? " < > |'
    if name.endswith('.'): return "The name can't end with a dot."
    if name in env.system: return "That name belongs to one of Bambu's own presets. Pick a different name."

def build_json(env, name, base, changes):
    parent = env.resolve(base)
    doc = {'from': 'User', 'inherits': base, 'name': name, 'print_settings_id': name, 'version': env.preset_version()}
    for k in ('print_extruder_id', 'print_extruder_variant'):
        if isinstance(parent.get(k), list): doc[k] = [str(x) for x in parent[k]]
    changed = 0
    for key, value in changes:
        bv = base_values(parent, key); n = vector_len(parent, key)
        if bv is not None and len(bv) == n and all(x == value for x in bv): continue
        doc[key] = [value] * n if OPT[key]['type'].endswith('s') else value
        changed += 1
    text = '{\n' + ',\n'.join(
        f'    {json.dumps(k)}: ' + ('[\n' + ',\n'.join(f'        {json.dumps(x)}' for x in v) + '\n    ]' if isinstance(v, list) else json.dumps(v))
        for k, v in sorted(doc.items())) + '\n}\n'
    return text, changed

def read_info(path):
    out = {}
    try:
        for line in open(path, encoding='utf-8', errors='replace'):
            if '=' in line:
                k, v = line.split('=', 1); out[k.strip()] = v.strip()
    except OSError:
        return None
    return out

def write_preset(env, folder, name, base, changes, backup_root, log):
    text, changed = build_json(env, name, base, changes)
    json.loads(text)
    os.makedirs(folder['dir'], exist_ok=True)
    jp, ip = os.path.join(folder['dir'], name + '.json'), os.path.join(folder['dir'], name + '.info')
    setting_id, sync, backup, updated = '', '', None, False
    if os.path.exists(jp) or os.path.exists(ip):
        updated = True
        info = read_info(ip) or {}
        setting_id = '' if info.get('setting_id') in (None, 'null') else info.get('setting_id', '')
        if setting_id: sync = 'update'     # keep its cloud identity and push the change
        backup = os.path.join(backup_root, time.strftime('%Y-%m-%d_%H-%M-%S') + ' - ' + name)
        os.makedirs(backup, exist_ok=True)
        for p in (jp, ip):
            if os.path.exists(p): shutil.copy2(p, backup)
    base_id = env.system.get(base, {}).get('setting_id', '')
    user_id = '' if folder['id'] == 'default' else folder['id']
    # A brand-new preset MUST have an empty setting_id: Bambu Studio deletes local presets whose
    # setting_id isn't in the cloud. Empty setting_id + empty sync_info = "new, please upload".
    info = f"sync_info = {sync}\r\nuser_id = {user_id}\r\nsetting_id = {setting_id}\r\nbase_id = {base_id}\r\nupdated_time = {int(time.time())}\r\n"
    for p, data in ((jp, text.replace('\n', '\r\n')), (ip, info)):
        tmp = p + '.bfstmp'
        with open(tmp, 'w', encoding='utf-8', newline='') as f: f.write(data)
        os.replace(tmp, p)
    if json.load(open(jp, encoding='utf-8')).get('name') != name: raise IOError("The preset didn't read back correctly.")
    log('STEP', f"Wrote {jp} ({'updated' if updated else 'new'}, {changed} settings changed from {base})" + (f"\nBackup: {backup}" if backup else '') + "\n--- json ---\n" + text.strip() + "\n--- info ---\n" + info.replace('\r', '').strip())
    return dict(json=jp, info=ip, updated=updated, changed=changed, backup=backup)

def is_synced(info_path):
    i = read_info(info_path)
    return bool(i) and i.get('sync_info', 'x') == '' and i.get('setting_id', '') not in ('', 'null'), (i or {}).get('setting_id')


# ------------------------------------------------------------------ the Bambu Studio program
def running():
    try:
        if IS_WIN:
            out = subprocess.run(['tasklist', '/FI', 'IMAGENAME eq bambu-studio.exe', '/NH', '/FO', 'CSV'], capture_output=True, text=True, creationflags=0x08000000).stdout
            return out.lower().count('"bambu-studio.exe"')
        out = subprocess.run(['pgrep', '-f', 'bin/bambu-studio'], capture_output=True, text=True).stdout
        return len([x for x in out.split() if x.strip()])
    except Exception:
        return 0

def ask_close(force=False):
    if IS_WIN:
        args = ['taskkill', '/IM', 'bambu-studio.exe'] + (['/F'] if force else [])
        subprocess.run(args, capture_output=True, creationflags=0x08000000)
    else:
        subprocess.run(['pkill', '-9' if force else '-TERM', '-f', 'bin/bambu-studio'], capture_output=True)

def launch(exe, file=None):
    args = [exe] + ([file] if file else [])
    flags = 0x00000008 | 0x00000200 if IS_WIN else 0   # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    subprocess.Popen(args, cwd=os.path.dirname(exe), creationflags=flags, close_fds=True,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


# ------------------------------------------------------------------ project copies (settings + size) and real print times
def _mat_str(M):
    r = M[:3, :3].T.flatten().tolist() + M[:3, 3].tolist()
    return ' '.join('%.9g' % x for x in r)

def write_project(project, dst, env, base, changes, preset_name, log=None):
    """A copy of the Bambu project with these process settings and the current size applied.
    Size goes into the build/assembly transforms, the same way Bambu Studio saves a scaled object."""
    src = project['path']
    parent = env.resolve(base)
    by_oid = {p.oid: p for p in project['parts'] if getattr(p, 'oid', None)}
    zin = zipfile.ZipFile(src)
    with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == 'Metadata/project_settings.config':
                cfg = json.loads(data)
                changed = []
                def put(k, v):
                    cur = cfg.get(k)
                    if isinstance(cur, list): cfg[k] = [v] * max(1, len(cur))
                    elif OPT.get(k, {}).get('type', '').endswith('s'): cfg[k] = [v]
                    else: cfg[k] = v
                for k, v in parent.items():
                    d = OPT.get(k)
                    if not d or not d.get('process') or k not in cfg: continue
                    if isinstance(v, list) and isinstance(cfg[k], list) and len(v) == len(cfg[k]): cfg[k] = [str(x) for x in v]
                    else: put(k, str(v[0]) if isinstance(v, list) else str(v))
                for k, v in changes: put(k, v); changed.append(k)
                cfg['print_settings_id'] = preset_name
                if isinstance(cfg.get('different_settings_to_system'), list) and cfg['different_settings_to_system']:
                    cfg['different_settings_to_system'][0] = ';'.join(sorted(set(changed)))
                data = json.dumps(cfg, indent=4).encode()
            elif item.filename == '3D/3dmodel.model' and by_oid and any(abs(p.scale - 1) > 1e-9 for p in by_oid.values()):
                text = data.decode('utf-8')
                def fix_item(m):
                    tag = m.group(0); oid = re.search(r'objectid="([^"]+)"', tag)
                    p = by_oid.get(oid.group(1)) if oid else None
                    if p is None: return tag
                    S = np.diag([p.scale] * 3 + [1.0])
                    T = p.off @ p.P @ S                     # original local -> plate grid, at the new size
                    return re.sub(r'transform="[^"]*"', f'transform="{_mat_str(T)}"', tag) if 'transform="' in tag else tag.replace('<item ', f'<item transform="{_mat_str(T)}" ', 1)
                text = re.sub(r'<item\b[^>]*/?>', fix_item, text)
                data = text.encode('utf-8')
            elif item.filename == 'Metadata/model_settings.config' and by_oid and any(abs(p.scale - 1) > 1e-9 for p in by_oid.values()):
                text = data.decode('utf-8')
                def fix_asm(m):
                    tag = m.group(0); oid = re.search(r'object_id="([^"]+)"', tag)
                    p = by_oid.get(oid.group(1)) if oid else None
                    if p is None or p.A is None: return tag
                    S = np.diag([p.scale] * 3 + [1.0])
                    tag = re.sub(r'transform="[^"]*"', f'transform="{_mat_str(p.A @ S)}"', tag)
                    return re.sub(r'offset="[^"]*"', 'offset="0 0 0"', tag)
                text = re.sub(r'<assemble_item\b[^>]*/?>', fix_asm, text)
                data = text.encode('utf-8')
            zout.writestr(item, data)
    if log: log('STEP', f"Wrote project copy with '{preset_name}': {dst}")

def slice_times(exe, project_file, workdir, timeout, heartbeat, log):
    shutil.rmtree(workdir, ignore_errors=True); os.makedirs(workdir, exist_ok=True)
    args = [exe, '--slice', '0', '--min-save', '--outputdir', workdir, '--export-3mf', 'estimate.3mf', project_file]
    log('STEP', 'Slicing with Bambu Studio: ' + ' '.join(f'"{a}"' if ' ' in a else a for a in args))
    t0 = time.time()
    p = subprocess.Popen(args, cwd=os.path.dirname(exe), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         creationflags=0x08000000 if IS_WIN else 0)
    while p.poll() is None:
        el = time.time() - t0
        if heartbeat: heartbeat(int(el))
        if el > timeout:
            p.kill(); raise RuntimeError(f"Bambu Studio took longer than {timeout // 60} minutes, so it was stopped.")
        time.sleep(1)
    log('INFO', f'Bambu Studio finished slicing after {time.time() - t0:.0f} s')
    res = os.path.join(workdir, 'result.json')
    if not os.path.exists(res): raise RuntimeError("Bambu Studio didn't report a result.")
    j = json.load(open(res, encoding='utf-8'))
    if str(j.get('return_code')) != '0': raise RuntimeError(f"Bambu Studio couldn't slice it: {j.get('error_string')}")
    out = [{'plate': int(pl['id']), 'seconds': float(pl['total_predication']), 'grams': sum(float(f['total_used_g']) for f in pl.get('filaments', [])),
            'by_slot': {int(f['id']): float(f['total_used_g']) for f in pl.get('filaments', []) if 'id' in f}}
           for pl in j.get('sliced_plates', [])]
    log('INFO', 'Print time per plate: ' + ', '.join(f"plate {x['plate']} {hm(x['seconds'])} / {x['grams']:.0f} g" for x in out))
    return out

def hm(s):
    h, m = int(s // 3600), int(s % 3600 // 60)
    return f"{h} h {m:02d} m" if h else f"{m} m"


def project_with_settings(project, dst, env, base, changes, preset_name, log=None, printer=None, filament=None, plate=None, prof=None, tower_extra=0.0):
    slots = project.get('filaments')
    """Write the current parts as a Bambu project for this printer, filament and plate, with these process settings applied."""
    import build, zipfile as _z
    tmp = dst + '.parts.3mf'
    build.write_bambu_project(project, tmp)
    parent = env.resolve(base)
    zin = _z.ZipFile(tmp)
    with _z.ZipFile(dst, 'w', _z.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == 'Metadata/project_settings.config':
                cfg = json.loads(data)
                if printer:
                    apply_printer_and_filament(cfg, prof or Profiles(env), printer, filament, plate, slots)
                def put(k, v):
                    cur = cfg.get(k)
                    if isinstance(cur, list): cfg[k] = [v] * max(1, len(cur))
                    elif OPT.get(k, {}).get('type', '').endswith('s'): cfg[k] = [v]
                    else: cfg[k] = v
                for k, v in parent.items():
                    d = OPT.get(k)
                    if not d or not d.get('process') or k not in cfg: continue
                    if isinstance(v, list) and isinstance(cfg[k], list) and len(v) == len(cfg[k]): cfg[k] = [str(x) for x in v]
                    else: put(k, str(v[0]) if isinstance(v, list) else str(v))
                for k, v in changes: put(k, v)
                # where the prime tower goes on each plate: a free spot inside the plate, clear of every part
                lh = dict(changes).get('layer_height') or (parent.get('layer_height') if not isinstance(parent.get('layer_height'), list) else parent['layer_height'][0]) or 0.2
                try:
                    cfg['wipe_tower_x'], cfg['wipe_tower_y'] = build.tower_positions(project, build.plate_check(project, float(lh), tower_extra))
                    tc = project.get('tower_cfg') or {}
                    if 'enabled' in tc: cfg['enable_prime_tower'] = '1' if tc['enabled'] else '0'
                    if 'width' in tc: cfg['prime_tower_width'] = str(tc['width'])
                    if 'brim' in tc: cfg['prime_tower_brim_width'] = str(tc['brim'])
                    if 'rib' in tc: cfg['prime_tower_rib_wall'] = '1' if tc['rib'] else '0'
                    if log: log('INFO', f"Prime tower at x={cfg['wipe_tower_x']} y={cfg['wipe_tower_y']} (extra room {tower_extra} mm)")
                except Exception:
                    pass
                cfg['print_settings_id'] = preset_name
                cp = (env.system.get(base) or {}).get('compatible_printers')
                if cp: cfg['print_compatible_printers'] = cp     # Bambu checks the base process belongs to this printer
                if isinstance(cfg.get('different_settings_to_system'), list) and cfg['different_settings_to_system']:
                    cfg['different_settings_to_system'][0] = ';'.join(sorted({k for k, _ in changes}))
                data = json.dumps(cfg, indent=4).encode()
            zout.writestr(item, data)
    zin.close()
    os.remove(tmp)
    if log: log('STEP', f"Wrote project with '{preset_name}' settings: {dst}")


# ================================================================== every Bambu printer, plate and filament
KEYSETS = json.load(open(os.path.join(HERE, 'bambu_keysets.json'), encoding='utf-8'))
PRINTER_KEYS = set(KEYSETS['s_Preset_printer_options']) | set(KEYSETS['s_Preset_machine_limits_options'])
FILAMENT_KEYS = set(KEYSETS['s_Preset_filament_options'])
PLATES = [  # (what people call it, Bambu's curr_bed_type value, the filament setting that holds its bed temperature)
    ('Cool Plate SuperTack', 'Supertack Plate', 'supertack_plate_temp'),
    ('Cool Plate', 'Cool Plate', 'cool_plate_temp'),
    ('Engineering Plate', 'Engineering Plate', 'eng_plate_temp'),
    ('High Temp Plate', 'High Temp Plate', 'hot_plate_temp'),
    ('Textured PEI Plate', 'Textured PEI Plate', 'textured_plate_temp'),
]


def _load_dir(d, into, src):
    """Every profile under d, including vendor sub-folders (SUNLU, Polymaker, eSUN...)."""
    if not d or not os.path.isdir(d):
        return
    for root, _dirs, files in os.walk(d):
        for f in files:
            if not f.endswith('.json'):
                continue
            try:
                j = json.load(open(os.path.join(root, f), encoding='utf-8'))
            except Exception:
                continue
            if isinstance(j, dict) and j.get('name') and j['name'] not in into:
                j['_src'] = src
                into[j['name']] = j


class Profiles:
    """Bambu's printer (machine) and filament profiles, plus your own saved ones.
    Printers load straight away (a few hundred small files); the thousands of filament files load the first
    time they're needed, and only from the first place that has them."""
    def __init__(self, env):
        self.env = env
        roots = [os.path.join(env.data, 'system', 'BBL')]
        if env.exe: roots.append(os.path.join(os.path.dirname(env.exe), 'resources', 'profiles', 'BBL'))
        ov = os.environ.get('BFS_BAMBU_PROFILES')
        if ov: roots.insert(0, ov)
        self._roots = [r for r in roots if os.path.isdir(os.path.join(r, 'machine'))]
        self.machines, self._filaments = {}, None
        for r in self._roots[:1]:
            _load_dir(os.path.join(r, 'machine'), self.machines, 'system')
        for f in env.folders:
            _load_dir(os.path.join(os.path.dirname(f['dir']), 'machine'), self.machines, 'user:' + f['id'])

    @property
    def filaments(self):
        if self._filaments is None:
            t = time.time(); fl = {}
            for f in self.env.folders:                       # your own filaments win over Bambu's of the same name
                _load_dir(os.path.join(os.path.dirname(f['dir']), 'filament'), fl, 'user:' + f['id'])
            for r in self._roots[:1]:
                _load_dir(os.path.join(r, 'filament'), fl, 'system')
            self._filaments = fl
            if os.environ.get('BFS_DEBUG_TIMING'): print(f'filament profiles: {len(fl)} in {time.time() - t:.1f}s')
        return self._filaments

    @staticmethod
    def _resolve(name, table):
        chain, seen, cur = [], set(), name
        while cur and cur in table and cur not in seen:
            seen.add(cur); chain.append(table[cur]); cur = table[cur].get('inherits')
        out = {}
        for j in reversed(chain):
            out.update({k: v for k, v in j.items() if not k.startswith('_')})
        return out

    def machine(self, name):
        return self._resolve(name, self.machines)

    def filament(self, name):
        return self._resolve(name, self.filaments)

    def printer_names(self):
        out = [n for n, j in self.machines.items() if j.get('instantiation') == 'true' and j['_src'] == 'system' and 'Bambu Lab' in n]
        return sorted(out, key=lambda n: (n.split(' ')[2] if len(n.split(' ')) > 2 else n, n))

    def spec(self, name):
        """Bed size, build height and the no-print corner for a printer, from its profile."""
        m = self.machine(name)
        pts = [tuple(float(x) for x in str(p).strip().split('x')) for p in m.get('printable_area', ['0x0', '256x0', '256x256', '0x256'])]
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        ex = [tuple(float(x) for x in str(p).strip().split('x')) for p in (m.get('bed_exclude_area') or []) if str(p).strip()]
        excl = (min(p[0] for p in ex), min(p[1] for p in ex), max(p[0] for p in ex), max(p[1] for p in ex)) if ex else None
        if excl and (excl[2] - excl[0] < 1 or excl[3] - excl[1] < 1): excl = None
        noz = m.get('nozzle_diameter', ['0.4'])
        return {'name': name, 'model': m.get('printer_model', name), 'w': max(xs) - min(xs), 'd': max(ys) - min(ys),
                'h': float(m.get('printable_height', 250)), 'excl': excl, 'nozzle': float(noz[0] if isinstance(noz, list) else noz),
                'extruders': len(m.get('extruder_type', ['x'])) if isinstance(m.get('extruder_type'), list) else 1}

    def filament_names(self, printer):
        """Your filaments first, then Bambu's, then generic ones. Only those that work on this printer."""
        mine, bambu, generic = [], [], []
        for n, j in self.filaments.items():
            if j.get('instantiation') != 'true' and not j['_src'].startswith('user'):
                continue
            r = self.filament(n)
            cp = r.get('compatible_printers') or []
            if cp and printer not in cp:
                continue
            if j['_src'].startswith('user'): mine.append(n)
            elif n.startswith('Generic'): generic.append(n)
            else: bambu.append(n)
        return {'mine': sorted(mine), 'bambu': sorted(bambu), 'generic': sorted(generic)}

    def match_filament(self, name, printer):
        """The same filament for this printer (e.g. "SUNLU PLA+ 2.0 @BBL X1C" -> "... @BBL P1S 0.4 nozzle")."""
        if not name: return None
        fl = self.filament_names(printer)
        allf = fl['mine'] + fl['bambu'] + fl['generic']
        if name in allf: return name
        stem = name.split(' @')[0].strip()
        cands = [f for f in allf if f.split(' @')[0].strip() == stem]
        if cands:
            model = printer.replace('Bambu Lab ', '').split(' ')[0]
            cands.sort(key=lambda f: (model not in f, len(f)))
            return cands[0]
        return None

    def catalog(self, printer):
        """Brands -> types -> preset, for the filament picker (only what works on this printer)."""
        fl = self.filament_names(printer)
        out = {}
        for group in ('mine', 'bambu', 'generic'):
            for n in fl[group]:
                r = self.filament(n)
                vend = (r.get('filament_vendor') or ['Generic'])
                vend = vend[0] if isinstance(vend, list) else vend
                if group == 'mine': vend = 'Your filaments'
                typ = (r.get('filament_type') or ['PLA']); typ = typ[0] if isinstance(typ, list) else typ
                fid = r.get('filament_id', ''); fid = fid[0] if isinstance(fid, list) else fid
                dc = r.get('default_filament_colour') or ['']; dc = dc[0] if isinstance(dc, list) else dc
                lo = r.get('nozzle_temperature_range_low') or ['190']; hi = r.get('nozzle_temperature_range_high') or ['230']
                out.setdefault(vend, []).append({'preset': n, 'name': n.split(' @')[0], 'type': typ, 'id': fid, 'default_color': dc,
                                                 'tmin': int(float(lo[0] if isinstance(lo, list) else lo)), 'tmax': int(float(hi[0] if isinstance(hi, list) else hi))})
        order = ['Your filaments', 'Bambu Lab', 'Generic']
        return [{'brand': b, 'items': sorted(out[b], key=lambda x: x['name'])} for b in sorted(out, key=lambda b: (order.index(b) if b in order else 3, b))]

    def color_codes(self):
        """Bambu's official named colours per filament id (from filaments_color_codes.json)."""
        if getattr(self, '_cc', None) is None:
            self._cc = {}
            roots = [os.path.join(self.env.data, 'system', 'BBL', 'filament')]
            if self.env.exe: roots.append(os.path.join(os.path.dirname(self.env.exe), 'resources', 'profiles', 'BBL', 'filament'))
            ov = os.environ.get('BFS_BAMBU_PROFILES')
            if ov: roots.insert(0, os.path.join(ov, 'filament'))
            for r in roots:
                p = os.path.join(r, 'filaments_color_codes.json')
                if not os.path.exists(p): continue
                try:
                    for d in json.load(open(p, encoding='utf-8')).get('data', []):
                        col = (d.get('fila_color') or ['#808080FF'])[0]
                        allc = [str(x).upper() for x in (d.get('fila_color') or [])]
                        kind = {'渐变色': 'gradient', '多拼色': 'multi'}.get(d.get('fila_color_type'), 'single')
                        self._cc.setdefault(d.get('fila_id'), []).append({'name': (d.get('fila_color_name') or {}).get('en', ''), 'color': col[:7].upper(),
                                                                         'colors': allc, 'ctype': kind, 'alpha': allc[0][7:9] if allc and len(allc[0]) == 9 else 'FF',
                                                                         'multi': len(allc) > 1})
                    break
                except Exception:
                    continue
        return self._cc

    def plate_temps(self, filament):
        r = self.filament(filament)
        out = {}
        for label, _, key in PLATES:
            v = r.get(key, ['0'])
            v = v[0] if isinstance(v, list) else v
            try: out[label] = int(float(v))
            except Exception: out[label] = 0
        noz = r.get('nozzle_temperature', ['220']); noz = noz[0] if isinstance(noz, list) else noz
        dens = r.get('filament_density', ['1.24']); dens = dens[0] if isinstance(dens, list) else dens
        typ = r.get('filament_type', ['PLA']); typ = typ[0] if isinstance(typ, list) else typ
        return {'plates': out, 'nozzle': int(float(noz)), 'density': float(dens), 'type': typ}


def apply_printer_and_filament(cfg, prof, printer, filament, plate_label, slots=None):
    """Turn a project config into one for this printer, plate and filaments (Bambu's own profile values).
    slots: one dict per filament slot {'preset', 'color'}; slots without a usable preset get `filament`."""
    m = prof.machine(printer)
    for k, v in m.items():
        if k in PRINTER_KEYS and k not in META:
            cfg[k] = v
    cfg['printer_settings_id'] = printer
    if 'printer_model' in m: cfg['printer_model'] = m['printer_model']
    slots = list(slots or [])
    n = max(4, len(slots), len(cfg.get('filament_colour') or []))
    names = []
    for i in range(n):
        sp = slots[i] if i < len(slots) else None
        names.append(prof.match_filament(sp.get('preset') if sp else None, printer) or filament)
    if not any(names):
        return cfg
    names = [x or filament or next(y for y in names if y) for x in names]
    res = [prof.filament(x) for x in names]
    for k in FILAMENT_KEYS:
        if k in META: continue
        vals = [r.get(k) for r in res]
        if all(v is None for v in vals): continue
        out = []
        for v in vals:
            if v is None: v = next(x for x in vals if x is not None)
            out.extend(v if isinstance(v, list) else [v])
        cfg[k] = out if any(isinstance(v, list) for v in vals) else out[0]
    cfg['filament_settings_id'] = names
    cols = []
    for i in range(n):
        c = (slots[i].get('color') if i < len(slots) and slots[i] else None)
        if not c:
            d = res[i].get('default_filament_colour') or ['#00AE42']
            c = d[0] if isinstance(d, list) and d and d[0] else '#00AE42'
        cols.append(str(c)[:7].upper())
    cfg['filament_colour'] = cols
    multi, ctype = [], []
    for i in range(n):
        sp = slots[i] if i < len(slots) and slots[i] else {}
        cs = [str(x).upper() for x in (sp.get('colors') or []) if str(x).startswith('#')]
        if len(cs) > 1:
            multi.append(' '.join(x if len(x) == 9 else x[:7] + 'FF' for x in cs))
            ctype.append('0' if sp.get('ctype') == 'gradient' else '1')
        else:
            one = cs[0] if cs else cols[i]
            multi.append(one if len(one) == 9 else one[:7] + 'FF')
            ctype.append('1')
    cfg['filament_multi_colour'] = multi     # Bambu's own fields for gradient / multicolour / see-through filament
    cfg['filament_colour_type'] = ctype
    old = int(round(len(cfg.get('flush_volumes_matrix') or []) ** 0.5))
    if old != n:   # purge amounts between every pair of filaments: a safe 280 mm³, none to itself
        cfg['flush_volumes_matrix'] = [('0' if r == c else '280') for r in range(n) for c in range(n)]
        cfg['flush_volumes_vector'] = ['140'] * (2 * n)
    for label, value, _ in PLATES:
        if label == plate_label:
            cfg['curr_bed_type'] = value
    return cfg


def slice_plate_export(exe, project_file, plate, out_path, workdir, timeout, heartbeat, log):
    """Slice one plate and save the printable .gcode.3mf (what the printer runs)."""
    od = os.path.join(workdir, 'slice'); shutil.rmtree(od, ignore_errors=True); os.makedirs(od, exist_ok=True)
    name = 'job.gcode.3mf'
    args = [exe, '--slice', str(int(plate)), '--outputdir', od, '--export-3mf', name, project_file]
    log('STEP', 'Slicing for the printer: ' + ' '.join(f'"{a}"' if ' ' in a else a for a in args))
    t0 = time.time()
    p = subprocess.Popen(args, cwd=os.path.dirname(exe), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         creationflags=0x08000000 if IS_WIN else 0)
    while p.poll() is None:
        el = time.time() - t0
        if heartbeat: heartbeat(int(el))
        if el > timeout:
            p.kill(); raise RuntimeError(f"Bambu Studio took longer than {timeout // 60} minutes, so it was stopped.")
        time.sleep(1)
    res = os.path.join(od, 'result.json')
    if not os.path.exists(res): raise RuntimeError("Bambu Studio didn't report a result.")
    j = json.load(open(res, encoding='utf-8'))
    if str(j.get('return_code')) != '0': raise RuntimeError(f"Bambu Studio couldn't slice it: {j.get('error_string')}")
    made = os.path.join(od, name)
    if not os.path.exists(made): raise RuntimeError("Bambu Studio didn't write the sliced file.")
    with zipfile.ZipFile(made) as z:
        if f'Metadata/plate_{int(plate)}.gcode' not in z.namelist():
            raise RuntimeError(f'The sliced file has no G-code for plate {plate}.')
    shutil.move(made, out_path)
    pl = next((x for x in j.get('sliced_plates', []) if int(x['id']) == int(plate)), None)
    out = {'seconds': float(pl['total_predication']) if pl else None, 'grams': sum(float(f['total_used_g']) for f in pl.get('filaments', [])) if pl else None}
    log('INFO', f"Sliced plate {plate}: {hm(out['seconds']) if out['seconds'] else '?'}, {out['grams'] or 0:.0f} g -> {out_path}")
    return out


def parse_tower(gcode_path, every=3, max_segs=16000):
    """The prime tower as Bambu actually sliced it: line segments (x0, y0, x1, y1, z) from every few layers,
    plus its true footprint. Coordinates are on the plate (mm)."""
    wx = wy = None
    feat, X, Y, Z, layer = None, None, None, 0.0, 0
    segs, bb = [], [1e9, 1e9, -1e9, -1e9]
    num = re.compile(r'([XYZE])(-?[\d.]+)')
    with open(gcode_path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            if line.startswith(';'):
                if line.startswith('; FEATURE:'): feat = line[10:].strip()
                elif line.startswith('; CHANGE_LAYER'): layer += 1
                elif line.startswith('; wipe_tower_x = '): wx = float(line.split('=')[1].split(',')[0])
                elif line.startswith('; wipe_tower_y = '): wy = float(line.split('=')[1].split(',')[0])
                continue
            if not line.startswith(('G0', 'G1', 'G2', 'G3')): continue
            px, py = X, Y; e = False
            for k, v in num.findall(line.split(';')[0]):
                if k == 'X': X = float(v)
                elif k == 'Y': Y = float(v)
                elif k == 'Z': Z = float(v)
                elif k == 'E' and float(v) > 0: e = True
            if not e or feat != 'Prime tower' or px is None or X is None or wx is None: continue
            if abs(X - px) + abs(Y - py) < 0.05: continue            # an un-retract dot, not a printed line
            # only the tower itself (Bambu also labels the start-up purge line as prime tower)
            if not (wx - 15 <= X <= wx + 70 and wy - 15 <= Y <= wy + 70 and wx - 15 <= px <= wx + 70 and wy - 15 <= py <= wy + 70): continue
            if layer >= 2:
                bb = [min(bb[0], X, px), min(bb[1], Y, py), max(bb[2], X, px), max(bb[3], Y, py)]
            if (layer - 1) % every == 0 and len(segs) < max_segs:
                segs.append((round(px, 2), round(py, 2), round(X, 2), round(Y, 2), round(Z, 3)))
    if wx is None or not segs: return None
    return {'x': wx, 'y': wy, 'bbox': [round(v, 1) for v in bb] if bb[0] < 1e8 else None, 'segs': segs, 'layers': layer}
