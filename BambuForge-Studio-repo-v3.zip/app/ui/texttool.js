// BambuForge Studio: the text tool. Live preview on the part, drag to place, several texts per part, each editable later.
const $ = id => document.getElementById(id);
const X = () => window.studio && window.studio.ctx;
const DEF = { size: 10, spacing: 0, rot: 0, th: 1.2, emb: 0.4, arc: 90, waveH: 2, waveL: 20 };
const MINLEFT = 2.0;
const UNITS = { mm: [1, 200, 0.1, 1, 1], in: [0.04, 7.87, 0.01, 1 / 25.4, 2], pt: [3, 567, 1, 2.835, 0] };   // min,max,step (in that unit), mm->unit, decimals
const COMMON = ['#111111', '#FFFFFF', '#C12E1F', '#F4EE2A', '#FF6A13', '#00AE42', '#0086D6', '#0A2989', '#5E43B7', '#F077E8', '#9D432C', '#8E9089', '#E4BD68'];
let fontsInfo = null, fontTab = 'mine', part = -1, items = [], cur = -1, preview = null, drag = null, thick = {}, layoutCache = {}, rebuildT = null, busyApply = false;

const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const it = () => items[cur];
function stat(m, bad) { const c = X(); if (c) c.status(m, bad); }

// ------------------------------------------------------------------ open / list / add / remove
async function open() {
  const c = X(); if (!c || !c.state()) return;
  part = c.selected();
  if (part < 0) { $('ttNone').innerHTML = 'Click a part first, then press <b>+ Add text</b>.'; $('ttNone').classList.remove('hidden'); $('ttEd').classList.add('hidden'); renderChips(); clearPreview(); return; }
  if (!fontsInfo) fontsInfo = await c.api().fonts_list();
  const got = await c.api().part_texts(part);
  items = (got || []).map(x => ({ ...DEF, unit: 'mm', allow: false, ...x, saved: true }));
  cur = items.length ? items.length - 1 : -1;
  if (!items.length) addNew(); else { renderAll(); }
}
function defaultFont() {
  const f = (fontsInfo && fontsInfo.families) || [];
  for (const want of ['Arial Black', 'Arial', 'Segoe UI', 'DejaVu Sans', 'Liberation Sans']) if (f.includes(want)) return want;
  return f[0] || 'Arial';
}
function anchorGuess() {
  // where the camera looks at the part; else the middle of its top
  const c = X(), m = meshOf(part); if (!m) return null;
  const ray = new c.THREE.Raycaster(); ray.setFromCamera(new c.THREE.Vector2(0, 0), c.camera);
  let h = ray.intersectObject(m, false)[0];
  if (!h) { const b = new c.THREE.Box3().setFromObject(m), ctr = b.getCenter(new c.THREE.Vector3()); ray.set(new c.THREE.Vector3(ctr.x, ctr.y, b.max.z + 50), new c.THREE.Vector3(0, 0, -1)); h = ray.intersectObject(m, false)[0]; }
  if (!h) return null;
  return { point: m.worldToLocal(h.point.clone()).toArray(), normal: h.face.normal.clone().toArray() };
}
function addNew() {
  const a = anchorGuess(); if (!a) { stat("Couldn't find a spot on that part. Turn the view so the part is in the middle.", true); return; }
  const slots = X().state().filaments.slots, used = slots.find(s => s.used) || slots[0];
  const other = slots.find(s => s.slot !== (used && used.slot)) || used;
  items.push({ ...DEF, text: 'TEXT', font: defaultFont(), bold: false, italic: false, under: false, style: 'raise', path: 'straight', unit: 'mm', slot: other ? other.slot : 1, allow: false, ...a, saved: false, dirty: true });
  cur = items.length - 1; renderAll(); applySoon(400); setTimeout(() => { $('ttText').focus(); $('ttText').select(); }, 30);
}
function renderChips() {
  $('ttChips').innerHTML = items.map((t, i) => `<div class="ttchip ${i === cur ? 'on' : ''}" data-i="${i}" title="${esc(t.text)}"><span>${esc(t.text || '(empty)')}${t.dirty ? ' •' : ''}</span><b data-x="${i}" title="Remove this text">✕</b></div>`).join('') +
    (part >= 0 ? `<div class="ttchip" id="ttAddNew" style="color:var(--green2)">+ Add text</div>` : '');
  $('ttChips').querySelectorAll('[data-i]').forEach(ch => ch.onclick = e => {
    if (e.target.dataset.x !== undefined) { removeItem(+e.target.dataset.x); return; }
    cur = +ch.dataset.i; renderAll();
  });
  const a = $('ttAddNew'); if (a) a.onclick = addNew;
}
async function removeItem(i) {
  const t = items[i];
  items.splice(i, 1); cur = Math.min(cur, items.length - 1); clearPreview();
  renderAll();
  if (t.saved) apply(`Removed text "${t.text}"`);
}

// ------------------------------------------------------------------ panel
function toU(mm) { const u = UNITS[it().unit]; return +(mm * u[3]).toFixed(u[4]); }
function fromU(v) { return v / UNITS[it().unit][3]; }
const SL = [ // slider id, key, unit-converted?
  ['ttSize', 'size', true], ['ttSp', 'spacing'], ['ttRot', 'rot'], ['ttTh', 'th'], ['ttEmb', 'emb'], ['ttArc', 'arc'], ['ttWH', 'waveH'], ['ttWL', 'waveL']];
function bindSliders() {
  SL.forEach(([id, key, conv]) => {
    const r = $(id), n = $(id + 'N');
    r.oninput = () => { it()[key] = conv ? fromU(+r.value) : +r.value; n.value = r.value; changed(); };
    n.onchange = () => { let v = parseFloat(n.value); if (!isFinite(v)) { showVals(); return; } v = Math.min(+r.max, Math.max(+r.min, v)); it()[key] = conv ? fromU(v) : v; showVals(); changed(); };
    n.onkeydown = e => { if (e.key === 'Enter') n.blur(); };
  });
  document.querySelectorAll('#tt .trs').forEach(b => b.onclick = () => { it()[b.dataset.r] = DEF[b.dataset.r]; showVals(); changed(); });
}
function showVals() {
  const t = it(); if (!t) return;
  const u = UNITS[t.unit]; $('ttSize').min = u[0]; $('ttSize').max = u[1]; $('ttSize').step = u[2];
  SL.forEach(([id, key, conv]) => {
    const v = conv ? toU(t[key]) : t[key]; $(id).value = v;
    if (document.activeElement !== $(id + 'N')) $(id + 'N').value = (key === 'rot' || key === 'arc') ? Math.round(v) : (conv ? v : (+v).toFixed(1));
  });
}
function renderAll() {
  renderChips();
  const t = it();
  $('ttNone').classList.toggle('hidden', !!t); $('ttEd').classList.toggle('hidden', !t);
  if (!t) { clearPreview(); return; }
  $('ttText').value = t.text; $('ttFontName').textContent = t.font; $('ttFontName').style.fontFamily = `'${t.font}'`; $('ttUnit').value = t.unit;
  $('ttB').classList.toggle('on', !!t.bold); $('ttI').classList.toggle('on', !!t.italic); $('ttU').classList.toggle('on', !!t.under);
  document.querySelectorAll('#ttStyle span').forEach(s => s.classList.toggle('on', s.dataset.v === t.style));
  document.querySelectorAll('#ttPath span').forEach(s => s.classList.toggle('on', s.dataset.v === t.path));
  $('ttThL').textContent = t.style === 'cut' ? 'Depth' : 'Thickness';
  $('ttThRow').classList.toggle('hidden', t.style === 'through');
  $('ttEmbRow').classList.toggle('hidden', t.style !== 'flat');
  $('ttArcRow').classList.toggle('hidden', t.path !== 'arc');
  ['ttWHRow', 'ttWLRow'].forEach(r => $(r).classList.toggle('hidden', t.path !== 'wave'));
  const slot = X().state().filaments.slots.find(s => s.slot === t.slot);
  $('ttColSw').style.background = slot ? slot.color : '#888'; $('ttColName').textContent = slot ? `${slot.slot} · ${slot.name}` : `Colour ${t.slot}`;
  $('ttNote').textContent = {
    raise: 'Solid letters standing up from the surface.', cut: 'Letters cut into the part.', through: 'Letters cut all the way through, like a stencil.',
    flat: 'Flat tiles; "Sinks in" pushes them into the part so no corner floats.'
  }[t.style] + ' Changes go onto the model by themselves.';
  showVals(); if (t.dirty || !t.saved) rebuild(); else clearPreview();
}
function changed() { const t = it(); if (!t) return; t.dirty = true; renderChips(); renderAllLight(); rebuildSoon(); applySoon(900); }
function renderAllLight() {
  const t = it(); $('ttThL').textContent = t.style === 'cut' ? 'Depth' : 'Thickness';
}
function wire() {
  bindSliders();
  $('ttText').oninput = () => { it().text = $('ttText').value; changed(); };
  $('ttUnit').onchange = () => { it().unit = $('ttUnit').value; showVals(); };
  [['ttB', 'bold'], ['ttI', 'italic'], ['ttU', 'under']].forEach(([id, k]) => $(id).onclick = () => { it()[k] = !it()[k]; $(id).classList.toggle('on', it()[k]); changed(); });
  document.querySelectorAll('#ttStyle span').forEach(s => s.onclick = () => { it().style = s.dataset.v; it().dirty = true; renderAll(); applySoon(900); });
  document.querySelectorAll('#ttPath span').forEach(s => s.onclick = () => { it().path = s.dataset.v; it().dirty = true; renderAll(); applySoon(900); });
  $('ttAllow').onchange = () => { it().allow = $('ttAllow').checked; it().dirty = true; checkDepth(); applySoon(300); };
  $('ttDelete').onclick = () => { if (cur >= 0) removeItem(cur); };
  // fonts
  $('ttFontBtn').onclick = e => { e.stopPropagation(); $('ttColPop').classList.add('hidden'); $('ttFontPop').classList.toggle('hidden'); $('ttFontQ').value = ''; fontList(); $('ttFontQ').focus(); };
  $('ttFontQ').oninput = fontList;
  document.querySelectorAll('#ttFontPop .tttabs span').forEach(t => t.onclick = () => { fontTab = t.dataset.t; document.querySelectorAll('#ttFontPop .tttabs span').forEach(x => x.classList.toggle('on', x === t)); fontList(); });
  $('ttFontAdd').onclick = async () => { const d = await X().api().font_add_dialog(); if (!d) return; if (d.error) { stat(d.error, true); return; } fontsInfo = d; if (d.added) { it().font = d.added; changed(); renderAll(); stat(`Added the font "${d.added}".`); } fontList(); };
  // colour
  $('ttColBtn').onclick = e => { e.stopPropagation(); $('ttFontPop').classList.add('hidden'); $('ttColPop').classList.toggle('hidden'); tiles(); };
  document.querySelectorAll('.ttpop').forEach(p => p.addEventListener('click', e => e.stopPropagation()));
  document.addEventListener('click', () => document.querySelectorAll('.ttpop').forEach(p => p.classList.add('hidden')));
  wheel();
  $('ttHex').onchange = () => { const v = $('ttHex').value.trim(); if (/^#?[0-9a-f]{6}$/i.test(v)) useColour('#' + v.replace('#', '').toUpperCase()); };
}
function fontList() {
  const q = $('ttFontQ').value.toLowerCase(), box = $('ttFontList');
  if (fontTab === 'mine') {
    const fams = ((fontsInfo && fontsInfo.families) || []).filter(f => f.toLowerCase().includes(q)).slice(0, 400);
    box.innerHTML = fams.map(f => `<div class="ttfi ${it() && f === it().font ? 'on' : ''}" data-f="${esc(f)}"><span style="font-family:'${esc(f)}'">${esc(f)}</span></div>`).join('') || '<div class="dim small" style="padding:6px">No font matches.</div>';
    box.querySelectorAll('[data-f]').forEach(d => d.onclick = () => { it().font = d.dataset.f; $('ttFontPop').classList.add('hidden'); changed(); renderAll(); });
  } else {
    const fr = ((fontsInfo && fontsInfo.free) || []).filter(f => f.name.toLowerCase().includes(q));
    box.innerHTML = fr.map(f => `<div class="ttfi" data-g="${esc(f.name)}"><span>${esc(f.name)}</span><button ${f.installed ? 'disabled' : ''}>${f.installed ? 'Installed' : 'Get'}</button></div>`).join('') +
      '<div class="dim small" style="padding:6px">Free fonts from Google Fonts (free to use and print).</div>';
    box.querySelectorAll('[data-g]').forEach(d => {
      d.onclick = () => { const f = fr.find(x => x.name === d.dataset.g); if (f && f.installed) { it().font = f.name; $('ttFontPop').classList.add('hidden'); changed(); renderAll(); } };
      const b = d.querySelector('button'); b.onclick = async e => {
        e.stopPropagation(); if (b.disabled) return; b.textContent = '…'; b.disabled = true;
        const r = await X().api().font_download(d.dataset.g); if (r.error) { stat(r.error, true); b.textContent = 'Get'; b.disabled = false; return; }
        fontsInfo = r; it().font = d.dataset.g; changed(); renderAll(); fontList(); stat(`Downloaded ${d.dataset.g} and added it to your fonts.`);
      };
    });
  }
}
function tiles() {
  const slots = X().state().filaments.slots, t = it();
  $('ttTilesF').innerHTML = slots.map(s => `<div class="tttile ${s.slot === t.slot ? 'on' : ''}" title="${s.slot} · ${esc(s.name)}" style="background:${s.color}" data-s="${s.slot}"></div>`).join('');
  $('ttTilesC').innerHTML = COMMON.map(c => `<div class="tttile" title="${c}" style="background:${c}" data-c="${c}"></div>`).join('');
  $('ttTilesF').querySelectorAll('[data-s]').forEach(d => d.onclick = () => { t.slot = +d.dataset.s; changed(); renderAll(); tiles(); });
  $('ttTilesC').querySelectorAll('[data-c]').forEach(d => d.onclick = () => useColour(d.dataset.c));
  const s = slots.find(x => x.slot === t.slot); if (s && document.activeElement !== $('ttHex')) $('ttHex').value = s.color;
}
async function useColour(hex) {
  // an existing colour slot with that colour, or a new slot (same filament as colour 1)
  const c = X(), slots = c.state().filaments.slots, same = slots.find(s => s.color.toUpperCase() === hex.toUpperCase());
  if (same) { it().slot = same.slot; changed(); renderAll(); tiles(); return; }
  const n = slots.length + 1; if (n > 16) { stat('16 colours is the most a project can have.', true); return; }
  const base = slots[0];
  const d = await c.api().set_slot(n, base.preset, hex, base.type, null, 'single', null);
  if (d.error) { stat(d.error, true); return; }
  c.state().filaments = d.filaments; c.pushUndo(`Add colour ${n}`);
  it().slot = n; changed(); renderAll(); tiles(); stat(`Added colour ${n} (${hex}) for the text.`);
}
function wheel() {
  const cv = $('ttWheel'), x = cv.getContext('2d'), W = cv.width, R = W / 2, img = x.createImageData(W, W);
  for (let y = 0; y < W; y++) for (let i = 0; i < W; i++) {
    const dx = i - R, dy = y - R, d = Math.hypot(dx, dy), o = (y * W + i) * 4; if (d > R) continue;
    const h = (Math.atan2(dx, -dy) * 180 / Math.PI + 360) % 360, s = d / R, f = n => { const k = (n + h / 60) % 6; return 1 - s * Math.max(0, Math.min(k, 4 - k, 1)); };
    img.data[o] = f(5) * 255; img.data[o + 1] = f(3) * 255; img.data[o + 2] = f(1) * 255; img.data[o + 3] = 255;
  }
  x.putImageData(img, 0, 0);
  cv.onclick = e => { const r = cv.getBoundingClientRect(), p = x.getImageData(Math.min(W - 1, (e.clientX - r.left) * W / r.width), Math.min(W - 1, (e.clientY - r.top) * W / r.height), 1, 1).data; if (p[3]) useColour('#' + [p[0], p[1], p[2]].map(v => v.toString(16).padStart(2, '0')).join('').toUpperCase()); };
}

// ------------------------------------------------------------------ preview on the part (placement worked out by the back end, so it's quick)
function meshOf(i) { const c = X(); return c && c.meshes().find(m => m.userData.id === i); }
function clearPreview() { if (preview && preview.parent) preview.parent.remove(preview); preview = null; }
let prevT = null, applyT = null, gen = 0, applying = 0, lastApplied = 0;
function rebuildSoon(ms = 220) { clearTimeout(prevT); prevT = setTimeout(rebuild, ms); }
function shapesOf(contours) {
  const T = X().THREE, sp = new T.ShapePath();
  let big = 0, sign = 1;
  contours.forEach(c => { let a = 0; for (let i = 0; i < c.length; i++) { const p = c[i], q = c[(i + 1) % c.length]; a += p[0] * q[1] - q[0] * p[1]; } if (Math.abs(a) > big) { big = Math.abs(a); sign = Math.sign(a); } });
  contours.forEach(c => { sp.moveTo(c[0][0], c[0][1]); for (let i = 1; i < c.length; i++) sp.lineTo(c[i][0], c[i][1]); });
  return sp.toShapes(sign > 0);
}
function frameOf(T, n, rot) {   // same as the back end's frame(): x along the text, y up the letters, z out of the surface
  n = n.clone().normalize();
  const up = Math.abs(n.z) < 0.9 ? new T.Vector3(0, 0, 1) : new T.Vector3(0, 1, 0);
  const x = new T.Vector3().crossVectors(up, n).normalize(), y = new T.Vector3().crossVectors(n, x), a = rot * Math.PI / 180;
  return { x: x.clone().multiplyScalar(Math.cos(a)).addScaledVector(y, Math.sin(a)), y: x.clone().multiplyScalar(-Math.sin(a)).addScaledVector(y, Math.cos(a)), n };
}
function anchorMatrix(T, t) { const F = frameOf(T, new T.Vector3().fromArray(t.normal), t.rot); return new T.Matrix4().makeBasis(F.x, F.y, F.n).setPosition(new T.Vector3().fromArray(t.point)); }
async function rebuild() {
  const c = X(); if (!c || part < 0) return; const T = c.THREE;
  const t = it(); if (!t) { clearPreview(); return; }
  const req = JSON.stringify([t.text, t.font, t.size, t.bold, t.italic, t.under, t.spacing, t.rot, t.path, t.arc, t.waveH, t.waveL, t.style, t.point, t.normal]);
  const L = await c.api().text_preview(part, { text: t.text, font: t.font, size: t.size, bold: t.bold, italic: t.italic, under: t.under, spacing: t.spacing,
    rot: t.rot, path: t.path, arc: t.arc, waveH: t.waveH, waveL: t.waveL, style: t.style, point: t.point, normal: t.normal });
  if (!L || L.error || !it() || JSON.stringify([it().text, it().font, it().size, it().bold, it().italic, it().under, it().spacing, it().rot, it().path, it().arc, it().waveH, it().waveL, it().style, it().point, it().normal]) !== req) return;   // something changed meanwhile
  const m = meshOf(part); if (!m) return;
  clearPreview();
  const g = new T.Group(); g.userData.textPreview = true; g.matrixAutoUpdate = false;
  const slot = c.state().filaments.slots.find(s => s.slot === t.slot), hole = t.style === 'cut' || t.style === 'through';
  const mat = new T.MeshStandardMaterial({ color: hole ? 0x2a1630 : (slot ? slot.color : '#ffffff'), roughness: 0.6, emissive: 0x0a2a14, polygonOffset: true, polygonOffsetFactor: -2 });
  const z = { raise: [0, t.th], flat: [-t.emb, t.th - t.emb], cut: [-0.2, 0.08], through: [-0.2, 0.08] }[t.style];
  const pieces = L.glyphs.map(gl => gl.contours); if (L.underline) pieces.push([L.underline]);
  pieces.forEach((contours, i) => {
    const f = L.frames[i]; if (!f) return;
    const shapes = shapesOf(contours); if (!shapes.length) return;
    const geo = new T.ExtrudeGeometry(shapes, { depth: Math.max(0.05, z[1] - z[0]), bevelEnabled: false, curveSegments: 2 }); geo.translate(0, 0, z[0]);
    const n = new T.Vector3().fromArray(f[2]).normalize(), tx = new T.Vector3().fromArray(f[1]); tx.addScaledVector(n, -tx.dot(n)).normalize();
    geo.applyMatrix4(new T.Matrix4().makeBasis(tx, new T.Vector3().crossVectors(n, tx), n).setPosition(new T.Vector3().fromArray(f[0])));
    const me = new T.Mesh(geo, mat); me.userData.textItem = cur; g.add(me);
  });
  g.userData.base = anchorMatrix(T, t);   // dragging moves this whole group without rebuilding it
  m.add(g); preview = g;
  thick[cur] = t.style === 'cut' && L.thick != null ? L.thick : Infinity;
  checkDepth();
}
function checkDepth() {
  const t = it(); if (!t) return;
  const tmin = thick[cur], isCut = t.style === 'cut' && isFinite(tmin);
  if (isCut) { const cap = Math.max(0.2, Math.floor(tmin * 10) / 10); $('ttTh').max = cap; if (t.th > cap) { t.th = cap; showVals(); } $('ttMax').textContent = `deepest possible here: ${cap.toFixed(1)} mm (the part is ${tmin.toFixed(1)} mm thick)`; }
  else { $('ttTh').max = 200; $('ttMax').textContent = ''; }
  const left = isCut ? tmin - t.th : Infinity, thin = left < MINLEFT;
  $('ttWarn').classList.toggle('hidden', !thin);
  if (thin) {
    $('ttWarnT').innerHTML = `⚠ Only <b>${Math.max(0, left).toFixed(1)} mm</b> would be left under the letters (keep at least ${MINLEFT} mm). It may crack, or show through on the other side.` +
      (tmin > MINLEFT + 0.2 ? ` A depth of <b>${(tmin - MINLEFT).toFixed(1)} mm</b> or less is safe.` : ` The part is only ${tmin.toFixed(1)} mm thick here, so any cut is risky: try <b>Raised</b>, or <b>Cut out</b>.`) +
      (t.allow ? '' : ' <b>Not added to the model until this is fixed or allowed.</b>');
    $('ttAllow').checked = !!t.allow;
  }
}
const blockedItem = x => x.style === 'cut' && isFinite(thick[items.indexOf(x)]) && thick[items.indexOf(x)] - x.th < MINLEFT && !x.allow;
// every change goes onto the model by itself (in the background); only the newest version is kept
function applySoon(ms = 650) { clearTimeout(applyT); applyT = setTimeout(() => apply(), ms); }
async function apply(label) {
  const c = X(); if (part < 0) return;
  const send = items.filter(x => !blockedItem(x)).map(t => ({ text: t.text, font: t.font, bold: !!t.bold, italic: !!t.italic, under: !!t.under, size: t.size, spacing: t.spacing, rot: t.rot,
    style: t.style, th: t.th, emb: t.emb, path: t.path, arc: t.arc, waveH: t.waveH, waveL: t.waveL, slot: t.slot, point: t.point, normal: t.normal, allow: !!t.allow })).filter(t => (t.text || '').trim());
  const my = ++gen, keep = part; applying++; working(true);
  let d;
  try { d = await c.api().text_set(keep, send, my); } catch (e) { d = { error: String(e && e.message || e) }; } finally { applying--; }
  if (my !== gen || !d || d.stale) { if (!applying) working(false); return; }   // a newer change is on its way
  working(false); lastApplied = Date.now();
  if (d.error) { stat(d.error, true); return; }
  const dragNow = drag;
  clearPreview();
  try { await c.show(d); } catch (e) { try { await c.show(await c.api().plates_info()); } catch (_) { stat("The view didn't refresh; it will on the next change.", true); } }
  c.select(keep, false); part = keep;
  c.pushUndo(label || (send.length ? `Text on the part` : 'Removed the text'));
  items.forEach(x => { if (!blockedItem(x)) { x.saved = true; x.dirty = false; } });
  renderChips();
  if (dragNow || items.some(x => x.dirty)) rebuild();
}
function working(on) { const n = $('ttBusy'); if (n) n.classList.toggle('hidden', !on); }

// ------------------------------------------------------------------ dragging: the preview moves as one piece; letters re-fit when you let go
let proxy = null, proxyKey = null;
async function ensureProxy() {
  const c = X(), m = meshOf(part); if (!m) return null; const T = c.THREE;
  const key = part + ':' + (c.state() && c.state().gen);
  if (proxy && proxyKey === key) return proxy;
  const r = await c.api().part_proxy(part); if (!r || r.error) return null;
  // cut the light copy into tiles, so a pick only tests the few tiles under the mouse
  const V = r.v, F = r.f, nt = F.length / 3, N = 8;
  let x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
  for (let i = 0; i < V.length; i += 3) { x0 = Math.min(x0, V[i]); x1 = Math.max(x1, V[i]); y0 = Math.min(y0, V[i + 1]); y1 = Math.max(y1, V[i + 1]); }
  const bins = Array.from({ length: N * N }, () => []);
  for (let k = 0; k < nt; k++) {
    const a = F[3 * k] * 3, b = F[3 * k + 1] * 3, cc = F[3 * k + 2] * 3;
    const cx = (V[a] + V[b] + V[cc]) / 3, cy = (V[a + 1] + V[b + 1] + V[cc + 1]) / 3;
    const ix = Math.min(N - 1, Math.max(0, Math.floor((cx - x0) / (x1 - x0 + 1e-9) * N))), iy = Math.min(N - 1, Math.max(0, Math.floor((cy - y0) / (y1 - y0 + 1e-9) * N)));
    bins[iy * N + ix].push(F[3 * k], F[3 * k + 1], F[3 * k + 2]);
  }
  const pos = new T.BufferAttribute(new Float32Array(V), 3), mat = new T.MeshBasicMaterial({ side: T.DoubleSide });
  proxy = new T.Group(); proxy.matrixAutoUpdate = false;
  bins.forEach(ix => { if (!ix.length) return; const g = new T.BufferGeometry(); g.setAttribute('position', pos); g.setIndex(ix); g.computeBoundingSphere(); g.computeBoundingBox(); const me = new T.Mesh(g, mat); me.matrixAutoUpdate = false; proxy.add(me); });
  proxyKey = key;
  return proxy;
}
function hookDrag() {
  const c = X(), T = c.THREE, el = c.renderer.domElement, ray = new T.Raycaster(), ndc = new T.Vector2();
  let pendingMove = null;
  const pick = e => { const r = el.getBoundingClientRect(); ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1); ray.setFromCamera(ndc, c.camera); };
  el.addEventListener('pointerdown', e => {
    if (!preview || e.button !== 0) return; pick(e);
    const h = ray.intersectObjects(preview.children, false)[0]; if (!h) return;
    drag = true; c.controls.enabled = false; e.stopPropagation(); el.style.cursor = 'grabbing'; ensureProxy();
  }, true);
  window.addEventListener('pointermove', e => {
    if (!preview) return;
    if (!drag) { if (e.target === el) { pick(e); el.style.cursor = ray.intersectObjects(preview.children, false).length ? 'grab' : ''; } return; }
    pendingMove = e;
    if (pendingMove.__q) return; pendingMove.__q = true;
    requestAnimationFrame(() => {
      const ev = pendingMove; pendingMove = null; if (!ev || !drag || !preview) return;
      pick(ev); const m = meshOf(part); if (!m || !proxy) return;
      proxy.matrixWorld.copy(m.matrixWorld); proxy.children.forEach(ch => ch.matrixWorld.copy(m.matrixWorld));   // the light copy sits exactly where the part is
      const h = ray.intersectObjects(proxy.children, false)[0]; if (!h) return;
      const nrm = h.face.normal.clone(); if (nrm.dot(ray.ray.direction.clone().transformDirection(new T.Matrix4().copy(m.matrixWorld).invert())) > 0) nrm.negate();
      const t = it(); t.point = m.worldToLocal(h.point.clone()).toArray(); t.normal = nrm.toArray(); t.dirty = true;
      // move the whole preview from where it was built to the new spot, instantly
      preview.matrix.copy(anchorMatrix(T, t)).multiply(new T.Matrix4().copy(preview.userData.base).invert());
      preview.matrixWorldNeedsUpdate = true;
    });
  });
  window.addEventListener('pointerup', () => {
    if (!drag) return; drag = false; c.controls.enabled = true; el.style.cursor = '';
    renderChips(); rebuild().catch(() => {}).finally(() => applySoon(300));
  });
}

// ------------------------------------------------------------------ start
(function boot() {
  if (!X() || !$('tt')) { setTimeout(boot, 200); return; }
  wire(); hookDrag();
  window.texttool = { open, addNew, items: () => items, rebuild, apply };
  // leaving the text section, another part, or another step: drop the unsaved preview
  setInterval(() => {
    const c = X(); if (!c) return;
    const sec = $('textCard'), openSec = sec && sec.classList.contains('open') && c.step() === 1;
    if (!openSec && preview) clearPreview();
    if (openSec && c.selected() !== part && !applying && !drag && Date.now() - lastApplied > 1500) open();
  }, 400);
})();
