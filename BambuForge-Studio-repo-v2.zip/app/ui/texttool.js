// BambuForge Studio: the text tool. Live preview on the part, drag to place, several texts per part, each editable later.
const $ = id => document.getElementById(id);
const X = () => window.studio && window.studio.ctx;
const DEF = { size: 10, spacing: 0, rot: 0, th: 1.2, emb: 0.4, arc: 90, waveH: 2, waveL: 20 };
const MINLEFT = 2.0;
const UNITS = { mm: [1, 200, 0.1, 1, 1], in: [0.04, 7.87, 0.01, 1 / 25.4, 2], pt: [3, 567, 1, 2.835, 0] };   // min,max,step (in that unit), mm->unit, decimals
const COMMON = ['#111111', '#FFFFFF', '#C12E1F', '#F4EE2A', '#FF6A13', '#00AE42', '#0086D6', '#0A2989', '#5E43B7', '#F077E8', '#9D432C', '#8E9089', '#E4BD68'];
let fontsInfo = null, fontTab = 'mine', part = -1, items = [], cur = -1, preview = null, drag = null, thick = {}, layoutCache = {}, rebuildT = null, busyApply = false;

const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const it = () => items[cur];
function stat(m, bad) { const c = X(); if (c) c.status(m, bad); }

// ------------------------------------------------------------------ open / list / add / remove
async function open() {
  const c = X(); if (!c || !c.state()) return;
  part = c.selected();
  if (part < 0) { $('ttNone').innerHTML = 'Click a part first, then press <b>+ Add text</b>.'; $('ttNone').classList.remove('hidden'); $('ttEd').classList.add('hidden'); renderChips(); clearPreview(); return; }
  if (!fontsInfo) fontsInfo = await c.api().fonts_list();
  const got = await c.api().part_texts(part);
  items = (got || []).map(x => ({ ...DEF, unit: 'mm', allow: false, ...x, saved: true }));
  cur = items.length ? items.length - 1 : -1;
  if (!items.length) addNew(); else { renderAll(); }
}
function defaultFont() {
  const f = (fontsInfo && fontsInfo.families) || [];
  for (const want of ['Arial Black', 'Arial', 'Segoe UI', 'DejaVu Sans', 'Liberation Sans']) if (f.includes(want)) return want;
  return f[0] || 'Arial';
}
function anchorGuess() {
  // where the camera looks at the part; else the middle of its top
  const c = X(), m = meshOf(part); if (!m) return null;
  const ray = new c.THREE.Raycaster(); ray.setFromCamera(new c.THREE.Vector2(0, 0), c.camera);
  let h = ray.intersectObject(m, false)[0];
  if (!h) { const b = new c.THREE.Box3().setFromObject(m), ctr = b.getCenter(new c.THREE.Vector3()); ray.set(new c.THREE.Vector3(ctr.x, ctr.y, b.max.z + 50), new c.THREE.Vector3(0, 0, -1)); h = ray.intersectObject(m, false)[0]; }
  if (!h) return null;
  return { point: m.worldToLocal(h.point.clone()).toArray(), normal: h.face.normal.clone().toArray() };
}
function addNew() {
  const a = anchorGuess(); if (!a) { stat("Couldn't find a spot on that part. Turn the view so the part is in the middle.", true); return; }
  const slots = X().state().filaments.slots, used = slots.find(s => s.used) || slots[0];
  const other = slots.find(s => s.slot !== (used && used.slot)) || used;
  items.push({ ...DEF, text: 'TEXT', font: defaultFont(), bold: false, italic: false, under: false, style: 'raise', path: 'straight', unit: 'mm', slot: other ? other.slot : 1, allow: false, ...a, saved: false, dirty: true });
  cur = items.length - 1; renderAll(); setTimeout(() => { $('ttText').focus(); $('ttText').select(); }, 30);
}
function renderChips() {
  $('ttChips').innerHTML = items.map((t, i) => `<div class="ttchip ${i === cur ? 'on' : ''}" data-i="${i}" title="${esc(t.text)}"><span>${esc(t.text || '(empty)')}${t.dirty ? ' •' : ''}</span><b data-x="${i}" title="Remove this text">✕</b></div>`).join('') +
    (part >= 0 ? `<div class="ttchip" id="ttAddNew" style="color:var(--green2)">+ Add text</div>` : '');
  $('ttChips').querySelectorAll('[data-i]').forEach(ch => ch.onclick = e => {
    if (e.target.dataset.x !== undefined) { removeItem(+e.target.dataset.x); return; }
    cur = +ch.dataset.i; renderAll();
  });
  const a = $('ttAddNew'); if (a) a.onclick = addNew;
}
async function removeItem(i) {
  const t = items[i];
  items.splice(i, 1); cur = Math.min(cur, items.length - 1);
  if (t.saved) { await apply(`Removed text "${t.text}"`); return; }
  renderAll();
}

// ------------------------------------------------------------------ panel
function toU(mm) { const u = UNITS[it().unit]; return +(mm * u[3]).toFixed(u[4]); }
function fromU(v) { return v / UNITS[it().unit][3]; }
const SL = [ // slider id, key, unit-converted?
  ['ttSize', 'size', true], ['ttSp', 'spacing'], ['ttRot', 'rot'], ['ttTh', 'th'], ['ttEmb', 'emb'], ['ttArc', 'arc'], ['ttWH', 'waveH'], ['ttWL', 'waveL']];
function bindSliders() {
  SL.forEach(([id, key, conv]) => {
    const r = $(id), n = $(id + 'N');
    r.oninput = () => { it()[key] = conv ? fromU(+r.value) : +r.value; n.value = r.value; changed(); };
    n.onchange = () => { let v = parseFloat(n.value); if (!isFinite(v)) { showVals(); return; } v = Math.min(+r.max, Math.max(+r.min, v)); it()[key] = conv ? fromU(v) : v; showVals(); changed(); };
    n.onkeydown = e => { if (e.key === 'Enter') n.blur(); };
  });
  document.querySelectorAll('#tt .trs').forEach(b => b.onclick = () => { it()[b.dataset.r] = DEF[b.dataset.r]; showVals(); changed(); });
}
function showVals() {
  const t = it(); if (!t) return;
  const u = UNITS[t.unit]; $('ttSize').min = u[0]; $('ttSize').max = u[1]; $('ttSize').step = u[2];
  SL.forEach(([id, key, conv]) => {
    const v = conv ? toU(t[key]) : t[key]; $(id).value = v;
    if (document.activeElement !== $(id + 'N')) $(id + 'N').value = (key === 'rot' || key === 'arc') ? Math.round(v) : (conv ? v : (+v).toFixed(1));
  });
}
function renderAll() {
  renderChips();
  const t = it();
  $('ttNone').classList.toggle('hidden', !!t); $('ttEd').classList.toggle('hidden', !t);
  if (!t) { clearPreview(); return; }
  $('ttText').value = t.text; $('ttFontName').textContent = t.font; $('ttFontName').style.fontFamily = `'${t.font}'`; $('ttUnit').value = t.unit;
  $('ttB').classList.toggle('on', !!t.bold); $('ttI').classList.toggle('on', !!t.italic); $('ttU').classList.toggle('on', !!t.under);
  document.querySelectorAll('#ttStyle span').forEach(s => s.classList.toggle('on', s.dataset.v === t.style));
  document.querySelectorAll('#ttPath span').forEach(s => s.classList.toggle('on', s.dataset.v === t.path));
  $('ttThL').textContent = t.style === 'cut' ? 'Depth' : 'Thickness';
  $('ttThRow').classList.toggle('hidden', t.style === 'through');
  $('ttEmbRow').classList.toggle('hidden', t.style !== 'flat');
  $('ttArcRow').classList.toggle('hidden', t.path !== 'arc');
  ['ttWHRow', 'ttWLRow'].forEach(r => $(r).classList.toggle('hidden', t.path !== 'wave'));
  const slot = X().state().filaments.slots.find(s => s.slot === t.slot);
  $('ttColSw').style.background = slot ? slot.color : '#888'; $('ttColName').textContent = slot ? `${slot.slot} · ${slot.name}` : `Colour ${t.slot}`;
  $('ttNote').textContent = {
    raise: 'Solid letters standing up from the surface.', cut: 'Letters cut into the part.', through: 'Letters cut all the way through, like a stencil.',
    flat: 'Flat tiles; "Sinks in" pushes them into the part so no corner floats.'
  }[t.style] + (t.style === 'cut' || t.style === 'through' ? ' The preview shows where; the real cut appears when you press Add to model.' : '');
  $('ttApply').textContent = items.some(x => x.saved) ? 'Apply to model' : 'Add to model';
  showVals(); rebuild();
}
function changed() { const t = it(); if (!t) return; t.dirty = true; renderChips(); renderAllLight(); rebuildSoon(); }
function renderAllLight() {
  const t = it(); $('ttThL').textContent = t.style === 'cut' ? 'Depth' : 'Thickness';
}
function wire() {
  bindSliders();
  $('ttText').oninput = () => { it().text = $('ttText').value; changed(); };
  $('ttUnit').onchange = () => { it().unit = $('ttUnit').value; showVals(); };
  [['ttB', 'bold'], ['ttI', 'italic'], ['ttU', 'under']].forEach(([id, k]) => $(id).onclick = () => { it()[k] = !it()[k]; $(id).classList.toggle('on', it()[k]); changed(); });
  document.querySelectorAll('#ttStyle span').forEach(s => s.onclick = () => { it().style = s.dataset.v; it().dirty = true; renderAll(); });
  document.querySelectorAll('#ttPath span').forEach(s => s.onclick = () => { it().path = s.dataset.v; it().dirty = true; renderAll(); });
  $('ttAllow').onchange = () => { it().allow = $('ttAllow').checked; checkDepth(); };
  $('ttApply').onclick = () => apply();
  $('ttCancel').onclick = async () => { clearPreview(); await open(); stat('Text changes cancelled.'); };
  // fonts
  $('ttFontBtn').onclick = e => { e.stopPropagation(); $('ttColPop').classList.add('hidden'); $('ttFontPop').classList.toggle('hidden'); $('ttFontQ').value = ''; fontList(); $('ttFontQ').focus(); };
  $('ttFontQ').oninput = fontList;
  document.querySelectorAll('#ttFontPop .tttabs span').forEach(t => t.onclick = () => { fontTab = t.dataset.t; document.querySelectorAll('#ttFontPop .tttabs span').forEach(x => x.classList.toggle('on', x === t)); fontList(); });
  $('ttFontAdd').onclick = async () => { const d = await X().api().font_add_dialog(); if (!d) return; if (d.error) { stat(d.error, true); return; } fontsInfo = d; if (d.added) { it().font = d.added; changed(); renderAll(); stat(`Added the font "${d.added}".`); } fontList(); };
  // colour
  $('ttColBtn').onclick = e => { e.stopPropagation(); $('ttFontPop').classList.add('hidden'); $('ttColPop').classList.toggle('hidden'); tiles(); };
  document.querySelectorAll('.ttpop').forEach(p => p.addEventListener('click', e => e.stopPropagation()));
  document.addEventListener('click', () => document.querySelectorAll('.ttpop').forEach(p => p.classList.add('hidden')));
  wheel();
  $('ttHex').onchange = () => { const v = $('ttHex').value.trim(); if (/^#?[0-9a-f]{6}$/i.test(v)) useColour('#' + v.replace('#', '').toUpperCase()); };
}
function fontList() {
  const q = $('ttFontQ').value.toLowerCase(), box = $('ttFontList');
  if (fontTab === 'mine') {
    const fams = ((fontsInfo && fontsInfo.families) || []).filter(f => f.toLowerCase().includes(q)).slice(0, 400);
    box.innerHTML = fams.map(f => `<div class="ttfi ${it() && f === it().font ? 'on' : ''}" data-f="${esc(f)}"><span style="font-family:'${esc(f)}'">${esc(f)}</span></div>`).join('') || '<div class="dim small" style="padding:6px">No font matches.</div>';
    box.querySelectorAll('[data-f]').forEach(d => d.onclick = () => { it().font = d.dataset.f; $('ttFontPop').classList.add('hidden'); changed(); renderAll(); });
  } else {
    const fr = ((fontsInfo && fontsInfo.free) || []).filter(f => f.name.toLowerCase().includes(q));
    box.innerHTML = fr.map(f => `<div class="ttfi" data-g="${esc(f.name)}"><span>${esc(f.name)}</span><button ${f.installed ? 'disabled' : ''}>${f.installed ? 'Installed' : 'Get'}</button></div>`).join('') +
      '<div class="dim small" style="padding:6px">Free fonts from Google Fonts (free to use and print).</div>';
    box.querySelectorAll('[data-g]').forEach(d => {
      d.onclick = () => { const f = fr.find(x => x.name === d.dataset.g); if (f && f.installed) { it().font = f.name; $('ttFontPop').classList.add('hidden'); changed(); renderAll(); } };
      const b = d.querySelector('button'); b.onclick = async e => {
        e.stopPropagation(); if (b.disabled) return; b.textContent = '…'; b.disabled = true;
        const r = await X().api().font_download(d.dataset.g); if (r.error) { stat(r.error, true); b.textContent = 'Get'; b.disabled = false; return; }
        fontsInfo = r; it().font = d.dataset.g; changed(); renderAll(); fontList(); stat(`Downloaded ${d.dataset.g} and added it to your fonts.`);
      };
    });
  }
}
function tiles() {
  const slots = X().state().filaments.slots, t = it();
  $('ttTilesF').innerHTML = slots.map(s => `<div class="tttile ${s.slot === t.slot ? 'on' : ''}" title="${s.slot} · ${esc(s.name)}" style="background:${s.color}" data-s="${s.slot}"></div>`).join('');
  $('ttTilesC').innerHTML = COMMON.map(c => `<div class="tttile" title="${c}" style="background:${c}" data-c="${c}"></div>`).join('');
  $('ttTilesF').querySelectorAll('[data-s]').forEach(d => d.onclick = () => { t.slot = +d.dataset.s; changed(); renderAll(); tiles(); });
  $('ttTilesC').querySelectorAll('[data-c]').forEach(d => d.onclick = () => useColour(d.dataset.c));
  const s = slots.find(x => x.slot === t.slot); if (s && document.activeElement !== $('ttHex')) $('ttHex').value = s.color;
}
async function useColour(hex) {
  // an existing colour slot with that colour, or a new slot (same filament as colour 1)
  const c = X(), slots = c.state().filaments.slots, same = slots.find(s => s.color.toUpperCase() === hex.toUpperCase());
  if (same) { it().slot = same.slot; changed(); renderAll(); tiles(); return; }
  const n = slots.length + 1; if (n > 16) { stat('16 colours is the most a project can have.', true); return; }
  const base = slots[0];
  const d = await c.api().set_slot(n, base.preset, hex, base.type, null, 'single', null);
  if (d.error) { stat(d.error, true); return; }
  c.state().filaments = d.filaments; c.pushUndo(`Add colour ${n}`);
  it().slot = n; changed(); renderAll(); tiles(); stat(`Added colour ${n} (${hex}) for the text.`);
}
function wheel() {
  const cv = $('ttWheel'), x = cv.getContext('2d'), W = cv.width, R = W / 2, img = x.createImageData(W, W);
  for (let y = 0; y < W; y++) for (let i = 0; i < W; i++) {
    const dx = i - R, dy = y - R, d = Math.hypot(dx, dy), o = (y * W + i) * 4; if (d > R) continue;
    const h = (Math.atan2(dx, -dy) * 180 / Math.PI + 360) % 360, s = d / R, f = n => { const k = (n + h / 60) % 6; return 1 - s * Math.max(0, Math.min(k, 4 - k, 1)); };
    img.data[o] = f(5) * 255; img.data[o + 1] = f(3) * 255; img.data[o + 2] = f(1) * 255; img.data[o + 3] = 255;
  }
  x.putImageData(img, 0, 0);
  cv.onclick = e => { const r = cv.getBoundingClientRect(), p = x.getImageData(Math.min(W - 1, (e.clientX - r.left) * W / r.width), Math.min(W - 1, (e.clientY - r.top) * W / r.height), 1, 1).data; if (p[3]) useColour('#' + [p[0], p[1], p[2]].map(v => v.toString(16).padStart(2, '0')).join('').toUpperCase()); };
}

// ------------------------------------------------------------------ preview on the part
function meshOf(i) { const c = X(); return c && c.meshes().find(m => m.userData.id === i); }
function clearPreview() { if (preview && preview.parent) preview.parent.remove(preview); preview = null; }
function rebuildSoon() { clearTimeout(rebuildT); rebuildT = setTimeout(rebuild, 120); }
async function layout(t) {
  const key = [t.text, t.font, t.size.toFixed(2), !!t.bold, !!t.italic, !!t.under, (+t.spacing).toFixed(2)].join('|');
  if (!layoutCache[key]) layoutCache[key] = await X().api().text_layout({ text: t.text, font: t.font, size: t.size, bold: t.bold, italic: t.italic, under: t.under, spacing: t.spacing });
  return layoutCache[key];
}
function shapesOf(contours) {
  const T = X().THREE, sp = new T.ShapePath();
  let big = 0, sign = 1;
  contours.forEach(c => { let a = 0; for (let i = 0; i < c.length; i++) { const p = c[i], q = c[(i + 1) % c.length]; a += p[0] * q[1] - q[0] * p[1]; } if (Math.abs(a) > big) { big = Math.abs(a); sign = Math.sign(a); } });
  contours.forEach(c => { sp.moveTo(c[0][0], c[0][1]); for (let i = 1; i < c.length; i++) sp.lineTo(c[i][0], c[i][1]); });
  return sp.toShapes(sign > 0);
}
function frameOf(T, n, rot) {   // same as the back end's frame(): x along the text, y up the letters, z out of the surface
  n = n.clone().normalize();
  const up = Math.abs(n.z) < 0.9 ? new T.Vector3(0, 0, 1) : new T.Vector3(0, 1, 0);
  const x = new T.Vector3().crossVectors(up, n).normalize(), y = new T.Vector3().crossVectors(n, x), a = rot * Math.PI / 180;
  return { x: x.clone().multiplyScalar(Math.cos(a)).addScaledVector(y, Math.sin(a)), y: x.clone().multiplyScalar(-Math.sin(a)).addScaledVector(y, Math.cos(a)), n };
}
function surfaceHit(m, T, q, n, t) {  // the part's surface near q (all in the part's own coords), looking down, then leaning back over curved edges
  const ray = new T.Raycaster(), wq = new T.Vector3();
  for (const back of [0, 0.4, 0.8, 1.3, 2, 3.5]) {
    const o = q.clone().addScaledVector(n, 3).addScaledVector(t, back * 3), d = n.clone().negate().addScaledVector(t, -back).normalize();
    ray.set(m.localToWorld(o.clone()), d.clone().transformDirection(m.matrixWorld));
    const h = ray.intersectObject(m, false)[0];
    if (h && h.distance < 14) return { p: m.worldToLocal(h.point.clone()), n: h.face.normal.clone() };
  }
  return null;
}
function walkPath(m, T, p0, n0, x0, len) {
  const out = [{ s: 0, p: p0.clone(), n: n0.clone(), t: x0.clone() }];
  for (const sg of [1, -1]) {
    let p = p0.clone(), n = n0.clone(), t = x0.clone().multiplyScalar(sg);
    for (let s = 0.5; s <= len; s += 0.5) {
      const h = surfaceHit(m, T, p.clone().addScaledVector(t, 0.5), n, t); if (!h) break;
      t = h.p.clone().sub(p); t.addScaledVector(h.n, -t.dot(h.n)).normalize(); p = h.p; n = h.n;
      out.push({ s: sg * s, p: p.clone(), n: n.clone(), t: t.clone().multiplyScalar(sg) });
    }
  }
  return out;
}
const nearest = (path, s) => path.reduce((b, q) => Math.abs(q.s - s) < Math.abs(b.s - s) ? q : b, path[0]);
function thicknessAt(m, T, p, n) {   // how much part is under a point, straight in along -n
  const ray = new T.Raycaster(), side = m.material.side; m.material.side = T.DoubleSide;
  ray.set(m.localToWorld(p.clone().addScaledVector(n, -0.02)), n.clone().negate().transformDirection(m.matrixWorld));
  const h = ray.intersectObject(m, false)[0]; m.material.side = side;
  return h ? h.distance + 0.02 : Infinity;
}
async function rebuild() {
  const c = X(); if (!c) return; const T = c.THREE;
  clearPreview();
  const m = meshOf(part); if (!m) return;
  const g = new T.Group(); g.userData.textPreview = true;
  for (let idx = 0; idx < items.length; idx++) {
    const t = items[idx]; if (!t.dirty && t.saved) continue;
    const L = await layout(t); if (!L || L.error || !L.glyphs) continue;
    const p0 = new T.Vector3().fromArray(t.point), n0 = new T.Vector3().fromArray(t.normal).normalize(), F = frameOf(T, n0, t.rot);
    const total = L.width || 1, A = t.arc * Math.PI / 180, Rr = Math.abs(A) > 1e-3 ? total / Math.abs(A) : 1e9;
    const path = t.path === 'wrap' ? walkPath(m, T, p0, n0, F.x, total / 2 + t.size * 2) : null;
    const slot = c.state().filaments.slots.find(s => s.slot === t.slot);
    const hole = t.style === 'cut' || t.style === 'through';
    const mat = new T.MeshStandardMaterial({ color: hole ? 0x2a1630 : (slot ? slot.color : '#ffffff'), roughness: 0.6, transparent: hole, opacity: hole ? 0.9 : 1, emissive: idx === cur ? 0x0a2a14 : 0x000000 });
    const z = { raise: [0, t.th], flat: [-t.emb, t.th - t.emb], cut: [-Math.min(t.th, 0.3), 0.06], through: [-0.3, 0.06] }[t.style];
    let tmin = Infinity;
    const pieces = L.glyphs.map(gl => [gl.x, gl.contours]); if (L.underline) pieces.push([0, [L.underline]]);
    for (const [cx, contours] of pieces) {
      const shapes = shapesOf(contours); if (!shapes.length) continue;
      const geo = new T.ExtrudeGeometry(shapes, { depth: Math.max(0.05, z[1] - z[0]), bevelEnabled: false, curveSegments: 2 }); geo.translate(0, 0, z[0]);
      let o, n, lx, ang = 0;
      if (path) { const P = nearest(path, cx); o = P.p; n = P.n; lx = P.t.clone(); }
      else {
        let along = cx, off = 0;
        if (t.path === 'arc' && Math.abs(A) > 1e-3) { const tt = cx / Rr; along = Rr * Math.sin(tt); off = Math.sign(A) * (Rr - Rr * Math.cos(tt)); ang = Math.sign(A) * tt; }
        if (t.path === 'wave') { const H = t.waveH, Lw = Math.max(1, t.waveL); off = H * Math.sin(cx / Lw * 2 * Math.PI); ang = Math.atan(H * 2 * Math.PI / Lw * Math.cos(cx / Lw * 2 * Math.PI)) * 0.6; }
        o = p0.clone().addScaledVector(F.x, along).addScaledVector(F.y, off); n = n0.clone(); lx = F.x.clone();
      }
      lx.addScaledVector(n, -lx.dot(n)).normalize(); const ly = new T.Vector3().crossVectors(n, lx);
      const bx = lx.clone().multiplyScalar(Math.cos(ang)).addScaledVector(ly, Math.sin(ang)), by = new T.Vector3().crossVectors(n, bx);
      geo.applyMatrix4(new T.Matrix4().makeBasis(bx, by, n).setPosition(o));
      const me = new T.Mesh(geo, mat); me.userData.textItem = idx; g.add(me);
      if (t.style === 'cut') tmin = Math.min(tmin, thicknessAt(m, T, o, n));
    }
    thick[idx] = tmin;
  }
  m.add(g); preview = g;
  checkDepth();
}
function checkDepth() {
  const t = it(); if (!t) return;
  const tmin = thick[cur], isCut = t.style === 'cut' && isFinite(tmin);
  if (isCut) { const cap = Math.max(0.2, Math.floor(tmin * 10) / 10); $('ttTh').max = cap; if (t.th > cap) { t.th = cap; showVals(); } $('ttMax').textContent = `deepest possible here: ${cap.toFixed(1)} mm (the part is ${tmin.toFixed(1)} mm thick)`; }
  else { $('ttTh').max = 200; $('ttMax').textContent = ''; }
  const left = isCut ? tmin - t.th : Infinity, thin = left < MINLEFT;
  $('ttWarn').classList.toggle('hidden', !thin);
  if (thin) {
    $('ttWarnT').innerHTML = `⚠ Only <b>${Math.max(0, left).toFixed(1)} mm</b> would be left under the letters (keep at least ${MINLEFT} mm). It may crack, or show through on the other side.` +
      (tmin > MINLEFT + 0.2 ? ` A depth of <b>${(tmin - MINLEFT).toFixed(1)} mm</b> or less is safe.` : ` The part is only ${tmin.toFixed(1)} mm thick here, so any cut is risky: try <b>Raised</b>, or <b>Cut out</b>.`);
    $('ttAllow').checked = !!t.allow;
  }
  const blocked = items.some((x, i) => x.dirty && x.style === 'cut' && isFinite(thick[i]) && thick[i] - x.th < MINLEFT && !x.allow);
  $('ttApply').disabled = blocked || busyApply; $('ttApply').title = blocked ? 'Fix the warning, or switch on "Allow it anyway"' : '';
}
async function apply(label) {
  const c = X(); if (part < 0) return;
  busyApply = true; checkDepth();
  const send = items.map(t => ({ text: t.text, font: t.font, bold: !!t.bold, italic: !!t.italic, under: !!t.under, size: t.size, spacing: t.spacing, rot: t.rot,
    style: t.style, th: t.th, emb: t.emb, path: t.path, arc: t.arc, waveH: t.waveH, waveL: t.waveL, slot: t.slot, point: t.point, normal: t.normal, allow: !!t.allow }));
  const d = await c.longJob('Adding the text…', () => c.api().text_set(part, send));
  busyApply = false;
  if (!d || d.error) { stat((d && d.error) || "Couldn't add the text.", true); checkDepth(); return; }
  clearPreview(); const keep = part, keepCur = cur;
  await c.show(d); c.pushUndo(label || (items.length ? `Text on the part` : 'Removed the text'));
  c.select(keep, false);
  part = keep; const got = await c.api().part_texts(part);
  items = (got || []).map(x => ({ ...DEF, unit: 'mm', allow: false, ...x, saved: true })); cur = Math.min(keepCur, items.length - 1);
  renderAll(); stat((label || 'Text added') + '. Click a text chip to edit it; Ctrl+Z undoes it.');
}

// ------------------------------------------------------------------ dragging the preview over the part
function hookDrag() {
  const c = X(), T = c.THREE, el = c.renderer.domElement, ray = new T.Raycaster(), ndc = new T.Vector2();
  const pick = e => { const r = el.getBoundingClientRect(); ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1); ray.setFromCamera(ndc, c.camera); };
  el.addEventListener('pointerdown', e => {
    if (!preview || e.button !== 0) return; pick(e);
    const h = ray.intersectObjects(preview.children, false)[0]; if (!h) return;
    cur = h.object.userData.textItem; drag = true; c.controls.enabled = false; e.stopPropagation(); renderAll();
  }, true);
  window.addEventListener('pointermove', e => {
    if (!preview) return; pick(e);
    if (!drag) { el.style.cursor = ray.intersectObjects(preview.children, false).length ? 'grab' : ''; return; }
    const m = meshOf(part); if (!m) return;
    const h = ray.intersectObject(m, false)[0]; if (!h) return;
    const t = it(); t.point = m.worldToLocal(h.point.clone()).toArray(); t.normal = h.face.normal.toArray(); t.dirty = true;
    rebuildSoon();
  });
  window.addEventListener('pointerup', () => { if (drag) { drag = false; c.controls.enabled = true; renderChips(); } });
}

// ------------------------------------------------------------------ start
(function boot() {
  if (!X() || !$('tt')) { setTimeout(boot, 200); return; }
  wire(); hookDrag();
  window.texttool = { open, addNew, items: () => items, rebuild, apply };
  // leaving the text section, another part, or another step: drop the unsaved preview
  setInterval(() => {
    const c = X(); if (!c) return;
    const sec = $('textCard'), openSec = sec && sec.classList.contains('open') && c.step() === 1;
    if (!openSec && preview) clearPreview();
    if (openSec && c.selected() !== part) open();
  }, 400);
})();
